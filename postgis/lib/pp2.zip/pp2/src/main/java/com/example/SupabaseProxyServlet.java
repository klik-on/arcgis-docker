package com.example;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.*;
import java.net.*;

@WebServlet("/api/*")
public class SupabaseProxyServlet extends HttpServlet {

    private static final String SUPABASE_API_BASE = "http://172.16.2.122:8000/rest/v1/";
    private static final String API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzUxMzAyODAwLCJleHAiOjE5MDkwNjkyMDB9.5B3KqroqKZUnXyjJg99AtjSjGci-wKqJtH7LWCz7x2U";

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String path = request.getPathInfo();
        String query = request.getQueryString();

        String fullUrl = SUPABASE_API_BASE +
                (path != null ? path.substring(1) : "") +
                (query != null ? "?" + query : "");

        HttpURLConnection conn = (HttpURLConnection) new URL(fullUrl).openConnection();
        conn.setRequestMethod(request.getMethod());
        conn.setRequestProperty("apikey", API_KEY);
        conn.setRequestProperty("Authorization", "Bearer " + API_KEY);

        if ("POST".equalsIgnoreCase(request.getMethod()) ||
            "PUT".equalsIgnoreCase(request.getMethod()) ||
            "PATCH".equalsIgnoreCase(request.getMethod())) {

            conn.setDoOutput(true);
            try (InputStream is = request.getInputStream();
                 OutputStream os = conn.getOutputStream()) {
                byte[] buffer = new byte[8192];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }
            }
        }

        int status = conn.getResponseCode();
        response.setStatus(status);

        String contentType = conn.getContentType();
        if (contentType != null) {
            response.setContentType(contentType);
        }

        try (InputStream is = (status >= 400 ? conn.getErrorStream() : conn.getInputStream());
             OutputStream os = response.getOutputStream()) {
            if (is != null) {
                byte[] buffer = new byte[8192];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }
            }
        }
    }
}
