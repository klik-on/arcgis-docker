import geopandas as gpd
from shapely.geometry import Point
import os

def test_filegdb_write():
    print("--- Memulai Tes FileGDB ---")
    
    # 1. Buat data dummy sederhana
    data = {
        'name': ['Titik A', 'Titik B'],
        'geometry': [Point(106.8, -6.2), Point(106.9, -6.3)]
    }
    gdf = gpd.GeoDataFrame(data, crs="EPSG:4326")
    
    filename = "test_output.gdb"
    layer_name = "test_layer"

    try:
        # 2. Cek apakah driver tersedia
        import pyogrio
        drivers = pyogrio.list_drivers()
        if 'FileGDB' in drivers:
            print("✅ Driver 'FileGDB' (ESRI SDK) ditemukan.")
        else:
            print("❌ Driver 'FileGDB' tidak ditemukan. GeoPandas mungkin menggunakan Wheel bawaan.")
            return

        # 3. Mencoba menulis ke FileGDB
        print(f"Sedang menulis ke {filename}...")
        gdf.to_file(filename, layer=layer_name, driver="FileGDB", engine="pyogrio")
        print(f"✅ Berhasil menulis {filename}")

        # 4. Mencoba membaca kembali untuk verifikasi
        df_read = gpd.read_file(filename, layer=layer_name, engine="pyogrio")
        print(f"✅ Berhasil membaca kembali. Jumlah baris: {len(df_read)}")
        
        # Bersihkan file hasil tes
        import shutil
        shutil.rmtree(filename)
        print("--- Tes Selesai dengan Sukses ---")

    except Exception as e:
        print(f"❌ Terjadi error: {e}")

if __name__ == "__main__":
    test_filegdb_write()
