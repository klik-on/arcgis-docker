for wilayah in "Jawa Timur" "Jawa Tengah" "Papua"; do
  ./api_to_gdb.sh WADMPR=eq."$wilayah"
done
