import os
import time
import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# --- 0. Memuat Koneksi dari .env ---
load_dotenv()

DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
# Mengambil OUT_SCHEMA dari .env, default ke 'analisis' jika tidak ada
OUT_SCHEMA = os.getenv("SCHEMA_OUT") or os.getenv("OUT_SCHEMA") or "analisis"

# --- 1. Konfigurasi Tabel & Kolom ---
TABLES = {
    "A": {"name": "PL_BALI_CLIP", "cols": ["PL2024_ID", "pl2023_id_r"]},
    "B": {"name": "KWS_BALI_CLIP", "cols": ["FUNGSIKWS"]},
    "C": {"name": "RKTN_BALI_CLIP", "cols": ["rktn2019"]}
}

OUT_TABLE = "PL_KWS_RKTN_BALI_PGIS"
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE}"'

# --- 2. Detail Koneksi ---
conn_string = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(conn_string)

def fast_full_union():
    start_time = time.time()
    
    # Menyiapkan string kolom untuk query SQL
    cols_a = ", ".join([f'a."{c}"' for c in TABLES['A']['cols']])
    cols_b = ", ".join([f'b."{c}"' for c in TABLES['B']['cols']])
    cols_c = ", ".join([f'c."{c}"' for c in TABLES['C']['cols']])
    
    # Kolom gabungan untuk grouping di akhir
    all_attr_cols = TABLES['A']['cols'] + TABLES['B']['cols'] + TABLES['C']['cols']

    try:
        with engine.begin() as conn:
            print(f"🚀 Memulai PostGIS Full Union (Fast Mode)...")
            print(f"💾 Menyimpan hasil ke {RESULT_TABLE_FULL}...")
            
            # Pastikan Schema ada
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))
            
            # Hapus tabel lama jika ada
            conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL};'))

            # QUERY UTAMA:
            # 1. Ambil semua boundary (garis luar) dari 3 tabel
            # 2. Satukan semua garis tersebut (ST_Union)
            # 3. Bentuk poligon baru dari potongan garis tersebut (ST_Polygonize)
            # 4. Join kembali dengan atribut asli menggunakan titik tengah (ST_PointOnSurface)
            query = text(f"""
                CREATE TABLE {RESULT_TABLE_FULL} AS
                WITH 
                all_boundaries AS (
                    SELECT ST_Boundary(geom) as geom FROM "{OUT_SCHEMA}"."{TABLES['A']['name']}"
                    UNION ALL
                    SELECT ST_Boundary(geom) as geom FROM "{OUT_SCHEMA}"."{TABLES['B']['name']}"
                    UNION ALL
                    SELECT ST_Boundary(geom) as geom FROM "{OUT_SCHEMA}"."{TABLES['C']['name']}"
                ),
                unified_lines AS (
                    SELECT ST_Union(geom) as geom FROM all_boundaries
                ),
                atomic_polygons AS (
                    SELECT (ST_Dump(ST_Polygonize(geom))).geom as geom
                    FROM unified_lines
                )
                SELECT 
                    {cols_a}, {cols_b}, {cols_c},
                    p.geom
                FROM atomic_polygons p
                LEFT JOIN "{OUT_SCHEMA}"."{TABLES['A']['name']}" a ON ST_Intersects(ST_PointOnSurface(p.geom), a.geom)
                LEFT JOIN "{OUT_SCHEMA}"."{TABLES['B']['name']}" b ON ST_Intersects(ST_PointOnSurface(p.geom), b.geom)
                LEFT JOIN "{OUT_SCHEMA}"."{TABLES['C']['name']}" c ON ST_Intersects(ST_PointOnSurface(p.geom), c.geom);
            """)

            print("✂️  Memproses Geometri (Atomic Slicing)...")
            conn.execute(query)

            print("📏 Menghitung Luas & Membuat Index...")
            # Kalkulasi Luas dalam Hektar (SRID 54034 = World Cylindrical Equal Area)
            conn.execute(text(f'ALTER TABLE {RESULT_TABLE_FULL} ADD COLUMN "LUAS_CEA_HA" DOUBLE PRECISION;'))
            conn.execute(text(f'UPDATE {RESULT_TABLE_FULL} SET "LUAS_CEA_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000;'))
            
            # Cleaning: Hapus poligon kosong atau poligon sliver yang sangat kecil
            conn.execute(text(f'DELETE FROM {RESULT_TABLE_FULL} WHERE geom IS NULL OR "LUAS_CEA_HA" < 0.0001;'))
            
            # Optimasi Database
            conn.execute(text(f'CREATE INDEX ON {RESULT_TABLE_FULL} USING GIST(geom);'))
            conn.execute(text(f'ANALYZE {RESULT_TABLE_FULL};'))

        # --- 3. Ringkasan Hasil (Pandas) ---
        group_cols_str = ", ".join([f'"{c}"' for c in all_attr_cols])
        query_summary = f"""
            SELECT {group_cols_str}, SUM("LUAS_CEA_HA") as total_ha 
            FROM {RESULT_TABLE_FULL} 
            GROUP BY {group_cols_str} 
            ORDER BY total_ha DESC 
            LIMIT 10;
        """
        summary_df = pd.read_sql(query_summary, engine)

        print("\n" + "="*75)
        print(f"📊 RINGKASAN TOP 10 (POSTGIS FAST FULL UNION)")
        print("="*75)
        if not summary_df.empty:
            print(summary_df.to_string(index=False))
        else:
            print("⚠️ Tidak ada data hasil union.")
        print("="*75)

        duration = time.time() - start_time
        print(f"\n✅ Selesai dalam {duration:.2f} detik!")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")

if __name__ == "__main__":
    fast_full_union()
