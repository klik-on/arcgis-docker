import os
import sys
import shutil
import zipfile
import logging
import time
import random
import pandas as pd
import geopandas as gpd
import requests
import urllib3
from datetime import datetime
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# Menonaktifkan peringatan SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- 1. KONFIGURASI & START TIME ---
start_proc = time.time()
start_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

load_dotenv()
# Menggunakan driver psycopg (v3)
DB_URL = f"postgresql+psycopg://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}"
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
TABLE_NAME = os.getenv("KUPS_TABLE", "KUPS")
API_URL = os.getenv("KUPS_API_URL")

FOLDER_PATH = "/app/data"
ZIP_PATH = os.path.join(FOLDER_PATH, f"{TABLE_NAME}.gdb.zip")
INVALID_LOG = os.path.join(FOLDER_PATH, "invalid_kups_records.txt")
PROCESS_LOG = os.path.join(FOLDER_PATH, "kups_process.log")

os.makedirs(FOLDER_PATH, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(), logging.FileHandler(PROCESS_LOG, encoding="utf-8")]
)

# ==========================================
# 2. FETCH DATA DENGAN SMART RETRY
# ==========================================
def get_all_api_data(url):
    all_data = []
    page = 1
    session = requests.Session()
    per_page = 100

    while True:
        try:
            full_url = f"{url}?page={page}&per_page={per_page}"
            res = session.get(full_url, verify=False, timeout=60)

            if res.status_code == 429:
                wait = random.uniform(15, 30)
                logging.warning(f"⚠️ Terkena Limit 429. Menunggu {wait:.1f} detik...")
                time.sleep(wait); continue

            res.raise_for_status()
            data = res.json()
            items = data.get("data", [])

            if not items: break
            all_data.extend(items)
            logging.info(f"📄 Halaman {page} sukses. Total data: {len(all_data)}")

            if not data.get("next_page_url"): break
            page += 1
            time.sleep(0.3)

        except Exception as e:
            logging.error(f"❌ Error permanen di halaman {page}: {e}")
            break
    return all_data

# ==========================================
# 3. PROSES & AUDIT SPASIAL
# ==========================================
logging.info("🚀 Memulai proses pengambilan data dari API...")
raw_json = get_all_api_data(API_URL)
if not raw_json: sys.exit("❌ Data API kosong.")

df_raw = pd.DataFrame(raw_json)
total_downloaded = len(df_raw)

name_col = next((c for c in ['nama_kups', 'nama', 'deskripsi'] if c in df_raw.columns), None)

df_raw['nujur'] = pd.to_numeric(df_raw['nujur'], errors='coerce')
df_raw['lintang'] = pd.to_numeric(df_raw['lintang'], errors='coerce')

df_no_coord = df_raw[df_raw['nujur'].isna() | df_raw['lintang'].isna()].copy()
df_valid_coord = df_raw.dropna(subset=['nujur', 'lintang']).copy()

# Inisialisasi GeoDataFrame
gdf = gpd.GeoDataFrame(
    df_valid_coord,
    geometry=gpd.points_from_xy(df_valid_coord['nujur'], df_valid_coord['lintang']),
    crs="EPSG:4326"
)

# Filter koordinat wilayah Indonesia
mask_ri = (gdf.geometry.x >= 95.0) & (gdf.geometry.x <= 141.0) & \
          (gdf.geometry.y >= -11.0) & (gdf.geometry.y <= 6.0)

gdf_final = gdf[mask_ri].copy()
gdf_outside = gdf[~mask_ri].copy()

# --- PERUBAHAN NAMA KOLOM GEOMETRY MENJADI 'geom' ---
gdf_final = gdf_final.rename_geometry('geom')

# Logging Invalid Data
with open(INVALID_LOG, "w", encoding="utf-8") as f:
    f.write(f"=== LAPORAN DATA ERROR KUPS ({datetime.now()}) ===\n")
    f.write(f"Total Download  : {total_downloaded}\n")
    f.write(f"Valid RI        : {len(gdf_final)}\n")
    f.write(f"Luar RI         : {len(gdf_outside)}\n")
    f.write(f"Tanpa Koordinat : {len(df_no_coord)}\n\n")
    
    log_cols = [c for c in ['id', name_col, 'nujur', 'lintang'] if c]
    if not df_no_coord.empty:
        f.write("--- DATA TANPA KOORDINAT ---\n")
        f.write(df_no_coord[[c for c in log_cols if c in df_no_coord.columns]].to_string(index=False) + "\n\n")
    if not gdf_outside.empty:
        f.write("--- DATA DI LUAR WILAYAH RI ---\n")
        f.write(gdf_outside[[c for c in log_cols if c in gdf_outside.columns]].to_string(index=False) + "\n")

# ==========================================
# 4. EXPORT & FINALISASI
# ==========================================
if not gdf_final.empty:
    # Standarisasi kolom menjadi UPPERCASE kecuali geom
    gdf_final.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf_final.columns]
    gdf_final = gdf_final.drop(columns=['NUJUR', 'LINTANG'], errors='ignore')

    engine = create_engine(DB_URL)
    try:
        # 4a. Simpan ke PostGIS
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
        
        logging.info(f"🐘 Menyimpan ke PostGIS: {SCHEMA}.{TABLE_NAME} (geom_col='geom')...")
        # if_exists='replace' akan membuat ulang tabel dengan kolom 'geom'
        gdf_final.to_postgis(name=TABLE_NAME, con=engine, schema=SCHEMA, if_exists='replace', index=False)

        # 4b. Buat Spatial Index (GIST) pada kolom 'geom'
        with engine.begin() as conn:
            idx_name = f"idx_{TABLE_NAME.lower()}_geom"
            logging.info(f"⚡ Membuat Spatial Index: {idx_name}...")
            conn.execute(text(f'CREATE INDEX IF NOT EXISTS "{idx_name}" ON "{SCHEMA}"."{TABLE_NAME}" USING GIST (geom);'))

        # 4c. Jalankan VACUUM ANALYZE (Di luar transaksi)
        try:
            with engine.connect() as conn:
                conn.execution_options(isolation_level="AUTOCOMMIT")
                logging.info(f"✨ Mengoptimalkan statistik tabel (VACUUM ANALYZE)...")
                conn.execute(text(f'VACUUM ANALYZE "{SCHEMA}"."{TABLE_NAME}";'))
        except Exception as vac_err:
            logging.warning(f"⚠️ Gagal menjalankan VACUUM (non-kritikal): {vac_err}")

        # 4d. FileGDB & ZIP
        gdb_temp = os.path.join(FOLDER_PATH, f"{TABLE_NAME}_TEMP.gdb")
        if os.path.exists(gdb_temp): shutil.rmtree(gdb_temp)
        
        logging.info(f"📦 Menulis FileGDB ke ZIP (Engine: pyogrio)...")
        # Pyogrio mendukung penulisan GDB dengan write support yang sudah Anda instal
        gdf_final.to_file(gdb_temp, driver="OpenFileGDB", layer=TABLE_NAME, engine='pyogrio')

        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, dirs, files in os.walk(gdb_temp):
                for file in files:
                    z.write(os.path.join(root, file), os.path.join(f"{TABLE_NAME}.gdb", file))
        shutil.rmtree(gdb_temp)
        
    except Exception as e:
        logging.error(f"❌ Fatal Error saat Export: {e}")

# --- 5. RINGKASAN AKHIR ---
end_proc = time.time()
duration = end_proc - start_proc
minutes, seconds = divmod(duration, 60)

print(f"\n" + "—"*45)
print(f"🏁 PROSES SELESAI!")
print(f"—"*45)
print(f"🕒 Mulai    : {start_time_str}")
print(f"🕒 Selesai  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print(f"⚡ Durasi   : {int(minutes)} menit {int(seconds)} detik")
print(f"—"*45)
print(f"✅ Valid RI    : {len(gdf_final)}")
print(f"❌ Luar RI     : {len(gdf_outside)}")
print(f"🚫 Tanpa Koord : {len(df_no_coord)}")
print(f"📂 Lokasi ZIP  : {ZIP_PATH}")
print(f"—"*45 + "\n")
