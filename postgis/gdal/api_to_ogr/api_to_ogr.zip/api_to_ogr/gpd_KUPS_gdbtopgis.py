import os
import sys
import shutil
import zipfile
import pandas as pd
import geopandas as gpd
import requests
import urllib3
import logging
import time
import random
import pyogrio
from datetime import datetime
from shapely.geometry import Point
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# --- 0. KONFIGURASI WARNA KONSOL ---
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

# --- 1. LOAD KONFIGURASI .ENV ---
load_dotenv()

DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
TABLE_NAME = os.getenv("KUPS_TABLE", "KUPS")
API_URL = os.getenv("KUPS_API_URL")

FOLDER_PATH = "/app/data"
GDB_PATH = os.path.join(FOLDER_PATH, "KUPS.gdb")
ZIP_PATH = os.path.join(FOLDER_PATH, "KUPS.gdb.zip")
LOG_PATH = os.path.join(FOLDER_PATH, "log_kups.log")
INVALID_LIST_PATH = os.path.join(FOLDER_PATH, "invalid_kups.txt")

os.makedirs(FOLDER_PATH, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(), logging.FileHandler(LOG_PATH, encoding="utf-8")]
)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==============================
# 2. FUNGSI FETCH DENGAN RETRY
# ==============================
PER_PAGE = 100
MAX_RETRIES = 10
session = requests.Session()
session.headers.update({'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json'})

def fetch_with_retry(url, current_page):
    for attempt in range(MAX_RETRIES):
        try:
            full_url = f"{url}?page={current_page}&per_page={PER_PAGE}"
            response = session.get(full_url, verify=False, timeout=60)
            if response.status_code in [429, 500, 502, 503, 504]:
                wait = min(300, (5 * (2 ** attempt)) + random.uniform(0, 1))
                logging.warning(f"⚠️ Retry {attempt+1}/{MAX_RETRIES} dlm {wait:.1f}s...")
                time.sleep(wait); continue
            response.raise_for_status()
            return response.json()
        except Exception as e:
            wait = min(300, (5 * (2 ** attempt)) + random.uniform(0, 1))
            logging.error(f"❌ Error: {e}. Retry dlm {wait:.1f}s...")
            time.sleep(wait)
    return None

# ==============================
# 3. AMBIL DATA DARI API
# ==============================
all_data = []
page = 1
logging.info(f"{Colors.BOLD}{Colors.BLUE}🚀 Memulai penarikan data dari API...{Colors.ENDC}")

while True:
    res_json = fetch_with_retry(API_URL, page)
    if not res_json: break
    kups_list = res_json.get("data", [])
    if not kups_list: break
    all_data.extend(kups_list)
    logging.info(f"📄 Halaman {page} sukses. Total data: {len(all_data)}")
    if not res_json.get("next_page_url"): break
    page += 1
    time.sleep(0.2)

# ==============================
# 4. PROSES & AUDIT (KONSOL RINCI)
# ==============================
if not all_data:
    logging.error(f"{Colors.FAIL}❌ Tidak ada data yang ditarik.{Colors.ENDC}"); sys.exit(1)

try:
    df = pd.DataFrame(all_data)
    total_raw = len(df)
    df['nujur'] = pd.to_numeric(df['nujur'], errors='coerce')
    df['lintang'] = pd.to_numeric(df['lintang'], errors='coerce')

    df_no_coord = df[df['nujur'].isna() | df['lintang'].isna()].copy()
    df_clean = df.dropna(subset=['nujur', 'lintang']).copy()

    geometry = [Point(xy) for xy in zip(df_clean['nujur'], df_clean['lintang'])]
    gdf = gpd.GeoDataFrame(df_clean, geometry=geometry, crs="EPSG:4326")

    mask_indonesia = (gdf.geometry.x >= 95.0) & (gdf.geometry.x <= 141.0) & \
                     (gdf.geometry.y >= -11.0) & (gdf.geometry.y <= 6.0)

    gdf_valid = gdf[mask_indonesia].copy()
    gdf_outside = gdf[~mask_indonesia].copy()

    # --- OUTPUT KONSOL BERWARNA ---
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.ENDC}")
    print(f"{Colors.BOLD}📊 RINGKASAN AUDIT DATA KUPS{Colors.ENDC}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.ENDC}")
    print(f"Total Download API    : {Colors.BOLD}{total_raw}{Colors.ENDC}")
    print(f"Data Valid (Dalam RI) : {Colors.GREEN}{len(gdf_valid)}{Colors.ENDC}")
    print(f"Data Luar RI          : {Colors.FAIL}{len(gdf_outside)}{Colors.ENDC}")
    print(f"Data Tanpa Koordinat  : {Colors.FAIL}{len(df_no_coord)}{Colors.ENDC}")
    print(f"{Colors.BLUE}{'-'*60}{Colors.ENDC}")

    if not gdf_outside.empty:
        print(f"{Colors.WARNING}{Colors.BOLD}⚠️ DETAIL DATA DI LUAR INDONESIA:{Colors.ENDC}")
        cols = [c for c in ['id', 'nama_kups', 'nujur', 'lintang'] if c in gdf_outside.columns]
        print(f"{Colors.FAIL}{gdf_outside[cols].head(15).to_string(index=False)}{Colors.ENDC}")
        if len(gdf_outside) > 15: print(f"... ({len(gdf_outside)-15} data lainnya)")

    if not df_no_coord.empty:
        print(f"\n{Colors.WARNING}{Colors.BOLD}🚫 DETAIL DATA KOORDINAT KOSONG:{Colors.ENDC}")
        cols_no = [c for c in ['id', 'nama_kups'] if c in df_no_coord.columns]
        print(f"{Colors.FAIL}{df_no_coord[cols_no].head(15).to_string(index=False)}{Colors.ENDC}")

    print(f"{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.ENDC}\n")

    # Simpan laporan file
    with open(INVALID_LIST_PATH, 'w', encoding='utf-8') as f:
        f.write(f"AUDIT KUPS - {datetime.now()}\nValid: {len(gdf_valid)}\nLuar RI: {len(gdf_outside)}\nKosong: {len(df_no_coord)}\n")

    # --- FINALISASI GDF ---
    gdf = gdf_valid
    gdf.columns = [c.upper() if c.lower() != 'geometry' else 'geometry' for c in gdf.columns]
    gdf = gdf.drop(columns=['NUJUR', 'LINTANG'], errors='ignore')

    # ==============================
    # 5. SIMPAN GDB & POSTGIS
    # ==============================
    # GDB Export
    if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
    pyogrio.write_dataframe(gdf, GDB_PATH, layer='KUPS', driver="OpenFileGDB")
    with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as z:
        for r, d, files in os.walk(GDB_PATH):
            for file in files:
                p = os.path.join(r, file)
                z.write(p, os.path.relpath(p, os.path.join(GDB_PATH, '..')))
    shutil.rmtree(GDB_PATH)

    # PostGIS Export
    db_url = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))

    conn_gdal = f"PG:host={DB_HOST} port={DB_PORT} dbname={DB_NAME} user={DB_USER} password={DB_PASS}"
    logging.info(f"💾 Menyimpan ke PostGIS: {SCHEMA}.{TABLE_NAME}...")

    pyogrio.write_dataframe(gdf, conn_gdal, layer=TABLE_NAME, driver="PostgreSQL",
                            layer_options={"OVERWRITE":"YES", "SCHEMA":SCHEMA, "GEOMETRY_NAME":"geometry", "LAUNDER":"NO", "SPATIAL_INDEX":"NONE"})

    with engine.begin() as conn:
        conn.execute(text(f'CREATE INDEX IF NOT EXISTS "{TABLE_NAME}_geom_idx" ON "{SCHEMA}"."{TABLE_NAME}" USING GIST (geometry);'))
        conn.execute(text(f'ANALYZE "{SCHEMA}"."{TABLE_NAME}";'))

    logging.info(f"{Colors.GREEN}✅ Selesai! Data sinkron di database dan backup tersedia di {ZIP_PATH}{Colors.ENDC}")

except Exception as e:
    logging.error(f"{Colors.FAIL}❌ Fatal Error: {e}{Colors.ENDC}"); sys.exit(1)
