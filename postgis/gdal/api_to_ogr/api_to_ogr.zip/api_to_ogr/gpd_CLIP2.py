import sys
import os
import time
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

# ============================================================================
# PETUNJUK PENGGUNAAN (DOCKER CONSOLE):
# printf "%s\n" "Bali" "DKI Jakarta" | xargs -I {} -P 2 python3 gpd_CLIP2.py "{}"
# ============================================================================

# --- 0. Load Konfigurasi dari .env ---
load_dotenv()

DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
OUT_SCHEMA = os.getenv("SCHEMA_OUT", "analisis")

# --- 1. Ambil Argumen Command Line ---
if len(sys.argv) < 2:
    print("❌ Penggunaan: python3 gpd_CLIP2.py \"Nama Provinsi\"")
    sys.exit(1)

PROVINSI_TARGET = sys.argv[1]
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').upper()
start_time = time.time()

# --- 2. Detail Koneksi (Psycopg 3) ---
conn_string = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(conn_string)

# --- 3. Konfigurasi Tabel ---
TABLE_A = "PL2024_AR_250K"
TABLE_B = "ADM_KAB_KOTA"
OUT_TABLE = f"PL_{SAFE_NAME}_CLIP"
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE}"'

print(f"🚀 Memulai Proses CLIP PostGIS (Clean Polygon Mode)")
print(f"📍 Target: {PROVINSI_TARGET}")

try:
    with engine.begin() as conn:
        # A. Persiapan Skema
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))
        conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL};'))

        print(f"✂️ Menjalankan ST_Intersection di Server...")
        
        # B. Query Utama (In-Database Clipping)
        # ST_CollectionExtract(..., 3) memastikan hanya output Poligon
        query_clip = text(f"""
            CREATE TABLE {RESULT_TABLE_FULL} AS
            WITH mask AS (
                SELECT ST_MakeValid(ST_Union(geom)) as geom_mask 
                FROM "{SCHEMA}"."{TABLE_B}" 
                WHERE "WADMPR" ILIKE :prov
            )
            SELECT 
                a.*, 
                ST_Multi(ST_CollectionExtract(
                    ST_Intersection(ST_MakeValid(a.geom), m.geom_mask), 
                    3
                )) as geom_clip,
                ST_Area(ST_Transform(ST_Intersection(ST_MakeValid(a.geom), m.geom_mask), 54034)) / 10000 as "LUAS_CEA_HA"
            FROM "{SCHEMA}"."{TABLE_A}" a, mask m
            WHERE a.geom && m.geom_mask 
              AND ST_Intersects(a.geom, m.geom_mask);
        """)
        
        conn.execute(query_clip, {"prov": PROVINSI_TARGET})

        # C. Finalisasi Struktur Tabel
        print(f"🛠️ Merapikan kolom dan membuat Index Spasial...")
        conn.execute(text(f'ALTER TABLE {RESULT_TABLE_FULL} DROP COLUMN geom;'))
        conn.execute(text(f'ALTER TABLE {RESULT_TABLE_FULL} RENAME COLUMN geom_clip TO geom;'))
        
        # D. Membuat Index Spasial (GIST)
        conn.execute(text(f'CREATE INDEX ON {RESULT_TABLE_FULL} USING GIST(geom);'))
        conn.execute(text(f'ANALYZE {RESULT_TABLE_FULL};'))

    duration = time.time() - start_time
    print(f"✅ Selesai dalam {duration:.2f} detik!")
    print(f"📂 Hasil: {RESULT_TABLE_FULL}")

except Exception as e:
    print(f"❌ Error Terjadi: {e}")
    sys.exit(1)
