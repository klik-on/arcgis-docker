import os
import logging
import secrets
from fastapi import FastAPI, HTTPException, Depends, Security, status, Query
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, text
import geopandas as gpd
from contextlib import asynccontextmanager

# --- 1. KONFIGURASI LOGGING ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("api-to-ogr")

# --- 2. PENGAMBILAN VARIABEL ENVIRONMENT (SECURE) ---
def get_env_or_critical(key: str, default: str = None) -> str:
    """Mengambil variabel env atau stop aplikasi jika kunci krusial hilang."""
    value = os.getenv(key, default)
    if value is None:
        logger.error(f"❌ CRITICAL: Variabel environment '{key}' tidak ditemukan!")
        raise RuntimeError(f"Missing critical environment variable: {key}")
    return value

# Kredensial Database
DB_USER = get_env_or_critical("DB_USER")
DB_PASS = get_env_or_critical("DB_PASS")
DB_HOST = get_env_or_critical("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = get_env_or_critical("DB_NAME")

# Token Keamanan (Pastikan diatur di .env atau Docker)
PGIS_API_TOKEN = get_env_or_critical("PGIS_API_TOKEN")
API_KEY_NAME = "X-API-TOKEN"

# Koneksi ke PostGIS
DATABASE_URL = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# --- 3. SECURITY DEPENDENCY ---
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)

async def get_api_key(api_key: str = Security(api_key_header)):
    """Validasi Token dengan proteksi timing attack."""
    if api_key and secrets.compare_digest(api_key, PGIS_API_TOKEN):
        return api_key
    
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Akses Ditolak: Token tidak valid atau tidak ditemukan di Header X-API-TOKEN",
    )

# --- 4. DATABASE ENGINE ---
engine = create_engine(
    DATABASE_URL,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
    pool_recycle=3600
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Event Lifecycle: Startup & Shutdown."""
    logger.info("🚀 API Geospasial Kehutanan Memulai...")
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        logger.info(f"✅ Database terhubung di {DB_HOST}")
    except Exception as e:
        logger.error(f"❌ Koneksi Database Gagal: {e}")
    yield
    engine.dispose()
    logger.info("🛑 API Geospasial Berhenti.")

# --- 5. INISIALISASI APLIKASI ---
app = FastAPI(
    title="GIS API - Walidata Geospasial Kehutanan",
    description="""
    API untuk akses data Geospasial Kehutanan 
    * **Autentikasi**: Gunakan header `X-API-TOKEN`.
    * **Pagination**: Gunakan parameter `page` dan `limit` untuk data besar.
    """,
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- 6. ENDPOINTS ---

@app.get("/health", tags=["Sistem"])
def health_check():
    """Health check terbuka untuk monitoring status server."""
    return {"status": "healthy", "database": "connected"}

@app.get("/api/v1/layers/{schema_name}/{table_name}", tags=["API Walidata Geospasial"])
def get_spatial_layer(
    schema_name: str,
    table_name: str,
    page: int = Query(1, ge=1, description="Nomor halaman"),
    limit: int = Query(500, ge=1, le=5000, description="Data per halaman"),
    geom_column: str = "geom",
    _=Depends(get_api_key)
):
    """
    Mengambil data GeoJSON dari berbagai skema. 
    Contoh: /api/v1/layers/datagis/KUPS?page=1&limit=5000
    """
    try:
        offset = (page - 1) * limit
        sql = f'SELECT * FROM "{schema_name}"."{table_name}" LIMIT :limit OFFSET :offset'
        
        logger.info(f"REQUEST: {schema_name}.{table_name} (Page: {page})")

        with engine.connect() as conn:
            gdf = gpd.read_postgis(
                text(sql), 
                conn, 
                geom_col=geom_column,
                params={"limit": limit, "offset": offset}
            )

        if gdf.empty:
            return {"type": "FeatureCollection", "features": [], "metadata": {"status": "no_data"}}

        response = gdf.__geo_interface__
        response["metadata"] = {
            "schema": schema_name,
            "table": table_name,
            "page": page,
            "limit": limit,
            "count": len(gdf)
        }
        return response

    except Exception as e:
        logger.error(f"Error pada {schema_name}.{table_name}: {str(e)}")
        if "UndefinedTable" in str(e):
            raise HTTPException(status_code=404, detail="Tabel atau Skema tidak ditemukan.")
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get("/api/v1/stats/{schema_name}/{table_name}", tags=["API Walidata Geospasial"])
def get_table_stats(
    schema_name: str,
    table_name: str,
    _=Depends(get_api_key)
):
    """Melihat total jumlah record untuk estimasi jumlah halaman (pagination)."""
    try:
        count_sql = f'SELECT COUNT(*) FROM "{schema_name}"."{table_name}"'
        with engine.connect() as conn:
            total_count = conn.execute(text(count_sql)).scalar()
            
        return {
            "schema": schema_name,
            "table": table_name,
            "total_records": total_count,
            "total_pages_est": (total_count // 500) + (1 if total_count % 500 > 0 else 0)
        }
    except Exception as e:
        logger.error(f"Error stats {schema_name}.{table_name}: {str(e)}")
        raise HTTPException(status_code=404, detail="Tabel tidak ditemukan")

@app.get("/api/v1/drivers", tags=["Sistem"])
def list_drivers(_=Depends(get_api_key)):
    """Melihat format file spasial yang didukung oleh server."""
    import pyogrio
    return pyogrio.list_drivers()
