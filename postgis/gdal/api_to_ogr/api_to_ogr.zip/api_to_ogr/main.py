import os
import shutil
import logging
import secrets
import time
import requests
import subprocess
import pandas as pd
import geopandas as gpd
from datetime import datetime
from fastapi import FastAPI, HTTPException, Depends, Security, status, Query, BackgroundTasks
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, text
from contextlib import asynccontextmanager

# --- 1. KONFIGURASI LOGGING ---
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("api-gis-integrated")

# --- 2. ENV & DATABASE ---
def get_env_or_critical(key: str) -> str:
    val = os.getenv(key)
    if not val: raise RuntimeError(f"Missing env var: {key}")
    return val

DB_USER = get_env_or_critical("DB_USER")
DB_PASS = get_env_or_critical("DB_PASS")
DB_HOST = get_env_or_critical("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = get_env_or_critical("DB_NAME")
PGIS_API_TOKEN = get_env_or_critical("PGIS_API_TOKEN")

KUPS_API_URL = os.getenv("KUPS_API_URL")
SCHEMA_DATA = os.getenv("SCHEMA_DATA", "datagis")
TABLE_NAME_KUPS = os.getenv("KUPS_TABLE", "KUPS")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")

DATABASE_URL = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(DATABASE_URL, pool_size=10, max_overflow=20)

# --- 3. MONITORING STATUS ---
sync_status_kups = {"is_running": False, "last_run": None, "last_result": "N/A", "records": 0, "current_page": 0}
sync_status_pbph = {"is_running": False, "last_run": None, "last_result": "N/A", "igt_active": None, "error_log": None}

# --- 4. SECURITY ---
api_key_header = APIKeyHeader(name="X-API-TOKEN", auto_error=False)
async def get_api_key(api_key: str = Security(api_key_header)):
    if api_key and secrets.compare_digest(api_key, PGIS_API_TOKEN): return api_key
    raise HTTPException(status_code=401, detail="Token tidak valid")

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 API Geospasial Kehutanan Aktif...")
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    yield
    engine.dispose()

# --- 5. TAGS & APP INIT ---
tags_metadata = [
    {"name": "API Data Kehutanan", "description": "Penyajian data spasial (GeoJSON), tabular (JSON), dan statistik."},
    {"name": "Eksplorasi Data", "description": "Navigasi struktur database (daftar skema dan tabel)."},
    {"name": "Sinkronisasi Data", "description": "Otomasi Update IGT dari API Produsen."},
    {"name": "Sistem", "description": "Monitoring kesehatan API dan pemeliharaan penyimpanan (Storage & Cleanup)."},
]

# PERBAIKAN DI SINI: Menambahkan root_path agar Swagger UI berfungsi di balik Proxy Tomcat
app = FastAPI(
    title="GIS API - Data Spasial Kehutanan", 
    version="1.12.0", 
    lifespan=lifespan, 
    openapi_tags=tags_metadata,
    root_path="/datagis"
)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# --- 6. BACKGROUND LOGIC ---
def sync_kups_background():
    global sync_status_kups
    sync_status_kups.update({"is_running": True, "last_run": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "error_log": None})
    try:
        all_data, page, session = [], 1, requests.Session()
        while True:
            sync_status_kups["current_page"] = page
            res = session.get(f"{KUPS_API_URL}?page={page}&per_page=100", verify=False, timeout=60)
            if res.status_code == 429:
                time.sleep(30); continue
            res.raise_for_status()
            data = res.json()
            items = data.get("data", [])
            if not items: break
            all_data.extend(items)
            if not data.get("next_page_url"): break
            page += 1; time.sleep(1.5)

        df = pd.DataFrame(all_data)
        df['nujur'] = pd.to_numeric(df['nujur'], errors='coerce')
        df['lintang'] = pd.to_numeric(df['lintang'], errors='coerce')
        df = df.dropna(subset=['nujur', 'lintang'])
        gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df['nujur'], df['lintang']), crs="EPSG:4326").rename_geometry('geom')
        gdf.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf.columns]
        gdf.to_postgis(name=TABLE_NAME_KUPS, con=engine, schema=SCHEMA_DATA, if_exists='replace', index=False)
        sync_status_kups.update({"is_running": False, "last_result": "Sukses", "records": len(gdf)})
    except Exception as e:
        sync_status_kups.update({"is_running": False, "last_result": "Gagal", "error_log": str(e)})

def sync_pbph_background(igt_name: str):
    global sync_status_pbph
    sync_status_pbph.update({"is_running": True, "last_run": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "igt_active": igt_name, "error_log": None})
    try:
        result = subprocess.run(["/bin/bash", "./api_pbph.sh", igt_name], capture_output=True, text=True)
        if result.returncode == 0:
            sync_status_pbph.update({"is_running": False, "last_result": "Sukses"})
        else:
            sync_status_pbph.update({"is_running": False, "last_result": "Gagal", "error_log": result.stderr})
    except Exception as e:
        sync_status_pbph.update({"is_running": False, "last_result": "Gagal", "error_log": str(e)})

# --- 7. ENDPOINTS ---

@app.get("/api/v1/layers/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_spatial_layer(schema_name: str, table_name: str, page: int = Query(1), limit: int = Query(500), _=Depends(get_api_key)):
    try:
        offset = (page - 1) * limit
        sql = f'SELECT * FROM "{schema_name}"."{table_name}" LIMIT :limit OFFSET :offset'
        with engine.connect() as conn:
            gdf = gpd.read_postgis(text(sql), conn, geom_col="geom", params={"limit": limit, "offset": offset})
        res = gdf.__geo_interface__
        res["metadata"] = {"schema": schema_name, "table": table_name, "page": page, "count": len(gdf)}
        return res
    except Exception: raise HTTPException(status_code=500, detail="Error akses data.")

@app.get("/api/v1/tables/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_table_data(schema_name: str, table_name: str, page: int = Query(1), limit: int = Query(500), _=Depends(get_api_key)):
    try:
        offset = (page - 1) * limit
        sql = f'SELECT * FROM "{schema_name}"."{table_name}" LIMIT :limit OFFSET :offset'
        with engine.connect() as conn:
            df = pd.read_sql(text(sql), conn, params={"limit": limit, "offset": offset})
        df = df.drop(columns=[c for c in df.columns if c.lower() in ['geom', 'geometry', 'shape']], errors='ignore')
        return {"data": df.to_dict(orient="records")}
    except Exception: raise HTTPException(status_code=500, detail="Error akses tabel.")

@app.get("/api/v1/stats/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_table_stats(schema_name: str, table_name: str, _=Depends(get_api_key)):
    with engine.connect() as conn:
        total = conn.execute(text(f'SELECT COUNT(*) FROM "{schema_name}"."{table_name}"')).scalar()
        return {"total_records": total}

@app.get("/api/v1/list-schemas", tags=["Eksplorasi Data"])
def list_schemas(_=Depends(get_api_key)):
    with engine.connect() as conn:
        result = conn.execute(text("SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN ('information_schema', 'pg_catalog') ORDER BY schema_name;"))
        return {"schemas": [row[0] for row in result]}

@app.get("/api/v1/list-tables/{schema_name}", tags=["Eksplorasi Data"])
def list_tables(schema_name: str, search: str = Query(None), _=Depends(get_api_key)):
    query = f"SELECT table_name FROM information_schema.tables WHERE table_schema = :schema"
    with engine.connect() as conn:
        result = conn.execute(text(query + " ORDER BY table_name;"), {"schema": schema_name})
        tables = [row[0] for row in result]
        if search: tables = [t for t in tables if search.lower() in t.lower()]
        return {"tables": tables}

@app.post("/api/v1/sync/kups", tags=["Sinkronisasi Data"])
async def trigger_sync_kups(background_tasks: BackgroundTasks, _=Depends(get_api_key)):
    if sync_status_kups["is_running"]: return {"status": "Running"}
    background_tasks.add_task(sync_kups_background)
    return {"status": "Started"}

@app.post("/api/v1/sync/pbph", tags=["Sinkronisasi Data"])
async def trigger_sync_pbph(background_tasks: BackgroundTasks, igt: str = Query("PERSETUJUAN_KOMITMEN_PBPH"), _=Depends(get_api_key)):
    if sync_status_pbph["is_running"]: return {"status": "Running"}
    background_tasks.add_task(sync_pbph_background, igt)
    return {"status": "Started"}

@app.get("/api/v1/sync/status", tags=["Sinkronisasi Data"])
async def get_sync_status(_=Depends(get_api_key)):
    return {"kups": sync_status_kups, "pbph": sync_status_pbph}

@app.get("/health", tags=["Sistem"])
def health_check():
    return {"status": "healthy", "timestamp": datetime.now()}

@app.get("/api/v1/system/storage", tags=["Sistem"])
async def get_storage_info(_=Depends(get_api_key)):
    total, used, free = shutil.disk_usage(DATA_DIR)
    files = [{"name": f, "size_mb": round(os.path.getsize(os.path.join(DATA_DIR, f)) / (1024*1024), 2)}
             for f in os.listdir(DATA_DIR) if os.path.isfile(os.path.join(DATA_DIR, f))]
    return {
        "disk_free_gb": round(free / (1024**3), 2),
        "disk_total_gb": round(total / (1024**3), 2),
        "files_count": len(files),
        "files": files
    }

@app.delete("/api/v1/system/cleanup", tags=["Sistem"])
async def cleanup_storage(filename: str = Query(None, description="Hapus file tertentu atau semua .zip"), _=Depends(get_api_key)):
    deleted = 0
    if filename:
        path = os.path.join(DATA_DIR, filename)
        if os.path.exists(path): os.remove(path); deleted = 1
    else:
        for f in os.listdir(DATA_DIR):
            if f.endswith(".zip"): os.remove(os.path.join(DATA_DIR, f)); deleted += 1
    return {"deleted": deleted, "message": "Pembersihan selesai."}
