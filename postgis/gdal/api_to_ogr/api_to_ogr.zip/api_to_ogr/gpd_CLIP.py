import geopandas as gpd
from sqlalchemy import create_engine, text
import pandas as pd
import sys
import os
from dotenv import load_dotenv

# --- 0. Load Konfigurasi dari .env ---
load_dotenv()

DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
OUT_SCHEMA = os.getenv("SCHEMA_OUT", "analisis")

# --- 1. Ambil Argumen Command Line ---
if len(sys.argv) < 2:
    print("❌ Penggunaan: python3 gpd_CLIP.py \"Nama Provinsi\"")
    sys.exit(1)

PROVINSI_TARGET = sys.argv[1]
print(f"🎯 Target Provinsi Ditetapkan: {PROVINSI_TARGET}")

# --- 2. Koneksi Database (Psycopg 3) ---
conn_string = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(conn_string)

# --- 3. Konfigurasi Tabel ---
TABLE_A = "PL2024_AR_250K"
TABLE_B = "ADM_KAB_KOTA"
OUT_TABLE = 'PL'
FIELD_LUAS = "PL2024_ID"

# --- 4. Memuat Data dari PostGIS ---
try:
    with engine.begin() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))

    print(f"📂 Memuat data {TABLE_A} dan filter {TABLE_B}...")

    query_a = f'SELECT * FROM "{SCHEMA}"."{TABLE_A}"'
    query_b_filtered = text(f'SELECT * FROM "{SCHEMA}"."{TABLE_B}" WHERE "WADMPR" = :provinsi')

    # Memuat GeoDataFrame
    gdf_lahan = gpd.read_postgis(query_a, engine, geom_col='geom')
    gdf_provinsi_target = gpd.read_postgis(query_b_filtered, engine, geom_col='geom', params={"provinsi": PROVINSI_TARGET})

except Exception as e:
    print(f"❌ Gagal memuat data: {e}")
    sys.exit(1)

if gdf_provinsi_target.empty:
    print(f"⚠️ Data batas provinsi '{PROVINSI_TARGET}' tidak ditemukan.")
    sys.exit(1)

# --- 5. Geoprocessing (Overlay Mode) ---
if gdf_lahan.crs != gdf_provinsi_target.crs:
    gdf_provinsi_target = gdf_provinsi_target.to_crs(gdf_lahan.crs)

gdf_provinsi_target = gdf_provinsi_target[['WADMPR', 'geom']]
gdf_batas_target = gdf_provinsi_target.dissolve(by='WADMPR').reset_index()

print(f"🚀 Melakukan INTERSECT {TABLE_A} dengan {PROVINSI_TARGET}...")
gdf_lahan_di_target = gdf_lahan.overlay(gdf_batas_target, how='intersection', keep_geom_type=True)

# --- 6. Penyimpanan & Penambahan Field SQL ---
RESULT_TABLE_NAME = f"{OUT_TABLE}_{PROVINSI_TARGET.replace(' ', '_').upper()}_CLIP"
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{RESULT_TABLE_NAME}"'

try:
    if gdf_lahan_di_target.geometry.name != 'geom':
        gdf_lahan_di_target = gdf_lahan_di_target.rename_geometry('geom')

    print(f"💾 Menyimpan hasil ke {RESULT_TABLE_FULL}...")
    gdf_lahan_di_target.to_postgis(
        name=RESULT_TABLE_NAME,
        con=engine,
        schema=OUT_SCHEMA,
        if_exists='replace',
        index=False
    )

    print(f"📏 Menghitung Luas (CEA) dalam Hektar (HA) via PostGIS...")
    with engine.begin() as conn:
        conn.execute(text(f'ALTER TABLE {RESULT_TABLE_FULL} ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;'))
        conn.execute(text(f'UPDATE {RESULT_TABLE_FULL} SET "LUAS_CEA_HA" = ST_Area(ST_Transform("geom", 54034)) / 10000;'))

    # --- 7. Ringkasan Luas ---
    if FIELD_LUAS in gdf_lahan_di_target.columns:
        query_summary = f"""
            SELECT "{FIELD_LUAS}", SUM("LUAS_CEA_HA") as total_ha
            FROM {RESULT_TABLE_FULL}
            GROUP BY "{FIELD_LUAS}" ORDER BY total_ha DESC
        """
        summary_df = pd.read_sql(query_summary, engine)

        print(f"\n📊 RINGKASAN LUAS BERDASARKAN {FIELD_LUAS}:")
        if not summary_df.empty:
            print(summary_df.to_string(index=False))
        else:
            print("Tidak ada data untuk diringkas.")

    print(f"\n✅ Berhasil! Proses selesai.")

except Exception as e:
    print(f"❌ Gagal pada proses database: {e}")
