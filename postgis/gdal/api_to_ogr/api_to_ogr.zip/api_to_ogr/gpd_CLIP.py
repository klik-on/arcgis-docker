import geopandas as gpd
from sqlalchemy import create_engine, text
import pandas as pd
import sys

# --- 1. Ambil Argumen Command Line ---
if len(sys.argv) < 2:
    print("Penggunaan: python3 gpd_CLIP.py \"Nama Provinsi\"")
    sys.exit(1)

PROVINSI_TARGET = sys.argv[1]
print(f"🎯 Target Provinsi Ditetapkan: {PROVINSI_TARGET}")

# --- 2. Detail Koneksi Database ---
DB_USER, DB_PASS = "postgres.67888", "password00"
DB_HOST, DB_PORT, DB_NAME = "172.16.2.122", "5432", "postgres"
conn_string = f"postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(conn_string)

SCHEMA = "datagis"
TABLE_A = "PL2024_AR_250K"
TABLE_B = "ADM_KAB_KOTA"

# --- 3. Konstruksi Query SQL ---
query_a = f'SELECT * FROM "{SCHEMA}"."{TABLE_A}"'
query_b_filtered = f"SELECT * FROM \"{SCHEMA}\".\"{TABLE_B}\" WHERE \"WADMPR\" = '{PROVINSI_TARGET}'"

# --- 4. Memuat Data dari PostGIS ---
try:
    print(f"Memuat data {TABLE_A} dan filter {TABLE_B}...")
    gdf_lahan = gpd.read_postgis(query_a, engine, geom_col='geom')
    gdf_provinsi_target = gpd.read_postgis(query_b_filtered, engine, geom_col='geom')
except Exception as e:
    print(f"❌ Gagal memuat data: {e}")
    sys.exit(1)

if gdf_provinsi_target.empty:
    print(f"⚠️ Data batas provinsi '{PROVINSI_TARGET}' tidak ditemukan.")
    sys.exit(1)

# --- 5. Geoprocessing ---
if gdf_lahan.crs != gdf_provinsi_target.crs:
    gdf_provinsi_target = gdf_provinsi_target.to_crs(gdf_lahan.crs)

# Seleksi kolom agar hanya WADMPR yang terbawa dari tabel pemotong
gdf_provinsi_target = gdf_provinsi_target[['WADMPR', 'geom']]
gdf_batas_target = gdf_provinsi_target.dissolve(by='WADMPR').reset_index()

print(f"🚀 Melakukan INTERSECT {TABLE_A} dengan {PROVINSI_TARGET}...")
gdf_lahan_di_target = gdf_lahan.overlay(gdf_batas_target, how='intersection', keep_geom_type=True)


# --- 6. Penyimpanan & Penambahan Field SQL ---
RESULT_TABLE_NAME = f"PL_{PROVINSI_TARGET.replace(' ', '_').upper()}_CLIP"
RESULT_TABLE_FULL = f'"{SCHEMA}"."{RESULT_TABLE_NAME}"'

try:
    # A. Pastikan kolom geometri bernama 'geom' di GeoDataFrame
    if gdf_lahan_di_target.geometry.name != 'geom':
        gdf_lahan_di_target = gdf_lahan_di_target.rename_geometry('geom')

    # B. Simpan ke PostGIS
    print(f"💾 Menyimpan hasil ke {RESULT_TABLE_FULL}...")
    gdf_lahan_di_target.to_postgis(
        name=RESULT_TABLE_NAME,
        con=engine,
        schema=SCHEMA,
        if_exists='replace',
        index=False
    )

    # C. Tambahkan kolom dan hitung luas menggunakan PostGIS SQL
    print(f"📏 Menghitung Luas (CEA) dalam Hektar (HA) via PostGIS...")

    sql_commands = [
        f'ALTER TABLE {RESULT_TABLE_FULL} ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;',
        f'UPDATE {RESULT_TABLE_FULL} SET "LUAS_CEA_HA" = ST_Area(ST_Transform("geom", 54034)) / 10000;'
    ]

    with engine.begin() as conn:
        for cmd in sql_commands:
            conn.execute(text(cmd))

    print(f"✅ Berhasil! Tabel {RESULT_TABLE_FULL} siap digunakan.")

    # D. Opsional: Tampilkan ringkasan luas di terminal
    # Sesuaikan 'TIPE_LHN' dengan nama kolom kategori Anda
    if 'PL2024_ID' in gdf_lahan_di_target.columns:
        query_summary = f'SELECT "PL2024_ID", SUM("LUAS_CEA_HA") as total_ha FROM {RESULT_TABLE_FULL} GROUP BY "PL2024_ID" ORDER BY total_ha DESC'
        summary_df = pd.read_sql(query_summary, engine)
        print("\n📊 RINGKASAN LUAS CEA:")
        print(summary_df.to_string(index=False))

except Exception as e:
    print(f"❌ Gagal pada proses database: {e}")
