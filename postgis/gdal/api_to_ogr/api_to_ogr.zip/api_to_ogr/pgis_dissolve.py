from sqlalchemy import create_engine, text

# 🔹 Koneksi ke PostGIS
engine = create_engine("postgresql://postgres.67888:password00@172.16.2.122:5432/postgres")

# 🔹 Nama schema dan tabel input/output
schema_name = "datagis"
input_table = "ADM_KAB_KOTA"
output_table = "ADM_PROV_DISSOLVED"

# 🔹 SQL untuk dissolve + hitung luas
sql = f"""
DROP TABLE IF EXISTS "{schema_name}"."{output_table}";

CREATE TABLE "{schema_name}"."{output_table}" AS
SELECT 
    "WADMPR",
    SUM(ST_Area(ST_Transform(geom, 54034))) / 10000 AS "LUAS_CEA_HA",  -- luas ha
    ST_Union(geom) AS geom
FROM "{schema_name}"."{input_table}"
GROUP BY "WADMPR";

-- Buat spatial index
CREATE INDEX "IDX_{output_table}_GEOM"
ON "{schema_name}"."{output_table}"
USING GIST (geom);
"""

# 🔹 Eksekusi SQL
with engine.connect() as conn:
    conn.execute(text(sql))
    conn.commit()

print(f"Table {schema_name}.{output_table} berhasil dibuat dan di-dissolve dengan luas (ha).")
