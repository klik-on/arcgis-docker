import os
import sys
import json
import requests
import urllib3
import logging
import time
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from datetime import datetime

# ==============================
# KONFIGURASI FOLDER & PATH
# ==============================
FOLDER_PATH = "/app/data"
GEOJSON_PATH = os.path.join(FOLDER_PATH, "KUPS.geojson")
LOG_PATH = os.path.join(FOLDER_PATH, "log_kups.log")

os.makedirs(FOLDER_PATH, exist_ok=True)

# ==============================
# KONFIGURASI LOGGING
# ==============================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(LOG_PATH, encoding="utf-8")
    ]
)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==============================
# KONFIGURASI API
# ==============================
API_URL = "https://gokups.hutsos.kehutanan.go.id/api/v1/kups"
PER_PAGE = 500
MAX_RETRIES = 5
BASE_RETRY_DELAY = 10

# ==============================
# AMBIL DATA DARI API
# ==============================
all_kups = []
page = 1
session = requests.Session()

logging.info("🚀 Mulai mengambil data dari API...")

while True:
    delay = BASE_RETRY_DELAY
    for attempt in range(MAX_RETRIES):
        try:
            response = session.get(
                f"{API_URL}?page={page}&per_page={PER_PAGE}",
                verify=False,
                timeout=15
            )

            if "html" in response.text.lower():
                logging.warning(f"⚠️ Respons HTML pada hal {page}. Menunggu {delay}s...")
                time.sleep(delay)
                delay *= 2
                continue

            response.raise_for_status()
            break
        except Exception as e:
            if attempt == MAX_RETRIES - 1:
                logging.error(f"❌ Gagal setelah {MAX_RETRIES} percobaan: {e}")
                sys.exit(1)
            time.sleep(delay)
            delay *= 2

    data = response.json()
    kups_list = data.get("data", [])
    
    if not kups_list:
        break

    all_kups.extend(kups_list)
    logging.info(f"📄 Berhasil mengambil halaman {page} ({len(kups_list)} data)")

    if not data.get("next_page_url"):
        break
    page += 1

# ==============================
# PEMROSESAN DENGAN GEOPANDAS
# ==============================
if not all_kups:
    logging.error("❌ Tidak ada data yang berhasil diambil.")
    sys.exit(1)

logging.info("🔄 Memproses data dengan GeoPandas...")

# 1. Konversi List ke Pandas DataFrame
df = pd.DataFrame(all_kups)

# 2. Bersihkan koordinat dan konversi ke numerik
df['nujur'] = pd.to_numeric(df['nujur'], errors='coerce')
df['lintang'] = pd.to_numeric(df['lintang'], errors='coerce')

# 3. Filter data yang tidak memiliki koordinat valid
invalid_mask = df['nujur'].isna() | df['lintang'].isna() | \
               (~df['nujur'].between(-180, 180)) | (~df['lintang'].between(-90, 90))

invalid_count = invalid_mask.sum()
df_clean = df[~invalid_mask].copy()

# 4. Buat Geometry Point
geometry = [Point(xy) for xy in zip(df_clean['nujur'], df_clean['lintang'])]

# 5. Buat GeoDataFrame (CRS: WGS84 - EPSG:4326)
gdf = gpd.GeoDataFrame(df_clean, geometry=geometry, crs="EPSG:4326")

# 6. Transformasi Nama Kolom menjadi UPPERCASE (Sesuai kebutuhan SHP/GDB)
# Serta hapus kolom koordinat asli karena sudah jadi geometry
gdf.columns = [c.upper() for c in gdf.columns]
gdf = gdf.drop(columns=['NUJUR', 'LINTANG'])

# ==============================
# SIMPAN KE GEOJSON
# ==============================
try:
    # GeoPandas to_file secara otomatis menangani struktur GeoJSON
    gdf.to_file(GEOJSON_PATH, driver='GeoJSON', encoding='utf-8')
    
    logging.info(f"✅ Berhasil disimpan: {GEOJSON_PATH}")
    logging.info(f"🧾 Total records: {len(gdf)}")
    logging.info(f"🚫 Records dibuang: {invalid_count}")
except Exception as e:
    logging.error(f"❌ Gagal menyimpan file: {e}")
    sys.exit(1)
