import requests

# Base URL
tata_kelola = "https://sigap.kehutanan.go.id/tatakelola/api-new"  # ganti dengan URL Anda

# -------------------------
# 1. LOGIN untuk dapatkan token
# -------------------------

login_url = f"{tata_kelola}/api/auth/signin"

payload = {
    "username": "klik",
    "password": "sigap12345"
}

response = requests.post(login_url, json=payload)

if response.status_code == 200:
    token = response.json().get("accessToken")
    print("Token:", token)
else:
    print("Gagal login:", response.text)
    exit()

# -------------------------
# 2. DOWNLOAD FILE
# -------------------------

uuid = "77ee278d-391b-4f60-bc58-305cf47ff833"   # ganti dengan UUID yang benar
download_url = f"{tata_kelola}/api/data-produsen/unduhFile/{uuid}"

headers = {
    "x-access-token": token
}

file_response = requests.get(download_url, headers=headers)

if file_response.status_code == 200:
    filename = "downloaded_file"
    with open(filename, "wb") as f:
        f.write(file_response.content)
    print(f"File berhasil diunduh: {filename}")
else:
    print("Gagal download:", file_response.text)
