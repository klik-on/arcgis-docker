import requests
import os
import subprocess
from dotenv import load_dotenv

# Load variabel dari .env
load_dotenv()

# Konfigurasi dari .env
BASE_URL = os.getenv("SIGAP_URL")
USERNAME = os.getenv("SIGAP_USER")
PASSWORD = os.getenv("SIGAP_PASS")

# Parameter Data (Bisa diubah sesuai kebutuhan)
UUID = "2726e362-a2b9-4324-9309-477ce4591adf"
LAYER_NAME = "MANGROVE_AR_25K_24"

# Lokasi penyimpanan sementara
DATA_DIR = "/app/data"
os.makedirs(DATA_DIR, exist_ok=True)

def login():
    print(f"🔑 Login ke SIGAP ({USERNAME})...")
    url = f"{BASE_URL}/api/auth/signin"
    try:
        res = requests.post(url, json={"username": USERNAME, "password": PASSWORD})
        res.raise_for_status()
        print("✅ Login Berhasil.")
        return res.json().get("accessToken")
    except Exception as e:
        print(f"❌ Gagal login: {e}")
        return None

def download(token):
    filename = f"{LAYER_NAME}.gdb.zip"
    filepath = os.path.join(DATA_DIR, filename)
    url = f"{BASE_URL}/api/data-produsen/unduhFile/{UUID}"
    
    print(f"📥 Mengunduh: {filename}...")
    headers = {"x-access-token": token}
    
    try:
        with requests.get(url, headers=headers, stream=True) as r:
            r.raise_for_status()
            with open(filepath, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
        print(f"✅ File tersimpan di: {filepath}")
        return True
    except Exception as e:
        print(f"❌ Gagal unduh: {e}")
        return False

def migrate():
    print(f"🔄 Menjalankan migrasi database untuk {LAYER_NAME}...")
    try:
        # Menjalankan script shell dan meneruskan variabel environment
        subprocess.run(["bash", "./gdb_to_pgis.sh", LAYER_NAME], check=True)
        print("🚀 Proses Selesai Seluruhnya!")
    except subprocess.CalledProcessError:
        print("❌ Terjadi kesalahan saat menjalankan gdb_to_pgis.sh")

if __name__ == "__main__":
    token = login()
    if token:
        if download(token):
            migrate()
