import geopandas as gpd
import fiona
import os
import zipfile
import shutil
from sqlalchemy import create_engine, text

FOLDER_PATH = "/app/data"
IGT = "KUPS"
SCHEMA = "datagis"  # schema khusus

# zip_path harus berupa string yang digabung dengan benar
zip_path = f"{FOLDER_PATH}/{IGT}.gdb.zip"
extract_dir = FOLDER_PATH

print("ZIP Path:", zip_path)

# Ekstrak ZIP
with zipfile.ZipFile(zip_path, 'r') as z:
    z.extractall(extract_dir)

# Cari folder .gdb di FOLDER_PATH
gdb_path = [
    os.path.join(extract_dir, f)
    for f in os.listdir(extract_dir)
    if f.endswith(".gdb")
][0]

print("GDB Path:", gdb_path)

# Lihat daftar layer di GDB
layers = fiona.listlayers(gdb_path)
print("Layers in GDB:", layers)

# Baca layer GDB sebagai GeoDataFrame
gdf = gpd.read_file(gdb_path, layer=layers[0])
print("DataFrame loaded:", gdf.shape)

# 🔹 Cek CRS GeoDataFrame
if gdf.crs is None:
    gdf = gdf.set_crs("EPSG:4326")
    print("CRS tidak ditemukan, di-set ke EPSG:4326")
else:
    print(f"CRS GeoDataFrame: {gdf.crs}")

# Koneksi ke PostGIS
engine = create_engine(
    "postgresql://postgres.67888:password00@172.16.2.122:5432/postgres"
)

# 🔹 Cek / buat schema jika belum ada
with engine.connect() as conn:
    result = conn.execute(
        text("SELECT schema_name FROM information_schema.schemata WHERE schema_name=:schema"),
        {"schema": SCHEMA}
    )
    if result.first() is None:
        conn.execute(text(f"CREATE SCHEMA {SCHEMA}"))
        print(f"Schema '{SCHEMA}' dibuat.")
    else:
        print(f"Schema '{SCHEMA}' sudah ada.")

# Upload ke tabel PostGIS dengan schema khusus
gdf.to_postgis(
    name=layers[0],
    con=engine,
    schema=SCHEMA,
    if_exists="replace",
    index=False
)
print(f"Upload to PostGIS schema '{SCHEMA}' completed!")

# Hapus folder hasil ekstrak GDB
try:
    shutil.rmtree(gdb_path)
    print(f"Folder {gdb_path} berhasil dihapus.")
except Exception as e:
    print(f"Gagal menghapus folder {gdb_path}: {e}")
