import geopandas as gpd
from sqlalchemy import create_engine, text
from shapely.geometry import MultiPolygon, Polygon
import pandas as pd
import sys

# --- 1. Detail Koneksi Database ---
DB_USER = "postgres.67888"
DB_PASS = "password00"
DB_HOST = "172.16.2.122"
DB_PORT = "5432"
DB_NAME = "postgres"

conn_string = f"postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(conn_string)

SCHEMA = "datagis"
TABLE_A = "ADM_KAB_KOTA"
FIELD_DISS = "WADMPR"
TABLE_OUTPUT = "ADM_KAB_KOTA_DISS"

def run_process():
    try:
        # --- 2. Membaca Data ---
        print(f"📂 Membaca data dari {SCHEMA}.{TABLE_A}...")
        sql_read = f'SELECT "{FIELD_DISS}", geom FROM "{SCHEMA}"."{TABLE_A}"'
        gdf = gpd.read_postgis(sql_read, engine, geom_col='geom')

        if gdf.empty:
            print("❌ Data kosong. Proses dihentikan.")
            return

        # --- 3. Operasi Dissolve & Pembersihan Geometri ---
        print(f"🧩 Melakukan dissolve berdasarkan: {FIELD_DISS}...")

        # Dissolve awal
        gdf_dissolved = gdf.dissolve(by=FIELD_DISS).reset_index()

        # FIX: Mengatasi GeometryCollection agar menjadi MultiPolygon murni
        print("🧹 Membersihkan geometri (Explode & Filter Polygon)...")
        # Explode memecah MultiPolygon/Collection menjadi baris tunggal (Polygon)
        gdf_exploded = gdf_dissolved.explode(index_parts=False)

        # Hanya ambil yang bertipe Polygon (membuang Point/Line sisa dissolve jika ada)
        gdf_polygons = gdf_exploded[gdf_exploded.geometry.type == 'Polygon'].copy()

        # Gabungkan kembali menjadi MultiPolygon per grup WADMPR
        gdf_final = gdf_polygons.dissolve(by=FIELD_DISS).reset_index()

        # Memastikan hanya kolom WADMPR dan geometri
        gdf_output = gdf_final[[FIELD_DISS, 'geom']]

        # --- 4. Menyimpan Hasil ---
        print(f"💾 Menyimpan hasil bersih ke {SCHEMA}.{TABLE_OUTPUT}...")
        # Kita paksa skema database menggunakan MultiPolygon
        gdf_output.to_postgis(
            TABLE_OUTPUT,
            engine,
            schema=SCHEMA,
            if_exists='replace',
            index=False,
            dtype={'geom': 'MultiPolygon'} 
        )

        # --- 5. Kalkulasi Luas via PostGIS SQL (CEA) ---
        print(f"📏 Menghitung Luas (CEA) via PostGIS...")
        full_table_path = f'"{SCHEMA}"."{TABLE_OUTPUT}"'

        sql_commands = [
            f'ALTER TABLE {full_table_path} ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;',
            # Tambahkan ST_Multi untuk memastikan tipe data di kolom geom konsisten MultiPolygon
            f'UPDATE {full_table_path} SET geom = ST_Multi(ST_CollectionExtract(geom, 3));',
            f'UPDATE {full_table_path} SET "LUAS_CEA_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000;'
        ]

        with engine.connect() as conn:
            for cmd in sql_commands:
                conn.execute(text(cmd))
            conn.commit()

        print(f"✅ Selesai! Tabel {TABLE_OUTPUT} kini berisi MultiPolygon murni.")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")
        sys.exit(1)

if __name__ == "__main__":
    run_process()
