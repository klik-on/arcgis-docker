#!/bin/bash
set -e

IGT="REHAB_DAS"
DATA_DIR="/app/data"
GEOJSON_PATH="${DATA_DIR}/${IGT}.geojson"
GDB_DIR="${DATA_DIR}/${IGT}.gdb"
ZIP_PATH="${DATA_DIR}/${IGT}.gdb.zip"

# Opsional: Logging ke file (aktifkan jika perlu)
# LOG_FILE="${DATA_DIR}/log_${IGT}_$(date +%Y%m%d%H%M%S).log"
# exec > >(tee -a "$LOG_FILE") 2>&1

# Pastikan direktori data ada
mkdir -p "$DATA_DIR"

echo "🚀 Menjalankan script Python untuk ambil data dan buat GeoJSON..."
if ! python3 sipdas_geojson.py; then
  echo "❌ Gagal menjalankan sipdas_geojson.py"
  exit 1
fi

if [ ! -f "$GEOJSON_PATH" ]; then
  echo "❌ File GeoJSON tidak ditemukan: $GEOJSON_PATH"
  exit 1
fi

if ! command -v ogr2ogr &> /dev/null; then
  echo "❌ Perintah 'ogr2ogr' tidak ditemukan. Pastikan GDAL terinstal dengan benar."
  exit 1
fi

echo "🚀 Mengkonversi GeoJSON ke OpenFileGDB menggunakan ogr2ogr..."
ogr2ogr -f "OpenFileGDB" \
  "$GDB_DIR" \
  "$GEOJSON_PATH" \
  -dim 2 \
  -nln "$IGT" \
  -nlt MULTIPOLYGON \
  -t_srs EPSG:4326 \
  -progress \
  --config OGR_OPENFILEGDB_METHOD SKIP \
  --config OGR_ENABLE_CURVE_REDUCTION YES \
  --config OGR_ORGANIZE_POLYGONS SKIP

echo "📦 Membuat archive ZIP dari ${IGT}.gdb..."
cd "$DATA_DIR"
zip -r "${ZIP_PATH}" "${IGT}.gdb"

echo "🧹 Menghapus folder ${IGT}.gdb dan file ${IGT}.geojson..."
rm -rf "$GDB_DIR"
rm -f "$GEOJSON_PATH"

echo "✅ Proses selesai! File ZIP tersimpan di: ${ZIP_PATH}"
