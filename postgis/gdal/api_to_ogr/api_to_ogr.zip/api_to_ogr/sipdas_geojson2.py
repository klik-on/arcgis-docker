import requests
import json
import urllib3
import os
import subprocess
import shutil

# ==============================
# Konfigurasi
# ==============================
IGT = "REHAB_DAS"
DATA_DIR = "/app/data"
GEOJSON_PATH = f"{DATA_DIR}/{IGT}.geojson"
GDB_DIR = f"{DATA_DIR}/{IGT}.gdb"
ZIP_PATH = f"{DATA_DIR}/{IGT}.gdb.zip"

# Pastikan folder output ada
os.makedirs(DATA_DIR, exist_ok=True)

# Nonaktifkan warning SSL (karena verify=False)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# URL ArcGIS REST API
url = "https://ditjen-pdasrh.kehutanan.go.id/server/rest/services/REHAB_DAS/MapServer/0/query"
params = {
    "where": "1=1",
    "outFields": "*",
    "f": "geojson",
    "token": "IJvO8W_TbKxE9SgDiBJE-fBCeE83iLwqzlNIekxJtxK05bnJuXQGIYlkize1EAa2nfvnfVnwfW-nBDluaZ237MhnVW_WvyxNdBXEaVkLJReTHkj6lZklYo1hY1QvBDK7IDyHOGcjNwArRUZ_PkiWVzlVG19IW0rzxwVQVDwIAq9Txrg3SKz-W5jcAABCMp4dxK9izY40CbOglUjiFDIYLA.."
}

# ==============================
# 1️⃣ Ambil data GeoJSON dari server
# ==============================
try:
    print("🌐 Mengambil data dari ArcGIS REST API...")
    response = requests.get(url, params=params, verify=False)
    response.raise_for_status()

    geojson_data = response.json()

    if not geojson_data.get("features"):
        print("⚠️ Tidak ada fitur yang dikembalikan dari server.")
    else:
        print(f"✅ Jumlah fitur yang diterima: {len(geojson_data['features'])}")

    # ==============================
    # 2️⃣ Ubah semua nama field ke huruf besar
    # ==============================
    print("🔠 Mengubah semua nama field menjadi huruf besar...")
    for feature in geojson_data.get("features", []):
        if "properties" in feature:
            feature["properties"] = {
                k.upper(): v for k, v in feature["properties"].items()
            }

    # ==============================
    # 3️⃣ Simpan hasil ke file GeoJSON
    # ==============================
    with open(GEOJSON_PATH, "w", encoding="utf-8") as f:
        json.dump(geojson_data, f, ensure_ascii=False, indent=2)

    print(f"💾 Berhasil disimpan ke {GEOJSON_PATH}")

    # ==============================
    # 4️⃣ Konversi ke FileGDB menggunakan ogr2ogr
    # ==============================
    print("🚀 Mengonversi ke FileGDB...")
    subprocess.run([
        "ogr2ogr", "-f", "FileGDB", GDB_DIR, GEOJSON_PATH,
        "-dim", "2",
        "-nln", IGT,
        "-nlt", "MULTIPOLYGON",
        "-t_srs", "EPSG:4326",
        "-progress",
        "--config", "OGR_OPENFILEGDB_METHOD", "SKIP",
        "--config", "OGR_ENABLE_CURVE_REDUCTION", "YES",
        "--config", "OGR_ORGANIZE_POLYGONS", "SKIP"
    ], check=True)

    print(f"✅ FileGDB berhasil dibuat: {GDB_DIR}")

    # ==============================
    # 5️⃣ Membuat ZIP archive dari GDB (REHAB_DAS.gdb.zip)
    # ==============================
    print(f"📦 Membuat archive ZIP dari {IGT}.gdb...")
    shutil.make_archive(
        base_name=ZIP_PATH.replace(".zip", ""),  # base tanpa ekstensi
        format="zip",
        root_dir=DATA_DIR,
        base_dir=f"{IGT}.gdb"
    )
    print(f"✅ ZIP berhasil dibuat: {ZIP_PATH}")

    # ==============================
    # 6️⃣ Hapus file sementara (.geojson dan folder .gdb)
    # ==============================
    print(f"🧹 Menghapus folder {IGT}.gdb dan file {IGT}.geojson...")
    shutil.rmtree(GDB_DIR, ignore_errors=True)
    if os.path.exists(GEOJSON_PATH):
        os.remove(GEOJSON_PATH)

    print(f"✅ Proses selesai! File ZIP tersimpan di: {ZIP_PATH}")

except requests.exceptions.RequestException as e:
    print("❌ Error saat mengakses data:", e)
except json.JSONDecodeError:
    print("❌ Respons API tidak valid (bukan GeoJSON).")
except subprocess.CalledProcessError as e:
    print("❌ Gagal menjalankan ogr2ogr:", e)
except Exception as e:
    print("❌ Terjadi kesalahan tak terduga:", e)
