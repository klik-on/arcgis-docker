#!/bin/bash
set -e

# === 1. Validasi Input ===
if [ -z "$1" ]; then
  echo "❌ Error: Nama layer (file) tidak ditentukan!"
  echo "💡 Penggunaan: $0 NAMA_LAYER_ANDA"
  exit 1
fi

LAYER_NAME="$1"

# === 2. Load .env ===
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

# === 3. Konfigurasi Path ===
DATA_DIR="/app/import_temp"
NEXTCLOUD_REMOTE="${NC_REMOTE:-nextcloud}"
NEXTCLOUD_PATH="${NC_PATH:-GIS/Export}"

ZIP_FILE="${LAYER_NAME}.gdb.zip"
GDB_FOLDER="${LAYER_NAME}.gdb"

# === 4. Persiapan Direktori ===
mkdir -p "$DATA_DIR"
cd "$DATA_DIR"

# === 5. Download dari Nextcloud ===
echo "📥 Mendownload ${ZIP_FILE} dari Nextcloud..."
rclone copy "${NEXTCLOUD_REMOTE}:${NEXTCLOUD_PATH}/${ZIP_FILE}" . --progress

# === 6. Ekstrak File ===
echo "📦 Mengekstrak ${ZIP_FILE}..."
if [ -f "$ZIP_FILE" ]; then
  # Hapus folder GDB lama jika ada hasil sisa sebelumnya
  rm -rf "$GDB_FOLDER"
  unzip -q "$ZIP_FILE"
else
  echo "❌ Error: File zip tidak ditemukan setelah download!"
  exit 1
fi

# === 7. Import ke PostGIS ===
echo "🚀 Mengimpor ${LAYER_NAME} ke PostGIS..."

# LD_LIBRARY_PATH untuk FileGDB API
if [ -d "/usr/local/FileGDB_API/lib" ]; then
  export LD_LIBRARY_PATH="/usr/local/FileGDB_API/lib:${LD_LIBRARY_PATH:-}"
fi

ogr2ogr \
  -f "PostgreSQL" \
  PG:"host=${DB_HOST} port=${DB_PORT} dbname=${DB_NAME} user='${DB_USER}' password='${DB_PASS}'" \
  "$GDB_FOLDER" \
  -nln "${DB_SCHEMA}.${LAYER_NAME}" \
  -overwrite \
  -progress \
  -t_srs EPSG:4326 \
  -nlt PROMOTE_TO_MULTI \
  --config PG_USE_COPY YES

# === 8. Cleanup ===
echo "🧹 Membersihkan file sementara..."
rm -f "$ZIP_FILE"
rm -rf "$GDB_FOLDER"

echo "✅ Berhasil: Layer ${LAYER_NAME} telah diimpor ke database."
