#!/bin/bash
set -e

# === 1. Validasi Input ===
# Cek apakah argumen pertama ($1) kosong
if [ -z "$1" ]; then
  echo "❌ Error: Nama layer tidak ditentukan!"
  echo "💡 Penggunaan: $0 NAMA_LAYER_ANDA"
  echo "💡 Penggunaan Multi : for layer in Layer1 Layer2 Layer3; do $0 $layer; done "
  exit 1
fi

LAYER_NAME="$1"

# === 2. Load .env (Jika ada, untuk Docker environment) ===
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

# === 3. Konfigurasi Path ===
DATA_DIR="/app/data"
OUTPUT_GDB="${DATA_DIR}/${LAYER_NAME}.gdb"
OUTPUT_ZIP="${DATA_DIR}/${LAYER_NAME}.gdb.zip"

NEXTCLOUD_REMOTE="${NC_REMOTE:-nextcloud}"
NEXTCLOUD_PATH="${NC_PATH:-GIS/Export}"

# === 4. Cek Driver FileGDB API ===
if [ -d "/usr/local/FileGDB_API/lib" ]; then
  export LD_LIBRARY_PATH="/usr/local/FileGDB_API/lib:${LD_LIBRARY_PATH:-}"
fi

# === 5. Ekspor ke FileGDB ===
mkdir -p "$DATA_DIR"

# Hapus GDB lama jika ada agar tidak tertumpuk
if [ -d "$OUTPUT_GDB" ]; then
  echo "🗑️  Menghapus folder lama: $OUTPUT_GDB"
  rm -rf "$OUTPUT_GDB"
fi

echo "🚀 Mengekspor Layer: ${LAYER_NAME}..."

ogr2ogr \
  -f "FileGDB" \
  "$OUTPUT_GDB" \
  PG:"host=${DB_HOST} port=${DB_PORT} dbname=${DB_NAME} user='${DB_USER}' password='${DB_PASS}'" \
  "${DB_SCHEMA}.${LAYER_NAME}" \
  -nln "$LAYER_NAME" \
  -dim 2 \
  -t_srs EPSG:4326 \
  -nlt PROMOTE_TO_MULTI \
  -skipfailures \
  -lco TARGET_ARCGIS_VERSION=ARCGIS_PRO_3_2_OR_LATER \
  -progress \
  --config OGR_ORGANIZE_POLYGONS SKIP \
  --config OGR_ENABLE_CURVE_REDUCTION YES

# === 6. Kompresi & Upload ===
echo "📦 Mengompres dan Mengunggah ke Nextcloud..."
cd "$DATA_DIR"
# Zip folder GDB menjadi satu file .zip
zip -r "$(basename "$OUTPUT_ZIP")" "$(basename "$OUTPUT_GDB")"

rclone copy "$OUTPUT_ZIP" "${NEXTCLOUD_REMOTE}:${NEXTCLOUD_PATH}" --progress

# === 7. Cleanup ===
rm -rf "$OUTPUT_GDB"
rm -f "$OUTPUT_ZIP"
echo "✅ Berhasil: ${LAYER_NAME} telah diunggah ke Nextcloud."
