# docker cp CA.crt api-to-ogr:/usr/local/share/ca-certificates/CA.crt
# docker exec -it api-to-ogr update-ca-certificates
# docker exec -it api-to-ogr rclone config create nextcloud webdav url=https://dbgis.menlhk.go.id:8080/remote.php/dav/files/datagis/ vendor=nextcloud user=datagis pass=Pass#45678
# docker exec -it api-to-ogr rclone copy /app/data/PBPH_DEFINITIF.gdb.zip nextcloud:GIS/Export --progress

#!/bin/bash
set -e

# === Muat variabel dari .env (jika ada) ===
if [ -f .env ]; then
  echo "📦 Memuat variabel dari .env..."
  set -a
  source .env
  set +a
fi

# === Konfigurasi PostgreSQL ===
PG_HOST="172.16.2.122"
PG_PORT="5432"
PG_DB="postgres"
PG_USER="postgres.67888"
PG_PASS="password00"
PG_SCHEMA="datagis"

# === Layer & direktori ===
LAYER_NAME="KUPS"
DATA_DIR="/app/data"
OUTPUT_GDB="${DATA_DIR}/${LAYER_NAME}.gdb"
OUTPUT_ZIP="${DATA_DIR}/${LAYER_NAME}.gdb.zip"

# === Remote Nextcloud ===
NEXTCLOUD_REMOTE="nextcloud"
NEXTCLOUD_PATH="GIS/Export"

# === Cek dependensi utama ===
for cmd in ogr2ogr ogrinfo rclone zip; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "❌ Perintah $cmd tidak ditemukan. Pastikan sudah terinstal."; exit 1; }
done

# === Atur LD_LIBRARY_PATH untuk FileGDB API resmi ===
if [ -f "/usr/local/FileGDB_API/lib/libFileGDBAPI.so" ]; then
  export LD_LIBRARY_PATH="/usr/local/FileGDB_API/lib:${LD_LIBRARY_PATH:-}"
  echo "🔧 FileGDB API resmi ditemukan. LD_LIBRARY_PATH diatur."
else
  echo "⚠️ FileGDB API resmi tidak ditemukan. Akan coba fallback otomatis."
fi

# === Deteksi driver GDAL ===
if ogrinfo --formats | grep -qE "FileGDB.*(rw\\+)"; then
  DRIVER="FileGDB"
  echo "✅ Menggunakan driver GDAL resmi FileGDB (rw+)"
elif ogrinfo --formats | grep -q "OpenFileGDB"; then
  DRIVER="OpenFileGDB"
  echo "⚠️ Fallback: Menggunakan driver OpenFileGDB (fitur write terbatas)"
else
  echo "❌ Tidak ada driver GDB yang tersedia di GDAL"
  exit 1
fi

# === Siapkan direktori kerja ===
mkdir -p "$DATA_DIR"
rm -rf "$OUTPUT_GDB"

echo "🚀 Mengekspor layer ${LAYER_NAME} dari PostgreSQL ke ${DRIVER}..."

# === Jalankan ekspor dengan opsi dari pgis_to_gdb.sh ===
export CPL_LOG=OFF  # Nonaktifkan log GDAL berlebihan

OGR_ARGS=(
  -f "$DRIVER"
  "$OUTPUT_GDB"
  PG:"host=${PG_HOST} port=${PG_PORT} dbname=${PG_DB} user='${PG_USER}' password=${PG_PASS}"
  "${PG_SCHEMA}.${LAYER_NAME}"
  -nln "$LAYER_NAME"
  -dim 2
  -t_srs EPSG:4326
  -nlt PROMOTE_TO_MULTI
  -progress
  --config OGR_ENABLE_CURVE_REDUCTION YES
  --config OGR_ORGANIZE_POLYGONS SKIP
)

# Gunakan OVERWRITE hanya jika FileGDB resmi
if [ "$DRIVER" = "FileGDB" ]; then
  OGR_ARGS+=(-lco OVERWRITE=YES)
fi

ogr2ogr "${OGR_ARGS[@]}"

# === Validasi hasil ekspor ===
if [ ! -d "$OUTPUT_GDB" ]; then
  echo "❌ Ekspor gagal: folder ${OUTPUT_GDB} tidak ditemukan."
  exit 1
fi
echo "✅ Ekspor selesai. File GDB: $OUTPUT_GDB"

# === Kompres ke ZIP ===
echo "📦 Mengarsipkan ${LAYER_NAME}.gdb ke ZIP..."
(
  cd "$DATA_DIR" || exit 1
  zip -r "$(basename "$OUTPUT_ZIP")" "$(basename "$OUTPUT_GDB")" > /dev/null
)
echo "✅ File ZIP dibuat: $OUTPUT_ZIP"

# === Hapus folder GDB setelah kompresi ===
echo "🧹 Menghapus folder ${LAYER_NAME}.gdb..."
rm -rf "${OUTPUT_GDB}"

# === Upload ke Nextcloud via rclone ===
echo "☁️ Mengunggah ${LAYER_NAME}.gdb.zip ke Nextcloud..."
rclone copy "${OUTPUT_ZIP}" "${NEXTCLOUD_REMOTE}:${NEXTCLOUD_PATH}" --progress

if rclone ls "${NEXTCLOUD_REMOTE}:${NEXTCLOUD_PATH}" | grep -q "${LAYER_NAME}.gdb.zip"; then
  echo "✅ Semua selesai! File ZIP diunggah ke Nextcloud:"
  echo "   📁 ${NEXTCLOUD_PATH}/${LAYER_NAME}.gdb.zip"
else
  echo "⚠️ Upload ke Nextcloud mungkin gagal. Periksa koneksi atau kredensial rclone."
fi

echo "🕒 Selesai: $(date)"
