#!/bin/bash
set -e

# === 2. Muat Variabel & Konfigurasi ===
if [ -f .env ]; then
  source .env
fi

PG_HOST="172.16.2.122"
PG_PORT="5432"
PG_DB="postgres"
PG_USER="postgres.67888"
PG_PASS="password00"
PG_SCHEMA="datagis"

# Layer name bisa diubah sesuai tabel yang ingin diekspor
LAYER_NAME="PL_DKI_JAKARTA_CLIP" 
DATA_DIR="/app/data"
OUTPUT_GDB="${DATA_DIR}/${LAYER_NAME}.gdb"
OUTPUT_ZIP="${DATA_DIR}/${LAYER_NAME}.gdb.zip"

NEXTCLOUD_REMOTE="nextcloud"
NEXTCLOUD_PATH="GIS/Export"

# === 3. Cek Driver ===
if [ -f "/usr/local/FileGDB_API/lib/libFileGDBAPI.so" ]; then
  export LD_LIBRARY_PATH="/usr/local/FileGDB_API/lib:${LD_LIBRARY_PATH:-}"
fi

# === 4. Ekspor ke FileGDB ===
mkdir -p "$DATA_DIR"

if [ -d "$OUTPUT_GDB" ]; then
  echo "🗑️ Menghapus folder GDB lama..."
  rm -rf "$OUTPUT_GDB"
fi

echo "🚀 Mengekspor ${LAYER_NAME} ke FileGDB (Universal Mode)..."

# MODIFIKASI UTAMA:
# 1. Menggunakan -nlt PROMOTE_TO_MULTI agar:
#    - Polygon -> MultiPolygon
#    - LineString -> MultiLineString
#    - Point -> Tetap Point/MultiPoint
# 2. Menghapus paksaan MULTIPOLYGON agar tidak error saat ekspor Point/Line.

OGR_ARGS=(
  -f "OpenFileGDB"
  "$OUTPUT_GDB"
  PG:"host=${PG_HOST} port=${PG_PORT} dbname=${PG_DB} user='${PG_USER}' password=${PG_PASS}"
  "${PG_SCHEMA}.${LAYER_NAME}"
  -nln "$LAYER_NAME"
  -dim 2
  -t_srs EPSG:4326
  -nlt PROMOTE_TO_MULTI   # Otomatis menyesuaikan ke tipe Multi yang relevan
  -skipfailures
  -lco TARGET_ARCGIS_VERSION=ARCGIS_PRO_3_2_OR_LATER
  -progress
  --config OGR_ORGANIZE_POLYGONS SKIP
  --config OGR_ENABLE_CURVE_REDUCTION YES
)

# Eksekusi perintah
ogr2ogr "${OGR_ARGS[@]}"

# === 5. Kompresi & Upload ===
echo "📦 Mengarsipkan dan Mengunggah ke Nextcloud..."
(cd "$DATA_DIR" && zip -r "$(basename "$OUTPUT_ZIP")" "$(basename "$OUTPUT_GDB")" > /dev/null)

rclone copy "$OUTPUT_ZIP" "${NEXTCLOUD_REMOTE}:${NEXTCLOUD_PATH}" --progress

# === 6. Cleanup ===
rm -rf "$OUTPUT_GDB"
rm -f "$OUTPUT_ZIP"
echo "✅ Pipeline Selesai: $(date)"
