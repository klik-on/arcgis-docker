import os
import sys
import json
import binascii
import requests
from shapely import wkb
from shapely.geometry import mapping

# ==============================
# 1️⃣ Konfigurasi API dan output
# ==============================
IGT = "PBPH_DEFINITIF"
KONDISI = "select=*"
USERNAME = os.getenv("USERNAME")
PASSWORD = os.getenv("PASSWORD")

if not USERNAME or not PASSWORD:
    print("❌ USERNAME dan PASSWORD tidak ditemukan di environment.")
    sys.exit(1)

BASE_URL = "https://phl.menlhk.go.id"
ENDPOINT = f"{BASE_URL}/api/v1/{IGT}?{KONDISI}"
OUTPUT_PATH = f"/app/data/{IGT}.geojson"

print(f"🌐 Mengambil data dari API: {ENDPOINT}")
try:
    response = requests.get(ENDPOINT, auth=(USERNAME, PASSWORD), timeout=10)
    response.raise_for_status()
except requests.exceptions.RequestException as e:
    print(f"❌ Error saat mengakses API: {e}")
    sys.exit(1)

try:
    data_json = response.json()
except Exception as e:
    print(f"❌ Gagal parsing JSON: {e}")
    sys.exit(1)

if not data_json.get("status") or "data" not in data_json:
    print("❌ Struktur data tidak sesuai.")
    sys.exit(1)

entries = data_json["data"]
features = []

for idx, item in enumerate(entries, start=1):
    geom_wkb_hex = item.get("geom")
    if not geom_wkb_hex or len(geom_wkb_hex.strip()) < 4:
        print(f"⚠️ Entry ke-{idx} tidak memiliki 'geom' yang valid.")
        continue

    try:
        geom_wkb = binascii.unhexlify(geom_wkb_hex)
        geom = wkb.loads(geom_wkb)
        geojson_geom = mapping(geom)
    except Exception as e:
        print(f"⚠️ Gagal parsing WKB di entry ke-{idx}: {e}")
        continue

    feature = {
        "type": "Feature",
        "geometry": geojson_geom,
        "properties": {k: v for k, v in item.items() if k != "geom"}
    }
    features.append(feature)
    print(f"✅ Parsed entry ke-{idx}")

if not features:
    print("❌ Tidak ada fitur valid untuk disimpan.")
    sys.exit(1)

geojson_obj = {
    "type": "FeatureCollection",
    "features": features
}

# ==============================
# 2️⃣ Ubah semua nama field ke huruf besar
# ==============================
print("🔠 Mengubah semua nama field menjadi huruf besar...")
for feature in geojson_obj.get("features", []):
    if "properties" in feature:
        feature["properties"] = {
            k.upper(): v for k, v in feature["properties"].items()
        }

# ==============================
# 3️⃣ Simpan hasil ke file GeoJSON
# ==============================
os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)

try:
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(geojson_obj, f, ensure_ascii=False, indent=2)
except Exception as e:
    print(f"❌ Gagal menyimpan file GeoJSON: {e}")
    sys.exit(1)

print(f"\n✅ GeoJSON berhasil disimpan di: {OUTPUT_PATH}")
print(f"📦 Total fitur disimpan: {len(features)}")
