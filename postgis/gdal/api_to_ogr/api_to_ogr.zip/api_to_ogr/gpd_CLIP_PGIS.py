import sys
import os
import time
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

# Memuat variabel lingkungan dari file .env
load_dotenv()

# =================================================================
# 1. KONFIGURASI DATABASE & PARAMETER
# =================================================================
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT')
DB_NAME = os.getenv('DB_NAME')

# Parameter Skema & Tabel
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
OUT_SCHEMA = os.getenv("SCHEMA_OUT", "analisis")

TABLE_A = "KWSHUTAN_AR_250K_v18102025"
FIELD_CATEGORY_A = "FUNGSIKWS" # Kolom untuk ringkasan

TABLE_B = "ADM_KAB_KOTA"
FIELD_FILTER_B = "WADMPR"    # Kolom untuk filter wilayah

# Validasi awal
if not all([DB_USER, DB_PASS, DB_HOST, DB_NAME]):
    print("❌ ERROR: Konfigurasi database di file .env tidak lengkap!")
    sys.exit(1)

# Menggunakan +psycopg untuk library versi 3
engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

# =================================================================
# 2. PENANGANAN ARGUMEN & PARAMETER DINAMIS
# =================================================================
if len(sys.argv) < 2:
    SCRIPT_NAME = os.path.basename(__file__)
    print(f"\n💡 PENGGUNAAN: python3 {SCRIPT_NAME} \"Nama Wilayah\"")
    print(f"📝 CONTOH:      python3 {SCRIPT_NAME} \"DKI Jakarta\"\n")
    sys.exit(1)

PROVINSI_TARGET = sys.argv[1]
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

OUT_TABLE = f"KWS_{SAFE_NAME}_CLIP"
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE}"'

print("-" * 60)
print(f"🚀 Memulai Optimized CLIP (Full Columns): {PROVINSI_TARGET}")
print(f"📂 Simpan ke: {RESULT_TABLE_FULL}")
print("-" * 60)

# =================================================================
# 3. EKSEKUSI PROSES SPASIAL (POSTGIS ENGINE)
# =================================================================
try:
    with engine.begin() as conn:
        # A. Persiapan Skema dan Drop Table lama
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))
        conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL};'))

        # B. Eksekusi Intersection (DIPISAH dari ALTER untuk menghindari error prepared statement)
        print(f"✂️  Memproses: {TABLE_A} CLIP BY {PROVINSI_TARGET}...")
        
        query_create = text(f"""
            CREATE TABLE {RESULT_TABLE_FULL} AS
            WITH mask AS (
                SELECT ST_MakeValid(ST_Union(geom)) as geom_mask
                FROM "{SCHEMA}"."{TABLE_B}"
                WHERE "{FIELD_FILTER_B}" ILIKE :prov
            )
            SELECT
                a.*, 
                ST_Multi(ST_CollectionExtract(
                    ST_Intersection(a.geom, m.geom_mask), 3
                )) as geom_new,
                ST_Area(ST_Transform(ST_CollectionExtract(ST_Intersection(a.geom, m.geom_mask), 3), 54034)) / 10000 as "LUAS_CEA_HA"
            FROM "{SCHEMA}"."{TABLE_A}" a
            JOIN mask m ON ST_Intersects(a.geom, m.geom_mask)
            WHERE NOT ST_IsEmpty(ST_Intersection(a.geom, m.geom_mask));
        """)
        conn.execute(query_create, {"prov": PROVINSI_TARGET})

        # C. Menyelaraskan Kolom Geometri (Hapus yang lama, ganti yang baru)
        print(f"🔄 Menyelaraskan struktur atribut...")
        conn.execute(text(f'ALTER TABLE {RESULT_TABLE_FULL} DROP COLUMN geom;'))
        conn.execute(text(f'ALTER TABLE {RESULT_TABLE_FULL} RENAME COLUMN geom_new TO geom;'))

        # D. Optimasi Database (Indexing & Analyze)
        print(f"🛠️  Membuat Index Spasial & Optimasi...")
        conn.execute(text(f'CREATE INDEX ON {RESULT_TABLE_FULL} USING GIST(geom);'))
        conn.execute(text(f'ANALYZE {RESULT_TABLE_FULL};'))

# =================================================================
# 4. RINGKASAN DATA (SUMMARY)
# =================================================================
    query_summary = f'SELECT "{FIELD_CATEGORY_A}", SUM("LUAS_CEA_HA") as total_ha FROM {RESULT_TABLE_FULL} GROUP BY 1 ORDER BY 2 DESC'
    summary_df = pd.read_sql(query_summary, engine)

    print(f"\n📊 RINGKASAN {PROVINSI_TARGET} (Kolom: {FIELD_CATEGORY_A}):")
    if not summary_df.empty:
        pd.options.display.float_format = '{:,.2f}'.format
        print(summary_df.to_string(index=False))
        
        total_seluruh = summary_df['total_ha'].sum()
        print("-" * 30)
        print(f"TOTAL LUAS: {total_seluruh:,.2f} HA")
    else:
        print(f"⚠️ Tidak ada data ditemukan untuk '{PROVINSI_TARGET}'")

# =================================================================
# 5. INFORMASI AKHIR
# =================================================================
    duration = time.time() - start_time
    print(f"\n✅ Selesai dalam {duration:.2f} detik.")
    print("-" * 60)

except Exception as e:
    print(f"\n❌ TERJADI ERROR:")
    print(f"Detail: {e}")
    sys.exit(1)
