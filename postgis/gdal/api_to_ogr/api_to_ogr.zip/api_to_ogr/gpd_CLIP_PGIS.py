import sys
import os
import time
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

load_dotenv()

# --- Detail Koneksi ---
engine = create_engine(f"postgresql+psycopg://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}")
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
OUT_SCHEMA = os.getenv("SCHEMA_OUT", "analisis")

# --- 1. Ambil Argumen Command Line & Penanganan Error ---
if len(sys.argv) < 2:
    print("\n" + "="*50)
    print("❌ ERROR: NAMA PROVINSI HARUS DISERTAKAN!")
    print("="*50)
    print("💡 CARA PENGGUNAAN:")
    print("   python3 gpd_CLIP_PGIS.py \"Nama Provinsi\"")
    print("\n📝 CONTOH:")
    print("   python3 gpd_CLIP_PGIS.py \"Kalimantan Barat\"")
    print("   python3 gpd_CLIP_PGIS.py \"DKI Jakarta\"")
    print("="*50 + "\n")
    sys.exit(1)

PROVINSI_TARGET = sys.argv[1]
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').upper()
start_time = time.time()

# Konfigurasi Tabel
TABLE_A = "KWSHUTAN_AR_250K_v18102025"
TABLE_B = "ADM_KAB_KOTA"
OUT_TABLE = f"KWS_{SAFE_NAME}_CLIP"
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE}"'

print(f"🚀 Memulai Optimized CLIP: {PROVINSI_TARGET}")

try:
    with engine.begin() as conn:
        # 1. Persiapan Skema dan Drop Table
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))
        conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL};'))

        # 2. Eksekusi Utama: Pembuatan Tabel dengan ST_Intersection & Luas (Atomic)
        print(f"✂️  Memproses Geometri...")
        query_main = text(f"""
            CREATE TABLE {RESULT_TABLE_FULL} AS
            WITH mask AS (
                SELECT ST_MakeValid(ST_Union(geom)) as geom_mask
                FROM "{SCHEMA}"."{TABLE_B}"
                WHERE "WADMPR" ILIKE :prov
            )
            SELECT 
                a."FUNGSIKWS",
                ST_Multi(ST_CollectionExtract(
                    ST_Intersection(a.geom, m.geom_mask), 3
                )) as geom,
                ST_Area(ST_Transform(ST_CollectionExtract(ST_Intersection(a.geom, m.geom_mask), 3), 54034)) / 10000 as "LUAS_CEA_HA"
            FROM "{SCHEMA}"."{TABLE_A}" a
            JOIN mask m ON ST_Intersects(a.geom, m.geom_mask)
            WHERE NOT ST_IsEmpty(ST_Intersection(a.geom, m.geom_mask));
        """)
        conn.execute(query_main, {"prov": PROVINSI_TARGET})

        # 3. Finalisasi: Indexing
        print(f"🛠️  Membuat Index Spasial...")
        conn.execute(text(f'CREATE INDEX ON {RESULT_TABLE_FULL} USING GIST(geom);'))
        conn.execute(text(f'ANALYZE {RESULT_TABLE_FULL};'))

    # --- 4. Ringkasan Luas ---
    query_summary = f'SELECT "FUNGSIKWS", SUM("LUAS_CEA_HA") as total_ha FROM {RESULT_TABLE_FULL} GROUP BY 1 ORDER BY 2 DESC'
    summary_df = pd.read_sql(query_summary, engine)

    print(f"\n📊 RINGKASAN {PROVINSI_TARGET}:")
    if not summary_df.empty:
        # Mengatur format angka: ribuan dipisah koma, 2 desimal
        pd.options.display.float_format = '{:,.2f}'.format
        print(summary_df.to_string(index=False))
    else:
        print("⚠️ Tidak ada data untuk diringkas.")

    # --- 5. Output Akhir ---
    duration = time.time() - start_time
    print(f"\n✅ Selesai dalam {duration:.2f} detik.")
    print(f"📂 Hasil: {RESULT_TABLE_FULL}")

except Exception as e:
    print(f"\n❌ Error Terjadi: {e}")
    sys.exit(1)
