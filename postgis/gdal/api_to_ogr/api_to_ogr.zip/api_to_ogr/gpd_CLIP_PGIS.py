import sys
import os
import time
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

# Memuat variabel lingkungan dari file .env
load_dotenv()

# --- 1. Konfigurasi Database ---
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT')
DB_NAME = os.getenv('DB_NAME')

# Validasi koneksi awal
if not all([DB_USER, DB_PASS, DB_HOST, DB_NAME]):
    print("❌ ERROR: Konfigurasi database di file .env tidak lengkap!")
    sys.exit(1)

engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

# --- 2. Konfigurasi Parameter Tabel & Field ---
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
OUT_SCHEMA = os.getenv("SCHEMA_OUT", "analisis")

# Parameter Dinamis
TABLE_A = "KWSHUTAN_AR_250K_v18102025"
FIELD_TABLE_A = "FUNGSIKWS"

TABLE_B = "ADM_KAB_KOTA"
FIELD_TABLE_B = "WADMPR" # Kolom untuk filter wilayah (Provinsi)

# --- 3. Penanganan Argumen Command Line ---
if len(sys.argv) < 2:
    SCRIPT_NAME = os.path.basename(__file__)
    print("\n" + "!"*60)
    print("❌ ERROR: ARGUMEN TIDAK LENGKAP")
    print("!"*60)
    print(f"💡 CARA PENGGUNAAN:")
    print(f"   python3 {SCRIPT_NAME} \"Nama Wilayah\"")
    print("\n📝 CONTOH:")
    print(f"   python3 {SCRIPT_NAME} \"DKI Jakarta\"")
    print(f"   python3 {SCRIPT_NAME} \"Kalimantan Barat\"")
    print("-" * 60)
    print(f"ℹ️  Info: Filter dilakukan pada kolom [{FIELD_TABLE_B}]")
    print("!"*60 + "\n")
    sys.exit(1)

PROVINSI_TARGET = sys.argv[1]
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

# Penamaan Tabel Output
OUT_TABLE = f"KWS_{SAFE_NAME}_CLIP"
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE}"'

print(f"🚀 Memulai Optimized CLIP: {PROVINSI_TARGET}")

try:
    with engine.begin() as conn:
        # A. Persiapan Skema dan Drop Table lama
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))
        conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL};'))

        # B. Eksekusi Proses Spasial (ST_Intersection & ST_Area)
        # 54034 adalah SRID untuk World Cylindrical Equal Area (satuan Meter)
        print(f"✂️  Memproses: {TABLE_A}({FIELD_TABLE_A}) CLIP BY {TABLE_B}({FIELD_TABLE_B})")
        
        query_main = text(f"""
            CREATE TABLE {RESULT_TABLE_FULL} AS
            WITH mask AS (
                SELECT ST_MakeValid(ST_Union(geom)) as geom_mask
                FROM "{SCHEMA}"."{TABLE_B}"
                WHERE "{FIELD_TABLE_B}" ILIKE :prov
            )
            SELECT
                a."{FIELD_TABLE_A}",
                ST_Multi(ST_CollectionExtract(
                    ST_Intersection(a.geom, m.geom_mask), 3
                )) as geom,
                ST_Area(ST_Transform(ST_CollectionExtract(ST_Intersection(a.geom, m.geom_mask), 3), 54034)) / 10000 as "LUAS_CEA_HA"
            FROM "{SCHEMA}"."{TABLE_A}" a
            JOIN mask m ON ST_Intersects(a.geom, m.geom_mask)
            WHERE NOT ST_IsEmpty(ST_Intersection(a.geom, m.geom_mask));
        """)

        conn.execute(query_main, {"prov": PROVINSI_TARGET})

        # C. Optimasi Database (Indexing & Analyze)
        print(f"🛠️  Membuat Index Spasial & Optimasi...")
        conn.execute(text(f'CREATE INDEX ON {RESULT_TABLE_FULL} USING GIST(geom);'))
        conn.execute(text(f'ANALYZE {RESULT_TABLE_FULL};'))

    # --- 4. Ringkasan Data (Summary) ---
    query_summary = f'SELECT "{FIELD_TABLE_A}", SUM("LUAS_CEA_HA") as total_ha FROM {RESULT_TABLE_FULL} GROUP BY 1 ORDER BY 2 DESC'
    summary_df = pd.read_sql(query_summary, engine)

    print(f"\n📊 RINGKASAN {PROVINSI_TARGET} (Kolom: {FIELD_TABLE_A}):")
    if not summary_df.empty:
        pd.options.display.float_format = '{:,.2f}'.format
        print(summary_df.to_string(index=False))
        
        total_seluruh = summary_df['total_ha'].sum()
        print("-" * 30)
        print(f"TOTAL LUAS: {total_seluruh:,.2f} HA")
    else:
        print(f"⚠️ Tidak ada data ditemukan untuk '{PROVINSI_TARGET}'")

    # --- 5. Informasi Akhir ---
    duration = time.time() - start_time
    print(f"\n✅ Selesai dalam {duration:.2f} detik.")
    print(f"📂 Hasil disimpan di: {RESULT_TABLE_FULL}")

except Exception as e:
    print(f"\n❌ TERJADI ERROR:")
    print(f"Detail: {e}")
    sys.exit(1)
