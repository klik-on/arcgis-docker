import os
import sys
import json
import requests
import urllib3
import logging
import time
from datetime import datetime

# ========== KONFIGURASI LOGGING ==========
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("data/log_kups.log", encoding="utf-8")
    ]
)

# ========== KONFIGURASI ==========
FOLDER_PATH = "data"  # path di dalam container
JSON_PATH = os.path.join(FOLDER_PATH, "kups.json")
GEOJSON_PATH = os.path.join(FOLDER_PATH, "kups.geojson")
API_URL = "https://gokups.menlhk.go.id/api/v1/kups"
PER_PAGE = 100  # Jumlah data per halaman
MAX_RETRIES = 5  # Maksimal percobaan ulang
RETRY_DELAY = 10  # Delay antar percobaan ulang dalam detik

# ========== PERSIAPAN FOLDER ==========
try:
    os.makedirs(FOLDER_PATH, exist_ok=True)
    logging.info(f"📁 Folder disiapkan: {FOLDER_PATH}")
except Exception as e:
    logging.error(f"❌ Gagal membuat folder: {e}")
    sys.exit(1)

# ========== NONAKTIFKAN PERINGATAN SSL ==========
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ========== AMBIL DATA DARI API DENGAN Paginasi ==========
all_kups = []  # Untuk menyimpan semua data dari semua halaman
page = 1

while True:
    for attempt in range(MAX_RETRIES):
        try:
            # Memanggil API dengan parameter paginasi
            response = requests.get(f"{API_URL}?page={page}&per_page={PER_PAGE}", verify=False, timeout=10)
            
            # Cek apakah respons HTML, yang menandakan 429 Too Many Requests
            if "html" in response.text.lower():
                logging.error(f"❌ Respons HTML (mungkin rate-limited) pada halaman {page}. Menunggu dan mencoba lagi...")
                time.sleep(RETRY_DELAY)
                continue
            
            response.raise_for_status()  # Mengecek status code
            
            # Jika permintaan berhasil, keluar dari loop retry
            break
        except requests.exceptions.HTTPError as e:
            if response.status_code == 429:  # Error 429: Too Many Requests
                logging.warning(f"⚠️ Terlalu banyak permintaan. Menunggu {RETRY_DELAY} detik sebelum mencoba lagi...")
                time.sleep(RETRY_DELAY)  # Tunggu beberapa detik sebelum mencoba lagi
                RETRY_DELAY *= 2  # Tingkatkan waktu penundaan (Exponential Backoff)
            else:
                logging.error(f"❌ Gagal mengambil data pada halaman {page}: {e}")
                sys.exit(1)
        except Exception as e:
            logging.error(f"❌ Terjadi kesalahan saat mengambil data pada halaman {page}: {e}")
            sys.exit(1)

    # Memproses data jika berhasil
    try:
        # Cek apakah respons valid sebagai JSON
        try:
            data = response.json()  # Parse JSON dari response
        except json.JSONDecodeError:
            logging.error(f"❌ Gagal mendekode JSON pada halaman {page}. Respons: {response.text}")
            sys.exit(1)

        kups_list = data.get("data", [])
        if not kups_list:
            logging.warning("⚠️ Tidak ada data ditemukan dari API!")
            break  # Keluar dari loop jika data kosong
        all_kups.extend(kups_list)  # Gabungkan data dari halaman ini

        # Cek apakah ada halaman berikutnya
        next_page_url = data.get("next_page_url")
        if not next_page_url:
            logging.info("✅ Semua data telah diambil!")
            break  # Tidak ada halaman berikutnya, keluar dari loop
        else:
            page += 1  # Lanjutkan ke halaman berikutnya
            logging.info(f"📄 Mengambil halaman {page}")

    except Exception as e:
        logging.error(f"❌ Gagal memproses data pada halaman {page}: {e}")
        sys.exit(1)

# ========== MEMBACA DAN KONVERSI KE GEOJSON ==========
features = []
invalid_count = 0

for item in all_kups:
    try:
        lon = float(item["nujur"])
        lat = float(item["lintang"])

        if not (-180 <= lon <= 180 and -90 <= lat <= 90):
            raise ValueError(f"Koordinat di luar batas: lon={lon}, lat={lat}")

        feature = {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [lon, lat]
            },
            "properties": {
                k: v for k, v in item.items() if k not in ["lintang", "nujur"]
            }
        }
        features.append(feature)
    except (KeyError, ValueError, TypeError) as e:
        invalid_count += 1
        logging.warning(f"⚠️ Data dilewati (koordinat tidak valid): {e}")

geojson_data = {
    "type": "FeatureCollection",
    "features": features,
    "metadata": {
        "sumber": API_URL,
        "jumlah_titik": len(features),
        "jumlah_tidak_valid": invalid_count,
        "waktu_dibuat": datetime.now().isoformat()
    }
}

# ========== SIMPAN GEOJSON ==========
try:
    with open(GEOJSON_PATH, "w", encoding="utf-8") as f:
        json.dump(geojson_data, f, ensure_ascii=False, indent=2)
    logging.info(f"✅ Konversi selesai. GeoJSON disimpan di: {GEOJSON_PATH}")
    logging.info(f"🧾 Jumlah titik valid: {len(features)}")
    logging.info(f"🚫 Jumlah titik dilewati (tidak valid): {invalid_count}")
except Exception as e:
    logging.error(f"❌ Gagal menyimpan GeoJSON: {e}")
    sys.exit(1)
