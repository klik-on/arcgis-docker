docker cp /home/dbgis/menlhk_go_id_reissue/Chain_RootCA_Bundle.crt api-to-ogr:/usr/local/share/ca-certificates/CA.crt
docker exec -it api-to-ogr chown root:root  /usr/local/share/ca-certificates/CA.crt
docker exec -it api-to-ogr update-ca-certificates
docker exec -it api-to-ogr rclone config create nextcloud webdav url=https://dbgis.menlhk.go.id:8080/remote.php/dav/files/datagis/ vendor=nextcloud user=datagis pass=jdsIPSDH2025
