import os
import sys
import json
import requests
import urllib3
import logging
import time
from datetime import datetime

# ==============================
# KONFIGURASI FOLDER
# ==============================
FOLDER_PATH = "/app/data"
GEOJSON_PATH = os.path.join(FOLDER_PATH, "kups.geojson")
LOG_PATH = os.path.join(FOLDER_PATH, "log_kups.log")

# Pastikan folder data ada
os.makedirs(FOLDER_PATH, exist_ok=True)

# ==============================
# KONFIGURASI LOGGING
# ==============================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(LOG_PATH, encoding="utf-8")
    ]
)

logging.info(f"📁 Folder dan log disiapkan: {FOLDER_PATH}, {LOG_PATH}")

# ==============================
# NONAKTIFKAN PERINGATAN SSL
# ==============================
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==============================
# KONFIGURASI API
# ==============================
API_URL = "https://gokups.menlhk.go.id/api/v1/kups"
PER_PAGE = 500
MAX_RETRIES = 5
BASE_RETRY_DELAY = 10

# ==============================
# AMBIL DATA DARI API
# ==============================
all_kups = []
page = 1
session = requests.Session()

while True:
    delay = BASE_RETRY_DELAY

    for attempt in range(MAX_RETRIES):
        try:
            response = session.get(
                f"{API_URL}?page={page}&per_page={PER_PAGE}",
                verify=False,
                timeout=10
            )

            if "html" in response.text.lower():
                logging.warning(f"⚠️ Respons HTML (rate-limited?) pada halaman {page}. Menunggu {delay} detik...")
                time.sleep(delay)
                delay *= 2
                continue

            response.raise_for_status()
            break

        except requests.exceptions.HTTPError as e:
            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After")
                wait_time = int(retry_after) if retry_after else delay
                logging.warning(f"⚠️ Rate-limited. Menunggu {wait_time} detik...")
                time.sleep(wait_time)
                delay *= 2
            else:
                logging.error(f"❌ HTTP error halaman {page}: {e}")
                sys.exit(1)

        except Exception as e:
            logging.error(f"❌ Gagal ambil data halaman {page}: {e}")
            sys.exit(1)
    else:
        logging.error(f"❌ Gagal setelah {MAX_RETRIES} percobaan pada halaman {page}")
        sys.exit(1)

    # === Proses data halaman ===
    try:
        data = response.json()
        if not isinstance(data, dict) or "data" not in data:
            logging.error(f"❌ Struktur respons API tidak sesuai pada halaman {page}")
            sys.exit(1)

        kups_list = data["data"]
        if not kups_list:
            logging.warning("⚠️ Tidak ada data ditemukan!")
            break

        all_kups.extend(kups_list)

        next_page_url = data.get("next_page_url")
        if not next_page_url:
            logging.info("✅ Semua data telah diambil!")
            break
        else:
            page += 1
            logging.info(f"📄 Mengambil halaman {page}")

    except Exception as e:
        logging.error(f"❌ Gagal memproses data halaman {page}: {e}")
        sys.exit(1)

# ==============================
# KONVERSI KE GEOJSON DENGAN FIELD HURUF BESAR
# ==============================
features = []
invalid_count = 0

for item in all_kups:
    try:
        lon = float(item["nujur"])
        lat = float(item["lintang"])

        if not (-180 <= lon <= 180 and -90 <= lat <= 90):
            raise ValueError(f"Koordinat di luar batas: lon={lon}, lat={lat}")

        feature = {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [lon, lat]
            },
            "properties": {
                k.upper(): v for k, v in item.items() if k not in ["lintang", "nujur"]
            }
        }
        features.append(feature)
    except (KeyError, ValueError, TypeError) as e:
        invalid_count += 1
        logging.warning(f"⚠️ Data dilewati (koordinat tidak valid): {e}")

geojson_data = {
    "type": "FeatureCollection",
    "features": features,
    "metadata": {
        "sumber": API_URL,
        "jumlah_titik": len(features),
        "jumlah_tidak_valid": invalid_count,
        "waktu_dibuat": datetime.now().isoformat()
    }
}

# ==============================
# SIMPAN GEOJSON
# ==============================
try:
    with open(GEOJSON_PATH, "w", encoding="utf-8") as f:
        json.dump(geojson_data, f, ensure_ascii=False, indent=2)
    logging.info(f"✅ Konversi selesai. GeoJSON disimpan di: {GEOJSON_PATH}")
    logging.info(f"🧾 Jumlah titik valid: {len(features)}")
    logging.info(f"🚫 Jumlah titik dilewati (tidak valid): {invalid_count}")
except Exception as e:
    logging.error(f"❌ Gagal menyimpan GeoJSON: {e}")
    sys.exit(1)
