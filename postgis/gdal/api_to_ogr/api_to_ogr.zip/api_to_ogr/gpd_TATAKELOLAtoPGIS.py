import os
import sys
import zipfile
import shutil
import requests
import geopandas as gpd
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
from dotenv import load_dotenv

# Load konfigurasi dari .env
load_dotenv()

# --- Konfigurasi dari .env ---
SIGAP_URL = os.getenv("SIGAP_URL")
SIGAP_USER = os.getenv("SIGAP_USER")
SIGAP_PASS = os.getenv("SIGAP_PASS")

DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME")
DB_SCHEMA = os.getenv("DB_SCHEMA", "datagis")

# Set direktori kerja ke /app/data
DATA_DIR = "/app/data"
os.makedirs(DATA_DIR, exist_ok=True)

def get_token():
    print(f"🔑 Login ke SIGAP ({SIGAP_USER})...")
    url = f"{SIGAP_URL}/api/auth/signin"
    try:
        res = requests.post(url, json={"username": SIGAP_USER, "password": SIGAP_PASS}, timeout=30)
        res.raise_for_status()
        return res.json().get("accessToken")
    except Exception as e:
        print(f"❌ Gagal login: {e}")
        return None

def download_file(token, uuid, layer_name):
    zip_path = os.path.join(DATA_DIR, f"{layer_name}.gdb.zip")
    url = f"{SIGAP_URL}/api/data-produsen/unduhFile/{uuid}"
    
    print(f"📥 Mengunduh data ke: {zip_path}...")
    headers = {"x-access-token": token}
    
    try:
        with requests.get(url, headers=headers, stream=True, timeout=120) as r:
            r.raise_for_status()
            with open(zip_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
        return zip_path
    except Exception as e:
        print(f"❌ Gagal unduh: {e}")
        return None

def extract_and_migrate(zip_path, layer_name):
    gdb_path = os.path.join(DATA_DIR, f"{layer_name}.gdb")
    
    print(f"📦 Mengekstrak ke {gdb_path}...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(DATA_DIR)
    
    # Koneksi DB (Psycopg 3)
    connection_url = URL.create(
        drivername="postgresql+psycopg",
        username=DB_USER,
        password=DB_PASS,
        host=DB_HOST,
        port=DB_PORT,
        database=DB_NAME
    )
    engine = create_engine(connection_url)

    try:
        import pyogrio
        layers = pyogrio.list_layers(gdb_path)
        
        for ln in layers[:, 0]:
            print(f"---------------------------------------------------")
            print(f"📥 Membaca & Memproses: {ln}")
            gdf = gpd.read_file(gdb_path, layer=ln, engine="pyogrio")

            if gdf.empty: continue

            # Standardisasi CRS ke WGS84
            if gdf.crs is None or gdf.crs != "EPSG:4326":
                gdf = gdf.to_crs("EPSG:4326")

            # Import ke PostGIS
            print(f"📤 Mengirim ke PostGIS ({DB_SCHEMA}.{ln})...")
            gdf.to_postgis(
                name=ln,
                con=engine,
                schema=DB_SCHEMA,
                if_exists='replace',
                index=False,
                chunksize=5000 
            )
            print(f"✅ Berhasil mengimpor {len(gdf)} baris.")

    except Exception as e:
        print(f"❌ Kesalahan migrasi: {e}")
    finally:
        # Cleanup file lokal
        if os.path.exists(gdb_path): shutil.rmtree(gdb_path)
        if os.path.exists(zip_path): os.remove(zip_path)
        print(f"🧹 Pembersihan file di {DATA_DIR} selesai.")
        engine.dispose()

if __name__ == "__main__":
    # Penggunaan: python3 sigap_to_postgis.py <UUID> <NAMA_LAYER>
    if len(sys.argv) < 3:
        # Contoh default jika tidak ada argumen
        uuid = "2726e362-a2b9-4324-9309-477ce4591adf"
        name = "MANGROVE_AR_25K_24"
        print(f"💡 Menggunakan parameter default: {name}")
    else:
        uuid = sys.argv[1]
        name = sys.argv[2]

    token = get_token()
    if token:
        path = download_file(token, uuid, name)
        if path:
            extract_and_migrate(path, name)
            print("\n🚀 PROSES SELESAI!")
