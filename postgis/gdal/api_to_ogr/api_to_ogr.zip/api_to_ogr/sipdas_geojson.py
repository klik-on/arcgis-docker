import requests
import json
import urllib3

# Konfigurasi API dan output
IGT = "REHAB_DAS"
OUTPUT_PATH = f"/app/data/{IGT}.geojson"

# Nonaktifkan warning SSL (karena verify=False)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

url = "https://ditjen-pdasrh.kehutanan.go.id/server/rest/services/REHAB_DAS/MapServer/0/query"
params = {
    "where": "1=1",
    "outFields": "*",
    "f": "geojson",
    "token": "IJvO8W_TbKxE9SgDiBJE-fBCeE83iLwqzlNIekxJtxK05bnJuXQGIYlkize1EAa2nfvnfVnwfW-nBDluaZ237GbUYFqvfsfufQXUjQWWy-AjP0pJulu5eUAM1qwyFgieJS51a7ZZxvnoPHafprW5xP7ooVgQq-9HI_p690Tjd8o."
}

try:
    response = requests.get(url, params=params, verify=False)
    response.raise_for_status()
    
    geojson_data = response.json()

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(geojson_data, f, ensure_ascii=False, indent=2)

    print(f"✅ Berhasil disimpan ke {OUTPUT_PATH}")

except requests.exceptions.RequestException as e:
    print("❌ Error saat mengakses data:", e)
