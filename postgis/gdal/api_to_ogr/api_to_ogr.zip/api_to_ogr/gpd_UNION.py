import os
import geopandas as gpd
import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# --- 0. Memuat Koneksi dari .env ---
load_dotenv()

DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
SCHEMA_DATA = os.getenv("SCHEMA_DATA") 
OUT_SCHEMA = os.getenv("OUT_SCHEMA")   

# --- 1. Konfigurasi Tabel (Internal Skrip) ---
TABLE_A = "PL_DKI_JAKARTA_CLIP"
TABLE_B = "KWS_DKI_JAKARTA_CLIP"
OUT_TABLE = "PLKWS_UNION_FULL"
FIELD_PL = "PL2024_ID"
FIELD_KWS = "FUNGSIKWS"

# --- 2. Detail Koneksi (Menggunakan driver psycopg versi 3) ---
# Format SQLAlchemy untuk psycopg 3 adalah 'postgresql+psycopg://'
conn_string = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(conn_string)

# --- 3. Memuat Data dari PostGIS ---
try:
    with engine.connect() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))
        conn.commit()

    print(f"📂 Memuat data '{TABLE_A}' dan '{TABLE_B}' dari skema '{SCHEMA_DATA}'...")

    query_a = f'SELECT * FROM "{OUT_SCHEMA}"."{TABLE_A}"'
    query_b = f'SELECT * FROM "{OUT_SCHEMA}"."{TABLE_B}"'

    # Geopandas akan menggunakan SQLAlchemy engine dengan driver psycopg 3
    gdf_lahan = gpd.read_postgis(query_a, engine, geom_col='geom')
    gdf_kws = gpd.read_postgis(query_b, engine, geom_col='geom')
    
    print(f"✅ Data berhasil dimuat. ({len(gdf_lahan)} baris lahan, {len(gdf_kws)} baris kawasan)")
except Exception as e:
    print(f"❌ Gagal memuat data: {e}")
    exit(1)

# --- 4. Geoprocessing (UNION) ---
# Sinkronisasi CRS (Coordinate Reference System)
if gdf_lahan.crs != gdf_kws.crs:
    print(f"🔄 Menyelaraskan CRS ke {gdf_lahan.crs}...")
    gdf_kws = gdf_kws.to_crs(gdf_lahan.crs)

print(f"🚀 Melakukan FULL SPATIAL UNION (Overlay)...")
# Union menggabungkan geometri dan atribut dari kedua layer
gdf_hasil_union = gpd.overlay(gdf_lahan, gdf_kws, how='union', keep_geom_type=True)

# --- 5. Penyimpanan ke PostGIS ---
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE}"'

try:
    # Standarisasi nama kolom geometri
    if gdf_hasil_union.geometry.name != 'geom':
        gdf_hasil_union = gdf_hasil_union.rename_geometry('geom')

    print(f"💾 Menyimpan hasil ke {RESULT_TABLE_FULL}...")
    gdf_hasil_union.to_postgis(
        name=OUT_TABLE,
        con=engine,
        schema=OUT_SCHEMA,
        if_exists='replace',
        index=False
    )

    # --- 6. Perhitungan Luas via SQL (Server-side) ---
    print(f"📏 Menghitung Luas (CEA) dalam Hektar via PostGIS...")
    sql_commands = [
        f'ALTER TABLE {RESULT_TABLE_FULL} ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;',
        f'UPDATE {RESULT_TABLE_FULL} SET "LUAS_CEA_HA" = ST_Area(ST_Transform("geom", 54034)) / 10000;'
    ]

    with engine.begin() as conn:
        for cmd in sql_commands:
            conn.execute(text(cmd))

    # --- 7. Ringkasan Luas Global ---
    print(f"📊 Membuat Ringkasan Luas...")
    query_summary = f"""
        SELECT 
            "{FIELD_PL}", "{FIELD_KWS}",
            SUM("LUAS_CEA_HA") as total_ha
        FROM {RESULT_TABLE_FULL}
        GROUP BY "{FIELD_PL}", "{FIELD_KWS}"
        ORDER BY total_ha DESC
    """
    summary_df = pd.read_sql(query_summary, engine)
    
    print("\n" + "="*40)
    print("📊 RINGKASAN LUAS HASIL UNION")
    print("="*40)
    print(summary_df.to_string(index=False))
    print("="*40)
    print(f"\n✅ Selesai! Tabel output: {RESULT_TABLE_FULL}")

except Exception as e:
    print(f"❌ Terjadi kesalahan pada tahap akhir: {e}")
