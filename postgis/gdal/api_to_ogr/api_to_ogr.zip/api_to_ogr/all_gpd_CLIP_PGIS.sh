#!/bin/bash
PROVINSI=("DKI Jakarta" "Jawa Barat" "Jawa Tengah")

for PROV in "${PROVINSI[@]}"
do
    python3 gpd_CLIP_PGIS.py "$PROV"
done
