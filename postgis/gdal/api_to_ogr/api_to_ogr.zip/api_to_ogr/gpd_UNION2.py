import os
import time
import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# --- 0. Memuat Koneksi dari .env ---
load_dotenv()

DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
OUT_SCHEMA = os.getenv("SCHEMA_OUT") or os.getenv("OUT_SCHEMA") or "analisis"

# --- 1. Konfigurasi Tabel (Mudah Diganti Seperti gpd_UNION.py) ---
TABLE_A = "PL_DKI_JAKARTA_CLIP"
COLS_A  = ["PL2024_ID"] # Daftar kolom dari Tabel A

TABLE_B = "KWS_DKI_JAKARTA_CLIP"
COLS_B  = ["FUNGSIKWS"] # Daftar kolom dari Tabel B

OUT_TABLE = "PLKWS_UNION_FAST"
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE}"'

# --- 2. Detail Koneksi ---
conn_string = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(conn_string)

def run_fast_union():
    start_time = time.time()
    
    # Menyiapkan string kolom secara otomatis
    cols_a_sql = ", ".join([f'a."{c}"' for c in COLS_A])
    cols_b_sql = ", ".join([f'b."{c}"' for c in COLS_B])
    all_cols_group = ", ".join([f'"{c}"' for c in (COLS_A + COLS_B)])

    try:
        with engine.begin() as conn:
            print(f"🚀 Memulai Fast PostGIS Union...")
            print(f"💾 Menyimpan hasil ke {RESULT_TABLE_FULL}...")

            # Inisialisasi Skema dan Tabel
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))
            conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL};'))

            # LOGIKA: Memecah semua poligon menjadi garis, lalu membentuk ulang poligon terkecil 
            # untuk memastikan tidak ada geometri yang hilang (Full Union)
            
            query = text(f"""
                CREATE TABLE {RESULT_TABLE_FULL} AS
                WITH 
                boundaries AS (
                    SELECT ST_Boundary(geom) as geom FROM "{OUT_SCHEMA}"."{TABLE_A}"
                    UNION ALL
                    SELECT ST_Boundary(geom) as geom FROM "{OUT_SCHEMA}"."{TABLE_B}"
                ),
                unified_lines AS (
                    SELECT ST_Union(geom) as geom FROM boundaries
                ),
                atomic_polygons AS (
                    SELECT (ST_Dump(ST_Polygonize(geom))).geom as geom
                    FROM unified_lines
                )
                SELECT 
                    {cols_a_sql}, {cols_b_sql},
                    p.geom
                FROM atomic_polygons p
                LEFT JOIN "{OUT_SCHEMA}"."{TABLE_A}" a ON ST_Intersects(ST_PointOnSurface(p.geom), a.geom)
                LEFT JOIN "{OUT_SCHEMA}"."{TABLE_B}" b ON ST_Intersects(ST_PointOnSurface(p.geom), b.geom);
            """)

            print(f"✂️  Memproses Geometri (Slicing {TABLE_A} & {TABLE_B})...")
            conn.execute(query)

            # Perhitungan Luas dan Optimasi
            print(f"📏 Menghitung Luas (CEA) & Membersihkan Data...")
            conn.execute(text(f'ALTER TABLE {RESULT_TABLE_FULL} ADD COLUMN "LUAS_CEA_HA" DOUBLE PRECISION;'))
            conn.execute(text(f'UPDATE {RESULT_TABLE_FULL} SET "LUAS_CEA_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000;'))
            
            # Hapus sliver atau geometri kosong
            conn.execute(text(f'DELETE FROM {RESULT_TABLE_FULL} WHERE "LUAS_CEA_HA" < 0.0001 OR geom IS NULL;'))
            
            # Buat Index Spasial
            conn.execute(text(f'CREATE INDEX ON {RESULT_TABLE_FULL} USING GIST(geom);'))
            conn.execute(text(f'ANALYZE {RESULT_TABLE_FULL};'))

        # --- 3. Ringkasan Luas ---
        query_summary = f"""
            SELECT {all_cols_group}, SUM("LUAS_CEA_HA") as total_ha
            FROM {RESULT_TABLE_FULL}
            GROUP BY {all_cols_group}
            ORDER BY total_ha DESC
        """
        summary_df = pd.read_sql(query_summary, engine)
        
        print("\n" + "="*45)
        print("📊 RINGKASAN LUAS HASIL FAST UNION")
        print("="*45)
        print(summary_df.to_string(index=False))
        print("="*45)
        
        duration = time.time() - start_time
        print(f"\n✅ Selesai dalam {duration:.2f} detik!")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")

if __name__ == "__main__":
    run_fast_union()
