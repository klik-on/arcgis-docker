import os
import geopandas as gpd
import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# --- 0. Memuat Koneksi dari .env ---
load_dotenv()

DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
SCHEMA_DATA = os.getenv("SCHEMA_DATA") 
OUT_SCHEMA = os.getenv("OUT_SCHEMA")   

# --- 1. Konfigurasi Tabel & Kolom (Dinamis) ---
TABLE_A = "PL_DKI_JAKARTA_CLIP"
COLS_A  = ["PL2024_ID", "pl2023_id_r"] # <-- Tambah kolom di sini

TABLE_B = "KWS_DKI_JAKARTA_CLIP"
COLS_B  = ["FUNGSIKWS"]

TABLE_C = "RKTN_DKI_JAKARTA_CLIP"
COLS_C  = ["rktn2019"]

OUT_TABLE = "PL_KWS_RKTN_UNION"
ALL_ATTR_FIELDS = COLS_A + COLS_B + COLS_C

# --- 2. Detail Koneksi (Psycopg 3) ---
conn_string = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(conn_string)

def run_process():
    try:
        # --- 3. Inisialisasi Skema ---
        with engine.connect() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))
            conn.commit()

        # --- 4. Memuat Data dengan Kolom Spesifik ---
        print(f"📂 Memuat data dari '{OUT_SCHEMA}'...")
        
        def load_gdf(table, columns):
            # Mengubah list kolom menjadi string: "col1", "col2", "geom"
            cols_str = ", ".join([f'"{c}"' for c in columns])
            query = f'SELECT {cols_str}, "geom" FROM "{OUT_SCHEMA}"."{table}"'
            return gpd.read_postgis(query, engine, geom_col='geom')

        gdf_a = load_gdf(TABLE_A, COLS_A)
        gdf_b = load_gdf(TABLE_B, COLS_B)
        gdf_c = load_gdf(TABLE_C, COLS_C)
        
        # Sinkronisasi CRS
        for gdf in [gdf_b, gdf_c]:
            if gdf.crs != gdf_a.crs:
                gdf.to_crs(gdf_a.crs, inplace=True)

        # --- 5. Geoprocessing Union (Sequential) ---
        print(f"🚀 Langkah 1: Union {TABLE_A} & {TABLE_B}...")
        union_1 = gpd.overlay(gdf_a, gdf_b, how='union', keep_geom_type=True)

        print(f"🚀 Langkah 2: Union dengan {TABLE_C}...")
        gdf_final = gpd.overlay(union_1, gdf_c, how='union', keep_geom_type=True)

        # --- 6. Seleksi Kolom Akhir ---
        # Memastikan kolom benar-benar ada di hasil akhir (overlay kadang menambah suffix jika ada bentrok nama)
        existing_cols = [c for c in ALL_ATTR_FIELDS if c in gdf_final.columns]
        gdf_output = gdf_final[existing_cols + [gdf_final.geometry.name]].copy()

        # --- 7. Penyimpanan ke PostGIS ---
        RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE}"'
        if gdf_output.geometry.name != 'geom':
            gdf_output = gdf_output.rename_geometry('geom')

        print(f"💾 Menyimpan hasil ke {RESULT_TABLE_FULL}...")
        gdf_output.to_postgis(name=OUT_TABLE, con=engine, schema=OUT_SCHEMA, if_exists='replace', index=False)

        # --- 8. Kalkulasi Luas & Cleaning via SQL ---
        print(f"📏 Menghitung Luas & Membersihkan Data...")
        sql_commands = [
            f'ALTER TABLE {RESULT_TABLE_FULL} ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;',
            f'UPDATE {RESULT_TABLE_FULL} SET "LUAS_CEA_HA" = ST_Area(ST_Transform("geom", 54034)) / 10000;',
            f'DELETE FROM {RESULT_TABLE_FULL} WHERE "LUAS_CEA_HA" < 0.00001 OR "geom" IS NULL;'
        ]

        with engine.begin() as conn:
            for cmd in sql_commands:
                conn.execute(text(cmd))

        # --- 9. Ringkasan Luas Akhir ---
        cols_sql = ", ".join([f'"{c}"' for c in existing_cols])
        query_summary = f"""
            SELECT {cols_sql}, SUM("LUAS_CEA_HA") as total_ha
            FROM {RESULT_TABLE_FULL}
            GROUP BY {cols_sql}
            ORDER BY total_ha DESC
            LIMIT 10;
        """
        summary_df = pd.read_sql(query_summary, engine)
        
        print("\n" + "="*70)
        print(f"📊 HASIL RINGKASAN (KOLOM: {', '.join(existing_cols)})")
        print("="*70)
        print(summary_df.to_string(index=False))
        print("="*70)

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")

if __name__ == "__main__":
    run_process()
