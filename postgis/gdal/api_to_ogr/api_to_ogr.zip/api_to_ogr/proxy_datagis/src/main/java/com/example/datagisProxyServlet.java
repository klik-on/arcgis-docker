package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.stream.Collectors;

@WebServlet("/*")
public class datagisProxyServlet extends HttpServlet {

    private static final String DATAGIS_REST_BASE = "http://172.16.2.122:8000";
    private static String API_KEY;

    @Override
    public void init() throws ServletException {
        super.init();
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            if (input == null) throw new FileNotFoundException("config.properties not found");
            Properties prop = new Properties();
            prop.load(input);
            API_KEY = prop.getProperty("datagis.api.key");
        } catch (IOException e) {
            throw new ServletException("Failed to load config", e);
        }
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pathInfo = request.getPathInfo();
        // Redirect root ke /docs internal
        String targetPath = (pathInfo == null || pathInfo.equals("/")) ? "/docs" : pathInfo;

        // 1. CORS Headers
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, X-API-TOKEN, apikey");

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        // 2. Build URL
        String queryString = request.getQueryString();
        String targetUrlStr = DATAGIS_REST_BASE + targetPath + (queryString != null ? "?" + queryString : "");

        HttpURLConnection connection = null;
        try {
            URL url = new URL(targetUrlStr);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(request.getMethod());
            
            // Forward Headers
            Enumeration<String> hs = request.getHeaderNames();
            while (hs.hasMoreElements()) {
                String h = hs.nextElement();
                if (!h.equalsIgnoreCase("Host") && !h.equalsIgnoreCase("Content-Length")) {
                    connection.setRequestProperty(h, request.getHeader(h));
                }
            }
            connection.setRequestProperty("apikey", API_KEY);

            // Forward Body
            if (request.getContentLength() > 0) {
                connection.setDoOutput(true);
                try (InputStream in = request.getInputStream(); OutputStream out = connection.getOutputStream()) {
                    in.transferTo(out);
                }
            }

            int code = connection.getResponseCode();
            response.setStatus(code);

            // 3. Handle Response
            String contentType = connection.getContentType();
            if (contentType != null) response.setContentType(contentType);

            try (InputStream is = (code >= 400) ? connection.getErrorStream() : connection.getInputStream()) {
                if (is != null) {
                    // JIKA HTML: Lakukan Rewrite Path
                    if (contentType != null && contentType.contains("text/html")) {
                        String body = new String(is.readAllBytes(), "UTF-8");
                        // Mengganti jalur JSON agar menunjuk ke /datagis/
                        body = body.replace("\"/openapi.json\"", "\"/datagis/openapi.json\"")
                                   .replace("'./openapi.json'", "'/datagis/openapi.json'")
                                   .replace("/static", "/datagis/static");
                        
                        response.getWriter().write(body);
                    } else {
                        // JIKA BUKAN HTML (JSON/JS/CSS): Kirim langsung
                        try (OutputStream os = response.getOutputStream()) {
                            is.transferTo(os);
                        }
                    }
                }
            }
        } catch (Exception e) {
            response.sendError(502, "Proxy Error: " + e.getMessage());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
