#!/usr/bin/env bash
set -e

cd "$(dirname "$0")"

IGT="kups"
DATA_DIR="/app/data"
GEOJSON_PATH="${DATA_DIR}/${IGT}.geojson"
GDB_PATH="${DATA_DIR}/${IGT}.gdb"
ZIP_PATH="${DATA_DIR}/${IGT}.gdb.zip"
JSON_PATH="${DATA_DIR}/${IGT}.json"
LOG_PATH="${DATA_DIR}/log_kups.log"

cleanup() {
  echo "🧹 Cleanup sementara..."
  rm -rf "$GDB_PATH" "$GEOJSON_PATH"
}
trap cleanup EXIT

echo "🕒 Mulai proses: $(date)"
echo "🚀 Menjalankan script Python untuk ambil data dan buat GeoJSON..."

# Cek dependensi
for cmd in python3 ogr2ogr zip; do
  if ! command -v "$cmd" &> /dev/null; then
    echo "❌ Perintah '$cmd' tidak ditemukan. Pastikan terinstal."
    exit 1
  fi
done

# Jalankan skrip Python
if ! python3 kups_geojson.py; then
  echo "❌ Gagal menjalankan kups_geojson.py"
  exit 1
fi

if [ ! -f "$GEOJSON_PATH" ]; then
  echo "❌ File GeoJSON tidak ditemukan: $GEOJSON_PATH"
  exit 1
fi

echo "🚀 Mengkonversi GeoJSON ke OpenFileGDB..."
if ! ogr2ogr -f "OpenFileGDB" "$GDB_PATH" "$GEOJSON_PATH" \
  -dim 2 -nln "$IGT" -nlt PROMOTE_TO_MULTI \
  -t_srs EPSG:4326 -progress \
  --config OGR_OPENFILEGDB_METHOD SKIP \
  --config OGR_ENABLE_CURVE_REDUCTION YES; then
  echo "❌ Konversi GDB gagal"
  exit 1
fi

if [ ! -d "$GDB_PATH" ]; then
  echo "❌ Folder GDB tidak ditemukan: $GDB_PATH"
  exit 1
fi

echo "📦 Membuat archive ZIP dari ${IGT}.gdb..."
(
  cd "$DATA_DIR" || exit 1
  zip -r "$(basename "$ZIP_PATH")" "$(basename "$GDB_PATH")"
)

if [ ! -f "$ZIP_PATH" ]; then
  echo "❌ Gagal membuat ZIP file: $ZIP_PATH"
  exit 1
fi

# Cleanup tambahan
[ -f "$JSON_PATH" ] && rm -f "$JSON_PATH" && echo "🧹 File JSON dihapus: $JSON_PATH"
[ -f "$LOG_PATH" ] && rm -f "$LOG_PATH" && echo "🧹 File log dihapus: $LOG_PATH"

echo "✅ Proses selesai! File ZIP tersimpan di: $ZIP_PATH"
echo "🕒 Selesai: $(date)"
