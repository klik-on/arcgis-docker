#!/bin/bash
set -e

IGT="kups"
DATA_DIR="/app/data"
GEOJSON_PATH="${DATA_DIR}/${IGT}.geojson"
GDB_PATH="${DATA_DIR}/${IGT}.gdb"
ZIP_PATH="${DATA_DIR}/${IGT}.gdb.zip"
JSON_PATH="${DATA_DIR}/${IGT}.json"
LOG_PATH="${DATA_DIR}/log_kups.log"

echo "🚀 Menjalankan script Python untuk ambil data dan buat GeoJSON..."

# ✅ Cek apakah file Python ada
if [ ! -f "kups_geojson.py" ]; then
  echo "❌ File kups_geojson.py tidak ditemukan di /app"
  exit 1
fi

# ✅ Jalankan skrip Python
if ! python3 kups_geojson.py; then
  echo "❌ Gagal menjalankan kups_geojson.py"
  exit 1
fi

# ✅ Cek apakah file GeoJSON berhasil dibuat
if [ ! -f "$GEOJSON_PATH" ]; then
  echo "❌ File GeoJSON tidak ditemukan: $GEOJSON_PATH"
  exit 1
fi

# ✅ Cek apakah ogr2ogr tersedia
if ! command -v ogr2ogr &> /dev/null; then
  echo "❌ Perintah 'ogr2ogr' tidak ditemukan. Pastikan GDAL terinstal dengan benar."
  exit 1
fi

echo "🚀 Mengkonversi GeoJSON ke FileGDB menggunakan ogr2ogr..."

ogr2ogr -f "OpenFileGDB" \
  "$GDB_PATH" \
  "$GEOJSON_PATH" \
  -dim 2 \
  -nlt MULTIPOINT \
  -lco OVERWRITE=YES \
  -t_srs EPSG:4326 \
  -progress \
  --config OGR_OPENFILEGDB_METHOD SKIP \
  --config OGR_ENABLE_CURVE_REDUCTION YES

# ✅ Cek apakah folder .gdb berhasil dibuat
if [ ! -d "$GDB_PATH" ]; then
  echo "❌ Folder GDB tidak berhasil dibuat: $GDB_PATH"
  exit 1
fi

echo "📦 Membuat archive ZIP dari ${IGT}.gdb..."

pushd "$DATA_DIR" > /dev/null
zip -r "${IGT}.gdb.zip" "${IGT}.gdb"
popd > /dev/null

# ✅ Cek apakah file ZIP berhasil dibuat
if [ ! -f "$ZIP_PATH" ]; then
  echo "❌ Gagal membuat ZIP file: $ZIP_PATH"
  exit 1
fi

echo "🧹 Menghapus file sementara..."
rm -rf "$GDB_PATH"
rm -f "$GEOJSON_PATH"

# ✅ Tambahan: hapus juga JSON dan log
if [ -f "$JSON_PATH" ]; then
  rm -f "$JSON_PATH"
  echo "🧹 File JSON dihapus: $JSON_PATH"
fi

if [ -f "$LOG_PATH" ]; then
  rm -f "$LOG_PATH"
  echo "🧹 File log dihapus: $LOG_PATH"
fi

echo "✅ Proses selesai! File ZIP tersimpan di: $ZIP_PATH"
