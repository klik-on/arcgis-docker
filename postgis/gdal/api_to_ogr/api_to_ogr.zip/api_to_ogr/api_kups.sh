#!/usr/bin/env bash
set -e

cd "$(dirname "$0")"

IGT="KUPS"
DATA_DIR="/app/data"
GEOJSON_PATH="${DATA_DIR}/${IGT}.geojson"
GDB_PATH="${DATA_DIR}/${IGT}.gdb"
ZIP_PATH="${DATA_DIR}/${IGT}.gdb.zip"
JSON_PATH="${DATA_DIR}/${IGT}.json"
LOG_PATH="${DATA_DIR}/log_kups.log"

cleanup() {
  echo "🧹 Cleanup sementara..."
  rm -rf "$GDB_PATH" "$GEOJSON_PATH"
}
trap cleanup EXIT

echo "🕒 Mulai proses: $(date)"
echo "🚀 Menjalankan script Python untuk ambil data dan buat GeoJSON..."

# === Cek dependensi utama ===
for cmd in python3 ogr2ogr zip; do
  if ! command -v "$cmd" &> /dev/null; then
    echo "❌ Perintah '$cmd' tidak ditemukan. Pastikan sudah terinstal."
    exit 1
  fi
done

# === Jalankan skrip Python untuk ambil data ===
if ! python3 kups_geojson.py; then
  echo "❌ Gagal menjalankan kups_geojson.py"
  exit 1
fi

# === Pastikan file GeoJSON ada ===
if [ ! -f "$GEOJSON_PATH" ]; then
  echo "❌ File GeoJSON tidak ditemukan: $GEOJSON_PATH"
  exit 1
fi

# === Atur LD_LIBRARY_PATH untuk FileGDB resmi (jika ada) ===
if [ -f "/usr/local/FileGDB_API/lib/libFileGDBAPI.so" ]; then
  export LD_LIBRARY_PATH="/usr/local/FileGDB_API/lib:${LD_LIBRARY_PATH:-}"
fi

# === Deteksi driver GDB ===
if ogrinfo --formats | grep -qE "FileGDB.*\(rw\+\)"; then
  DRIVER="FileGDB"
  echo "✅ Menggunakan driver GDAL resmi FileGDB"
elif ogrinfo --formats | grep -q "OpenFileGDB"; then
  DRIVER="OpenFileGDB"
  echo "⚠️ Driver FileGDB resmi tidak ditemukan, fallback ke OpenFileGDB (read/write terbatas)"
else
  echo "❌ Tidak ada driver GDB yang tersedia di GDAL"
  exit 1
fi

# === Konversi GeoJSON → GDB ===
echo "🚀 Mengkonversi GeoJSON ke GDB dengan driver: $DRIVER ..."

export CPL_LOG=OFF  # Matikan warning HTTPS opsional

# Gunakan array agar aman dari karakter spesial
OGR_ARGS=(
  -f "$DRIVER"
  "$GDB_PATH"
  "$GEOJSON_PATH"
  -dim 2
  -nln "$IGT"
  -nlt PROMOTE_TO_MULTI
  -t_srs EPSG:4326
  --config OGR_ENABLE_CURVE_REDUCTION YES
  --config OGR_ORGANIZE_POLYGONS SKIP
)

# Tambahkan opsi overwrite jika driver FileGDB
if [ "$DRIVER" = "FileGDB" ]; then
  OGR_ARGS+=(-lco OVERWRITE=YES)
fi

ogr2ogr "${OGR_ARGS[@]}"

# === Validasi hasil GDB ===
if [ ! -d "$GDB_PATH" ]; then
  echo "❌ Folder GDB tidak ditemukan: $GDB_PATH"
  exit 1
fi

echo "✅ Konversi selesai. File GDB tersimpan di: $GDB_PATH"

# === Compress hasil ===
echo "📦 Membuat archive ZIP dari ${IGT}.gdb..."
(
  cd "$DATA_DIR" || exit 1
  zip -r "$(basename "$ZIP_PATH")" "$(basename "$GDB_PATH")"
)

if [ ! -f "$ZIP_PATH" ]; then
  echo "❌ Gagal membuat ZIP file: $ZIP_PATH"
  exit 1
fi

# === Info tambahan ===
echo "📦 Ukuran ZIP: $(du -h "$ZIP_PATH" | cut -f1)"

# === Cleanup tambahan ===
[ -f "$JSON_PATH" ] && rm -f "$JSON_PATH" && echo "🧹 File JSON dihapus: $JSON_PATH"
[ -f "$LOG_PATH" ] && rm -f "$LOG_PATH" && echo "🧹 File log dihapus: $LOG_PATH"

echo "✅ Proses selesai! File ZIP tersimpan di: $ZIP_PATH"
echo "🕒 Selesai: $(date)"
