import os
import sys
import requests
import pandas as pd
import geopandas as gpd
from sqlalchemy import create_engine, text
from shapely.geometry import MultiPolygon, Polygon

# =================================================================
# 1️⃣ KONFIGURASI DINAMIS
# =================================================================
IGT = os.getenv("IGT")
if not IGT:
    print("❌ Error: Variabel environment 'IGT' tidak ditemukan.")
    sys.exit(1)

DATA_DIR = os.getenv("DATA_DIR", "/app/data")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_SCHEMA = os.getenv("DB_SCHEMA", "public")
PBPH_USER = os.getenv("PBPH_USER")
PBPH_PASS = os.getenv("PBPH_PASS")

if not all([PBPH_USER, PBPH_PASS, DB_NAME, DB_USER, DB_PASS]):
    print("❌ Error: Kredensial API atau Database belum lengkap.")
    sys.exit(1)

GDB_PATH = os.path.join(DATA_DIR, f"{IGT}.gdb")
ENDPOINT = f"https://phl.kehutanan.go.id/api/v1/{IGT}?select=*"

# =================================================================
# 2️⃣ PENGAMBILAN & TRANSFORMASI DATA (AUTO-REPROJECT)
# =================================================================
print(f"🌐 Menghubungi API untuk IGT: {IGT}")
try:
    response = requests.get(ENDPOINT, auth=(PBPH_USER, PBPH_PASS), timeout=180)
    response.raise_for_status()
    raw_data = response.json().get("data", [])
except Exception as e:
    print(f"❌ Error API: {e}")
    sys.exit(1)

if not raw_data:
    print(f"⚠️ Data '{IGT}' kosong.")
    sys.exit(0)

print(f"⚡ Memproses {len(raw_data)} fitur...")
df = pd.DataFrame(raw_data)
# Filter data yang memiliki string hex geom valid
df = df[df['geom'].str.len() > 10].copy()

# Inisialisasi awal (WKB ke GeoDataFrame) dengan nama kolom 'geom'
gdf = gpd.GeoDataFrame(
    df.drop(columns=['geom']),
    geometry=gpd.GeoSeries.from_wkb(df['geom'].apply(lambda x: bytes.fromhex(x))),
    crs=None
)
# Pastikan nama kolom aktif di GeoPandas adalah 'geom'
gdf = gdf.rename_geometry('geom')

# A. DETEKSI & REPROYEKSI KOORDINAT
print("🧹 Validasi koordinat dan sistem referensi spasial...")
test_geom = gdf.geom.dropna().iloc[0] if not gdf.empty else None

if test_geom and abs(test_geom.centroid.x) > 180:
    print("📍 Deteksi koordinat METER (Projected). Melakukan reproyeksi ke EPSG:4326...")
    gdf.crs = "EPSG:3857"
    gdf = gdf.to_crs("EPSG:4326")
else:
    print("📍 Deteksi koordinat DERAJAT (Geographic). Menetapkan EPSG:4326.")
    gdf.crs = "EPSG:4326"
    
    def is_valid_wgs84(geom):
        try:
            minx, miny, maxx, maxy = geom.bounds
            return -180 <= minx <= 180 and -90 <= miny <= 90
        except: return False
    gdf = gdf[gdf.geom.apply(is_valid_wgs84)].copy()

# B. PEMBERSIHAN GEOMETRI & STANDARISASI TIPE
def clean_and_fix(geom):
    if geom is None or geom.is_empty:
        return None
    if not geom.is_valid:
        geom = geom.buffer(0)

    if geom.geom_type == 'Polygon':
        return MultiPolygon([geom])
    elif geom.geom_type == 'MultiPolygon':
        return geom
    elif geom.geom_type == 'GeometryCollection':
        polys = [p for p in geom.geoms if p.geom_type in ['Polygon', 'MultiPolygon']]
        if polys:
            parts = []
            for p in polys:
                if p.geom_type == 'Polygon': parts.append(p)
                else: parts.extend(list(p.geoms))
            return MultiPolygon(parts)
    return None

gdf['geom'] = gdf['geom'].apply(clean_and_fix)
gdf = gdf[gdf.geom.notnull()].copy()

# Uppercase kolom atribut, KECUALI 'geom'
gdf.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf.columns]

print(f"✅ Data valid: {len(gdf)} fitur siap disimpan.")

# =================================================================
# 3️⃣ EXPORT KE POSTGIS
# =================================================================
if not gdf.empty:
    print(f"🐘 Mengimpor ke PostGIS: \"{IGT}\" (kolom: geom)")
    try:
        # Menggunakan driver psycopg (v3) agar konsisten dengan main.py
        conn_url = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        engine = create_engine(conn_url)
        
        # Simpan ke PostGIS dengan tipe data geometri eksplisit pada kolom 'geom'
        gdf.to_postgis(name=IGT, con=engine, schema=DB_SCHEMA, if_exists='replace', index=False,
                        dtype={'geom': 'Geometry(MultiPolygon, 4326)'})
        
        with engine.begin() as conn:
            # Buat Spatial Index GIST pada kolom 'geom'
            conn.execute(text(f'CREATE INDEX IF NOT EXISTS "{IGT}_GIST_IDX" ON "{DB_SCHEMA}"."{IGT}" USING GIST (geom)'))
            # Jalankan ANALYZE untuk optimasi query
            conn.execute(text(f'ANALYZE "{DB_SCHEMA}"."{IGT}"'))
            
        print("✅ PostGIS Update Berhasil.")
    except Exception as e:
        print(f"⚠️ Gagal simpan PostGIS: {e}")

# =================================================================
# 4️⃣ EXPORT KE FILEGDB
# =================================================================
if not gdf.empty:
    print(f"💾 Menulis ke FileGDB: {GDB_PATH}")
    try:
        os.environ["OGR_ORGANIZE_POLYGONS"] = "SKIP"
        # Gunakan driver OpenFileGDB dengan engine pyogrio (High Performance)
        lco = {"TARGET_ARCGIS_VERSION": "ARCGIS_PRO_3_2_OR_LATER"}
        gdf.to_file(GDB_PATH, driver="OpenFileGDB", layer=IGT, engine="pyogrio", **lco)
        print("✅ FileGDB Update Berhasil.")
    except Exception as e:
        print(f"❌ Gagal simpan FileGDB: {e}")

print(f"🏁 Selesai memproses IGT: {IGT}")
