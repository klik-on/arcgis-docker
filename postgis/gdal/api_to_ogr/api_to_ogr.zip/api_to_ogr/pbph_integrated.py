import os
import sys
import requests
import pandas as pd
import geopandas as gpd
from sqlalchemy import create_engine, text
from shapely.geometry import MultiPolygon, Polygon

# =================================================================
# 1️⃣ KONFIGURASI & ENVIRONMENT
# =================================================================
IGT = os.getenv("IGT", "PERSETUJUAN_KOMITMEN_PBPH")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")

# Database Configuration
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_SCHEMA = os.getenv("DB_SCHEMA", "public")

# API Configuration
PBPH_USER = os.getenv("PBPH_USER")
PBPH_PASS = os.getenv("PBPH_PASS")

if not all([PBPH_USER, PBPH_PASS, DB_NAME, DB_USER, DB_PASS]):
    print("❌ Error: Variabel environment API atau Database belum lengkap.")
    sys.exit(1)

GDB_PATH = os.path.join(DATA_DIR, f"{IGT}.gdb")
ENDPOINT = f"https://phl.kehutanan.go.id/api/v1/{IGT}?select=*"

# =================================================================
# 2️⃣ AMBIL & PROSES DATA (GEOPANDAS)
# =================================================================
print(f"🌐 Menghubungi API untuk: {IGT}")
try:
    response = requests.get(ENDPOINT, auth=(PBPH_USER, PBPH_PASS), timeout=60)
    response.raise_for_status()
    raw_data = response.json().get("data", [])
except Exception as e:
    print(f"❌ Error saat akses API: {e}")
    sys.exit(1)

if not raw_data:
    print("⚠️ Data tidak ditemukan di API.")
    sys.exit(0)

print(f"⚡ Memproses {len(raw_data)} fitur...")
df = pd.DataFrame(raw_data)

# Filter: Ambil hanya yang memiliki geometri
df = df[df['geom'].str.len() > 10].copy()

# Konversi Hex WKB ke Geometry secara efisien
print("🔗 Mengonversi geometri (Vektor)...")
gdf = gpd.GeoDataFrame(
    df.drop(columns=['geom']),
    geometry=gpd.GeoSeries.from_wkb(df['geom'].apply(lambda x: bytes.fromhex(x))),
    crs="EPSG:4326"
)

# Uppercase semua kolom atribut
gdf.columns = [c.upper() if c != 'geometry' else 'geometry' for c in gdf.columns]

# Pastikan tipe data geometri konsisten sebagai MultiPolygon
def to_multi(geom):
    if isinstance(geom, Polygon):
        return MultiPolygon([geom])
    return geom

gdf['geometry'] = gdf['geometry'].apply(to_multi)

# =================================================================
# 3️⃣ SIMPAN KE POSTGIS (Uppercase Table Name)
# =================================================================
print(f"🐘 Mengimpor ke PostGIS (Tabel: \"{IGT}\")...")
try:
    # Dialek postgresql+psycopg untuk versi library 3.x
    conn_url = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    engine = create_engine(conn_url)
    
    # Simpan ke PostGIS. Nama IGT dikirim apa adanya (Uppercase).
    # GeoPandas/SQLAlchemy akan otomatis memberikan double quotes (" ").
    gdf.to_postgis(
        name=IGT,
        con=engine,
        schema=DB_SCHEMA,
        if_exists='replace',
        index=False,
        dtype={'geometry': 'Geometry(MultiPolygon, 4326)'}
    )
    
    # Buat indeks spasial GIST (Nama tabel harus pakai quotes di SQL manual)
    with engine.begin() as conn:
        sql_idx = text(f'CREATE INDEX IF NOT EXISTS "{IGT}_GIST_IDX" ON {DB_SCHEMA}."{IGT}" USING GIST (geometry)')
        conn.execute(sql_idx)
    
    print(f"✅ PostGIS: Tabel \"{IGT}\" berhasil diperbarui.")
except Exception as e:
    print(f"⚠️ Gagal simpan PostGIS: {e}")

# =================================================================
# 4️⃣ SIMPAN KE FILEGDB
# =================================================================
print(f"💾 Menulis ke FileGDB: {GDB_PATH}")
try:
    # Optimasi untuk poligon kompleks
    os.environ["OGR_ORGANIZE_POLYGONS"] = "SKIP"
    
    # Opsi kompatibilitas ArcGIS Pro agar tipe Integer tetap terjaga
    lco = {"TARGET_ARCGIS_VERSION": "ARCGIS_PRO_3_2_OR_LATER"}

    gdf.to_file(
        GDB_PATH, 
        driver="OpenFileGDB", 
        layer=IGT, 
        engine="pyogrio",
        **lco
    )
    print(f"✅ FileGDB: Layer \"{IGT}\" berhasil disimpan.")
except Exception as e:
    print(f"❌ Gagal simpan FileGDB: {e}")

print(f"🏁 Selesai! Total fitur: {len(gdf)}")
