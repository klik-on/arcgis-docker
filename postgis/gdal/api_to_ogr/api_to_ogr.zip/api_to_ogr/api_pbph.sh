#!/bin/bash
set -e

# ==============================
# 1️⃣ Konfigurasi Dinamis
# ==============================
# Mengambil IGT dari argumen pertama, jika kosong gunakan default atau exit
export IGT=${1:-"PERSETUJUAN_KOMITMEN_PBPH"}
export DATA_DIR="/app/data"

GDB_PATH="${DATA_DIR}/${IGT}.gdb"
ZIP_PATH="${DATA_DIR}/${IGT}.gdb.zip"

echo "------------------------------------------"
echo "🕒 Mulai Proses untuk IGT: $IGT"
echo "🕒 Waktu: $(date)"

# === Jalankan Python ===
# Python akan otomatis membaca variabel 'IGT' dari environment yang di-export di atas
python3 pbph_integrated.py

# === Compress ke ZIP ===
echo "📦 Mengompres ke ZIP..."
cd "$DATA_DIR"
rm -f "$(basename "$ZIP_PATH")"
zip -r -q "$(basename "$ZIP_PATH")" "$(basename "$GDB_PATH")"

# === Cleanup Folder GDB ===
rm -rf "$(basename "$GDB_PATH")"

echo "✅ SELESAI!"
echo "📂 Lokasi: $ZIP_PATH"
echo "------------------------------------------"
