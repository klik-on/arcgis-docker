#!/bin/bash
set -e

# ==============================
# 1️⃣ Konfigurasi
# ==============================
IGT="PERSETUJUAN_KOMITMEN_PBPH"
DATA_DIR="/app/data"
GEOJSON_PATH="${DATA_DIR}/${IGT}.geojson"
GDB_PATH="${DATA_DIR}/${IGT}.gdb"
ZIP_PATH="${DATA_DIR}/${IGT}.gdb.zip"

# Export ke environment agar Python bisa baca
export IGT
export DATA_DIR

# ==============================
# 2️⃣ Cleanup sementara
# ==============================
cleanup() {
  echo "🧹 Cleanup sementara..."
  rm -rf "$GDB_PATH" "$GEOJSON_PATH"
}
trap cleanup EXIT

# ==============================
# 3️⃣ Mulai proses
# ==============================
echo "🕒 Mulai proses: $(date)"

# === Cek dependensi utama ===
for cmd in python3 ogr2ogr ogrinfo zip; do
  if ! command -v "$cmd" &> /dev/null; then
    echo "❌ Perintah '$cmd' tidak ditemukan. Pastikan sudah terinstal."
    exit 1
  fi
done

# === Jalankan skrip Python untuk ambil data ===
echo "🚀 Menjalankan script Python untuk ambil data dan buat GeoJSON..."
if ! python3 pbph_geojson.py; then
  echo "❌ Gagal menjalankan pbph_geojson.py"
  exit 1
fi

# === Pastikan file GeoJSON tersedia ===
if [ ! -f "$GEOJSON_PATH" ]; then
  echo "❌ File GeoJSON tidak ditemukan: $GEOJSON_PATH"
  exit 1
fi

# === Atur LD_LIBRARY_PATH untuk FileGDB API resmi (jika ada) ===
if [ -f "/usr/local/FileGDB_API/lib/libFileGDBAPI.so" ]; then
  export LD_LIBRARY_PATH="/usr/local/FileGDB_API/lib:${LD_LIBRARY_PATH:-}"
  echo "🔧 FileGDB API resmi ditemukan. LD_LIBRARY_PATH diatur."
else
  echo "⚠️ FileGDB API resmi tidak ditemukan. Akan coba fallback otomatis."
fi

# === Deteksi driver GDAL yang tersedia ===
if ogrinfo --formats | grep -qE "FileGDB.*\(rw\+\)"; then
  DRIVER="FileGDB"
  echo "✅ Menggunakan driver GDAL resmi FileGDB (rw+)"
elif ogrinfo --formats | grep -q "OpenFileGDB"; then
  DRIVER="OpenFileGDB"
  echo "⚠️ Fallback: Menggunakan driver OpenFileGDB (fitur write terbatas)"
else
  echo "❌ Tidak ada driver GDB yang tersedia di GDAL"
  exit 1
fi

# === Konversi GeoJSON → GDB ===
echo "🚀 Mengkonversi GeoJSON ke GDB dengan driver: $DRIVER ..."

export CPL_LOG=OFF  # matikan warning GDAL

OGR_ARGS=(
  -f "$DRIVER"
  "$GDB_PATH"
  "$GEOJSON_PATH"
  -dim 2
  -nln "$IGT"
  -nlt PROMOTE_TO_MULTI
  -t_srs EPSG:4326
  -progress
  --config OGR_ENABLE_CURVE_REDUCTION YES
  --config OGR_ORGANIZE_POLYGONS SKIP
)

if [ "$DRIVER" = "FileGDB" ]; then
  OGR_ARGS+=(-lco OVERWRITE=YES)
fi

ogr2ogr "${OGR_ARGS[@]}"

# === Validasi hasil ===
if [ ! -d "$GDB_PATH" ]; then
  echo "❌ Folder GDB tidak ditemukan: $GDB_PATH"
  exit 1
fi
echo "✅ Konversi selesai. File GDB tersimpan di: $GDB_PATH"

# === Compress hasil ke ZIP ===
echo "📦 Membuat archive ZIP dari ${IGT}.gdb..."
(
  cd "$DATA_DIR" || exit 1
  zip -r "$(basename "$ZIP_PATH")" "$(basename "$GDB_PATH")"
)

if [ ! -f "$ZIP_PATH" ]; then
  echo "❌ Gagal membuat ZIP file: $ZIP_PATH"
  exit 1
fi

# === Tampilkan ukuran hasil ZIP ===
echo "📦 Ukuran ZIP: $(du -h "$ZIP_PATH" | cut -f1)"

# === Cleanup tambahan ===
rm -rf "$GDB_PATH"
rm -f "$GEOJSON_PATH"

echo "✅ Proses selesai! File ZIP tersimpan di: $ZIP_PATH"
echo "🕒 Selesai: $(date)"
