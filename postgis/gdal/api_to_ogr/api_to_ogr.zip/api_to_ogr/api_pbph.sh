#!/bin/bash
set -e

# Load ENV dari file jika diperlukan, atau pastikan sudah di-export
export IGT="PERSETUJUAN_KOMITMEN_PBPH"
export DATA_DIR="/app/data"
ZIP_PATH="${DATA_DIR}/${IGT}.gdb.zip"

echo "------------------------------------------"
echo "🕒 Mulai: $(date)"

# 🚀 Jalankan integrasi Python (API -> PostGIS & GDB)
python3 pbph_integrated.py

# 📦 ZIP FileGDB
cd "$DATA_DIR"
zip -r -q "$(basename "$ZIP_PATH")" "${IGT}.gdb"
rm -rf "${IGT}.gdb"

echo "✅ SELESAI!"
echo "📂 ZIP: $ZIP_PATH"
echo "🕒 Selesai: $(date)"
echo "------------------------------------------"
