#!/bin/bash
set -e

IGT="PBPH_DEFINITIF"

echo "🚀 Menjalankan script Python untuk ambil data dan buat GeoJSON..."
if ! python3 pbph_geojson2.py; then
  echo "❌ Gagal menjalankan pbph_geojson.py"
  exit 1
fi

GEOJSON_PATH="/app/data/${IGT}.geojson"

if [ ! -f "$GEOJSON_PATH" ]; then
  echo "❌ File GeoJSON tidak ditemukan: $GEOJSON_PATH"
  exit 1
fi

if ! command -v ogr2ogr &> /dev/null; then
  echo "❌ Perintah 'ogr2ogr' tidak ditemukan. Pastikan GDAL terinstal dengan benar."
  exit 1
fi

echo "🚀 Mengkonversi GeoJSON ke OpenFileGDB menggunakan ogr2ogr..."
ogr2ogr -f "OpenFileGDB" \
  /app/data/${IGT}.gdb \
  "$GEOJSON_PATH" \
  -dim 2 \
  -nln "$IGT" \
  -nlt PROMOTE_TO_MULTI \
  -t_srs EPSG:4326 \
  -progress \
  --config OGR_OPENFILEGDB_METHOD SKIP \
  --config OGR_ENABLE_CURVE_REDUCTION YES \
  --config OGR_ORGANIZE_POLYGONS SKIP

echo "📦 Membuat archive ZIP dari ${IGT}.gdb..."
cd /app/data
zip -r ${IGT}.gdb.zip ${IGT}.gdb

echo "🧹 Menghapus folder ${IGT}.gdb dan file ${IGT}.geojson..."
rm -rf ${IGT}.gdb
rm -f "$GEOJSON_PATH"

echo "✅ Proses selesai! File ZIP tersimpan di: /app/data/${IGT}.gdb.zip"
