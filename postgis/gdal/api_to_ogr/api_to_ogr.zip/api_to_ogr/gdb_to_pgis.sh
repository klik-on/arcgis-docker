#!/bin/bash
set -e

# === Konfigurasi Internal ===
# Sekarang LAYER_NAME mengambil dari argumen pertama ($1)
LAYER_NAME=$1
DATA_DIR="/app/data"

# Validasi: Pastikan user memasukkan nama layer/file
if [ -z "$LAYER_NAME" ]; then
  echo "❌ Error: Nama layer tidak disertakan!"
  echo "Penggunaan: ./gdb_to_pgis.sh NAMA_LAYER"
  echo "Contoh: ./gdb_to_pgis.sh KUPS"
  exit 1
fi

# === Jalur File ===
OUTPUT_GDB="${DATA_DIR}/${LAYER_NAME}.gdb"
ZIP_PATH="${DATA_DIR}/${LAYER_NAME}.gdb.zip"

# === Cek Variabel Environment (dari .env) ===
if [ -z "$DB_HOST" ] || [ -z "$DB_PASS" ]; then
  echo "❌ Error: Variabel database tidak ditemukan di environment."
  exit 1
fi

echo "🚀 Memulai migrasi untuk input: ${LAYER_NAME}"

# === Ekstrak ZIP jika folder GDB belum ada ===
if [ ! -d "$OUTPUT_GDB" ]; then
  if [ -f "$ZIP_PATH" ]; then
    echo "🔍 Mengekstrak ZIP: $ZIP_PATH"
    unzip -o "$ZIP_PATH" -d "$DATA_DIR"
  else
    echo "❌ File ZIP tidak ditemukan: $ZIP_PATH"
    echo "Pastikan file ada di: $ZIP_PATH"
    exit 1
  fi
fi

# === Deteksi semua layer dalam FileGDB ===
LAYERS=$(ogrinfo -q "$OUTPUT_GDB" | grep -oE '^Layer: .+' | cut -d' ' -f2)

if [ -z "$LAYERS" ]; then
  echo "❌ Tidak ada layer ditemukan di GDB: $OUTPUT_GDB"
  exit 1
fi

# === Impor semua layer ke PostgreSQL ===
for LAYER in $LAYERS; do
  echo "---------------------------------------------------"
  echo "📥 Mengimpor: $LAYER -> Schema: ${DB_SCHEMA}"

  ogr2ogr -f "PostgreSQL" \
    PG:"host=${DB_HOST} port=${DB_PORT} dbname=${DB_NAME} user=${DB_USER} password=${DB_PASS}" \
    "$OUTPUT_GDB" \
    "$LAYER" \
    -nlt PROMOTE_TO_MULTI \
    -nln "$LAYER" \
    -dim 2 \
    -lco SCHEMA=${DB_SCHEMA} \
    -lco GEOMETRY_NAME=geom \
    -lco SPATIAL_INDEX=GIST \
    -lco LAUNDER=NO \
    -lco OVERWRITE=YES \
    -t_srs EPSG:4326 \
    -progress \
    --config OGR_ENABLE_CURVE_REDUCTION YES \
    --config OGR_FORCE_GML_MULTISURFACE_AS_MULTIPOLYGON YES \
    --config OGR_ORGANIZE_POLYGONS SKIP
done

echo "---------------------------------------------------"
echo "✅ Selesai: $(date)"

# === Bersihkan folder GDB ===
if [ -d "$OUTPUT_GDB" ]; then
  rm -rf "$OUTPUT_GDB"
  echo "🧹 Clean up: Folder $OUTPUT_GDB dihapus."
fi
