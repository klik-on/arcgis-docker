import os
import sys
import zipfile
import shutil
import geopandas as gpd
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
from dotenv import load_dotenv

# Memuat variabel dari file .env
load_dotenv()

def migrate_gdb_to_postgis(layer_input):
    # 1. Konfigurasi Database
    db_user = os.getenv("DB_USER")
    db_pass = os.getenv("DB_PASS")
    db_host = os.getenv("DB_HOST")
    db_port = os.getenv("DB_PORT", "5432")
    db_name = os.getenv("DB_NAME")
    db_schema = os.getenv("DB_SCHEMA", "datagis")

    data_dir = "./data"
    clean_name = layer_input.replace(".gdb", "").replace(".zip", "")
    zip_path = os.path.join(data_dir, f"{clean_name}.gdb.zip")
    gdb_path = os.path.join(data_dir, f"{clean_name}.gdb")

    # 2. Proses Ekstraksi Otomatis
    if not os.path.exists(gdb_path):
        if os.path.exists(zip_path):
            print(f"📦 Mengekstrak {zip_path}...")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(data_dir)
            print(f"✅ Ekstraksi selesai.")
        else:
            print(f"❌ Error: File {zip_path} tidak ditemukan!")
            return

    # 3. Membuat Connection Engine (Psycopg 3)
    connection_url = URL.create(
        drivername="postgresql+psycopg",
        username=db_user,
        password=db_pass,
        host=db_host,
        port=db_port,
        database=db_name
    )
    engine = create_engine(connection_url)

    try:
        import pyogrio
        print(f"🔍 Memeriksa isi GDB di {gdb_path}")
        layers = pyogrio.list_layers(gdb_path)
        
        for layer_name in layers[:, 0]:
            print(f"---------------------------------------------------")
            print(f"📥 Membaca Layer: {layer_name}")
            
            gdf = gpd.read_file(gdb_path, layer=layer_name, engine="pyogrio")

            if gdf.empty:
                continue

            # Transformasi ke WGS84
            if gdf.crs is None or gdf.crs != "EPSG:4326":
                print(f"🌍 Mengonversi ke EPSG:4326...")
                gdf = gdf.to_crs("EPSG:4326")

            # 4. Kirim ke PostGIS
            print(f"📤 Mengirim ke tabel: {db_schema}.{layer_name}...")
            gdf.to_postgis(
                name=layer_name,
                con=engine,
                schema=db_schema,
                if_exists='replace',
                index=False,
                chunksize=5000 
            )
            print(f"✅ Berhasil mengimpor {len(gdf)} baris.")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")
    finally:
        # Opsional: Hapus folder GDB setelah selesai untuk hemat ruang
        if os.path.exists(gdb_path):
            shutil.rmtree(gdb_path)
            print(f"🧹 Folder sementara {gdb_path} dihapus.")
        engine.dispose()

if __name__ == "__main__":
    if len(sys.argv) > 1:
        migrate_gdb_to_postgis(sys.argv[1])
    else:
        print("💡 Gunakan: python3 gdb_to_postgis.py MANGROVE_AR_25K_24")
