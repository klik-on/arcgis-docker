#!/bin/bash
# clip_pl_prov.sh — Clipping PL2024 ke batas provinsi tertentu
# Fitur:
# ✅ Input: kode provinsi (mis. 11 untuk Aceh)
# ✅ Auto hapus tabel lama
# ✅ LEFT JOIN ke kodefikasi."KODE_PL"
# ✅ LATERAL intersection (efisien)
# ✅ Auto buat spatial index
# ✅ Summary: jumlah record & total luas
# ✅ Logging ke /var/log/clip_pl_prov.log

# === Konfigurasi koneksi ===
HOST="172.16.2.122"
DBNAME="postgres"
USER="postgres.67888"
PASS="password00"
SCHEMA="datagis"
SOURCE_TABLE="PL2024_AR_250K"
ADM_TABLE="adm_provinsi_clean"
KODE_TABLE="KODE_PL"
KODE_SCHEMA="kodefikasi"

# === Cek input ===
if [ -z "$1" ]; then
  echo "❌ Gunakan: $0 <kode_provinsi>"
  echo "   Contoh: $0 11"
  exit 1
fi
KODE_PROV="$1"
TARGET_TABLE="clip_pl_${KODE_PROV}"

# === Setup log ===
LOG_FILE="/var/log/clip_pl_prov.log"
mkdir -p "$(dirname "$LOG_FILE")"

function log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "🚀 Mulai proses clipping untuk provinsi kode $KODE_PROV..."
START_TIME=$(date +%s)

# === Hapus tabel lama ===
log "🧹 Menghapus tabel lama ($SCHEMA.$TARGET_TABLE)..."
ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  DROP TABLE IF EXISTS $SCHEMA.\"$TARGET_TABLE\" CASCADE;
" >> "$LOG_FILE" 2>&1

# === Jalankan proses clipping ===
log "🏗️  Menjalankan ogr2ogr..."
{ time ogr2ogr -f "PostgreSQL" \
  "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" \
  "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" \
  -dialect PostgreSQL \
  -sql "
    SELECT
        b.\"PL2024_ID\",
        b.pl2023_id_r,
        a.nama_provinsi,
        a.kode_provinsi,
        k.\"KD_PL\",
        k.\"DESKRIPSI_PL\",        -- pakai kolom baru
        k.\"KELOMPOK\",
        ST_Area(inter.geom_54034) / 10000 AS luas_ha, -- luas dalam hektar
        ST_SetSRID(inter.geom_4326, 4326) AS geom      -- simpan geometri asli
    FROM $SCHEMA.\"$SOURCE_TABLE\" b
    JOIN $SCHEMA.\"$ADM_TABLE\" a
      ON ST_Intersects(a.geom, b.geom)
    LEFT JOIN $KODE_SCHEMA.\"$KODE_TABLE\" k
      ON b.\"PL2024_ID\" = k.\"KD_PL\"
    CROSS JOIN LATERAL (
        SELECT 
            ST_CollectionExtract(ST_MakeValid(ST_Intersection(b.geom, a.geom)), 3) AS geom_4326,
            ST_Transform(
                ST_CollectionExtract(ST_MakeValid(ST_Intersection(b.geom, a.geom)), 3), 54034
            ) AS geom_54034
    ) AS inter
    WHERE a.kode_provinsi = '$KODE_PROV'
      AND ST_IsValid(inter.geom_4326)
      AND ST_Area(inter.geom_54034) > 0
  " \
  -nln $SCHEMA.$TARGET_TABLE \
  -nlt PROMOTE_TO_MULTI \
  -overwrite; } 2>&1 | tee -a "$LOG_FILE"

if [ ${PIPESTATUS[0]} -ne 0 ]; then
  log "❌ Gagal menjalankan ogr2ogr."
  exit 1
fi

# === Buat index ===
log "🧱 Membuat index..."
ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  CREATE INDEX IF NOT EXISTS ${TARGET_TABLE}_geom_idx ON $SCHEMA.\"$TARGET_TABLE\" USING GIST(geom);
  CREATE INDEX IF NOT EXISTS ${TARGET_TABLE}_pl2024_id_idx ON $SCHEMA.\"$TARGET_TABLE\"(\"PL2024_ID\");
" >> "$LOG_FILE" 2>&1

# === Update statistik ===
log "📊 Update statistik tabel..."
ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  ANALYZE $SCHEMA.\"$TARGET_TABLE\";
" >> "$LOG_FILE" 2>&1

# === Summary ===
log "📈 Menghitung summary hasil..."
RECORD_COUNT=$(ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  SELECT COUNT(*) AS count FROM $SCHEMA.\"$TARGET_TABLE\";
" 2>/dev/null | grep -i "count" | sed -E 's/.* = ([0-9]+).*/\1/')

TOTAL_AREA=$(ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  SELECT SUM(luas_ha) AS total_ha FROM $SCHEMA.\"$TARGET_TABLE\";
" 2>/dev/null | grep -i "total_ha" | sed -E 's/.* = ([0-9]+).*/\1/')

log "📝 Summary:"
log "  - Total record: $RECORD_COUNT"
log "  - Total luas (ha): $TOTAL_AREA"

# === Selesai ===
END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))
log "🎉 Proses selesai dalam $((ELAPSED / 60)) menit $((ELAPSED % 60)) detik."
log "📁 Output: $SCHEMA.$TARGET_TABLE"
log "📝 Log: $LOG_FILE"
