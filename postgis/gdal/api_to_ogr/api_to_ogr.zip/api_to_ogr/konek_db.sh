#!/bin/bash
HOSTNAME=$(docker inspect --format '{{ .Config.Hostname }}' supabase-db)
# Menambahkan direktori psql ke PATH
# which psql
# export PATH=$PATH:/root/.nix-profile/bin
# \pset pager off
# \dt datagis.*


docker exec -it supabase-db psql -h "$HOSTNAME" -U postgres -d postgres -p 5432

