#!/usr/bin/env bash
set -e

# Berpindah ke direktori tempat script berada
cd "$(dirname "$0")"

# === Konfigurasi Variabel ===
IGT="KUPS"
DATA_DIR="/app/data"
GEOJSON_PATH="${DATA_DIR}/${IGT}.geojson"
GDB_PATH="${DATA_DIR}/${IGT}.gdb"
ZIP_PATH="${DATA_DIR}/${IGT}.gdb.zip"
LOG_PATH="${DATA_DIR}/log_kups.log"

# Cleanup saat exit (opsional: hapus file mentah setelah jadi ZIP)
cleanup() {
  echo "🧹 Membersihkan file sementara..."
  [ -d "$GDB_PATH" ] && rm -rf "$GDB_PATH"
  [ -f "$GEOJSON_PATH" ] && rm -f "$GEOJSON_PATH"
}
trap cleanup EXIT

echo "🕒 Dimulai pada: $(date)"

# === 1. Cek Dependensi ===
for cmd in python3 ogr2ogr zip; do
  if ! command -v "$cmd" &> /dev/null; then
    echo "❌ Error: Perintah '$cmd' tidak ditemukan."
    exit 1
  fi
done

# === 2. Jalankan GeoPandas Script ===
echo "🚀 Menjalankan Python (GeoPandas) untuk ekstraksi data..."
# Pastikan nama file python sesuai dengan file Anda
if ! python3 gpd_KUPS.py; then
  echo "❌ Error: Eksekusi Python Gagal."
  exit 1
fi

# === 3. Validasi Output GeoPandas ===
# Asumsi: GeoPandas menghasilkan GeoJSON untuk dikonversi oleh GDAL
if [ ! -f "$GEOJSON_PATH" ]; then
  echo "❌ Error: GeoJSON tidak ditemukan di $GEOJSON_PATH"
  exit 1
fi

# === 4. Deteksi Driver GDAL untuk GDB ===
if ogrinfo --formats | grep -q "FileGDB"; then
  DRIVER="FileGDB"
elif ogrinfo --formats | grep -q "OpenFileGDB"; then
  DRIVER="OpenFileGDB"
else
  echo "❌ Error: Tidak ada driver GDB di sistem (butuh libgdal-geospatial)."
  exit 1
fi

# === 5. Konversi ke FileGDB via GDAL ===
echo "🔄 Mengonversi GeoJSON ke $DRIVER..."

# Hapus GDB lama jika ada agar tidak bentrok
rm -rf "$GDB_PATH"

ogr2ogr \
  -f "$DRIVER" \
  "$GDB_PATH" \
  "$GEOJSON_PATH" \
  -nln "$IGT" \
  -nlt PROMOTE_TO_MULTI \
  -t_srs EPSG:4326 \
  -lco ENCODING=UTF-8

# === 6. Kompresi ke ZIP ===
if [ -d "$GDB_PATH" ]; then
  echo "📦 Mengompresi FileGDB ke ZIP..."
  (
    cd "$DATA_DIR" || exit
    zip -r "$(basename "$ZIP_PATH")" "$(basename "$GDB_PATH")"
  )
else
  echo "❌ Error: GDB tidak berhasil dibuat."
  exit 1
fi

# === 7. Finalisasi ===
echo "------------------------------------------"
echo "✅ Sukses!"
echo "📍 Lokasi: $ZIP_PATH"
echo "📊 Ukuran: $(du -h "$ZIP_PATH" | cut -f1)"
echo "🕒 Selesai: $(date)"
