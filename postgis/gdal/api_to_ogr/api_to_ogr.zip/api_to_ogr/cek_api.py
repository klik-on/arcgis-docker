import requests
import urllib3
import os
from pprint import pprint

# Nonaktifkan SSL warnings (jika perlu)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==============================
# Konfigurasi
# ==============================
BASE_URL = "https://dbgis.planologi.kehutanan.go.id/server/rest/services"
TOKEN = os.environ.get("AGOL_TOKEN")  # Pastikan token ada di env variable
if not TOKEN:
    raise ValueError("Environment variable AGOL_TOKEN belum diset!")

# ==============================
# Fungsi untuk ambil JSON dari service
# ==============================
def get_service_json(url):
    try:
        r = requests.get(url, params={"f": "pjson", "token": TOKEN}, verify=False)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.RequestException as e:
        print(f"❌ Gagal mengakses {url}: {e}")
        return None

# ==============================
# Eksplorasi folder dan services
# ==============================
def explore_folder(url, indent=0):
    data = get_service_json(url)
    if not data:
        return

    prefix = " " * indent
    folder_name = data.get("folderName", url.split("/")[-1])
    print(f"{prefix}📁 Folder: {folder_name}")

    # Daftar service di folder
    for service in data.get("services", []):
        name = service.get("name")
        service_type = service.get("type")
        print(f"{prefix}  🔹 Service: {name} ({service_type})")
        
        # Ambil layer di service
        service_url = f"{url}/{name}/{service_type}"
        service_info = get_service_json(service_url)
        for layer in service_info.get("layers", []):
            print(f"{prefix}    ▪ Layer: {layer.get('name')} (ID: {layer.get('id')})")

    # Rekursi ke sub-folder
    for subfolder in data.get("folders", []):
        explore_folder(f"{BASE_URL}/{subfolder}", indent=indent+2)

# ==============================
# Jalankan eksplorasi dari root
# ==============================
explore_folder(BASE_URL)
