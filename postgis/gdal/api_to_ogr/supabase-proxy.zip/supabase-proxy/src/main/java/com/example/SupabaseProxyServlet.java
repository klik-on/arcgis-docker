package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.net.*;
import java.util.Enumeration;

@WebServlet("/api/*")
public class SupabaseProxyServlet extends HttpServlet {

    private static final String SUPABASE_REST_BASE = "http://172.16.2.122:8000/rest/v1/";
    private static final String SUPABASE_AUTH_BASE = "http://172.16.2.122:8000/auth/v1/";
    private static final String SUPABASE_STORAGE_BASE = "http://172.16.2.122:8000/storage/v1/";
    private static final String SUPABASE_REALTIME_BASE = "http://172.16.2.122:8000/realtime/v1/";

    private static final String API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzUxMzAyODAwLCJleHAiOjE5MDkwNjkyMDB9.5B3KqroqKZUnXyjJg99AtjSjGci-wKqJtH7LWCz7x2U";

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // CORS headers
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, PATCH");
        response.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type, apikey");

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        // Validasi API key dari client
        String clientApiKey = request.getHeader("apikey");
        if (clientApiKey == null || !clientApiKey.equals(API_KEY)) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Missing or invalid API key");
            return;
        }

        String path = request.getPathInfo(); // e.g. /rest/v1/todos
        String query = request.getQueryString();
        String targetUrl = null;

        if (path == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid path");
            return;
        }

        // Routing logic
        if (path.startsWith("/rest/v1/")) {
            targetUrl = SUPABASE_REST_BASE + path.substring("/rest/v1/".length());
        } else if (path.startsWith("/auth/v1/")) {
            targetUrl = SUPABASE_AUTH_BASE + path.substring("/auth/v1/".length());
        } else if (path.startsWith("/storage/v1/")) {
            targetUrl = SUPABASE_STORAGE_BASE + path.substring("/storage/v1/".length());
        } else if (path.startsWith("/realtime/v1/")) {
            targetUrl = SUPABASE_REALTIME_BASE + path.substring("/realtime/v1/".length());
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Unsupported API path");
            return;
        }

        if (query != null) {
            targetUrl += "?" + query;
        }

        HttpURLConnection conn = (HttpURLConnection) new URL(targetUrl).openConnection();
        conn.setRequestMethod(request.getMethod());

        // Copy original request headers, kecuali host
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            if (!headerName.equalsIgnoreCase("host")) {
                conn.setRequestProperty(headerName, request.getHeader(headerName));
            }
        }

        // Set API key dan Authorization untuk Supabase
        conn.setRequestProperty("apikey", API_KEY);
        conn.setRequestProperty("Authorization", "Bearer " + API_KEY);

        // Handle request body jika ada
        if ("POST".equalsIgnoreCase(request.getMethod()) ||
            "PUT".equalsIgnoreCase(request.getMethod()) ||
            "PATCH".equalsIgnoreCase(request.getMethod())) {

            conn.setDoOutput(true);
            try (InputStream is = request.getInputStream();
                 OutputStream os = conn.getOutputStream()) {
                byte[] buffer = new byte[8192];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }
            }
        }

        int status = conn.getResponseCode();
        response.setStatus(status);

        String contentType = conn.getContentType();
        if (contentType != null) {
            response.setContentType(contentType);
        }

        try (InputStream is = (status >= 400 ? conn.getErrorStream() : conn.getInputStream());
             OutputStream os = response.getOutputStream()) {
            if (is != null) {
                byte[] buffer = new byte[8192];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }
            }
        }
    }
}
