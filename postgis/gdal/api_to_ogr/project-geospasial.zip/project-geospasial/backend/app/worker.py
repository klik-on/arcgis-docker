import os
import subprocess
import logging
from celery import Celery

# --- 1. Konfigurasi Logging Worker ---
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s in %(module)s: %(message)s"
)
logger = logging.getLogger("geo-worker")

# --- 2. Inisialisasi Celery ---
REDIS_URL = os.getenv("REDIS_URL", "redis://192.168.70.20:6379/0")

# Pastikan nama aplikasi "geo_tasks" sama dengan yang ada di main.py
celery_app = Celery(
    "geo_tasks",
    broker=REDIS_URL,
    backend=REDIS_URL
)

celery_app.conf.update(
    task_track_started=True,
    task_time_limit=3600,
    worker_prefetch_multiplier=1,
    # Menghapus task lama yang tidak terpakai dari memory jika ada
    task_ignore_result=False 
)

# --- 3. Task Definition ---

# HAPUS @celery_app.task untuk run_kups_integration dan run_pbph_sync jika masih ada.
# Gunakan hanya SATU fungsi utama ini:

@celery_app.task(name="execute_geo_script", bind=True)
def execute_geo_script(self, script_name: str, args: list = None, env: dict = None):
    """
    Worker task utama yang memanggil wrapper run_sync.sh
    """
    wrapper_path = "/app/scripts/run_sync.sh"
    script_path = os.path.join("/app/scripts", script_name.lstrip("/"))

    if not os.path.exists(script_path):
        error_msg = f"File skrip tidak ditemukan: {script_path}"
        logger.error(error_msg)
        return {"status": "error", "message": error_msg}

    # Persiapkan Command
    cmd = ["bash", wrapper_path, script_path]
    if args:
        cmd.extend([str(a) for a in args]) # Pastikan argumen adalah string

    current_env = os.environ.copy()
    if env:
        current_env.update(env)

    logger.info(f"🔄 Executing Task ID {self.request.id}: {script_name}")

    try:
        process = subprocess.run(
            cmd,
            env=current_env,
            capture_output=True,
            text=True,
            check=True
        )

        logger.info(f"✅ Success: {script_name}")
        return {
            "status": "success",
            "task_id": self.request.id,
            "script": script_name
        }

    except subprocess.CalledProcessError as e:
        logger.error(f"💥 Failed {script_name} with exit code {e.returncode}")
        return {
            "status": "error",
            "task_id": self.request.id,
            "exit_code": e.returncode,
            "stderr": e.stderr[-500:] if e.stderr else "Check sync.log"
        }
    except Exception as e:
        logger.error(f"⚠️ Worker System Error: {str(e)}")
        return {"status": "system_error", "message": str(e)}
