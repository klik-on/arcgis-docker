import os
import subprocess
import logging
from celery import Celery

# --- 1. Konfigurasi Logging Worker ---
# Memastikan kita bisa melacak apa yang terjadi di dalam kontainer/server
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s in %(module)s: %(message)s"
)
logger = logging.getLogger("geo-worker")

# --- 2. Inisialisasi Celery ---
REDIS_URL = os.getenv("REDIS_URL", "redis://192.168.70.20:6379/0")

celery_app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)

celery_app.conf.update(
    timezone='Asia/Jakarta',
    enable_utc=False,  # Sangat penting: memaksa Celery tidak menggunakan UTC
    task_track_started=True,
    result_extended=True,  # Menambahkan detail tambahan di hasil task
    task_time_limit=3600,           # Hard limit (1 jam)
    task_soft_time_limit=3550,      # Beri waktu 50 detik untuk cleanup sebelum hard limit
    worker_prefetch_multiplier=1,   # Penting untuk GIS agar tidak overload
    task_ignore_result=False
)

# --- 3. Task Definition ---

@celery_app.task(name="execute_geo_script", bind=True)
def execute_geo_script(self, script_name: str, args: list = None, env_vars: dict = None):
    """
    Menggabungkan logika validasi path, penggabungan env vars, 
    dan penanganan error subprocess.
    """
    scripts_dir = "/app/scripts"
    wrapper_path = os.path.join(scripts_dir, "run_sync.sh")
    target_script = os.path.join(scripts_dir, script_name.lstrip("/"))

    # 1. Validasi Keberadaan File
    if not os.path.exists(target_script):
        error_msg = f"File skrip tidak ditemukan: {target_script}"
        logger.error(error_msg)
        return {"status": "error", "message": error_msg}

    # 2. Persiapkan Command
    cmd = ["bash", wrapper_path, target_script]
    if args:
        # Pastikan semua argumen adalah string
        cmd.extend([str(a) for a in args])

    # 3. Gabungkan Environment Variables
    full_env = os.environ.copy()
    if env_vars:
        full_env.update(env_vars)

    logger.info(f"🔄 Executing Task ID {self.request.id}: {script_name}")

    try:
        # 4. Menjalankan Subprocess
        # Menggunakan timeout sedikit di bawah limit Celery agar tertangkap oleh Python
        process = subprocess.run(
            cmd,
            env=full_env,
            capture_output=True,
            text=True,
            check=True,
            timeout=3550 
        )

        logger.info(f"✅ Success: {script_name}")
        return {
            "status": "success",
            "task_id": self.request.id,
            "script": script_name,
            "stdout_summary": process.stdout[-1000:] if process.stdout else "Success"
        }

    except subprocess.TimeoutExpired as e:
        logger.error(f"⌛ Task {self.request.id} TIMEOUT")
        return {
            "status": "timeout",
            "task_id": self.request.id,
            "message": "Skrip melebihi batas waktu 1 jam.",
            "stdout_partial": e.stdout[-500:] if e.stdout else ""
        }

    except subprocess.CalledProcessError as e:
        logger.error(f"💥 Failed {script_name} with exit code {e.returncode}")
        return {
            "status": "failed",
            "task_id": self.request.id,
            "exit_code": e.returncode,
            "stderr": e.stderr[-1000:] if e.stderr else "Error tanpa pesan detail."
        }

    except Exception as e:
        logger.error(f"⚠️ System Error: {str(e)}")
        return {
            "status": "system_error",
            "task_id": self.request.id,
            "message": str(e)
        }
