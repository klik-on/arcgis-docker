import os
import logging
import pandas as pd
import geopandas as gpd
from datetime import datetime
from typing import List, Optional, Dict

from fastapi import FastAPI, Depends, HTTPException, Security
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from celery import Celery
from celery.result import AsyncResult

# --- 1. LOGGING & CONFIGURATION ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("geo-api")

DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("PGIS_API_TOKEN", "pgis-pass-2026")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
SCRIPTS_DIR = os.getenv("SCRIPTS_DIR", "/app/scripts")
ROOT_PATH = os.getenv("ROOT_PATH", "/datagis")

# Konfigurasi Celery (Redis Broker)
REDIS_URL = os.getenv("REDIS_URL", "redis://192.168.70.20:6379/0")
celery_app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)

# --- 2. SCHEMAS ---
class ScriptRequest(BaseModel):
    script_name: str
    args: Optional[List[str]] = []
    env: Optional[Dict[str, str]] = {}

# --- 3. APP METADATA ---
tags_metadata = [
    {"name": "API Data Kehutanan", "description": "Akses Layer Spasial (GeoJSON) & Tabel Atribut."},
    {"name": "Eksplorasi Data", "description": "Navigasi skema dan daftar tabel."},
    {"name": "Sinkronisasi Data (Redis)", "description": "ETL Control via Celery Worker."},
    {"name": "Sistem", "description": "Health & Logs."},
]

app = FastAPI(
    title="Geospasial API Kehutanan",
    description="### Enterprise Middleware v1.7.0\nLayanan Integrasi Data Kehutanan via Redis Task Queue & Fast GeoJSON Streamer.",
    version="1.7.0",
    root_path=ROOT_PATH,
    openapi_tags=tags_metadata
)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# --- 4. SECURITY ---
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)
async def get_api_key(header_key: str = Security(api_key_header)):
    if header_key == API_KEY: return header_key
    raise HTTPException(status_code=403, detail="Akses Ditolak: API Key tidak valid.")

# --- 5. DATABASE ---
engine = create_engine(DATABASE_URL, pool_pre_ping=True)

# --- 6. ENDPOINTS: API DATA KEHUTANAN ---

@app.get("/api/v1/layers/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_spatial_layer(schema_name: str, table_name: str, _=Depends(get_api_key)):
    """
    Mengambil data spasial dan dikonversi ke GeoJSON secara langsung di level PostGIS (High Performance).
    """
    # Validasi input sederhana untuk mencegah SQL Injection pada nama tabel/skema
    if not schema_name.isalnum() and "_" not in schema_name:
         raise HTTPException(status_code=400, detail="Invalid schema name")

    query = text(f"""
        SELECT jsonb_build_object(
            'type',     'FeatureCollection',
            'features', COALESCE(jsonb_agg(feature), '[]'::jsonb),
            'metadata', jsonb_build_object(
                'schema', :schema,
                'table', :table,
                'timestamp', :ts
            )
        )
        FROM (
          SELECT jsonb_build_object(
            'type',       'Feature',
            'geometry',   ST_AsGeoJSON(geom)::jsonb,
            'properties', to_jsonb(inputs) - 'geom'
          ) AS feature
          FROM (SELECT * FROM "{schema_name}"."{table_name}") AS inputs
        ) AS features;
    """)

    try:
        with engine.connect() as conn:
            result = conn.execute(query, {
                "schema": schema_name, 
                "table": table_name, 
                "ts": datetime.now().isoformat()
            }).fetchone()
            
            return result[0]
    except Exception as e:
        logger.error(f"PostGIS GeoJSON Error: {str(e)}")
        raise HTTPException(status_code=500, detail="Gagal memproses GeoJSON dari database.")

@app.get("/api/v1/data/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_attribute_data(schema_name: str, table_name: str, page: int = 1, limit: int = 500, _=Depends(get_api_key)):
    try:
        offset = (page - 1) * limit
        sql = text(f'SELECT * FROM "{schema_name}"."{table_name}" LIMIT :limit OFFSET :offset')
        with engine.connect() as conn:
            df = pd.read_sql(sql, conn, params={"limit": limit, "offset": offset})
            # Hapus kolom geometri agar JSON tidak berat
            if 'geom' in df.columns:
                df = df.drop(columns=['geom'])
        return {
            "metadata": {"schema": schema_name, "table": table_name, "record_count": len(df), "page": page},
            "data": df.to_dict(orient="records")
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- 7. ENDPOINTS: EKSPLORASI DATA ---

@app.get("/api/v1/list-schemas", tags=["Eksplorasi Data"])
def list_schemas(_=Depends(get_api_key)):
    with engine.connect() as conn:
        query = text("SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN ('information_schema', 'pg_catalog') ORDER BY schema_name;")
        result = conn.execute(query)
        return {"schemas": [row[0] for row in result]}

@app.get("/api/v1/list-tables/{schema_name}", tags=["Eksplorasi Data"])
def list_tables(schema_name: str, _=Depends(get_api_key)):
    try:
        query = text("SELECT table_name FROM information_schema.tables WHERE table_schema = :schema AND table_type = 'BASE TABLE' ORDER BY table_name;")
        with engine.connect() as conn:
            result = conn.execute(query, {"schema": schema_name})
            tables = [row[0] for row in result]
        return {"schema": schema_name, "tables": tables}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- 8. ENDPOINTS: SINKRONISASI DATA (CELERY/REDIS) ---

@app.post("/api/v1/sync/run-script", tags=["Sinkronisasi Data (Redis)"])
async def trigger_sync(req: ScriptRequest, _=Depends(get_api_key)):
    script_full_path = os.path.join(SCRIPTS_DIR, req.script_name.lstrip("/"))
    if not os.path.exists(script_full_path):
        raise HTTPException(status_code=404, detail=f"Skrip {req.script_name} tidak ditemukan di volume worker.")

    task = celery_app.send_task(
        "execute_geo_script",
        args=[req.script_name, req.args, req.env]
    )

    logger.info(f"Queued Task: {req.script_name} with ID {task.id}")
    return {
        "status": "Queued",
        "task_id": task.id,
        "script": req.script_name,
        "queued_at": datetime.now().isoformat()
    }

@app.get("/api/v1/sync/status/{task_id}", tags=["Sinkronisasi Data (Redis)"])
async def get_task_status(task_id: str, _=Depends(get_api_key)):
    res = AsyncResult(task_id, app=celery_app)
    response = {
        "task_id": task_id,
        "status": res.status,
        "ready": res.ready()
    }
    if res.ready():
        response["result"] = res.result
    return response

# --- 9. ENDPOINTS: SISTEM & LOGS ---

@app.get("/api/v1/sync/logs", tags=["Sistem"])
async def get_logs(lines: int = 50, _=Depends(get_api_key)):
    log_file = os.path.join(DATA_DIR, "sync.log")
    if not os.path.exists(log_file):
        return {"content": ["Log file not found at /app/data/sync.log"]}
    try:
        with open(log_file, "r") as f:
            content = f.readlines()
            return {"content": content[-lines:]}
    except Exception as e:
        return {"error": str(e)}

@app.get("/health", tags=["Sistem"])
def health():
    try:
        with engine.connect() as conn:
            db_status = "connected"
    except:
        db_status = "error"
        
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "version": "1.7.0",
        "database": db_status
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
