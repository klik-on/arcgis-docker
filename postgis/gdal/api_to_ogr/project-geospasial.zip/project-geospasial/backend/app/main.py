import os
import signal
import logging
import subprocess
import pandas as pd
import geopandas as gpd
from datetime import datetime
from typing import List, Optional, Dict

from fastapi import FastAPI, Depends, HTTPException, Query, Security, BackgroundTasks
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, text

# --- 1. LOGGING & CONFIGURATION ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("geo-api")

DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("PGIS_API_TOKEN", "pgis-pass-2026")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
SCRIPTS_DIR = os.getenv("SCRIPTS_DIR", "/app/scripts")
ROOT_PATH = os.getenv("ROOT_PATH", "/datagis")

# --- 2. GLOBAL STATE ---
running_process = {
    "pid": None,
    "script": None,
    "start_time": None,
    "env_vars": []
}

# --- 3. SCHEMAS ---
class ScriptRequest(BaseModel):
    script_name: str
    args: Optional[List[str]] = []
    env: Optional[Dict[str, str]] = {}

# --- 4. APP METADATA ---
tags_metadata = [
    {"name": "API Data Kehutanan", "description": "Akses Layer Spasial (GeoJSON) & Tabel Atribut."},
    {"name": "Eksplorasi Data", "description": "Navigasi skema dan daftar tabel."},
    {"name": "Sinkronisasi Data", "description": "ETL Control dengan Wrapper Logging."},
    {"name": "Sistem", "description": "Health & Logs."},
]

app = FastAPI(
    title="Geospasial API Kehutanan",
    description="### Enterprise Middleware v1.0.0\nLayanan Integrasi Data Spasial dan Tabular Kehutanan.",
    version="1.0.0",
    root_path=ROOT_PATH,
    openapi_tags=tags_metadata
)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# --- 5. SECURITY ---
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)
async def get_api_key(header_key: str = Security(api_key_header)):
    if header_key == API_KEY: return header_key
    raise HTTPException(status_code=403, detail="Akses Ditolak: API Key tidak valid.")

# --- 6. DATABASE ---
# Menggunakan pool_pre_ping untuk memastikan koneksi database tetap hidup
engine = create_engine(DATABASE_URL, pool_pre_ping=True)

# --- 7. BACKGROUND TASK ENGINE ---
def run_background_script(script_name: str, args: List[str], custom_env: Dict[str, str]):
    global running_process
    try:
        script_path = os.path.join(SCRIPTS_DIR, script_name.lstrip("/"))
        wrapper_path = os.path.join(SCRIPTS_DIR, "run_sync.sh")

        env_config = os.environ.copy()
        if custom_env: env_config.update(custom_env)

        proc = subprocess.Popen(
            ["bash", wrapper_path, script_path] + args,
            env=env_config,
            preexec_fn=os.setsid
        )

        running_process.update({
            "pid": proc.pid,
            "script": script_name,
            "start_time": datetime.now().isoformat(),
            "env_vars": list(custom_env.keys())
        })

        logger.info(f"🚀 [PID {proc.pid}] Started: {script_name}")
        proc.wait() 

    except Exception as e:
        logger.error(f"💥 Runtime Exception: {str(e)}")
    finally:
        running_process.update({"pid": None, "script": None, "start_time": None, "env_vars": []})

# --- 8. ENDPOINTS: API DATA KEHUTANAN ---

@app.get("/api/v1/layers/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_spatial_layer(schema_name: str, table_name: str, page: int = 1, limit: int = 500, _=Depends(get_api_key)):
    """Akses data spasial (GeoJSON). Memerlukan kolom 'geom' atau 'geometry'."""
    try:
        offset = (page - 1) * limit
        sql = text(f'SELECT * FROM "{schema_name}"."{table_name}" LIMIT :limit OFFSET :offset')
        with engine.connect() as conn:
            # Otomatis mendeteksi kolom geometri
            gdf = gpd.read_postgis(sql, conn, geom_col="geom", params={"limit": limit, "offset": offset})
        
        res = gdf.__geo_interface__
        res["metadata"] = {"schema": schema_name, "table": table_name, "count": len(gdf), "page": page}
        return res
    except Exception as e:
        logger.error(f"Spatial Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Gagal mengambil data spasial: {str(e)}")

@app.get("/api/v1/data/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_attribute_data(schema_name: str, table_name: str, page: int = 1, limit: int = 500, _=Depends(get_api_key)):
    """Akses data atribut murni (Non-Spasial). Digunakan untuk tabel rekap/statistik."""
    try:
        offset = (page - 1) * limit
        sql = text(f'SELECT * FROM "{schema_name}"."{table_name}" LIMIT :limit OFFSET :offset')
        with engine.connect() as conn:
            df = pd.read_sql(sql, conn, params={"limit": limit, "offset": offset})
        
        return {
            "metadata": {"schema": schema_name, "table": table_name, "record_count": len(df), "page": page},
            "data": df.to_dict(orient="records")
        }
    except Exception as e:
        logger.error(f"Attribute Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Gagal mengambil data atribut: {str(e)}")

# --- 9. ENDPOINTS: EKSPLORASI DATA ---

@app.get("/api/v1/list-schemas", tags=["Eksplorasi Data"])
def list_schemas(_=Depends(get_api_key)):
    """Mendapatkan daftar semua skema di database."""
    with engine.connect() as conn:
        query = text("SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN ('information_schema', 'pg_catalog') ORDER BY schema_name;")
        result = conn.execute(query)
        return {"schemas": [row[0] for row in result]}

@app.get("/api/v1/list-tables/{schema_name}", tags=["Eksplorasi Data"])
def list_tables(schema_name: str, _=Depends(get_api_key)):
    """Mendapatkan daftar tabel dalam skema tertentu (Case Sensitive)."""
    try:
        query = text("""
            SELECT table_name FROM information_schema.tables 
            WHERE table_schema = :schema AND table_type = 'BASE TABLE'
            ORDER BY table_name;
        """)
        with engine.connect() as conn:
            result = conn.execute(query, {"schema": schema_name})
            tables = [row[0] for row in result]
        return {"schema": schema_name, "tables": tables}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- 10. ENDPOINTS: SINKRONISASI DATA ---

@app.post("/api/v1/sync/run-script", tags=["Sinkronisasi Data"])
async def trigger_sync(req: ScriptRequest, background_tasks: BackgroundTasks, _=Depends(get_api_key)):
    if running_process["pid"]:
        raise HTTPException(status_code=400, detail=f"Proses '{running_process['script']}' masih berjalan.")

    script_path = os.path.join(SCRIPTS_DIR, req.script_name.lstrip("/"))
    if not os.path.exists(script_path):
        raise HTTPException(status_code=404, detail=f"Skrip {req.script_name} tidak ditemukan.")

    background_tasks.add_task(run_background_script, req.script_name, req.args, req.env)
    return {"status": "Started", "script": req.script_name}

@app.get("/api/v1/sync/status", tags=["Sinkronisasi Data"])
async def get_sync_status(_=Depends(get_api_key)):
    is_run = running_process["pid"] is not None
    return {
        "is_running": is_run,
        "current_script": running_process["script"],
        "start_time": running_process["start_time"]
    }

# --- 11. ENDPOINTS: SISTEM ---

@app.get("/api/v1/sync/logs", tags=["Sistem"])
async def get_logs(lines: int = 50, _=Depends(get_api_key)):
    log_file = os.path.join(DATA_DIR, "sync.log")
    if not os.path.exists(log_file): return {"content": ["Log tidak ditemukan."]}
    try:
        with open(log_file, "r") as f:
            content = f.readlines()
            return {"content": content[-lines:]}
    except Exception as e:
        return {"error": str(e)}

@app.get("/health", tags=["Sistem"])
def health():
    return {"status": "healthy", "timestamp": datetime.now().isoformat(), "version": "1.6.0"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
