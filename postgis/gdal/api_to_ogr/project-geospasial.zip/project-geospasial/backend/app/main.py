import os
import signal
import shutil
import logging
import subprocess
import time
from datetime import datetime
from typing import List, Optional, Dict

from fastapi import FastAPI, Depends, HTTPException, Query, Security, status, BackgroundTasks, Header
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, text

# --- 1. LOGGING & CONFIGURATION ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("geo-api")

DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("PGIS_API_TOKEN", "pgis-pass-2026")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
SCRIPTS_DIR = os.getenv("SCRIPTS_DIR", "/app/scripts")
ROOT_PATH = os.getenv("ROOT_PATH", "/datagis")

# --- 2. GLOBAL STATE (PID Tracking) ---
running_process = {
    "pid": None,
    "script": None,
    "start_time": None,
    "env_vars": []
}

# --- 3. SCHEMAS ---
class ScriptRequest(BaseModel):
    script_name: str
    args: Optional[List[str]] = []
    env: Optional[Dict[str, str]] = {}

# --- 4. APP & SWAGGER METADATA ---
tags_metadata = [
    {"name": "Sinkronisasi Data", "description": "Unified ETL Control (KUPS & PBPH) dengan Kill PID support."},
    {"name": "Eksplorasi Data", "description": "Navigasi skema dan tabel database PostGIS."},
    {"name": "API Data Kehutanan", "description": "Akses Layer Spasial (GeoJSON) dan Tabular."},
    {"name": "Sistem", "description": "Health check, Storage management, dan Logs."},
]

app = FastAPI(
    title="Geospatial API Kehutanan",
    description="### Enterprise Middleware v1.6.0\nAPI terpadu untuk pengolahan data spasial kehutanan.",
    version="1.6.0",
    root_path=ROOT_PATH,
    openapi_tags=tags_metadata,
    servers=[{"url": ROOT_PATH, "description": "Current Environment"}]
)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# --- 5. SECURITY ---
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)
async def get_api_key(header_key: str = Security(api_key_header)):
    if header_key == API_KEY: return header_key
    raise HTTPException(status_code=403, detail="Akses Ditolak: API Key tidak valid.")

# --- 6. DATABASE ENGINE ---
engine = create_engine(DATABASE_URL, pool_pre_ping=True)

# --- 7. BACKGROUND TASK ENGINE ---
def run_background_script(script_name: str, args: List[str], custom_env: Dict[str, str]):
    global running_process
    try:
        script_path = os.path.join(SCRIPTS_DIR, script_name.lstrip("/"))
        env_config = os.environ.copy()
        if custom_env: env_config.update(custom_env)

        proc = subprocess.Popen(
            ["python3", script_path] + args,
            env=env_config,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            preexec_fn=os.setsid
        )

        running_process.update({
            "pid": proc.pid,
            "script": script_name,
            "start_time": datetime.now().isoformat(),
            "env_vars": list(custom_env.keys())
        })

        logger.info(f"🚀 [PID {proc.pid}] Executing: {script_name}")
        stdout, stderr = proc.communicate()
        
    except Exception as e:
        logger.error(f"💥 Runtime Exception: {str(e)}")
    finally:
        running_process.update({"pid": None, "script": None, "env_vars": []})

# --- 8. ENDPOINTS ---

# --- SECTION: EKSPLORASI DATA ---
@app.get("/api/v1/list-schemas", tags=["Eksplorasi Data"])
def list_schemas(_=Depends(get_api_key)):
    """Melihat daftar semua skema di database (kecuali sistem)."""
    with engine.connect() as conn:
        query = "SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN ('information_schema', 'pg_catalog') ORDER BY schema_name;"
        result = conn.execute(text(query))
        return {"schemas": [row[0] for row in result]}

@app.get("/api/v1/list-tables/{schema_name}", tags=["Eksplorasi Data"])
def list_tables(schema_name: str, search: str = Query(None), _=Depends(get_api_key)):
    """Melihat daftar tabel di skema tertentu."""
    with engine.connect() as conn:
        query = text("SELECT table_name FROM information_schema.tables WHERE table_schema = :schema ORDER BY table_name")
        result = conn.execute(query, {"schema": schema_name})
        tables = [row[0] for row in result]
        if search:
            tables = [t for t in tables if search.lower() in t.lower()]
        return {"tables": tables}

# --- SECTION: SINKRONISASI DATA ---
@app.post("/api/v1/sync/run-script", tags=["Sinkronisasi Data"])
async def trigger_sync(req: ScriptRequest, background_tasks: BackgroundTasks, _=Depends(get_api_key)):
    if running_process["pid"]:
        raise HTTPException(status_code=400, detail="Ada proses yang masih berjalan.")
    
    script_path = os.path.join(SCRIPTS_DIR, req.script_name.lstrip("/"))
    if not os.path.exists(script_path):
        raise HTTPException(status_code=404, detail="Skrip tidak ditemukan.")

    background_tasks.add_task(run_background_script, req.script_name, req.args, req.env)
    return {"status": "Started", "script": req.script_name}

@app.get("/api/v1/sync/status", tags=["Sinkronisasi Data"])
async def get_sync_status(_=Depends(get_api_key)):
    is_run = running_process["pid"] is not None
    return {
        "kups": {"is_running": is_run if "kups" in (running_process["script"] or "").lower() else False},
        "pbph": {"is_running": is_run if "pbph" in (running_process["script"] or "").lower() else False},
        "generic": {
            "is_running": is_run,
            "pid": running_process["pid"],
            "script": running_process["script"],
            "message": "Running" if is_run else "Idle"
        }
    }

@app.post("/api/v1/sync/kill", tags=["Sinkronisasi Data"])
async def kill_process(_=Depends(get_api_key)):
    global running_process
    pid = running_process["pid"]
    if not pid: return {"message": "Idle"}
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
        running_process.update({"pid": None, "script": None})
        return {"status": "Killed"}
    except:
        running_process.update({"pid": None})
        return {"status": "Error/Dead"}

# --- SECTION: API DATA KEHUTANAN (Spatial) ---
@app.get("/api/v1/layers/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_spatial_layer(schema_name: str, table_name: str, page: int = 1, limit: int = 500, _=Depends(get_api_key)):
    try:
        offset = (page - 1) * limit
        # Membaca tabel spasial menggunakan GeoPandas
        sql = text(f'SELECT * FROM "{schema_name}"."{table_name}" LIMIT :limit OFFSET :offset')
        with engine.connect() as conn:
            import geopandas as gpd
            gdf = gpd.read_postgis(sql, conn, geom_col="geom", params={"limit": limit, "offset": offset})
        res = gdf.__geo_interface__
        res["metadata"] = {"schema": schema_name, "table": table_name, "count": len(gdf)}
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- SECTION: SISTEM ---
@app.get("/health", tags=["Sistem"])
def health(): return {"status": "healthy", "timestamp": datetime.now().isoformat()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
