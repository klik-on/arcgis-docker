import os
import logging
import json
import pandas as pd
import pytz
from datetime import datetime
from typing import List, Optional, Dict

from fastapi import FastAPI, Depends, HTTPException, Security, Header
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from celery import Celery
from celery.result import AsyncResult

# --- 1. LOGGING & CONFIGURATION ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("geo-api")

# Load Environment Variables
DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("PGIS_API_TOKEN", "pgis-pass-2026")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
SCRIPTS_DIR = os.getenv("SCRIPTS_DIR", "/app/scripts")
ROOT_PATH = os.getenv("ROOT_PATH", "/datagis")
REDIS_URL = os.getenv("REDIS_URL", "redis://192.168.70.20:6379/0")

# Konfigurasi Celery dengan Timezone Jakarta (WIB)
celery_app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)
celery_app.conf.update(
    timezone='Asia/Jakarta',
    enable_utc=False,
    task_track_started=True,
    result_extended=True,  # Menambahkan detail tambahan di hasil task
    worker_prefetch_multiplier=1
)

# Timezone helper
jakarta_tz = pytz.timezone('Asia/Jakarta')

# --- 2. SCHEMAS ---
class ScriptRequest(BaseModel):
    script_name: str
    args: Optional[List[str]] = []
    env: Optional[Dict[str, str]] = {}

# --- 3. APP METADATA ---
tags_metadata = [
    {"name": "API Data Kehutanan", "description": "Akses Layer Spasial (GeoJSON) & Tabel Atribut."},
    {"name": "Eksplorasi Data", "description": "Navigasi skema dan daftar tabel."},
    {"name": "Sinkronisasi Data (Redis)", "description": "ETL Control via Celery Worker."},
    {"name": "Sistem", "description": "Health, Logs, & Time Sync."},
]

app = FastAPI(
    title="Geospasial API Kehutanan",
    description="### Enterprise Middleware v1.7.0\nLayanan Integrasi Data Kehutanan via Redis Task Queue & Fast GeoJSON Streamer.",
    version="1.7.0",
    root_path=ROOT_PATH,
    openapi_tags=tags_metadata
)

app.add_middleware(
    CORSMiddleware, 
    allow_origins=["*"], 
    allow_methods=["*"], 
    allow_headers=["*"]
)

# --- 4. SECURITY ---
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)

async def get_api_key(header_key: str = Security(api_key_header)):
    if header_key == API_KEY:
        return header_key
    raise HTTPException(
        status_code=403, 
        detail="Akses Ditolak: API Key tidak valid atau belum disertakan."
    )

# --- 5. DATABASE ENGINE ---
engine = create_engine(
    DATABASE_URL, 
    pool_size=10, 
    max_overflow=20, 
    pool_pre_ping=True
)

# --- 6. ENDPOINTS: API DATA KEHUTANAN (SPATIAL & ATRIBUT) ---

@app.get("/api/v1/layers/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
async def get_spatial_layer(schema_name: str, table_name: str, _=Depends(get_api_key)):
    """
    High Performance Streamer: Mengalirkan GeoJSON langsung dari PostGIS.
    """
    # Sanitasi input dasar
    clean_schema = "".join(c for c in schema_name if c.isalnum() or c == "_")
    clean_table = "".join(c for c in table_name if c.isalnum() or c == "_")

    def generate_geojson():
        yield '{"type": "FeatureCollection", "features": ['

        query = text(f"""
            SELECT jsonb_build_object(
                'type', 'Feature',
                'geometry', ST_AsGeoJSON(geom)::jsonb,
                'properties', to_jsonb(t.*) - 'geom'
            ) AS feature
            FROM "{clean_schema}"."{clean_table}" AS t
        """)

        try:
            with engine.connect() as conn:
                result = conn.execution_options(stream_results=True).execute(query)
                first = True
                for row in result:
                    if not first:
                        yield ","
                    yield json.dumps(row[0])
                    first = False
        except Exception as e:
            logger.error(f"Streaming Error: {str(e)}")
            # JSON error placeholder jika streaming terputus
            yield f', "error": "{str(e)}"'

        meta = {
            "schema": clean_schema,
            "table": clean_table,
            "timestamp": datetime.now(jakarta_tz).isoformat()
        }
        yield f'], "metadata": {json.dumps(meta)}}}'

    return StreamingResponse(generate_geojson(), media_type="application/json")

@app.get("/api/v1/data/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_attribute_data(schema_name: str, table_name: str, page: int = 1, limit: int = 500, _=Depends(get_api_key)):
    """Mengambil data tabular dengan sistem paging."""
    try:
        offset = (page - 1) * limit
        sql = text(f'SELECT * FROM "{schema_name}"."{table_name}" LIMIT :limit OFFSET :offset')
        with engine.connect() as conn:
            df = pd.read_sql(sql, conn, params={"limit": limit, "offset": offset})
            if 'geom' in df.columns:
                df = df.drop(columns=['geom'])
        return {
            "metadata": {
                "schema": schema_name, 
                "table": table_name, 
                "record_count": len(df), 
                "page": page,
                "server_time": datetime.now(jakarta_tz).strftime("%Y-%m-%d %H:%M:%S")
            },
            "data": df.to_dict(orient="records")
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- 7. ENDPOINTS: EKSPLORASI DATA ---

@app.get("/api/v1/list-schemas", tags=["Eksplorasi Data"])
def list_schemas(_=Depends(get_api_key)):
    with engine.connect() as conn:
        query = text("SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN ('information_schema', 'pg_catalog') ORDER BY schema_name;")
        result = conn.execute(query)
        return {"schemas": [row[0] for row in result]}

@app.get("/api/v1/list-tables/{schema_name}", tags=["Eksplorasi Data"])
def list_tables(schema_name: str, _=Depends(get_api_key)):
    try:
        query = text("SELECT table_name FROM information_schema.tables WHERE table_schema = :schema AND table_type = 'BASE TABLE' ORDER BY table_name;")
        with engine.connect() as conn:
            result = conn.execute(query, {"schema": schema_name})
            tables = [row[0] for row in result]
        return {"schema": schema_name, "tables": tables}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- 8. ENDPOINTS: SINKRONISASI DATA (CELERY/REDIS TRIGGER) ---

@app.post("/api/v1/sync/run-script", tags=["Sinkronisasi Data (Redis)"])
async def trigger_sync(req: ScriptRequest, _=Depends(get_api_key)):
    """Memicu background task untuk menjalankan skrip Python."""
    script_path = req.script_name.lstrip("/")
    script_full_path = os.path.join(SCRIPTS_DIR, script_path)

    if not os.path.exists(script_full_path):
        logger.error(f"Script Not Found: {script_full_path}")
        raise HTTPException(status_code=404, detail=f"Skrip {script_path} tidak ditemukan.")

    # Memicu fungsi di worker.py
    task = celery_app.send_task(
        "execute_geo_script",
        args=[script_path, req.args, req.env]
    )

    return {
        "status": "success",
        "task_id": task.id,
        "script": script_path,
        "queued_at": datetime.now(jakarta_tz).strftime("%Y-%m-%d %H:%M:%S") + " WIB"
    }

@app.get("/api/v1/sync/status/{task_id}", tags=["Sinkronisasi Data (Redis)"])
async def get_task_status(task_id: str, _=Depends(get_api_key)):
    """Mengecek status task di Redis."""
    res = AsyncResult(task_id, app=celery_app)
    response = {
        "task_id": task_id, 
        "status": res.status, 
        "ready": res.ready(),
        "server_time": datetime.now(jakarta_tz).strftime("%H:%M:%S")
    }
    if res.ready():
        response["result"] = res.result
    return response

# --- 9. ENDPOINTS: SISTEM & LOGS ---

@app.get("/api/v1/sync/logs", tags=["Sistem"])
async def get_logs(lines: int = 50, _=Depends(get_api_key)):
    """Membaca log aktivitas sinkronisasi."""
    log_file = os.path.join(DATA_DIR, "kups_process.log") # Disesuaikan dengan skrip KUPS
    if not os.path.exists(log_file):
        return {"content": ["Log file not found."]}
    try:
        with open(log_file, "r") as f:
            content = f.readlines()
            return {"content": content[-lines:]}
    except Exception as e:
        return {"error": str(e)}

@app.get("/health", tags=["Sistem"])
def health():
    db_status = "connected"
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
    except:
        db_status = "error"

    return {
        "status": "healthy",
        "timestamp": datetime.now(jakarta_tz).isoformat(),
        "version": "1.7.0",
        "database": db_status,
        "timezone": "Asia/Jakarta (WIB)"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
