import os
import logging
import shutil
import subprocess
import pandas as pd
import geopandas as gpd
from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI, Depends, HTTPException, Query, Security, status, BackgroundTasks
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

# --- 1. LOGGING SETUP ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("geo-api")

# --- 2. ENVIRONMENT CONFIGURATION ---
DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("PGIS_API_TOKEN", "pgis-pass-2026")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
SCRIPTS_DIR = os.getenv("SCRIPTS_DIR", "/app/scripts")
ROOT_PATH = os.getenv("ROOT_PATH", "/datagis")
DEFAULT_SCHEMA = os.getenv("DB_SCHEMA", "datagis")

# --- 3. SECURITY SETUP ---
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)

async def get_api_key(api_key: str = Security(api_key_header)):
    if api_key == API_KEY:
        return api_key
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Validasi API Key Gagal. Akses Ditolak."
    )

# --- 4. MODELS ---
class ScriptRequest(BaseModel):
    script_name: str
    args: Optional[List[str]] = []

class PBPHSyncRequest(BaseModel):
    igt: str  # Contoh: PERSETUJUAN_KOMITMEN_PBPH atau PBPH_DEFINITIF

# --- 5. GLOBAL STATE (Sync Status) ---
sync_status_kups = {"is_running": False, "last_run": None, "message": "Idle"}
sync_status_pbph = {"is_running": False, "last_run": None, "message": "Idle", "current_igt": None}
sync_status_generic = {"is_running": False, "last_run": None, "message": "Idle"}

# --- 6. DATABASE & APP INITIALIZATION ---
if not DATABASE_URL:
    logger.error("DATABASE_URL tidak ditemukan di environment variables!")

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    connect_args={"options": f"-csearch_path={DEFAULT_SCHEMA},public"}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

tags_metadata = [
    {"name": "Eksplorasi Data", "description": "Navigasi skema dan tabel database."},
    {"name": "API Data Kehutanan", "description": "Akses data spasial dan tabular."},
    {"name": "Sinkronisasi Data", "description": "Otomatisasi pembaruan data (KUPS & PBPH)."},
    {"name": "Sistem", "description": "Pengecekan kesehatan dan manajemen storage."},
]

app = FastAPI(
    title="Geospatial API Kehutanan",
    version="1.6.0",
    root_path=ROOT_PATH,
    openapi_tags=tags_metadata
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- 7. BACKGROUND TASKS ---
def run_generic_script_task(script_name: str, args: List[str]):
    global sync_status_generic
    sync_status_generic.update({"is_running": True, "message": f"Running {script_name}"})
    try:
        script_path = os.path.join(SCRIPTS_DIR, script_name)
        cmd = ["python3", script_path] + args
        result = subprocess.run(cmd, capture_output=True, text=True)
        status_msg = "Success" if result.returncode == 0 else f"Error: {result.stderr}"
        sync_status_generic.update({"message": status_msg, "last_run": datetime.now().isoformat()})
    except Exception as e:
        sync_status_generic.update({"message": f"Exception: {str(e)}"})
    finally:
        sync_status_generic["is_running"] = False

def sync_pbph_task(igt: str):
    """Menjalankan skrip pbph_integrated.py dengan environment variable IGT tertentu"""
    global sync_status_pbph
    sync_status_pbph.update({"is_running": True, "message": f"Syncing {igt}...", "current_igt": igt})
    try:
        script_path = os.path.join(SCRIPTS_DIR, "pbph_integrated.py")
        # Mengirimkan environment variable IGT ke sub-proses
        env = os.environ.copy()
        env["IGT"] = igt
        
        result = subprocess.run(["python3", script_path], capture_output=True, text=True, env=env)
        
        if result.returncode == 0:
            status_msg = f"Selesai: {igt} berhasil diperbarui."
            logger.info(f"PBPH Sync Success: {igt}")
        else:
            status_msg = f"Gagal: {result.stderr.splitlines()[-1] if result.stderr else 'Unknown error'}"
            logger.error(f"PBPH Sync Error: {result.stderr}")
            
        sync_status_pbph.update({"message": status_msg, "last_run": datetime.now().isoformat()})
    except Exception as e:
        sync_status_pbph.update({"message": f"Exception: {str(e)}"})
    finally:
        sync_status_pbph["is_running"] = False

# --- 8. ENDPOINTS ---

# --- EKSPLORASI DATA ---
@app.get("/api/v1/list-schemas", tags=["Eksplorasi Data"])
def list_schemas(_=Depends(get_api_key)):
    with engine.connect() as conn:
        query = "SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN ('information_schema', 'pg_catalog') ORDER BY schema_name;"
        result = conn.execute(text(query))
        return {"schemas": [row[0] for row in result]}

@app.get("/api/v1/list-tables/{schema_name}", tags=["Eksplorasi Data"])
def list_tables(schema_name: str, search: str = Query(None), _=Depends(get_api_key)):
    with engine.connect() as conn:
        query = text("SELECT table_name FROM information_schema.tables WHERE table_schema = :schema ORDER BY table_name")
        result = conn.execute(query, {"schema": schema_name})
        tables = [row[0] for row in result]
        if search:
            tables = [t for t in tables if search.lower() in t.lower()]
        return {"tables": tables}

# --- API DATA KEHUTANAN ---
@app.get("/api/v1/layers/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_spatial_layer(schema_name: str, table_name: str, page: int = Query(1), limit: int = Query(500), _=Depends(get_api_key)):
    try:
        offset = (page - 1) * limit
        sql = text(f'SELECT * FROM "{schema_name}"."{table_name}" LIMIT :limit OFFSET :offset')
        with engine.connect() as conn:
            gdf = gpd.read_postgis(sql, conn, geom_col="geom", params={"limit": limit, "offset": offset})
        if gdf.empty:
            return {"type": "FeatureCollection", "features": [], "metadata": {"total": 0}}
        res = gdf.__geo_interface__
        res["metadata"] = {"schema": schema_name, "table": table_name, "page": page, "count": len(gdf)}
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/tables/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_table_data(schema_name: str, table_name: str, page: int = Query(1), limit: int = Query(500), _=Depends(get_api_key)):
    try:
        offset = (page - 1) * limit
        sql = text(f'SELECT * FROM "{schema_name}"."{table_name}" LIMIT :limit OFFSET :offset')
        with engine.connect() as conn:
            df = pd.read_sql(sql, conn, params={"limit": limit, "offset": offset})
        df = df.drop(columns=[c for c in df.columns if c.lower() in ['geom', 'geometry', 'shape']], errors='ignore')
        return {"data": df.to_dict(orient="records")}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/stats/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
def get_table_stats(schema_name: str, table_name: str, _=Depends(get_api_key)):
    with engine.connect() as conn:
        total = conn.execute(text(f'SELECT COUNT(*) FROM "{schema_name}"."{table_name}"')).scalar()
        return {"total_records": total}

# --- SINKRONISASI DATA ---
@app.post("/api/v1/sync/pbph", tags=["Sinkronisasi Data"])
async def trigger_pbph_sync(req: PBPHSyncRequest, background_tasks: BackgroundTasks, _=Depends(get_api_key)):
    """Memicu pembaruan data PBPH untuk IGT tertentu secara asinkron."""
    if sync_status_pbph["is_running"]:
        raise HTTPException(status_code=400, detail=f"Sinkronisasi PBPH sedang berjalan untuk {sync_status_pbph['current_igt']}")
    
    background_tasks.add_task(sync_pbph_task, req.igt)
    return {"status": "Started", "igt": req.igt, "estimated_duration": "15-30 seconds"}

@app.post("/api/v1/sync/run-script", tags=["Sinkronisasi Data"])
async def trigger_script(req: ScriptRequest, background_tasks: BackgroundTasks, _=Depends(get_api_key)):
    if not os.path.exists(os.path.join(SCRIPTS_DIR, req.script_name)):
        raise HTTPException(status_code=404, detail="Skrip tidak ditemukan.")
    background_tasks.add_task(run_generic_script_task, req.script_name, req.args)
    return {"status": "Started", "script": req.script_name}

@app.get("/api/v1/sync/status", tags=["Sinkronisasi Data"])
async def get_sync_status(_=Depends(get_api_key)):
    return {"kups": sync_status_kups, "pbph": sync_status_pbph, "generic": sync_status_generic}

# --- SISTEM ---
@app.get("/health", tags=["Sistem"])
def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.get("/api/v1/system/storage", tags=["Sistem"])
async def get_storage_info(_=Depends(get_api_key)):
    total, used, free = shutil.disk_usage(DATA_DIR)
    files = []
    for f in os.listdir(DATA_DIR):
        path = os.path.join(DATA_DIR, f)
        if os.path.isfile(path):
            files.append({"name": f, "size_mb": round(os.path.getsize(path) / (1024*1024), 2)})
    return {
        "disk_free_gb": round(free / (1024**3), 2),
        "disk_total_gb": round(total / (1024**3), 2),
        "files_count": len(files),
        "files": files
    }

@app.delete("/api/v1/system/cleanup", tags=["Sistem"])
async def cleanup_storage(filename: str = Query(None), _=Depends(get_api_key)):
    deleted = 0
    try:
        if filename:
            path = os.path.join(DATA_DIR, filename)
            if os.path.exists(path) and not os.path.isdir(path):
                os.remove(path); deleted = 1
        else:
            for f in os.listdir(DATA_DIR):
                if f.endswith((".zip", ".json", ".geojson", ".gdb_tmp", ".lock")):
                    os.remove(os.path.join(DATA_DIR, f))
                    deleted += 1
        return {"deleted": deleted, "message": "Pembersihan selesai."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
