import os
import sys
import requests
import shutil
import zipfile
import time
from datetime import datetime
import pandas as pd
import geopandas as gpd
from sqlalchemy import create_engine, text
from shapely.geometry import MultiPolygon

# =================================================================
# 1️⃣ KONFIGURASI & START TIME
# =================================================================
start_proc = time.time()
start_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Set PROJ_LIB agar library PROJ dapat menemukan database koordinat (EPSG)
os.environ['PROJ_LIB'] = '/usr/local/lib/python3.12/site-packages/pyproj/proj_dir/share/proj'

# Parameter Dinamis (Environment Variables)
IGT = os.getenv("IGT", "PERSETUJUAN_KOMITMEN_PBPH")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_SCHEMA = os.getenv("DB_SCHEMA", "public")
PBPH_USER = os.getenv("PBPH_USER")
PBPH_PASS = os.getenv("PBPH_PASS")

# Pathing File
GDB_NAME = f"{IGT}.gdb"
GDB_PATH = os.path.join(DATA_DIR, GDB_NAME)
ZIP_PATH = os.path.join(DATA_DIR, f"{GDB_NAME}.zip")
ENDPOINT = f"https://phl.kehutanan.go.id/api/v1/{IGT}?select=*"

def run_process():
    # Validasi Kredensial
    if not all([PBPH_USER, PBPH_PASS, DB_NAME, DB_USER, DB_PASS]):
        print("❌ Error: Kredensial API atau Database belum lengkap di Environment Variables.")
        sys.exit(1)

    print(f"------------------------------------------")
    print(f"🌐 Menghubungi API untuk IGT: {IGT}")
    
    # 2️⃣ PENGAMBILAN DATA (API)
    try:
        response = requests.get(ENDPOINT, auth=(PBPH_USER, PBPH_PASS), timeout=300)
        response.raise_for_status()
        raw_data = response.json().get("data", [])
    except Exception as e:
        print(f"❌ Error API: {e}")
        sys.exit(1)

    if not raw_data:
        print(f"⚠️ Data '{IGT}' kosong atau tidak ditemukan.")
        return

    print(f"⚡ Memproses {len(raw_data)} fitur...")
    df = pd.DataFrame(raw_data)
    
    # Filter hanya data yang memiliki geometri valid
    df = df[df['geom'].notnull() & (df['geom'].str.len() > 10)].copy()

    # 3️⃣ TRANSFORMASI SPASIAL & VALIDASI
    # Inisialisasi GeoDataFrame dari WKB (Hex)
    gdf = gpd.GeoDataFrame(
        df.drop(columns=['geom']),
        geometry=gpd.GeoSeries.from_wkb(df['geom'].apply(lambda x: bytes.fromhex(x))),
        crs=None
    ).rename_geometry('geom')

    print("🧹 Validasi koordinat dan sistem referensi spasial...")
    test_geom = gdf.geom.dropna().iloc[0] if not gdf.empty else None
    
    # Deteksi Otomatis: Projected (Meter) vs Geographic (Degree)
    if test_geom and abs(test_geom.centroid.x) > 180:
        print("📍 Deteksi koordinat METER. Reproyeksi ke EPSG:4326...")
        gdf.crs = "EPSG:3857"
        gdf = gdf.to_crs("EPSG:4326")
    else:
        print("📍 Deteksi koordinat DERAJAT. Menetapkan EPSG:4326.")
        gdf.crs = "EPSG:4326"

    # Fungsi perbaikan geometri agar selalu valid & bertipe MultiPolygon
    def clean_and_fix(geom):
        if geom is None or geom.is_empty: return None
        if not geom.is_valid: geom = geom.buffer(0)
        if geom.geom_type == 'Polygon': return MultiPolygon([geom])
        if geom.geom_type == 'MultiPolygon': return geom
        return None

    gdf['geom'] = gdf['geom'].apply(clean_and_fix)
    gdf = gdf[gdf.geom.notnull()].copy()
    
    # Standarisasi kolom: Uppercase kecuali kolom 'geom'
    gdf.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf.columns]
    
    print(f"✅ Data valid: {len(gdf)} fitur siap disimpan.")

    # 4️⃣ EXPORT KE POSTGIS
    print(f"🐘 Mengimpor ke PostGIS: \"{DB_SCHEMA}\".\"{IGT}\"")
    try:
        conn_url = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        engine = create_engine(conn_url)
        
        # Simpan ke tabel (Replace jika sudah ada)
        gdf.to_postgis(name=IGT, con=engine, schema=DB_SCHEMA, if_exists='replace', index=False,
                        dtype={'geom': 'Geometry(MultiPolygon, 4326)'})
        
        # Buat Index Spasial & Analyze
        with engine.begin() as conn:
            idx_name = f"idx_{IGT.lower()}_geom"
            conn.execute(text(f'CREATE INDEX IF NOT EXISTS "{idx_name}" ON "{DB_SCHEMA}"."{IGT}" USING GIST (geom)'))
            conn.execute(text(f'ANALYZE "{DB_SCHEMA}"."{IGT}"'))
        print("✅ PostGIS Update Berhasil.")
    except Exception as e:
        print(f"⚠️ Gagal simpan PostGIS: {e}")

    # 5️⃣ EXPORT KE FILEGDB & KOMPRESI ZIP
    print(f"💾 Menulis ke FileGDB: {GDB_PATH}")
    try:
        if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
        
        # Layer Creation Options (LCO) untuk mendukung Integer64 & ArcGIS Pro terbaru
        lco = {"TARGET_ARCGIS_VERSION": "ARCGIS_PRO_3_2_OR_LATER"}
        os.environ["OGR_ORGANIZE_POLYGONS"] = "SKIP"
        
        # Export menggunakan engine pyogrio (High Performance)
        gdf.to_file(GDB_PATH, driver="OpenFileGDB", layer=IGT, engine="pyogrio", **lco)
        
        print("📦 Mengompres ke ZIP...")
        if os.path.exists(ZIP_PATH): os.remove(ZIP_PATH)
        
        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, dirs, files in os.walk(GDB_PATH):
                for file in files:
                    full_path = os.path.join(root, file)
                    rel_path = os.path.join(GDB_NAME, file) # Struktur folder dalam ZIP
                    z.write(full_path, rel_path)
        
        # Cleanup folder .gdb setelah berhasil di-zip
        shutil.rmtree(GDB_PATH)
        print("✅ ZIP Berhasil Dibuat.")

    except Exception as e:
        print(f"❌ Gagal Export FileGDB/ZIP: {e}")

    # --- RINGKASAN AKHIR (OUTPUT STYLE KUPS) ---
    end_proc = time.time()
    duration = end_proc - start_proc
    minutes, seconds = divmod(duration, 60)

    print(f"\n" + "—"*45)
    print(f"🏁 PROSES SELESAI!")
    print(f"—"*45)
    print(f"🕒 Mulai    : {start_time_str}")
    print(f"🕒 Selesai  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"⚡ Durasi   : {int(minutes)} menit {int(seconds)} detik")
    print(f"—"*45)
    print(f"✅ Data Valid  : {len(gdf)}")
    print(f"📂 Lokasi ZIP  : {ZIP_PATH}")
    print(f"—"*45 + "\n")

if __name__ == "__main__":
    run_process()
