import os
import requests
import geopandas as gpd
import pandas as pd
from sqlalchemy import create_engine
from shapely.geometry import Point

# --- CONFIGURATION ---
DB_URL = os.getenv("DATABASE_URL")
BASE_URL = "https://gokups.hutsos.kehutanan.go.id/api/v1/kups"
SCHEMA = "datagis"
TABLE_NAME = "kups"

def fetch_all_kups():
    all_data = []
    current_page = 1
    
    print(f"🚀 Memulai pengambilan data dari {BASE_URL}...")
    
    while True:
        try:
            response = requests.get(f"{BASE_URL}?page={current_page}", timeout=30)
            response.raise_for_status()
            json_data = response.json()
            
            rows = json_data.get('data', [])
            if not rows:
                break
                
            all_data.extend(rows)
            print(f"✅ Page {current_page}/{json_data['last_page']} fetched ({len(rows)} records)")
            
            if current_page >= json_data['last_page']:
                break
            
            current_page += 1
        except Exception as e:
            print(f"❌ Error pada halaman {current_page}: {e}")
            break
            
    return all_data

def sync():
    engine = create_engine(DB_URL)
    raw_records = fetch_all_kups()
    
    if not raw_records:
        print("⚠️ Tidak ada data untuk disinkronisasi.")
        return

    # 1. Convert ke DataFrame
    df = pd.DataFrame(raw_records)
    
    # 2. Pembersihan: Ubah lintang/nujur ke numeric dan hapus yang tidak valid
    df['lintang'] = pd.to_numeric(df['lintang'], errors='coerce')
    df['nujur'] = pd.to_numeric(df['nujur'], errors='coerce')
    df = df.dropna(subset=['lintang', 'nujur'])

    # 3. Create Geometri Point (nujur=longitude, lintang=latitude)
    geometry = [Point(xy) for xy in zip(df['nujur'], df['lintang'])]
    
    # 4. Create GeoDataFrame
    gdf = gpd.GeoDataFrame(df, geometry=geometry, crs="EPSG:4326")
    
    # 5. Drop kolom list/dict agar bisa masuk ke SQL (potensi & produk)
    # Kita ubah menjadi string agar tetap bisa dibaca di tooltip peta
    gdf['potensi'] = gdf['potensi'].astype(str)
    gdf['produk'] = gdf['produk'].astype(str)

    # 6. Kirim ke PostGIS
    print(f"📦 Mengirim {len(gdf)} data ke tabel {SCHEMA}.{TABLE_NAME}...")
    gdf.to_postgis(TABLE_NAME, engine, schema=SCHEMA, if_exists="replace", index=False)
    print("✨ Sinkronisasi Selesai!")

if __name__ == "__main__":
    sync()
