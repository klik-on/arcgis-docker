from arcgis.gis import GIS
from getpass import getpass

def get_folder_name(f):
    props = getattr(f, "_properties", {})
    return props.get('title') or props.get('name')

# --- Login ---
portal_url = "https://dbgis.planologi.kehutanan.go.id/portal"
username = "portaladmin"
password = getpass("Masukkan password portal: ")

gis = GIS(portal_url, username, password)
user = gis.users.get(username)

# --- Folder target ---
target_folder = "DataSIG"

# --- Ambil folder user ---
folders = list(user.folders)
folder_names = [get_folder_name(f) for f in folders]

# Buat folder jika belum ada
if target_folder not in folder_names:
    user.create_folder(target_folder)
    print(f"Folder '{target_folder}' dibuat.")
else:
    print(f"Folder '{target_folder}' sudah ada.")

folder_obj = next(f for f in user.folders if get_folder_name(f) == target_folder)

# --- Upload GDB ---
zip_gdb_path = "./data/KUPS.gdb.zip"
item_title = "KUPS GDB Data"
service_name = "KUPS_GDB"

# Check apakah item dengan nama sama sudah ada di folder
existing_items = [i for i in user.items(folder=target_folder) if i.title == item_title]

if existing_items:
    print(f"Item '{item_title}' sudah ada, akan dihapus untuk overwrite.")
    for i in existing_items:
        try:
            i.delete()
            print(f"Item '{i.title}' dihapus.")
        except Exception as e:
            print(f"Gagal hapus item '{i.title}': {e}")

# Upload item baru ke portal root
item_properties = {
    "title": item_title,
    "tags": "gdb, spasial",
    "type": "File Geodatabase"
}

gdb_item = gis.content.add(item_properties=item_properties, data=zip_gdb_path)
print(f"Item '{item_title}' berhasil di-upload ke portal (sementara di root).")

# Pindahkan ke folder target
gdb_item.move(folder_obj)
print(f"Item '{item_title}' dipindahkan ke folder '{target_folder}'.")

# --- Publish Hosted Feature Layer ---
# Cek apakah layer dengan nama service_name sudah ada
existing_services = [s for s in gis.content.search(query=f"title:{service_name}", item_type="Feature Layer Collection") if s.owner == username]

if existing_services:
    print(f"Layer service '{service_name}' sudah ada, akan dihapus untuk overwrite.")
    for s in existing_services:
        try:
            s.delete()
            print(f"Layer service '{s.title}' dihapus.")
        except Exception as e:
            print(f"Gagal hapus layer '{s.title}': {e}")

# Publish FGDB baru
publish_params = {
    "name": service_name,
    "type": "fileGeodatabase"
}

published_item = gdb_item.publish(publish_parameters=publish_params)
print("URL service:", published_item.url)
print("Hosted layer item:", published_item)

