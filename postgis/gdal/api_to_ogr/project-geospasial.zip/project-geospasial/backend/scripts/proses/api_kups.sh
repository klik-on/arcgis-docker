#!/bin/bash
# Daftar IGT yang ingin ditarik
LAYERS=("KUPS" )

for layer in "${LAYERS[@]}"
do
    echo "Processing layer: $layer"
    IGT=$layer python3 /app/scripts/processing/gpd_KUPS_gdbtopgis.py
done
