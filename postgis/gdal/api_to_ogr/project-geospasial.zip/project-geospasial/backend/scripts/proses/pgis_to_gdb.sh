#!/bin/bash
set -e

# === Konfigurasi Internal ===
# Mengambil LAYER_NAME dari argumen pertama ($1)
LAYER_NAME=$1
DATA_DIR="/app/data"

# Validasi Input
if [ -z "$LAYER_NAME" ]; then
  echo "❌ Error: Nama layer tidak disertakan!"
  echo "Penggunaan: ./pgis_to_gdb.sh NAMA_LAYER"
  echo "Contoh: ./pgis_to_gdb.sh PBPH_DEFINITIF"
  exit 1
fi

# === Cek Variabel Environment (dari .env) ===
if [ -z "$DB_HOST" ] || [ -z "$DB_PASS" ]; then
  echo "❌ Error: Variabel database tidak ditemukan. Pastikan file .env dimuat."
  exit 1
fi

# === Jalur File ===
OUTPUT_GDB="${DATA_DIR}/${LAYER_NAME}.gdb"
ZIP_PATH="${DATA_DIR}/${LAYER_NAME}.gdb.zip"

# === Deteksi Driver GDB ===
# Mencoba FileGDB (Official SDK) atau OpenFileGDB (Built-in GDAL)
if ogrinfo --formats | grep -qE "FileGDB.*(rw\+)"; then
  DRIVER="FileGDB"
  echo "✅ Menggunakan driver FileGDB (SDK Resmi)"
elif ogrinfo --formats | grep -q "OpenFileGDB"; then
  DRIVER="OpenFileGDB"
  echo "⚠️ Menggunakan driver OpenFileGDB (Hanya mendukung write pada GDAL v3.6+)"
else
  echo "❌ Tidak ada driver FileGDB yang mendukung penulisan (write)."
  exit 1
fi

# === Siapkan folder ===
mkdir -p "$DATA_DIR"

echo "🚀 Mengekspor ${DB_SCHEMA}.${LAYER_NAME} dari PostGIS ke GDB..."

# === Jalankan ekspor ogr2ogr ===
# Menggunakan array untuk argumen agar lebih rapi
OGR_ARGS=(
  -f "$DRIVER"
  "$OUTPUT_GDB"
  PG:"host=${DB_HOST} port=${DB_PORT} dbname=${DB_NAME} user=${DB_USER} password=${DB_PASS}"
  "${DB_SCHEMA}.${LAYER_NAME}"
  -nln "$LAYER_NAME"
  -dim 2
  -t_srs EPSG:4326
  -nlt PROMOTE_TO_MULTI
  -progress
  --config OGR_ENABLE_CURVE_REDUCTION YES
  --config OGR_ORGANIZE_POLYGONS SKIP
)

# Tambahkan overwrite jika folder GDB sudah ada
if [ -d "$OUTPUT_GDB" ] || [ "$DRIVER" = "FileGDB" ]; then
  OGR_ARGS+=(-lco OVERWRITE=YES)
fi

ogr2ogr "${OGR_ARGS[@]}"

# === Validasi & Kompresi ===
if [ ! -d "$OUTPUT_GDB" ]; then
  echo "❌ Ekspor gagal: folder GDB tidak terbentuk."
  exit 1
fi

echo "📦 Mengarsipkan ke ZIP: ${ZIP_PATH}"
(
  cd "$DATA_DIR" || exit 1
  zip -r "$(basename "$ZIP_PATH")" "$(basename "$OUTPUT_GDB")" > /dev/null
)

# === Cleanup ===
if [ -f "$ZIP_PATH" ]; then
  rm -rf "$OUTPUT_GDB"
  echo "✅ Ekspor Berhasil!"
  echo "📁 Lokasi: $ZIP_PATH"
  echo "🕒 Selesai pada: $(date)"
else
  echo "❌ Gagal membuat file ZIP."
  exit 1
fi
