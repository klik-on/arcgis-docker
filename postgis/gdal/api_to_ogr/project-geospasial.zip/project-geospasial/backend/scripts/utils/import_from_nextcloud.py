#!/usr/bin/env python3
import os
import sys
import subprocess
from sqlalchemy import create_engine, text
import geopandas as gpd
from dotenv import load_dotenv

def import_from_nextcloud():
    # 1. Validasi Input
    if len(sys.argv) < 3:
        print("❌ Error: Argumen tidak lengkap!")
        print(f"💡 Penggunaan: {sys.argv[0]} NAMA_SKEMA NAMA_TABEL")
        sys.exit(1)

    schema = sys.argv[1]
    table = sys.argv[2]
    
    load_dotenv()
    db_url = os.getenv("DATABASE_URL")
    
    if not db_url:
        print("❌ Error: DATABASE_URL tidak ditemukan di .env")
        sys.exit(1)

    # 2. Konfigurasi Path
    data_dir = "/app/data"
    os.makedirs(data_dir, exist_ok=True)
    
    zip_name = f"{table}.gdb.zip"
    zip_local_path = os.path.join(data_dir, zip_name)
    gdb_name = f"{table}.gdb"
    gdb_local_path = os.path.join(data_dir, gdb_name)
    
    nc_remote = os.getenv("NC_REMOTE", "nextcloud")
    nc_path = os.getenv("NC_PATH", "GIS/Export")

    try:
        # 3. Download & Extract
        print(f"☁️  Mengunduh {zip_name} dari Nextcloud...")
        subprocess.run(["rclone", "copy", f"{nc_remote}:{nc_path}/{zip_name}", data_dir], check=True)

        print("🔓 Mengekstrak FileGDB...")
        if os.path.exists(gdb_local_path):
            subprocess.run(["rm", "-rf", gdb_local_path], check=True)
        subprocess.run(["unzip", "-q", zip_local_path, "-d", data_dir], check=True)

        # 4. Membaca Data
        print(f"📡 Membaca data dari FileGDB...")
        gdf = gpd.read_file(gdb_local_path, engine="pyogrio")

        if gdf.empty:
            print("⚠️ Data kosong.")
            sys.exit(0)

        # Pastikan kolom geometri bernama 'geom' sebelum diupload
        if gdf.geometry.name != 'geom':
            gdf = gdf.rename_geometry('geom')

        # 5. Upload ke PostGIS (Replace Mode)
        print(f"🚀 Menghubungkan ke database...")
        engine = create_engine(db_url)
        
        print(f"♻️  Mereplace tabel \"{schema}\".\"{table}\"...")
        # Note: 'index=False' mencegah kolom index dataframe ikut terbuat di database
        gdf.to_postgis(
            name=table,
            con=engine,
            schema=schema,
            if_exists='replace', 
            index=False
        )

        # 6. Pembuatan Index Spasial & Statistik
        print(f"⚡ Membuat index spasial & memperbarui statistik untuk \"{table}\"...")
        index_name = f"idx_{table}_geom"
        
        with engine.connect() as conn:
            # Drop index lama (jika ada) dan buat baru menggunakan GIST
            conn.execute(text(f'DROP INDEX IF EXISTS "{schema}"."{index_name}"'))
            conn.execute(text(f'CREATE INDEX "{index_name}" ON "{schema}"."{table}" USING GIST (geom)'))
            conn.commit()
            
            # Autocommit ANALYZE agar statistik query planner diperbarui
            with conn.execution_options(isolation_level="AUTOCOMMIT"):
                conn.execute(text(f'ANALYZE "{schema}"."{table}"'))
            
        print(f"✅ Index {index_name} dan ANALYZE berhasil diselesaikan.")

        # 7. Cleanup
        print("🧹 Membersihkan file temporer...")
        subprocess.run(["rm", "-rf", gdb_local_path])
        subprocess.run(["rm", "-f", zip_local_path])

        print(f"🏁 Selesai! Tabel \"{schema}\".\"{table}\" siap digunakan.")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    import_from_nextcloud()
