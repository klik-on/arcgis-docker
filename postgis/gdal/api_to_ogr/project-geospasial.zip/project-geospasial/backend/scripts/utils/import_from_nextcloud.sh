#!/bin/bash
# ==============================================================================
# Skrip: import_from_nextcloud.sh
# Fungsi: Import FileGDB dari Nextcloud ke PostGIS (Mendukung Huruf Besar)
# ==============================================================================
set -e

# === 1. Validasi Input ===
if [ -z "$1" ]; then
  echo "❌ Error: Nama layer tidak ditentukan!"
  echo "💡 Penggunaan: $0 KUPS"
  exit 1
fi

# Variabel LAYER_NAME akan mempertahankan casing asli (misal: KUPS)
LAYER_NAME="$1"

# === 2. Load .env ===
DOTENV_PATH="$(dirname "$0")/../../.env"
if [ -f "$DOTENV_PATH" ]; then
  export $(grep -v '^#' "$DOTENV_PATH" | xargs)
else
  echo "⚠️  Peringatan: File .env tidak ditemukan, pastikan env tersedia di sistem."
fi

# === 3. Konfigurasi Path ===
DATA_DIR="/tmp/gis_import_${LAYER_NAME}_$(date +%s)"
mkdir -p "$DATA_DIR"

NEXTCLOUD_REMOTE="${NC_REMOTE:-nextcloud}"
NEXTCLOUD_PATH="${NC_PATH:-GIS/Export}"
ZIP_FILE="${LAYER_NAME}.gdb.zip"
GDB_FOLDER="${LAYER_NAME}.gdb"

# === 4. Download dari Nextcloud ===
echo "📥 Mengunduh $ZIP_FILE dari Nextcloud..."
if ! rclone copy "${NEXTCLOUD_REMOTE}:${NEXTCLOUD_PATH}/$ZIP_FILE" "$DATA_DIR" --progress; then
    echo "❌ Error: File $ZIP_FILE tidak ditemukan di Nextcloud (${NEXTCLOUD_REMOTE}:${NEXTCLOUD_PATH})."
    rm -rf "$DATA_DIR"
    exit 1
fi

# === 5. Ekstrak File ===
echo "📦 Mengekstrak data..."
cd "$DATA_DIR"
unzip -o "$ZIP_FILE"

# === 6. Import ke PostGIS ===
# Perhatikan penggunaan \"${LAYER_NAME}\" untuk menjaga huruf besar
echo "🚀 Memasukkan ke PostGIS: ${LAYER_NAME}..."

ogr2ogr \
  -f "PostgreSQL" \
  PG:"host=${DB_HOST} port=${DB_PORT} dbname=${DB_NAME} user='${DB_USER}' password='${DB_PASS}'" \
  "$GDB_FOLDER" \
  -nln "${DB_SCHEMA:-public}.\"${LAYER_NAME}\"" \
  -overwrite \
  -progress \
  -skipfailures \
  -t_srs EPSG:4326 \
  -lco GEOMETRY_NAME=geom \
  -lco FID=fid \
  -lco PRECISION=NO \
  -nlt PROMOTE_TO_MULTI \
  --config PG_USE_COPY YES

# === 7. Cleanup ===
echo "🧹 Membersihkan file sementara..."
rm -rf "$DATA_DIR"

echo "✅ Berhasil: Layer '${LAYER_NAME}' telah diperbarui di database."
