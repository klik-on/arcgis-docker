#!/bin/bash

# Gunakan nama container sesuai docker-compose (geo-api atau geo-worker)
CONTAINER_NAME="geo-api"
CERT_SOURCE="/home/dbgis/menlhk_go_id_reissue/Chain_RootCA_Bundle.crt"

echo "==> [1/3] Mengunggah Sertifikat CA ke Container..."
docker cp "$CERT_SOURCE" ${CONTAINER_NAME}:/usr/local/share/ca-certificates/menlhk-ca.crt

echo "==> [2/3] Memperbarui Trust Store di Linux Container..."
docker exec -u root "$CONTAINER_NAME" chown root:root /usr/local/share/ca-certificates/menlhk-ca.crt
docker exec -u root "$CONTAINER_NAME" update-ca-certificates

echo "==> [3/3] Konfigurasi Rclone untuk Nextcloud..."
# Menggunakan rclone obscure untuk keamanan password (opsional)
# Password diambil langsung dari env di dalam container
docker exec "$CONTAINER_NAME" /bin/bash -c "rclone config create nextcloud webdav \
    url=https://dbgis.menlhk.go.id:8080/remote.php/dav/files/datagis/ \
    vendor=nextcloud \
    user=datagis \
    pass=\$(rclone obscure \$NC_PASS)"

echo "==> Selesai! Mengetes koneksi..."
docker exec "$CONTAINER_NAME" rclone lsf nextcloud:
