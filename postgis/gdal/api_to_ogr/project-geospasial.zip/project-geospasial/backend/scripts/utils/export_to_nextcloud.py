#!/usr/bin/env python3
import os
import sys
import subprocess
from sqlalchemy import create_engine, text
import geopandas as gpd
from dotenv import load_dotenv

def export_to_nextcloud():
    # 1. Validasi Input
    if len(sys.argv) < 3:
        print("❌ Error: Argumen tidak lengkap!")
        print(f"💡 Penggunaan: {sys.argv[0]} NAMA_SKEMA NAMA_TABEL")
        sys.exit(1)

    schema = sys.argv[1]
    table = sys.argv[2]
    
    load_dotenv()
    
    # Ambil DATABASE_URL dari .env
    # Format di .env Anda: postgresql+psycopg://user:pass@host:port/dbname
    db_url = os.getenv("DATABASE_URL")
    
    if not db_url:
        print("❌ Error: DATABASE_URL tidak ditemukan di .env")
        sys.exit(1)

    # 2. Konfigurasi Path
    data_dir = "/app/data"
    os.makedirs(data_dir, exist_ok=True)
    
    gdb_name = f"{table}.gdb"
    gdb_path = os.path.join(data_dir, gdb_name)
    zip_path = f"{gdb_path}.zip"
    
    nc_remote = os.getenv("NC_REMOTE", "nextcloud")
    nc_path = os.getenv("NC_PATH", "GIS/Export")

    try:
        # 3. Inisialisasi Database Engine (SQLAlchemy 2.0 + Psycopg 3)
        print(f"🚀 Menghubungkan ke database...")
        engine = create_engine(db_url)

        # 4. Membaca data menggunakan GeoPandas
        # Kita menggunakan query eksplisit untuk menghindari kolom ganda
        query = f'SELECT * FROM "{schema}"."{table}"'
        print(f"📡 Membaca tabel {schema}.{table}...")
        
        gdf = gpd.read_postgis(query, con=engine, geom_col='geom')

        if gdf.empty:
            print("⚠️ Tabel kosong, proses dihentikan.")
            sys.exit(0)

        # 5. Export ke FileGDB menggunakan pyogrio
        # Pyogrio sangat cepat dan sudah mendukung OpenFileGDB
        if os.path.exists(gdb_path):
            print(f"🗑️ Menghapus folder GDB lama...")
            subprocess.run(["rm", "-rf", gdb_path], check=True)

        print(f"📦 Mengekspor {len(gdf)} baris ke FileGDB...")
        gdf.to_file(
            gdb_path, 
            driver="OpenFileGDB", 
            engine="pyogrio", 
            layer=table
        )

        # 6. Kompresi (Pindah ke folder data dulu agar struktur ZIP bersih)
        print("zip Mengompres hasil...")
        subprocess.run(["zip", "-rq", f"{table}.gdb.zip", gdb_name], cwd=data_dir, check=True)

        # 7. Upload via rclone
        print(f"☁️ Mengunggah ke Nextcloud ({nc_remote})...")
        subprocess.run([
            "rclone", "copy", 
            zip_path, 
            f"{nc_remote}:{nc_path}", 
            "--progress"
        ], check=True)

        # 8. Cleanup
        print("🧹 Membersihkan file lokal...")
        if os.path.exists(gdb_path): subprocess.run(["rm", "-rf", gdb_path])
        if os.path.exists(zip_path): subprocess.run(["rm", "-f", zip_path])

        print(f"✅ Berhasil! Tabel {table} sudah diunggah ke {nc_path}")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    export_to_nextcloud()
