import fiona
import pyogrio
from osgeo import ogr

print("--- GDAL Driver Check ---")
# Cek via OGR (Biner GDAL langsung)
cnt = ogr.GetDriverCount()
drivers = [ogr.GetDriver(i).GetName() for i in range(cnt)]
has_filegdb = "FileGDB" in drivers
has_openfilegdb = "OpenFileGDB" in drivers

print(f"FileGDB (Esri SDK): {'✅ YES' if has_filegdb else '❌ NO'}")
print(f"OpenFileGDB (Native): {'✅ YES' if has_openfilegdb else '❌ NO'}")

# Cek via Pyogrio (Yang dipakai GeoPandas)
print("\n--- Pyogrio Driver Check ---")
pyo_drivers = pyogrio.list_drivers()
if "FileGDB" in pyo_drivers:
    print("Pyogrio FileGDB: ✅ Ready")
