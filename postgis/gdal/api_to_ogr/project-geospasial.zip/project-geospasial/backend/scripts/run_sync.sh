#!/bin/bash

# --- KONFIGURASI ---
LOG_FILE="/app/data/sync.log"
MAX_SIZE=10485760  # 10MB dalam Bytes
SCRIPT_PATH=$1
shift

# 1. CEK ROTASI LOG (Auto-Cleanup)
if [ -f "$LOG_FILE" ]; then
    FILE_SIZE=$(stat -c%s "$LOG_FILE")
    if [ $FILE_SIZE -gt $MAX_SIZE ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') [SYSTEM]: Log mencapai batas 10MB. Membersihkan log lama..." > $LOG_FILE
    fi
fi

# 2. HEADER SESI
echo -e "\n" >> $LOG_FILE
echo "##########################################" >> $LOG_FILE
echo "🚀 START: $(date '+%Y-%m-%d %H:%M:%S')" >> $LOG_FILE
echo "📜 Script: $SCRIPT_PATH" >> $LOG_FILE
echo "🆔 User: $(whoami)" >> $LOG_FILE
echo "##########################################" >> $LOG_FILE

# 3. EKSEKUSI PYTHON
# stdbuf memastikan output tidak tertahan di buffer
stdbuf -oL -eL python3 "$SCRIPT_PATH" "$@" 2>&1 | tee -a $LOG_FILE

# 4. FOOTER SESI
echo -e "\n------------------------------------------" >> $LOG_FILE
echo "🏁 END: $(date '+%Y-%m-%d %H:%M:%S')" >> $LOG_FILE
echo "##########################################" >> $LOG_FILE
