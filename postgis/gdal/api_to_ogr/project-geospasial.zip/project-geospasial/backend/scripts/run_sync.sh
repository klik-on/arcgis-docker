#!/bin/bash

# --- 1. KONFIGURASI PATH & LOGGING ---
LOG_FILE="/app/data/sync.log"
TIMESTAMP_START=$(date "+%Y-%m-%d %H:%M:%S")
MAX_LOG_SIZE_KB=5120  # Batas rotasi log (5MB)

# Pastikan direktori log tersedia
mkdir -p /app/data

# --- 2. LOAD ENVIRONMENT VARIABLES ---
# Mengambil variabel dari .env agar skrip Python bisa mengakses database
if [ -f "/app/.env" ]; then
    export $(grep -v '^#' /app/.env | xargs)
    echo "[$TIMESTAMP_START] 💡 Environment variables loaded from .env" >> $LOG_FILE
else
    echo "[$TIMESTAMP_START] ⚠️ Warning: .env file not found at /app/.env" >> $LOG_FILE
fi

# Argumen yang diterima dari Celery/Terminal
# $1: Path ke skrip target (Python atau Shell)
# $2+: Argumen tambahan untuk skrip tersebut
SCRIPT_PATH=$1
shift
ARGS=$@

# --- 3. LOG ROTATION (Proteksi Penyimpanan) ---
if [ -f "$LOG_FILE" ]; then
    FILE_SIZE=$(du -k "$LOG_FILE" | cut -f1)
    if [ "$FILE_SIZE" -gt "$MAX_LOG_SIZE_KB" ]; then
        echo "[$TIMESTAMP_START] 🔄 Rotating log: Max size 5MB reached." > "$LOG_FILE.old"
        tail -c 1M "$LOG_FILE" >> "$LOG_FILE.old"
        true > "$LOG_FILE"
        echo "[$TIMESTAMP_START] ✨ Log file cleared and rotated to sync.log.old" >> $LOG_FILE
    fi
fi

# --- 4. EXECUTION LOGIC ---
echo "----------------------------------------------------------" >> $LOG_FILE
echo "[$TIMESTAMP_START] 🚀 STARTING TASK: $SCRIPT_PATH" >> $LOG_FILE
[ -n "$ARGS" ] && echo "[$TIMESTAMP_START] 📂 ARGUMENTS: $ARGS" >> $LOG_FILE

# Cek apakah file skrip ada
if [ ! -f "$SCRIPT_PATH" ]; then
    echo "[$TIMESTAMP_START] ❌ Error: Script $SCRIPT_PATH not found." >> $LOG_FILE
    exit 1
fi

# Ambil ekstensi file untuk menentukan interpreter
EXTENSION="${SCRIPT_PATH##*.}"

case $EXTENSION in
    py)
        echo "[$TIMESTAMP_START] 🐍 Running with Python 3.12" >> $LOG_FILE
        # Menjalankan python dengan output unbuffered (-u) agar log real-time
        python3 -u "$SCRIPT_PATH" $ARGS >> $LOG_FILE 2>&1
        RESULT=$?
        ;;
    sh)
        echo "[$TIMESTAMP_START] 🐚 Running with Bash Shell" >> $LOG_FILE
        chmod +x "$SCRIPT_PATH"
        bash "$SCRIPT_PATH" $ARGS >> $LOG_FILE 2>&1
        RESULT=$?
        ;;
    *)
        echo "[$TIMESTAMP_START] ❓ Unknown extension .$EXTENSION. Attempting direct execution..." >> $LOG_FILE
        chmod +x "$SCRIPT_PATH"
        "$SCRIPT_PATH" $ARGS >> $LOG_FILE 2>&1
        RESULT=$?
        ;;
esac

# --- 5. FINALIZING & REPORTING ---
TIMESTAMP_END=$(date "+%Y-%m-%d %H:%M:%S")

if [ $RESULT -eq 0 ]; then
    echo "[$TIMESTAMP_END] ✅ TASK COMPLETED SUCCESSFULLY" >> $LOG_FILE
else
    echo "[$TIMESTAMP_END] 💥 TASK FAILED (Exit Code: $RESULT)" >> $LOG_FILE
fi
echo "----------------------------------------------------------" >> $LOG_FILE

# Mengembalikan exit code asli agar Celery Worker mencatat status FAILURE jika skrip gagal
exit $RESULT
