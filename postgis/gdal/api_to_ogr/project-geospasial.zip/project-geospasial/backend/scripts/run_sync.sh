#!/bin/bash

# --- 1. Load Environment Variables ---
# Mencari file .env di root project
if [ -f "/app/.env" ]; then
    # Mengambil variabel, mengabaikan komentar, dan mengekspornya
    export $(grep -v '^#' /app/.env | xargs)
fi

# Argumen yang diterima
SCRIPT_PATH=$1
shift # Sisanya dianggap sebagai argumen untuk skrip target
ARGS=$@

# --- 2. Konfigurasi Logging & Rotasi (Max 5MB) ---
LOG_FILE="/app/data/sync.log"
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

if [ -f "$LOG_FILE" ]; then
    # Cek ukuran file dalam Kilobytes (5120 KB = 5MB)
    FILE_SIZE=$(du -k "$LOG_FILE" | cut -f1)
    if [ "$FILE_SIZE" -gt 5120 ]; then
        echo "[$TIMESTAMP] 🔄 Rotating log: Max size 5MB reached." > "$LOG_FILE.old"
        # Ambil 1MB terakhir dari log lama untuk referensi, simpan ke .old
        tail -c 1M "$LOG_FILE" >> "$LOG_FILE.old"
        # Kosongkan file log utama
        true > "$LOG_FILE"
    fi
fi

# --- 3. Wrapper Execution Logic ---
echo "----------------------------------------------------------" >> $LOG_FILE
echo "[$TIMESTAMP] 🚀 STARTING TASK: $SCRIPT_PATH" >> $LOG_FILE
echo "[$TIMESTAMP] 📂 ARGUMENTS: $ARGS" >> $LOG_FILE

# Ambil ekstensi file
EXTENSION="${SCRIPT_PATH##*.}"

case $EXTENSION in
    py)
        echo "[$TIMESTAMP] 🐍 Interpreter: Python 3" >> $LOG_FILE
        python3 "$SCRIPT_PATH" $ARGS >> $LOG_FILE 2>&1
        RESULT=$?
        ;;
    sh)
        echo "[$TIMESTAMP] 🐚 Interpreter: Bash Shell" >> $LOG_FILE
        # Pastikan izin eksekusi ada
        chmod +x "$SCRIPT_PATH"
        bash "$SCRIPT_PATH" $ARGS >> $LOG_FILE 2>&1
        RESULT=$?
        ;;
    *)
        echo "[$TIMESTAMP] ❌ Error: Unknown file extension .$EXTENSION" >> $LOG_FILE
        RESULT=1
        ;;
esac

# --- 4. Finalizing Log Entry ---
END_TIME=$(date "+%Y-%m-%d %H:%M:%S")
if [ $RESULT -eq 0 ]; then
    echo "[$END_TIME] ✅ TASK COMPLETED SUCCESSFULLY" >> $LOG_FILE
else
    echo "[$END_TIME] 💥 TASK FAILED (Exit Code: $RESULT)" >> $LOG_FILE
fi
echo "----------------------------------------------------------" >> $LOG_FILE

# Kembalikan exit code asli ke worker agar Celery tahu statusnya
exit $RESULT
