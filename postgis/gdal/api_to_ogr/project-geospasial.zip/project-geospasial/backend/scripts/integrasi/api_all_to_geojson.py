import urllib3
import json
import os
import sys
from dotenv import load_dotenv

# === Load environment dari .env ===
load_dotenv()

# === Ambil IGT dari argumen shell ===
if len(sys.argv) < 2:
    print("❌ Gunakan: python api_all_to_geojson.py <IGT> [<CERT_FILE>]")
    sys.exit(1)

IGT = sys.argv[1]
CERT_FILE = sys.argv[2] if len(sys.argv) > 2 else None

BASE_URL = "https://dbgis.planologi.kehutanan.go.id"
ENDPOINT = f"{BASE_URL}/datagis/api/rest/v1/{IGT}"  # Tanpa filter

geojson_path = f"data/{IGT}.geojson"
os.makedirs(os.path.dirname(geojson_path), exist_ok=True)

if os.path.exists(geojson_path):
    print(f"⚠️ File sudah ada dan akan ditimpa: {geojson_path}")

# === Ambil API Key dari .env ===
ANON_KEY = os.getenv("SUPABASE_ANON_KEY")
if not ANON_KEY:
    print("❌ API Key tidak ditemukan. Pastikan file .env tersedia dan SUPABASE_ANON_KEY terisi.")
    sys.exit(1)

# === Konfigurasi HTTP ===
if CERT_FILE and os.path.exists(CERT_FILE):
    print(f"ℹ️ Menggunakan sertifikat self-signed: {CERT_FILE}")
    http = urllib3.PoolManager(cert_reqs='CERT_REQUIRED', ca_certs=CERT_FILE)
else:
    print("⚠️ Sertifikat self-signed tidak ditemukan, fallback tanpa verifikasi SSL")
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    http = urllib3.PoolManager(cert_reqs='CERT_NONE')

headers = {
    "apikey": ANON_KEY,
    "Accept": "application/json"
}

# === Request utama ===
try:
    response = http.request("GET", ENDPOINT, headers=headers)
    if response.status >= 400:
        raise Exception(f"Status code: {response.status}")
except Exception:
    # Fallback ke endpoint lain tanpa /rest/v1/
    ENDPOINT = f"{BASE_URL}/datagis/api/{IGT}"
    print(f"⚠️ Gagal ambil dari REST endpoint, mencoba fallback: {ENDPOINT}")
    response = http.request("GET", ENDPOINT, headers=headers)
    if response.status >= 400:
        print(f"❌ Gagal mengambil data dari API. Status: {response.status}")
        sys.exit(1)

print(f"✅ Data berhasil diambil dari: {ENDPOINT}")

# === Parsing JSON ===
try:
    data = json.loads(response.data.decode("utf-8"))
except Exception as e:
    print(f"❌ Gagal parsing JSON: {e}")
    sys.exit(1)

if not data:
    print("⚠️ API mengembalikan data kosong.")
    sys.exit(1)

# === Buat GeoJSON ===
features = []
total = len(data)
print(f"ℹ️ Memproses {total} entri...")

for idx, row in enumerate(data, start=1):
    geom = row.get("geom") or row.get("geometry")
    if isinstance(geom, str):
        try:
            geom = json.loads(geom)
        except Exception as e:
            print(f"❌ Gagal parsing geometry di entri ke-{idx}: {e}")
            continue

    if not isinstance(geom, dict) or "type" not in geom or "coordinates" not in geom:
        print(f"⚠️ Geometry tidak valid di entri ke-{idx}, dilewati.")
        continue

    feature = {
        "type": "Feature",
        "geometry": geom,
        "properties": {k: v for k, v in row.items() if k not in ["geom", "geometry"]}
    }
    features.append(feature)

    if idx % 100 == 0 or idx == total:
        print(f"🔄 Diproses: {idx}/{total} fitur")

if not features:
    print("⚠️ Tidak ada fitur valid ditemukan. Proses dihentikan.")
    sys.exit(1)

geojson = {
    "type": "FeatureCollection",
    "features": features
}

try:
    with open(geojson_path, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False, indent=2)
    print(f"✅ GeoJSON berhasil disimpan di: {geojson_path}")
    print(f"ℹ️ Total fitur valid: {len(features)}")
except Exception as e:
    print(f"❌ Gagal menyimpan file GeoJSON: {e}")
    sys.exit(1)
