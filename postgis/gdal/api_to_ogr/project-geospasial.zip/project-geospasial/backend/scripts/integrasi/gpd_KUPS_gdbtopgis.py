#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import random
import pandas as pd
import geopandas as gpd
import requests
import urllib3
from datetime import datetime
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# Konfigurasi PROJ agar transformasi koordinat akurat
os.environ['PROJ_LIB'] = '/usr/local/lib/python3.12/site-packages/pyproj/proj_dir/share/proj'

# Menonaktifkan peringatan SSL untuk API Pemerintah
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- 1. KONFIGURASI & START TIME ---
start_proc = time.time()
start_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

load_dotenv()
# Koneksi menggunakan SQLAlchemy 2.0 + Psycopg 3
DB_URL = os.getenv("DATABASE_URL")
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
TABLE_NAME = os.getenv("KUPS_TABLE", "KUPS")
API_URL = os.getenv("KUPS_API_URL")

FOLDER_PATH = "/app/data"
ZIP_PATH = os.path.join(FOLDER_PATH, f"{TABLE_NAME}.gdb.zip")
PROCESS_LOG = os.path.join(FOLDER_PATH, "kups_process.log")
INVALID_LOG = os.path.join(FOLDER_PATH, "invalid_kups_records.txt")

os.makedirs(FOLDER_PATH, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(), logging.FileHandler(PROCESS_LOG, encoding="utf-8")]
)

# ==========================================
# 2. FETCH DATA DENGAN SMART RETRY
# ==========================================
def get_all_api_data(url):
    all_data = []
    page = 1
    session = requests.Session()
    per_page = 100

    while True:
        try:
            full_url = f"{url}?page={page}&per_page={per_page}"
            res = session.get(full_url, verify=False, timeout=60)

            if res.status_code == 429:
                wait = random.uniform(15, 30)
                logging.warning(f"⚠️ Terkena Limit 429. Menunggu {wait:.1f} detik...")
                time.sleep(wait); continue

            res.raise_for_status()
            data = res.json()
            items = data.get("data", [])

            if not items: break
            all_data.extend(items)
            logging.info(f"📄 Halaman {page} sukses. Total data: {len(all_data)}")

            if not data.get("next_page_url"): break
            page += 1
            time.sleep(0.3)

        except Exception as e:
            logging.error(f"❌ Error permanen di halaman {page}: {e}")
            break
    return all_data

# ==========================================
# 3. PROSES & AUDIT SPASIAL
# ==========================================
logging.info("🚀 Memulai proses pengambilan data dari API...")
raw_json = get_all_api_data(API_URL)
if not raw_json: sys.exit("❌ Data API kosong.")

df_raw = pd.DataFrame(raw_json)
total_downloaded = len(df_raw)

# Konversi koordinat ke numerik
df_raw['nujur'] = pd.to_numeric(df_raw['nujur'], errors='coerce')
df_raw['lintang'] = pd.to_numeric(df_raw['lintang'], errors='coerce')

df_valid_coord = df_raw.dropna(subset=['nujur', 'lintang']).copy()
df_no_coord = df_raw[df_raw['nujur'].isna() | df_raw['lintang'].isna()].copy()

# Inisialisasi GeoDataFrame
gdf = gpd.GeoDataFrame(
    df_valid_coord,
    geometry=gpd.points_from_xy(df_valid_coord['nujur'], df_valid_coord['lintang']),
    crs="EPSG:4326"
)

# Filter koordinat wilayah Indonesia
mask_ri = (gdf.geometry.x >= 95.0) & (gdf.geometry.x <= 141.0) & \
          (gdf.geometry.y >= -11.0) & (gdf.geometry.y <= 6.0)

gdf_final = gdf[mask_ri].copy()
gdf_outside = gdf[~mask_ri].copy()

# Standarisasi nama kolom geometri menjadi 'geom'
gdf_final = gdf_final.rename_geometry('geom')

# ==========================================
# 4. EXPORT KE POSTGIS & FILEGDB
# ==========================================
if not gdf_final.empty:
    # 4a. Standarisasi Kolom (Uppercase untuk atribut, lowercase untuk geom)
    gdf_final.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf_final.columns]
    gdf_final = gdf_final.drop(columns=['NUJUR', 'LINTANG'], errors='ignore')

    engine = create_engine(DB_URL)
    
    try:
        # 4b. Simpan ke PostGIS
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))

        logging.info(f"🐘 Menyimpan ke PostGIS: \"{SCHEMA}\".\"{TABLE_NAME}\"...")
        gdf_final.to_postgis(
            name=TABLE_NAME, 
            con=engine, 
            schema=SCHEMA, 
            if_exists='replace', 
            index=False
        )

        # 4c. Buat Spatial Index (GIST) - Case Sensitive
        with engine.begin() as conn:
            idx_name = f"idx_{TABLE_NAME}_geom"
            logging.info(f"⚡ Membuat Spatial Index: {idx_name}...")
            # Menggunakan tanda kutip ganda agar mendukung nama tabel UPPERCASE
            sql_index = text(f'CREATE INDEX IF NOT EXISTS "{idx_name}" ON "{SCHEMA}"."{TABLE_NAME}" USING GIST (geom);')
            conn.execute(sql_index)

        # 4d. Jalankan VACUUM ANALYZE (Optimasi Statistik)
        try:
            with engine.connect() as conn:
                conn.execution_options(isolation_level="AUTOCOMMIT")
                logging.info(f"✨ Mengoptimalkan statistik tabel (VACUUM ANALYZE)...")
                conn.execute(text(f'VACUUM ANALYZE "{SCHEMA}"."{TABLE_NAME}";'))
        except Exception as vac_err:
            logging.warning(f"⚠️ Gagal menjalankan VACUUM: {vac_err}")

        # 4e. Export ke FileGDB Lokal
        gdb_temp = os.path.join(FOLDER_PATH, f"{TABLE_NAME}_TEMP.gdb")
        if os.path.exists(gdb_temp): shutil.rmtree(gdb_temp)

        logging.info(f"📦 Menulis FileGDB (Engine: pyogrio)...")
        gdf_final.to_file(gdb_temp, driver="OpenFileGDB", layer=TABLE_NAME, engine='pyogrio')

        # Kompresi GDB ke ZIP
        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, dirs, files in os.walk(gdb_temp):
                for file in files:
                    # Pastikan struktur folder dalam ZIP adalah NamaTabel.gdb/isi_file
                    arcname = os.path.join(f"{TABLE_NAME}.gdb", file)
                    z.write(os.path.join(root, file), arcname)
        
        shutil.rmtree(gdb_temp)
        logging.info(f"✅ File ZIP siap di: {ZIP_PATH}")

    except Exception as e:
        logging.error(f"❌ Fatal Error saat Export: {e}")

# ==========================================
# 5. RINGKASAN AKHIR
# ==========================================
end_proc = time.time()
duration = end_proc - start_proc
minutes, seconds = divmod(duration, 60)

print(f"\n" + "—"*45)
print(f"🏁 PROSES SELESAI!")
print(f"—"*45)
print(f"✅ Valid RI     : {len(gdf_final)}")
print(f"❌ Luar RI      : {len(gdf_outside)}")
print(f"🚫 Tanpa Koord  : {len(df_no_coord)}")
print(f"⚡ Durasi       : {int(minutes)} menit {int(seconds)} detik")
print(f"📂 Lokasi ZIP   : {ZIP_PATH}")
print(f"—"*45 + "\n")
