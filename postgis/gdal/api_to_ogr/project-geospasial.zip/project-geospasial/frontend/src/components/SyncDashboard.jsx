import React, { useState, useEffect } from 'react';

const SyncDashboard = () => {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const API_BASE = "http://localhost:8000/datagis/api/v1";
  const TOKEN = "pgis-pass-2026";

  const fetchStatus = async () => {
    try {
      const res = await fetch(`${API_BASE}/sync/status`, { 
        headers: { "X-API-TOKEN": TOKEN } 
      });
      const data = await res.json();
      setStatus(data);
    } catch (err) {
      console.error("Gagal mengambil status:", err);
    }
  };

  const runScript = async (scriptName, args = []) => {
    setLoading(true);
    try {
      await fetch(`${API_BASE}/sync/run-script`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json", 
          "X-API-TOKEN": TOKEN 
        },
        body: JSON.stringify({ script_name: scriptName, args: args })
      });
      alert(`Skrip ${scriptName} berhasil dijalankan di background!`);
    } catch (err) {
      alert("Gagal menjalankan skrip");
    } finally {
      setLoading(false);
      fetchStatus();
    }
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 5000); // Auto-refresh tiap 5 detik
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
      <div className="bg-slate-900 p-4">
        <h2 className="text-white text-lg font-bold flex items-center gap-2">
          <span className="animate-pulse text-emerald-400">●</span> 
          ETL System Control Panel
        </h2>
      </div>
      
      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card KUPS */}
        <div className="p-4 rounded-lg border-l-4 border-emerald-500 bg-emerald-50/30">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold text-emerald-700 uppercase">Sinkronisasi KUPS</p>
              <h3 className="text-xl font-black text-slate-800 mt-1">
                {status?.kups?.is_running ? '🔄 EXECUTING' : '✅ IDLE'}
              </h3>
            </div>
            <button 
              onClick={() => runScript('api_kups.sh')}
              disabled={loading || status?.kups?.is_running}
              className="px-4 py-2 bg-emerald-600 text-white rounded-lg font-bold hover:bg-emerald-700 disabled:bg-slate-300 transition-colors"
            >
              Sync KUPS
            </button>
          </div>
          <div className="mt-4 text-xs text-slate-500">
            <p>Last Run: <span className="font-mono">{status?.kups?.last_run || 'Never'}</span></p>
            <p>Records: <span className="font-mono">{status?.kups?.records || 0}</span></p>
          </div>
        </div>

        {/* Card PBPH */}
        <div className="p-4 rounded-lg border-l-4 border-indigo-500 bg-indigo-50/30">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold text-indigo-700 uppercase">Sinkronisasi PBPH</p>
              <h3 className="text-xl font-black text-slate-800 mt-1">
                {status?.pbph?.is_running ? '🔄 SYNCING IGT' : '✅ READY'}
              </h3>
            </div>
            <button 
              onClick={() => runScript('api_pbph.sh', ["PERSETUJUAN_KOMITMEN_PBPH"])}
              disabled={loading || status?.pbph?.is_running}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 disabled:bg-slate-300 transition-colors"
            >
              Update IGT
            </button>
          </div>
          <div className="mt-4 text-xs text-slate-500">
            <p>IGT Active: <span className="font-mono text-indigo-600">{status?.pbph?.igt_active || 'None'}</span></p>
            <p>Result: <span className="font-semibold">{status?.pbph?.last_result || '-'}</span></p>
          </div>
        </div>
      </div>

      <div className="bg-slate-50 p-3 text-center border-t border-slate-100">
         <p className="text-[10px] text-slate-400 font-medium">
           Connected to: {API_BASE} | Project Geospatial 2026
         </p>
      </div>
    </div>
  );
};

export default SyncDashboard;
