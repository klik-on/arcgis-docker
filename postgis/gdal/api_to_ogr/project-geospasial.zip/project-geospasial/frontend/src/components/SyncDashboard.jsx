import React, { useState, useEffect, useRef } from 'react';

const SyncDashboard = () => {
  const [status, setStatus] = useState(null);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedIgt, setSelectedIgt] = useState("PERSETUJUAN_KOMITMEN_PBPH");
  const logEndRef = useRef(null);

  // Daftar Layer IGT PBPH (Bisa ditambah sesuai API phl.kehutanan.go.id)
  const pbphLayers = [
    { id: "PERSETUJUAN_KOMITMEN_PBPH", name: "Persetujuan Komitmen" },
    { id: "PBPH_DEFINITIF", name: "PBPH Definitif" }
  ];

  const fetchStatus = async () => {
    try {
      const res = await fetch('/datagis/api/v1/sync/status', {
        headers: { 'X-API-KEY': 'pgis-pass-2026' }
      });
      const data = await res.json();
      setStatus(data);
    } catch (err) { console.error("Error fetching status"); }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch('/datagis/api/v1/sync/logs?lines=30', {
        headers: { 'X-API-KEY': 'pgis-pass-2026' }
      });
      const data = await res.json();
      if (data.content) setLogs(data.content);
    } catch (err) { }
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(() => {
      fetchStatus();
      if (status?.generic?.is_running) fetchLogs();
    }, 3000);
    return () => clearInterval(interval);
  }, [status?.generic?.is_running]);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  // Fungsi menjalankan script dengan ENV dinamis
  const handleRun = async (type) => {
    setLoading(true);
    let payload = {};
    
    if (type === 'KUPS') {
      payload = { script_name: "proses/gpd_KUPS_gdbtopgis.py", args: [] };
    } else {
      payload = { 
        script_name: "integrasi/pbph_integrated.py", 
        env: { "IGT": selectedIgt } 
      };
    }

    try {
      const res = await fetch('/datagis/api/v1/sync/run-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-KEY': 'pgis-pass-2026' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        const err = await res.json();
        alert(err.detail);
      }
    } catch (err) { alert("Server tidak merespon"); }
    setLoading(false);
  };

  const handleKill = async () => {
    if (!window.confirm("Hentikan proses secara paksa?")) return;
    try {
      await fetch('/datagis/api/v1/sync/kill', {
        method: 'POST',
        headers: { 'X-API-KEY': 'pgis-pass-2026' }
      });
    } catch (err) { alert("Gagal mengirim perintah kill"); }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Header Status */}
      <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
        <h3 className="font-bold text-slate-700">ETL Control Panel</h3>
        <div className="flex items-center space-x-2">
          <span className={`h-2.5 w-2.5 rounded-full ${status?.generic?.is_running ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`}></span>
          <span className="text-xs font-bold uppercase tracking-widest text-slate-500">
            {status?.generic?.is_running ? `RUNNING (PID: ${status.generic.pid})` : 'IDLE'}
          </span>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Section KUPS */}
        <div className="space-y-3">
          <label className="text-xs font-bold text-slate-400 uppercase">Master Data KUPS</label>
          <button 
            onClick={() => handleRun('KUPS')}
            disabled={status?.generic?.is_running}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 text-white rounded-xl font-bold transition flex justify-center items-center"
          >
            🚀 Sync Master KUPS
          </button>
        </div>

        {/* Section PBPH with Dropdown */}
        <div className="space-y-3">
          <label className="text-xs font-bold text-slate-400 uppercase">Integrasi PBPH (API PHL)</label>
          <div className="flex space-x-2">
            <select 
              value={selectedIgt} 
              onChange={(e) => setSelectedIgt(e.target.value)}
              className="flex-1 bg-slate-100 border-none rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-blue-500"
            >
              {pbphLayers.map(layer => (
                <option key={layer.id} value={layer.id}>{layer.name}</option>
              ))}
            </select>
            <button 
              onClick={() => handleRun('PBPH')}
              disabled={status?.generic?.is_running}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 text-white rounded-xl font-bold transition"
            >
              Sync
            </button>
          </div>
        </div>

        {/* Kill Button (Only shows when running) */}
        {status?.generic?.is_running && (
          <button 
            onClick={handleKill}
            className="w-full py-3 bg-red-50 text-red-600 border border-red-100 rounded-xl font-bold hover:bg-red-100 transition"
          >
            🛑 Stop Process
          </button>
        )}

        {/* Terminal Output */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-tight">Live Process Log</label>
          <div className="bg-slate-900 rounded-xl p-4 h-64 overflow-y-auto font-mono text-[11px] leading-relaxed text-emerald-400 shadow-inner">
            {logs.length > 0 ? (
              logs.map((line, i) => <div key={i} className="mb-1 border-l border-emerald-900 pl-2">{line}</div>)
            ) : (
              <span className="text-slate-600 italic">No active process...</span>
            )}
            <div ref={logEndRef} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SyncDashboard;
