import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, GeoJSON, LayersControl } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

const MapViewer = ({ schema, table }) => {
  const [geoData, setGeoData] = useState(null);
  const [loading, setLoading] = useState(false);
  const API_URL = "http://localhost:8000/datagis/api/v1/layers";
  const TOKEN = "pgis-pass-2026";

  useEffect(() => {
    if (schema && table) {
      setLoading(true);
      fetch(`${API_URL}/${schema}/${table}?limit=500`, {
        headers: { "X-API-TOKEN": TOKEN }
      })
      .then(res => res.json())
      .then(data => {
        setGeoData(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error loading map data:", err);
        setLoading(false);
      });
    }
  }, [schema, table]);

  return (
    <div className="relative h-[500px] w-full rounded-lg overflow-hidden border-2 border-slate-200 shadow-inner bg-slate-50">
      {loading && (
        <div className="absolute inset-0 z-[1000] flex items-center justify-center bg-white/50">
          <div className="px-4 py-2 bg-white rounded-full shadow-md font-bold text-emerald-600 animate-pulse">
            Loading Spatial Data...
          </div>
        </div>
      )}
      
      <MapContainer center={[-2.5, 118]} zoom={5} style={{ height: "100%", width: "100%" }}>
        <LayersControl position="topright">
          <LayersControl.BaseLayer checked name="OpenStreetMap">
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Esri World Imagery">
            <TileLayer url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}" />
          </LayersControl.BaseLayer>
          
          {geoData && (
            <LayersControl.Overlay checked name={`Layer: ${table}`}>
              <GeoJSON 
                data={geoData} 
                style={() => ({ 
                  color: '#10b981', 
                  weight: 2, 
                  fillOpacity: 0.4,
                  fillColor: '#34d399' 
                })} 
              />
            </LayersControl.Overlay>
          )}
        </LayersControl>
      </MapContainer>
    </div>
  );
};

export default MapViewer;
