import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, GeoJSON, Popup, LayersControl } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix icon marker default Leaflet yang sering hilang di React
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const MapViewer = () => {
  const [kupsData, setKupsData] = useState(null);
  const [loading, setLoading] = useState(true);

  // 1. Fungsi penentuan warna berdasarkan KELASKUPS
  const getKupsStyle = (feature) => {
    const kelas = feature.properties.KELASKUPS?.toUpperCase();
    let color = "#3388ff"; // Default Biru

    if (kelas === 'EMAS') color = "#FFD700"; // Gold
    else if (kelas === 'PERAK') color = "#C0C0C0"; // Silver
    else if (kelas === 'BIRU') color = "#00BFFF"; // DeepSkyBlue
    else if (kelas === 'PRATAMA') color = "#CD7F32"; // Bronze

    return {
      radius: 8,
      fillColor: color,
      color: "#fff",
      weight: 1,
      opacity: 1,
      fillOpacity: 0.8
    };
  };

  // 2. Fetch data dari API Backend
  useEffect(() => {
    const fetchKups = async () => {
      try {
        const response = await fetch('/datagis/api/v1/layers/datagis/KUPS?limit=1000', {
          headers: {
            'X-API-KEY': 'pgis-pass-2026' // Sesuai .env PGIS_API_TOKEN
          }
        });
        const data = await response.json();
        setKupsData(data);
        setLoading(false);
      } catch (error) {
        console.error("Gagal load data KUPS:", error);
        setLoading(false);
      }
    };

    fetchKups();
  }, []);

  // 3. Render Popup Content
  const onEachKups = (feature, layer) => {
    const props = feature.properties;
    
    // Parsing data produk yang berbentuk string '[{...}]'
    let produkClean = "Tidak ada data";
    try {
      if (props.PRODUK && props.PRODUK !== '[]') {
        const parsed = JSON.parse(props.PRODUK.replace(/'/g, '"'));
        produkClean = parsed.map(p => p.namaProduk).join(', ');
      }
    } catch (e) { console.warn("Parsing produk error"); }

    layer.bindPopup(`
      <div style="min-width: 200px">
        <h4 style="margin:0 0 8px 0; color:#2c3e50">${props.NAMAKUPS}</h4>
        <hr/>
        <b>Kelas:</b> <span class="badge">${props.KELASKUPS}</span><br/>
        <b>ID:</b> ${props.ID}<br/>
        <b>Produk:</b> ${produkClean}
      </div>
    `);
  };

  if (loading) return <div className="p-4">Memuat Peta Spasial...</div>;

  return (
    <div className="h-[600px] w-full rounded-lg overflow-hidden shadow-lg border border-gray-200">
      <MapContainer center={[-0.7893, 113.9213]} zoom={5} style={{ height: '100%', width: '100%' }}>
        <LayersControl position="topright">
          <LayersControl.BaseLayer checked name="OpenStreetMap">
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          </LayersControl.BaseLayer>
          
          <LayersControl.BaseLayer name="Citra Satelit">
            <TileLayer url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}" />
          </LayersControl.BaseLayer>

          <LayersControl.Overlay checked name="Titik KUPS (Menlhk)">
            {kupsData && (
              <GeoJSON 
                data={kupsData} 
                style={getKupsStyle}
                pointToLayer={(feature, latlng) => L.circleMarker(latlng, getKupsStyle(feature))}
                onEachFeature={onEachKups}
              />
            )}
          </LayersControl.Overlay>
        </LayersControl>
      </MapContainer>
    </div>
  );
};

export default MapViewer;
