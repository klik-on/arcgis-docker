import React from 'react';
import MapViewer from './components/MapViewer';
import SyncDashboard from './components/SyncDashboard';

function App() {
  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-900">
      {/* Header Bar */}
      <nav className="bg-white border-b border-slate-200 px-8 py-4 sticky top-0 z-[2000] shadow-sm">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-600 p-2 rounded-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight text-slate-800">
                GEO<span className="text-emerald-600">SPATIAL</span> PORTAL
              </h1>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Directorate General of PDASRH</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:block text-right">
              <p className="text-xs font-bold text-slate-500">API Status</p>
              <p className="text-xs text-emerald-500 font-mono">CONNECTED: 172.16.2.122</p>
            </div>
            <div className="h-8 w-8 rounded-full bg-slate-200 border border-slate-300 flex items-center justify-center text-xs font-bold">
              AD
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-6 lg:p-8 space-y-8">
        
        {/* Section 1: ETL Controls */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <h2 className="text-sm font-black uppercase tracking-wider text-slate-500">Data Management & ETL</h2>
            <div className="h-px bg-slate-200 flex-grow"></div>
          </div>
          <SyncDashboard />
        </section>

        {/* Section 2: Spatial Visualization */}
        <section className="grid grid-cols-1 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-md border border-slate-200">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-xl font-bold text-slate-800">Spatial Data Preview</h2>
                <p className="text-sm text-slate-500">Menampilkan data Layer KUPS secara live dari PostGIS</p>
              </div>
              <div className="flex gap-2">
                <span className="px-3 py-1 bg-slate-100 rounded text-xs font-mono text-slate-600 border border-slate-200">Schema: datagis</span>
                <span className="px-3 py-1 bg-slate-100 rounded text-xs font-mono text-slate-600 border border-slate-200">Table: KUPS</span>
              </div>
            </div>
            
            {/* Map Component */}
            <MapViewer schema="datagis" table="KUPS" />
            
            <div className="mt-4 grid grid-cols-3 gap-4">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-center">
                <p className="text-[10px] font-bold text-slate-400 uppercase">CRS</p>
                <p className="text-sm font-mono font-bold">EPSG:4326</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-center">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Engine</p>
                <p className="text-sm font-mono font-bold text-emerald-600">PyOgrio</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-center">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Format</p>
                <p className="text-sm font-mono font-bold">GeoJSON</p>
              </div>
            </div>
          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-8 py-12 text-center">
        <p className="text-slate-400 text-xs">
          © 2026 Geoprocessing Integrated System. Built with FastAPI, GeoPandas, and Leaflet.
        </p>
      </footer>
    </div>
  );
}

export default App;
