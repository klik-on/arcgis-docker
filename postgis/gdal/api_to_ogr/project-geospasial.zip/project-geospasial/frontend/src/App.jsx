import React from 'react';
import MapViewer from './components/MapViewer';
import SyncDashboard from './components/SyncDashboard';

function App() {
  return (
    <div className="min-h-screen bg-slate-100 font-sans antialiased text-slate-900">
      {/* Navbar / Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 sticky top-0 z-[1000]">
        <div className="max-w-[1600px] mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="bg-emerald-600 p-2 rounded-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-1 1H4a2 2 0 01-2-2V5a2 2 0 012-2h16a2 2 0 012 2v15a2 2 0 01-2 2h-4l-1-1m-6 0l-1 1m6-1l-1 1m-6-1v-7a3 3 0 013-3h4a3 3 0 013 3v1m-6 0h6" />
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold leading-tight">Geospatial API Kehutanan</h1>
              <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Enterprise Middleware v1.6.0</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <span className="flex items-center space-x-2 text-sm bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full border border-emerald-100">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
              <span>System Online</span>
            </span>
          </div>
        </div>
      </header>

      {/* Main Content Layout */}
      <main className="max-w-[1600px] mx-auto p-4 md:p-6 lg:p-8">
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          
          {/* Sisi Kiri: Visualisasi Peta (Mendapat 7 dari 12 kolom) */}
          <div className="xl:col-span-7 space-y-4">
            <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200">
              <div className="flex justify-between items-center mb-4 px-2">
                <h3 className="font-bold text-slate-700 flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  Monitoring Lokasi KUPS
                </h3>
                <span className="text-xs font-mono text-slate-400">EPSG:4326 / WGS84</span>
              </div>
              
              {/* Komponen Peta */}
              <div className="h-[650px] relative">
                <MapViewer />
              </div>
            </div>
          </div>

          {/* Sisi Kanan: Dashboard Kendali (Mendapat 5 dari 12 kolom) */}
          <div className="xl:col-span-5">
            <div className="sticky top-24">
              <SyncDashboard />
            </div>
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="mt-12 py-6 px-6 text-center text-slate-400 text-sm border-t border-slate-200">
        &copy; 2026 Kementerian Lingkungan Hidup dan Kehutanan - Geospatial API Project
      </footer>
    </div>
  );
}

export default App;
