import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    // Agar server Vite dapat diakses dari luar container (Host)
    host: '0.0.0.0',
    port: 3000,
    
    // Penting untuk Docker: menggunakan polling agar perubahan file di Windows/Linux host terdeteksi
    watch: {
      usePolling: true,
    },

    // Konfigurasi Hot Module Replacement (HMR) agar tidak error saat diakses via browser
    hmr: {
      clientPort: 3000,
    },

    // KONFIGURASI PROXY: Menghubungkan Frontend ke API Backend di dalam Network Docker
    proxy: {
      '/datagis': {
        // 'api-backend' merujuk pada nama service di docker-compose.yml
        target: 'http://api-backend:8000',
        changeOrigin: true,
        secure: false,
        // Karena FastAPI menggunakan root_path="/datagis", kita tidak perlu merewrite path
        // Request dari frontend ke '/datagis/api/v1/...' akan langsung diteruskan dengan benar
      }
    },
  },

  // Optimasi build untuk produksi
  build: {
    outDir: 'dist',
    sourcemap: true,
    // Membagi chunk agar loading awal lebih ringan (terutama untuk library besar seperti Leaflet)
    rollupOptions: {
      output: {
        manualChunks: {
          leaflet: ['leaflet', 'react-leaflet'],
        },
      },
    },
  },
})
