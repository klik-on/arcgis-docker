import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    // Agar bisa diakses dari luar container (Host)
    host: '0.0.0.0',
    port: 3000,
    // Penting untuk Docker di Windows/Linux agar perubahan file terdeteksi
    watch: {
      usePolling: true,
    },
    // Konfigurasi HMR agar tidak error saat diakses via browser
    hmr: {
      clientPort: 3000,
    },
  },
  // Optimasi build jika diperlukan
  build: {
    outDir: 'dist',
    sourcemap: true,
  }
})
