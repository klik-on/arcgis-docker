#!/bin/bash
# -------------------------------------------------------------------
# Script: config_psql_final.sh
# Deskripsi: Optimasi PostgreSQL untuk Mode Produksi Spasial
# -------------------------------------------------------------------

CONTAINER="db-pgis"
DB_USER="dbgis"
DB_NAME="gisdb"

echo "==> [1/4] Mendeteksi lokasi konfigurasi..."
# Mencari lokasi config_file secara dinamis dari sistem
CONF=$(docker exec "$CONTAINER" psql -U "$DB_USER" -d "$DB_NAME" -t -A -c "SHOW config_file;")
CONF_BAK="${CONF}.bak"

if [ -z "$CONF" ]; then
    echo "Error: File konfigurasi tidak ditemukan. Pastikan container aktif."
    exit 1
fi

echo "Lokasi ditemukan: $CONF"

echo "==> [2/4] Membuat backup konfigurasi di $CONF_BAK..."
docker exec "$CONTAINER" cp "$CONF" "$CONF_BAK"

echo "==> [3/4] Menerapkan optimasi parameter..."
# Menggunakan sed untuk mengganti nilai parameter (mencakup yang dicomment maupun tidak)
docker exec "$CONTAINER" sed -i "s/^#*shared_buffers.*/shared_buffers = 8GB/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*effective_cache_size.*/effective_cache_size = 24GB/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*work_mem.*/work_mem = 256MB/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*maintenance_work_mem.*/maintenance_work_mem = 1GB/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*max_parallel_workers_per_gather.*/max_parallel_workers_per_gather = 8/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*temp_buffers.*/temp_buffers = 512MB/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*max_connections.*/max_connections = 500/" "$CONF"

echo "==> [4/4] Restarting container untuk menerapkan perubahan..."
docker restart "$CONTAINER"

echo "Menunggu PostgreSQL siap (10 detik)..."
sleep 10

# Fungsi untuk mengambil nilai verifikasi
get_val() {
    docker exec "$CONTAINER" psql -U "$DB_USER" -d "$DB_NAME" -t -A -c "$1" 2>/dev/null
}

echo ""
echo "==================== VERIFIKASI OPTIMASI FINAL ===================="
printf "%-35s | %s\n" "PARAMETER" "NILAI BARU"
echo "-------------------------------------------------------------------"
printf "%-35s | %s\n" "shared_buffers (RAM)" "$(get_val "SHOW shared_buffers;")"
printf "%-35s | %s\n" "effective_cache_size" "$(get_val "SHOW effective_cache_size;")"
printf "%-35s | %s\n" "work_mem (Query Join)" "$(get_val "SHOW work_mem;")"
printf "%-35s | %s\n" "maintenance_work_mem" "$(get_val "SHOW maintenance_work_mem;")"
printf "%-35s | %s\n" "max_parallel_workers" "$(get_val "SHOW max_parallel_workers_per_gather;")"
printf "%-35s | %s\n" "temp_buffers" "$(get_val "SHOW temp_buffers;")"
printf "%-35s | %s\n" "max_connections" "$(get_val "SHOW max_connections;")"
echo "==================================================================="
echo ""

echo "==> Selesai! Database siap digunakan dalam mode performa tinggi."
