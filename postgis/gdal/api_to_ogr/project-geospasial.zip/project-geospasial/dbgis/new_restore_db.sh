#!/bin/bash

# Konfigurasi Akses
DB_USER="dbgis"
export PGPASSWORD="password00"
DB_HOST="172.16.2.122"
DB_PORT="5432"
NEW_DB="gisdb"

echo "Daftar file .dump di folder ini:"
ls *.dump 2>/dev/null || echo "Tidak ada file .dump ditemukan."
echo "--------------------------------"
read -p "Masukkan nama file backup yang ingin di-migrate: " FILE_INPUT

if [ -f "$FILE_INPUT" ]; then
    echo "Memulai restorasi ke $NEW_DB..."

    # Kita tidak pakai --clean karena DB sudah di-reset oleh pre_restore_fixdb.sh
    # Ini jauh lebih aman untuk menghindari error 'schema extensions'
    pg_restore -h $DB_HOST -p $DB_PORT -U $DB_USER \
               -d $NEW_DB \
               -j 8 \
               --no-owner \
               --no-privileges \
               --verbose \
               "$FILE_INPUT"

    if [ $? -eq 0 ]; then
        echo "-------------------------------------------"
        echo "Migrasi ke $NEW_DB Berhasil!"
        echo "Jangan lupa jalankan ./post_restore_cleanup.sh"
    else
        echo "Restorasi selesai dengan beberapa peringatan (cek log di atas)."
    fi
else
    echo "Error: File $FILE_INPUT tidak ditemukan!"
fi

unset PGPASSWORD
