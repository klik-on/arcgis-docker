#!/bin/bash

# Konfigurasi
APP_NAME="Geospatial-System"
BACKUP_DIR="./dbgis/backup"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo "🚀 [$(date)] Memulai Update $APP_NAME..."

# --- 1. PRE-DEPLOYMENT BACKEND (SAFETY) ---
echo "💾 Melakukan backup database sebelum update..."
mkdir -p $BACKUP_DIR
# Backup skema krusial secara cepat
docker exec db-pgis pg_dump -U dbgis -d gisdb -n datagis -F c -f "/tmp/backup/pre_deploy_$TIMESTAMP.dump"
if [ $? -eq 0 ]; then
    echo "✅ Backup berhasil disimpan di $BACKUP_DIR"
else
    echo "⚠️ Backup gagal! Melanjutkan dengan hati-hati..."
fi

# --- 2. DEPLOYMENT ---
echo "🔄 Mematikan layanan lama..."
docker compose down --remove-orphans

echo "🏗️ Membangun dan menjalankan ulang container..."
# Menggunakan build-arg jika diperlukan, dan pull image dasar terbaru
docker compose up -d --build

# --- 3. POST-DEPLOYMENT HEALTH CHECK ---
echo "⏳ Menunggu verifikasi kesehatan layanan (30 detik)..."
SUCCESS=0
for i in {1..6}; do
    sleep 5
    STATUS=$(docker compose ps --format json | grep -c '"HealthStatus":"healthy"')
    # Kita punya setidaknya 2 container dengan healthcheck (dbgis & redis)
    if [ "$STATUS" -ge 2 ]; then
        echo "✅ Layanan Inti (DB & Redis) Terdeteksi SEHAT."
        SUCCESS=1
        break
    fi
    echo "...masih menunggu status healthy ($i/6)"
done

if [ $SUCCESS -eq 0 ]; then
    echo "❌ [ERROR] Beberapa layanan gagal mencapai status 'healthy'. Silakan cek 'docker compose logs'."
else
    echo "🚀 Semua layanan up dan running!"
fi

# --- 4. CLEANUP ---
echo "🧹 Membersihkan build cache dan image usang..."
docker image prune -f

# --- 5. PERMISSION FIX (Optional but Recommended) ---
# Memastikan folder data dan log tetap bisa ditulis oleh worker
sudo chmod -R 775 ./data
sudo chown -R $USER:$USER ./data

echo "✅ [$(date)] Deployment Selesai!"
