#!/bin/bash
FRONT_DIR="./frontend"

echo "📂 Menyiapkan struktur folder frontend..."
mkdir -p $FRONT_DIR/src/components $FRONT_DIR/src/services $FRONT_DIR/public

# 1. Buat index.html
cat <<EOF > $FRONT_DIR/index.html
<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>WebGIS KUPS - Menlhk</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
EOF

# 2. Buat vite.config.js
cat <<EOF > $FRONT_DIR/vite.config.js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    host: '0.0.0.0'
  }
})
EOF

# 3. Buat src/main.jsx
cat <<EOF > $FRONT_DIR/src/main.jsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><App /></React.StrictMode>
)
EOF

# 4. Buat src/index.css (Tailwind)
cat <<EOF > $FRONT_DIR/src/index.css
@tailwind base;
@tailwind components;
@tailwind utilities;
EOF

# 5. Buat API Service
cat <<EOF > $FRONT_DIR/src/services/api.js
import axios from 'axios';

// Diarahkan ke Gateway (IP 130) yang akan meneruskan ke Backend
const API_BASE_URL = "/api/v1"; 

export const fetchKups = async (limit = 100, offset = 0) => {
    try {
        const response = await axios.get(\`\${API_BASE_URL}/layers/datagis/KUPS\`, {
            params: { api_key: 'pgis-pass-2026', limit, offset }
        });
        return response.data;
    } catch (error) {
        console.error("Gagal mengambil data:", error);
        throw error;
    }
};
EOF

# 6. Buat src/App.jsx (Layout Utama)
cat <<EOF > $FRONT_DIR/src/App.jsx
import React from 'react';
import DataTable from './components/DataTable';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 font-sans">
      <header className="bg-green-800 text-white shadow-lg p-4">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold tracking-tight">GeoSpatial Dashboard KUPS</h1>
          <span className="text-sm bg-green-900 px-3 py-1 rounded-full border border-green-700">Server 122</span>
        </div>
      </header>
      <main className="container mx-auto py-8 px-4">
        <DataTable />
      </main>
    </div>
  );
}
export default App;
EOF

# 7. Buat src/components/DataTable.jsx
cat <<EOF > $FRONT_DIR/src/components/DataTable.jsx
import React, { useEffect, useState } from 'react';
import { fetchKups } from '../services/api';
import { MapPin, Table as TableIcon } from 'lucide-react';

const DataTable = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchKups(50, 0).then(res => {
            setData(res.features || []);
            setLoading(false);
        }).catch(() => setLoading(false));
    }, []);

    if (loading) return (
        <div className="flex flex-col items-center justify-center p-20 space-y-4">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-800"></div>
            <p className="text-gray-600 font-medium">Menghubungkan ke API KUPS...</p>
        </div>
    );

    return (
        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
            <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                    <TableIcon className="text-green-700" size={20} />
                    <h2 className="text-lg font-semibold text-gray-800">Daftar KUPS (50 Record Terbaru)</h2>
                </div>
                <span className="text-xs font-mono text-gray-500 italic">Total Sync: 11.636</span>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                    <thead>
                        <tr className="bg-white text-gray-400 text-xs uppercase tracking-wider">
                            <th className="px-6 py-3 border-b">ID</th>
                            <th className="px-6 py-3 border-b">Nama KUPS</th>
                            <th className="px-6 py-3 border-b">Koordinat (Lat, Long)</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 text-sm">
                        {data.map((f, i) => (
                            <tr key={i} className="hover:bg-green-50/50 transition-colors">
                                <td className="px-6 py-4 font-mono text-gray-400">{f.properties.id}</td>
                                <td className="px-6 py-4 font-semibold text-gray-700">{f.properties.NAMAKUPS}</td>
                                <td className="px-6 py-4 flex items-center text-blue-600">
                                    <MapPin size={14} className="mr-1" />
                                    {f.geometry.coordinates[1].toFixed(5)}, {f.geometry.coordinates[0].toFixed(5)}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
export default DataTable;
EOF

echo "✨ Frontend siap dibangun!"
