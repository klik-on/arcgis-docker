#!/bin/bash

# Konfigurasi Folder
FRONT_DIR="./frontend"
SRC_DIR="$FRONT_DIR/src"

echo "🏗️ Membangun Geospatial Dashboard (Optimized Table & Scroll)..."

# 1. Pastikan folder tersedia
mkdir -p $SRC_DIR/components $SRC_DIR/services

# 2. Skrip API Service
cat <<EOF > $SRC_DIR/services/api.js
import axios from 'axios';
const API_BASE_URL = "/api/v1";

export const fetchKups = async (limit = 15000, offset = 0) => {
    try {
        const response = await axios.get(\`\${API_BASE_URL}/IGT\`, {
            params: {
                layer: 'KUPS',
                api_key: 'pgis-pass-2026',
                limit,
                offset
            },
            timeout: 60000
        });
        return response.data;
    } catch (error) {
        console.error("Kesalahan API:", error);
        throw error;
    }
};
EOF

# 3. Skrip DataTable.jsx (Master Component)
cat <<EOF > $SRC_DIR/components/DataTable.jsx
import React, { useEffect, useState, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import { fetchKups } from '../services/api';
import { Table as TableIcon, Loader2, Award, FilterX, Info, Map as MapIcon, MapPin, Search } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

const ChangeView = ({ center }) => {
  const map = useMap();
  if (center) { map.flyTo(center, 14, { duration: 1.5 }); }
  return null;
};

const getKupsColor = (kelas) => {
    const k = (kelas || '').toUpperCase();
    if (k.includes('PLATINUM')) return '#00ff88';
    if (k.includes('EMAS')) return '#ffd700';
    if (k.includes('PERAK')) return '#c0c0c0';
    if (k.includes('BIRU')) return '#00d1ff';
    return '#cbd5e1';
};

const createDynamicIcon = (klasifikasi, isSelected) => {
    const color = getKupsColor(klasifikasi);
    return L.divIcon({
        html: \`<svg width="24" height="24" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="40" fill="\${color}" stroke="white" stroke-width="8" opacity="0.9" />
                  <circle cx="50" cy="50" r="15" fill="white" />
                  \${isSelected ? '<circle cx="50" cy="50" r="60" fill="none" stroke="#ef4444" stroke-width="8" stroke-dasharray="15"/>' : ''}
                </svg>\`,
        className: 'custom-geo-marker',
        iconSize: [24, 24],
        iconAnchor: [12, 12]
    });
};

const DataTable = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [mapCenter, setMapCenter] = useState(null);
    const [selectedId, setSelectedId] = useState(null);

    useEffect(() => {
        fetchKups(15000, 0).then(res => {
            setData(res.results || []);
            setLoading(false);
        }).catch(() => setLoading(false));
    }, []);

    const stats = useMemo(() => {
        const counts = { PLATINUM: 0, EMAS: 0, PERAK: 0, BIRU: 0 };
        data.forEach(item => {
            const k = (item.KELASKUPS || '').toUpperCase();
            if (k.includes('PLATINUM')) counts.PLATINUM++;
            else if (k.includes('EMAS')) counts.EMAS++;
            else if (k.includes('PERAK')) counts.PERAK++;
            else if (k.includes('BIRU')) counts.BIRU++;
        });
        return counts;
    }, [data]);

    const filteredData = useMemo(() => {
        return data.filter(item => {
            const matchesFilter = filter ? (item.KELASKUPS || '').toUpperCase().includes(filter) : true;
            const matchesSearch = (item.NAMAKUPS || '').toLowerCase().includes(searchTerm.toLowerCase());
            return matchesFilter && matchesSearch;
        });
    }, [data, filter, searchTerm]);

    const handleLocate = (item) => {
        const coords = item.geometry_json?.coordinates;
        if (coords) {
            setMapCenter([coords[1], coords[0]]);
            setSelectedId(item.id || item.NAMAKUPS);
        }
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center h-screen bg-slate-900 text-white">
            <Loader2 className="animate-spin text-blue-400 mb-4" size={40} />
            <p className="font-black text-[10px] tracking-widest uppercase text-slate-400">Syncing Geo-Engine 2026...</p>
        </div>
    );

    return (
        <div className="p-4 max-w-[1600px] mx-auto space-y-4 bg-slate-50 min-h-screen font-sans text-slate-900">

            {/* HEADER */}
            <div className="flex flex-wrap items-center justify-between bg-white p-4 rounded-3xl shadow-sm border border-slate-100 gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-200"><MapIcon size={20} /></div>
                    <div>
                        <h1 className="text-xl font-black tracking-tighter uppercase leading-none text-slate-800">KUPS <span className="text-blue-600">Geo-Portal</span></h1>
                        <p className="text-slate-400 font-bold text-[8px] uppercase tracking-[0.2em]">Full Integrated Dataset 2026</p>
                    </div>
                </div>

                <div className="flex items-center gap-2 flex-1 max-w-md">
                    <div className="relative w-full group">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-blue-500 transition-colors" size={16} />
                        <input 
                            type="text" 
                            placeholder="Cari Kelompok KUPS..." 
                            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-100 rounded-2xl text-[11px] font-bold focus:ring-2 focus:ring-blue-500 focus:bg-white outline-none transition-all"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    { (filter || searchTerm) && (
                        <button onClick={() => {setFilter(null); setSearchTerm("");}} className="p-2 bg-red-50 text-red-500 rounded-xl hover:bg-red-100 transition-colors">
                            <FilterX size={18} />
                        </button>
                    )}
                </div>
            </div>

            {/* STATS */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {Object.entries(stats).map(([label, count]) => (
                    <div key={label} onClick={() => setFilter(label === filter ? null : label)}
                        className={\`cursor-pointer flex items-center justify-between p-4 rounded-3xl border transition-all \${filter === label ? 'bg-white ring-2 ring-blue-500 border-blue-500 shadow-md' : 'bg-white border-slate-100 shadow-sm hover:border-blue-200'}\`}>
                        <div className="flex items-center gap-3">
                            <div className="p-2.5 rounded-2xl" style={{ backgroundColor: getKupsColor(label) + '20', color: getKupsColor(label) }}><Award size={18} /></div>
                            <div>
                                <p className="text-[9px] font-black text-slate-400 uppercase leading-none mb-1">{label}</p>
                                <p className="text-xl font-black text-slate-800 tracking-tighter">{count.toLocaleString()}</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* MAP SECTION */}
            <div className="bg-white p-1 rounded-[2.5rem] shadow-xl border border-white h-[450px] overflow-hidden relative">
                <MapContainer center={[-0.7893, 113.9213]} zoom={5} className="h-full w-full rounded-[2.3rem]">
                    <TileLayer url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png" />
                    <ChangeView center={mapCenter} />
                    <MarkerClusterGroup chunkedLoading key={\`cluster-\${filter}-\${searchTerm}\`}>
                        {filteredData.slice(0, 5000).map((item, idx) => {
                            const coords = item.geometry_json?.coordinates;
                            if (!coords) return null;
                            const isSelected = selectedId === (item.id || item.NAMAKUPS);
                            return (
                                <Marker key={idx} position={[coords[1], coords[0]]} icon={createDynamicIcon(item.KELASKUPS, isSelected)}>
                                    <Popup minWidth={250} className="custom-popup">
                                        <div className="font-sans">
                                            <h4 className="font-black text-blue-600 uppercase text-[10px] mb-2 border-b pb-1">Detail Informasi</h4>
                                            {Object.entries(item).filter(([k]) => k === k.toUpperCase() && k !== 'GEOMETRY_JSON').map(([k, v]) => (
                                                <div key={k} className="mb-1">
                                                    <p className="text-[7px] font-black text-slate-400 uppercase leading-none">{k}</p>
                                                    <p className="text-[10px] font-bold text-slate-700">{v || '-'}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </Popup>
                                </Marker>
                            );
                        })}
                    </MarkerClusterGroup>
                </MapContainer>
            </div>

            {/* COMPACT SCROLLABLE TABLE */}
            <div className="bg-white rounded-[2rem] shadow-lg border border-slate-100 overflow-hidden flex flex-col">
                <div className="px-6 py-4 border-b flex justify-between items-center bg-slate-50/50">
                    <div className="flex items-center gap-2 font-black text-slate-700 text-[10px] uppercase tracking-widest">
                        <TableIcon size={14} className="text-blue-600" /> 
                        Dataset Terfilter <span className="text-blue-500 ml-1">({filteredData.length} baris)</span>
                    </div>
                    <span className="text-[8px] font-bold text-slate-400 uppercase italic">Scroll kebawah untuk data lainnya</span>
                </div>
                
                {/* Bagian Tinggi Tetap & Scroll */}
                <div className="overflow-y-auto custom-scrollbar" style={{ height: '300px' }}>
                    <table className="w-full text-[10px] text-left border-separate border-spacing-0">
                        <thead className="sticky top-0 bg-white shadow-sm z-30">
                            <tr className="text-slate-400 font-black uppercase">
                                <th className="px-6 py-3 border-b bg-white/95 backdrop-blur-sm">Nama Kelompok KUPS</th>
                                <th className="px-6 py-3 border-b text-center bg-white/95 backdrop-blur-sm">Kelas</th>
                                <th className="px-6 py-3 border-b text-right bg-white/95 backdrop-blur-sm w-20">Aksi</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                            {filteredData.map((item, i) => (
                                <tr key={i} onClick={() => handleLocate(item)} className="hover:bg-blue-50 transition-all cursor-pointer group">
                                    <td className="px-6 py-2.5 font-bold text-slate-700 uppercase leading-tight truncate max-w-[400px]">
                                        {item.NAMAKUPS}
                                    </td>
                                    <td className="px-6 py-2.5 text-center">
                                        <span className="px-2 py-0.5 rounded-full text-[8px] font-black text-white uppercase" style={{ backgroundColor: getKupsColor(item.KELASKUPS) }}>
                                            {item.KELASKUPS}
                                        </span>
                                    </td>
                                    <td className="px-6 py-2.5 text-right">
                                        <div className="flex justify-end">
                                            <div className="p-1.5 bg-slate-100 rounded-lg text-slate-400 group-hover:bg-blue-600 group-hover:text-white transition-all">
                                                <MapPin size={12} />
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default DataTable;
EOF

echo "✅ Full Script Berhasil Diupdate!"
echo "👉 Gunakan perintah: docker compose restart geo-frontend"
