#!/bin/bash

# Konfigurasi
APP_NAME="Geospatial-System"

echo "🚀 [$(date)] Memulai Update Cepat $APP_NAME..."

# 1. Matikan layanan lama (Data aman di dalam Volume)
echo "🔄 Menghentikan container..."
docker compose down --remove-orphans

# 2. Build dan jalankan ulang
echo "🏗️ Membangun ulang dan menjalankan container..."
docker compose up -d --build

# 3. Verifikasi status
echo "⏳ Menunggu verifikasi layanan..."
sleep 5
docker compose ps

# 4. Pastikan permission folder data tetap benar
# Penting agar worker tetap bisa menulis ke sync.log
echo "🔐 Mengatur izin akses folder data..."
chmod -R 775 ./data

# 5. Pembersihan
echo "🧹 Membersihkan image lama yang tidak terpakai..."
docker image prune -f

echo "✅ [$(date)] Update Selesai tanpa hambatan!"
