#!/bin/bash
echo "🚀 Memulai Update Sistem Geospasial..."
# Matikan semua layanan dan hapus network yang menggantung
docker compose down --remove-orphans
# Jika geo-ui tidak ada di compose, hapus manual
docker stop geo-ui 2>/dev/null && docker rm geo-ui 2>/dev/null
# Build dan jalankan ulang
docker compose up -d --build
echo "✅ Sistem Berhasil Diperbarui!"
