#!/bin/bash

# =================================================================
# SKRIP DEPLOY SISTEM GEOSPASIAL (STRICT SYNC VERSION)
# =================================================================

set -e # Berhenti jika ada error

echo "🚀 [$(date)] Memulai Update Sistem..."

# 1. Matikan layanan lama
echo "🔄 Menghentikan container lama..."
docker compose down --remove-orphans

# 2. Build secara sekuensial (Krusial untuk Sinkronisasi Library)
echo "🏗️ Membangun API Backend (Source of Truth)..."
docker compose build api-backend

echo "🏗️ Membangun DBGIS (Copying libraries from Backend)..."
docker compose build dbgis

echo "🏗️ Membangun layanan lainnya..."
docker compose build geo-worker

# 3. Jalankan Seluruh Stack
echo "🚢 Menjalankan container..."
docker compose up -d

# 4. Pembersihan Image Dangling
echo "🧹 Membersihkan sisa build..."
docker image prune -f

# 5. Verifikasi & Izin Folder
# if [ -d "./data" ]; then
#     echo "🔐 Mengatur izin akses folder ./data..."
#     sudo chmod -R 775 ./data
# fi

echo "------------------------------------------------"
echo "✅ UPDATE SELESAI PADA [$(date)]"
echo "------------------------------------------------"
docker compose ps

# update SSL untuk nextcloud
if [ -f "./backend/scripts/utils/update_nc_ssl.sh" ]; then
    ./backend/scripts/utils/update_nc_ssl.sh
fi


