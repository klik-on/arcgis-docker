
#  Verifikasi & Izin Folder
# if [ -d "./data" ]; then
#     echo "🔐 Mengatur izin akses folder ./data..."
#     sudo chmod -R 775 ./data
# fi
# screen -S deploy_gis
# Keluar dari sesi (Detach): Tekan Ctrl + A, lalu tekan D
# Masuk kembali (Attach): Jika nanti Anda login SSH lagi, cukup ketik:
# screen -r deploy_gis


#!/bin/bash

# =================================================================
# SKRIP DEPLOY SISTEM GEOSPASIAL (STRICT SYNC VERSION - FIXED 2026)
# =================================================================

set -e 

echo "🚀 [$(date)] Memulai Update Sistem (Python 3.13 Stack)..."

# 1. Matikan layanan lama secara total & Hapus container
echo "🔄 Menghentikan dan menghapus container lama..."
docker compose down --remove-orphans

# 2. Build secara sekuensial dengan FORCE PULL & NO-CACHE
# Kita tambahkan --pull untuk memastikan python:3.13-slim-bookworm ditarik ulang
# Kita tambahkan --no-cache agar Docker tidak memakai layer Python 3.12 lama

echo "🏗️ [1/3] Membangun API Backend (Python 3.13 + JIT)..."
docker compose build --pull --no-cache api-backend

echo "🏗️ [2/3] Membangun DBGIS (PostGIS 3.6.1 synced)..."
# DBGIS butuh build ulang karena dia mengambil COPY --from=api-backend
docker compose build --no-cache dbgis

echo "🏗️ [3/3] Membangun Geo-Worker..."
docker compose build geo-worker

# 3. Jalankan Seluruh Stack
echo "🚢 Menjalankan container..."
docker compose up -d

# 4. Verifikasi Langsung (Fail Fast)
echo "🔍 Melakukan verifikasi versi Python di container..."
ACTUAL_VER=$(docker exec geo-api python3 -V)
echo "Sistem melaporkan: $ACTUAL_VER"

# 5. Pembersihan Image Dangling
echo "🧹 Membersihkan sisa build lama..."
docker image prune -f

echo "------------------------------------------------"
echo "✅ UPDATE SELESAI PADA [$(date)]"
echo "------------------------------------------------"
docker compose ps
