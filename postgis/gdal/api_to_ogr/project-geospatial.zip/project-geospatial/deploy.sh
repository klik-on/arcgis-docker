#!/bin/bash
echo "🚀 Memulai Update Sistem Geospasial..."

# 1. Tarik perubahan terbaru (jika menggunakan git)
# git pull origin main

# 2. Matikan layanan lama
docker compose down --remove-orphans

# 3. Build dan jalankan ulang
docker compose up -d --build

# 4. Tunggu sebentar dan cek status
echo "⏳ Menunggu verifikasi layanan..."
sleep 5
docker compose ps

# 5. Baru bersihkan image lama setelah sistem baru dipastikan up
echo "🧹 Membersihkan image usang..."
docker image prune -f

echo "✅ Sistem Berhasil Diperbarui!"
