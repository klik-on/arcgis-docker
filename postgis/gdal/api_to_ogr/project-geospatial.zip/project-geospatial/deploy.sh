#!/bin/bash

# =================================================================
# SKRIP DEPLOY SISTEM GEOSPASIAL (APP SERVER - 172.16.2.122)
# =================================================================

# Konfigurasi
APP_NAME="Geospatial-System"

echo "🚀 [$(date)] Memulai Update Sistem $APP_NAME..."

# 1. Matikan layanan lama
# Menggunakan docker-compose down untuk memastikan network dan container lama bersih
echo "🔄 Menghentikan container lama..."
docker compose down --remove-orphans

# 2. Build dan jalankan ulang
# --build memastikan perubahan pada Dockerfile atau source code frontend/backend ikut ter-update
echo "🏗️ Membangun ulang dan menjalankan container..."
docker compose up -d --build

# 3. Pastikan izin akses folder data
# Celery worker membutuhkan akses tulis (write) untuk folder log dan hasil download
echo "🔐 Mengatur izin akses folder ./data..."
if [ -d "./data" ]; then
    sudo chmod -R 775 ./data
    # Jika perlu, sesuaikan kepemilikan user (opsional)
    # sudo chown -R $USER:docker ./data
fi

# 4. Pembersihan Image Dangling
# Menghapus image yang tidak terpakai setelah build agar penyimpanan tidak penuh
echo "🧹 Membersihkan image lama yang tidak terpakai..."
docker image prune -f

# 5. Verifikasi Status
echo "⏳ Menunggu verifikasi layanan (5 detik)..."
sleep 5

echo "------------------------------------------------"
echo "✅ UPDATE SELESAI PADA [$(date)]"
echo "📍 Server: 172.16.2.122"
echo "------------------------------------------------"
echo "🌐 Frontend : http://172.16.2.122:3000"
echo "📡 API      : http://172.16.2.122:8000"
echo "🌸 Flower   : http://172.16.2.122:5555"
echo "------------------------------------------------"
echo "🚀 GATEWAY  : http://172.16.2.130/ (WebGIS Utama)"
echo "------------------------------------------------"

# Menampilkan status container terakhir
docker compose ps

# update SSL untuk nextcloud
./backend/scripts/utils/update_nc_ssl.sh
