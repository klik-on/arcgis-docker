import geopandas as gpd
from sqlalchemy import create_engine, text
import pandas as pd
import sys
import os
import time  # Tambahkan modul time
from dotenv import load_dotenv

# Mulai hitung waktu
start_time = time.time()

# Memuat variabel lingkungan dari file .env
load_dotenv()

# =================================================================
# 1. KONFIGURASI DATABASE & PARAMETER
# =================================================================
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT')
DB_NAME = os.getenv('DB_NAME')

# Parameter Skema & Tabel
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
OUT_SCHEMA = os.getenv("SCHEMA_OUT", "analisis")

TABLE_A = "KWSHUTAN_AR_250K_v18102025"
FIELD_CATEGORY_A = "FUNGSIKWS"

TABLE_B = "ADM_KAB_KOTA"
FIELD_FILTER_B = "WADMPR"

PREFIX_TAB = "KWS"

# =================================================================
# 2. PENANGANAN ARGUMEN & PARAMETER DINAMIS
# =================================================================
if len(sys.argv) < 2:
    print(f"❌ Error: Argumen diperlukan.")
    print(f"Penggunaan: python3 gpd_CLIP.py \"Nama {FIELD_FILTER_B}\"")
    sys.exit(1)

TARGET_VALUE = sys.argv[1]
clean_name = TARGET_VALUE.replace(' ', '_').upper()

OUT_TABLE_NAME = f"{PREFIX_TAB}_{clean_name}_CLIP"
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE_NAME}"'

print("-" * 50)
print(f"🎯 TARGET FILTER : {TARGET_VALUE}")
print(f"📦 OUTPUT TABEL  : {RESULT_TABLE_FULL}")
print("-" * 50)

# =================================================================
# 3. KONEKSI KE DATABASE (MENGGUNAKAN PSYCOPG V3)
# =================================================================
conn_string = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(conn_string)

# =================================================================
# 4. LOAD DATA & GEOPROCESSING
# =================================================================
try:
    query_a = f'SELECT * FROM "{SCHEMA}"."{TABLE_A}"'
    query_b_filtered = f'SELECT * FROM "{SCHEMA}"."{TABLE_B}" WHERE "{FIELD_FILTER_B}" = \'{TARGET_VALUE}\''

    print(f"📖 Memuat data dari PostGIS...")
    gdf_lahan = gpd.read_postgis(query_a, engine, geom_col='geom')
    gdf_filter_target = gpd.read_postgis(query_b_filtered, engine, geom_col='geom')

    if gdf_filter_target.empty:
        print(f"⚠️ Data '{TARGET_VALUE}' tidak ditemukan.")
        sys.exit(1)

    if gdf_lahan.crs != gdf_filter_target.crs:
        print(f"🔄 Menyelaraskan CRS...")
        gdf_filter_target = gdf_filter_target.to_crs(gdf_lahan.crs)

    print(f"🧩 Memproses batas wilayah {TARGET_VALUE}...")
    gdf_filter_target = gdf_filter_target[[FIELD_FILTER_B, 'geom']]
    gdf_batas_target = gdf_filter_target.dissolve(by=FIELD_FILTER_B).reset_index()

    print(f"🚀 Melakukan Intersect (Clip) Geometri...")
    gdf_hasil = gdf_lahan.overlay(gdf_batas_target, how='intersection', keep_geom_type=True)

    if gdf_hasil.empty:
        print(f"⚠️ Hasil kosong untuk wilayah {TARGET_VALUE}.")
        sys.exit(0)

# =================================================================
# 5. PENYIMPANAN & KALKULASI LUAS
# =================================================================
    if gdf_hasil.geometry.name != 'geom':
        gdf_hasil = gdf_hasil.rename_geometry('geom')

    print(f"💾 Menyimpan hasil ke {RESULT_TABLE_FULL}...")
    gdf_hasil.to_postgis(
        name=OUT_TABLE_NAME,
        con=engine,
        schema=OUT_SCHEMA,
        if_exists='replace',
        index=False
    )

    print(f"📏 Menghitung Luas (CEA) via PostGIS...")
    sql_commands = [
        f'ALTER TABLE {RESULT_TABLE_FULL} ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;',
        f'UPDATE {RESULT_TABLE_FULL} SET "LUAS_CEA_HA" = ST_Area(ST_Transform("geom", 54034)) / 10000;'
    ]

    with engine.begin() as conn:
        for cmd in sql_commands:
            conn.execute(text(cmd))

    # Ringkasan Data
    if FIELD_CATEGORY_A in gdf_hasil.columns:
        query_summary = f'''
            SELECT "{FIELD_CATEGORY_A}", ROUND(SUM("LUAS_CEA_HA")::numeric, 2) as total_ha 
            FROM {RESULT_TABLE_FULL} 
            GROUP BY "{FIELD_CATEGORY_A}" 
            ORDER BY total_ha DESC
        '''
        summary_df = pd.read_sql(query_summary, engine)
        print(f"\n📊 RINGKASAN LUAS {TARGET_VALUE}:")
        print(summary_df.to_string(index=False))

    # --- 5. Informasi Akhir ---
    duration = time.time() - start_time
    print("-" * 50)
    print(f"✅ Selesai dalam {duration:.2f} detik.")
    print("-" * 50)

except Exception as e:
    print(f"❌ Terjadi kesalahan: {e}")
    sys.exit(1)
