#!/usr/bin/env python3
import os
import zipfile
import datetime
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# 1. LOAD KONFIGURASI
load_dotenv()
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
SCHEMA_DATA = os.getenv("SCHEMA_DATA", "datagis")

TABLE_B = "ADM_KAB_KOTA"
FIELD_FILTER_B = "WADMPR"
BASE_OUTPUT = "/app/data/output_gdb"

def get_expected_provinces():
    engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")
    query = text(f'SELECT DISTINCT "{FIELD_FILTER_B}" FROM "{SCHEMA_DATA}"."{TABLE_B}" WHERE "{FIELD_FILTER_B}" IS NOT NULL')
    with engine.connect() as conn:
        result = conn.execute(query)
        provs = [row[0].replace(' ', '_').replace('-', '_').upper() for row in result]
    engine.dispose()
    return provs

def validate():
    print("="*70)
    print(f"🔍 MEMULAI VALIDASI HASIL BATCH GDB")
    print(f"📂 Folder: {BASE_OUTPUT}")
    print("="*70)

    expected_names = get_expected_provinces()
    found_files = os.listdir(BASE_OUTPUT)
    
    report = []
    missing = []
    corrupt = []

    for name in expected_names:
        zip_filename = f"KWS_{name}.gdb.zip"
        zip_path = os.path.join(BASE_OUTPUT, zip_filename)

        if zip_filename not in found_files:
            missing.append(zip_filename)
            continue

        # Cek Integritas ZIP
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                # Cek apakah ada folder .gdb di dalamnya
                content = zf.namelist()
                is_gdb = any(".gdb/" in c for c in content)
                
                size = os.path.getsize(zip_path) / 1024 # KB
                
                if size < 1: # File kosong atau < 1KB
                    report.append(f"⚠️  {zip_filename}: UKURAN TERLALU KECIL ({size:.2f} KB)")
                elif not is_gdb:
                    report.append(f"❌ {zip_filename}: ISI BUKAN GDB")
                    corrupt.append(zip_filename)
                else:
                    report.append(f"✅ {zip_filename}: OK ({size:.2f} KB)")
                    
        except zipfile.BadZipFile:
            report.append(f"💥 {zip_filename}: FILE ZIP KORUP")
            corrupt.append(zip_filename)

    # RINGKASAN
    print("\n" + "\n".join(report))
    print("="*70)
    print(f"📊 HASIL AKHIR:")
    print(f"   - Total Seharusnya: {len(expected_names)}")
    print(f"   - Berhasil/Valid  : {len(expected_names) - len(missing) - len(corrupt)}")
    print(f"   - Hilang/Gagal    : {len(missing)}")
    print(f"   - Korup           : {len(corrupt)}")
    print("="*70)

    if missing:
        print(f"📝 DAFTAR HILANG: {missing}")

if __name__ == "__main__":
    validate()
