import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    host: '0.0.0.0',
    proxy: {
      /**
       * Proxy Setup:
       * Mengarahkan request lokal /api/v1 ke server Geoportal KLHK.
       * Frontend akan memanggil: /api/v1/IGT...
       * Vite akan meneruskan ke: http://geoportal.menlhk.go.id/datagis/api/v1/IGT...
       */
      '/api/v1': {
        // target: 'https://geoportal.menlhk.go.id/datagis',
        target: 'http://geo-api:8000',
        changeOrigin: true,
        secure: false, // Gunakan false jika server tujuan menggunakan self-signed SSL atau masih HTTP
        rewrite: (path) => `/datagis${path}`
      },
    },
  },
  build: {
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks: {
          maplibre: ['maplibre-gl'],
          react: ['react', 'react-dom'],
        },
      },
    },
  },
})
