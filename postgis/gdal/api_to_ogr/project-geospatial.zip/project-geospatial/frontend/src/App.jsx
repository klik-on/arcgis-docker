import React from 'react';
import DataTable from './components/DataTable';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 font-sans">
      <header className="bg-green-800 text-white shadow-lg p-4">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold tracking-tight">API GeoSpatial Dashboard </h1>
          <span className="text-sm bg-green-900 px-3 py-1 rounded-full border border-green-700">Input-DB-API-Dasboard</span>
        </div>
      </header>
      <main className="container mx-auto py-8 px-4">
        <DataTable />
      </main>
    </div>
  );
}
export default App;
