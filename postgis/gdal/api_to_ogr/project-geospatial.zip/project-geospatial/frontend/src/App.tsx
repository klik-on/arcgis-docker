import React, { useState, useEffect } from 'react';
import { fetchApi, ENDPOINTS, LayerTreeResponse } from './services/api';
import MapContainer from './components/MapContainer';
import DataTable from './components/DataTable';

const App: React.FC = () => {
  const [layers, setLayers] = useState<{ [schema: string]: string[] }>({});
  const [activeLayer, setActiveLayer] = useState<string>('');
  const [activeSchema, setActiveSchema] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [identifyData, setIdentifyData] = useState<any[] | null>(null);
  const [showTable, setShowTable] = useState<boolean>(true);

  useEffect(() => {
    const getLayerTree = async () => {
      try {
        const data = await fetchApi<LayerTreeResponse>(ENDPOINTS.LAYERS_TREE);
        if (data && data.repository) {
          const filteredRepo: { [schema: string]: string[] } = {};
          Object.entries(data.repository).forEach(([schema, tables]) => {
            if (schema.toLowerCase().endsWith('_3857')) {
              filteredRepo[schema] = tables;
            }
          });
          setLayers(filteredRepo);
          const schemas = Object.keys(filteredRepo);
          if (schemas.length > 0) {
            const defaultSchema = schemas.find(s => s.toLowerCase() === 'analisis_3857') || schemas[0];
            setActiveSchema(defaultSchema.toLowerCase());
            setActiveLayer(filteredRepo[defaultSchema][0].toUpperCase());
          }
        }
      } catch (err) { console.error("Load failed:", err); } finally { setLoading(false); }
    };
    getLayerTree();
  }, []);

  useEffect(() => { setIdentifyData(null); }, [activeLayer, activeSchema]);

  if (loading) return (
    <div className="h-screen w-screen bg-slate-950 flex items-center justify-center text-emerald-500 font-mono italic">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
        <p className="tracking-[0.3em] uppercase text-[10px] font-black animate-pulse">Initializing GIS Engine...</p>
      </div>
    </div>
  );

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-950 text-slate-200 font-sans overflow-hidden">
      {/* HEADER */}
      <header className="h-14 border-b border-white/5 bg-slate-900/90 flex items-center px-6 justify-between shrink-0 z-20">
        <div className="flex items-center gap-4">
          <div className="w-9 h-9 bg-emerald-500 rounded-xl flex items-center justify-center font-black text-slate-950 text-xs">3857</div>
          <h1 className="font-black tracking-tighter text-sm uppercase">GEOAPI <span className="text-emerald-500">OPTIMIZED</span></h1>
        </div>
        <div className="flex items-center gap-6">
          <div className="text-right">
            <div className="text-[10px] text-emerald-400 font-black uppercase tracking-widest">{activeLayer}</div>
            <div className="text-[9px] text-slate-500 font-mono italic">{activeSchema}</div>
          </div>
          <div className="h-2.5 w-2.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_10px_#10b981]"></div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* SIDEBAR */}
        <aside className="w-72 bg-slate-900/60 border-r border-white/5 flex flex-col shrink-0">
          <div className="p-5 border-b border-white/5"><h2 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Repositories</h2></div>
          <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
            {Object.entries(layers).map(([schema, tables]) => (
              <div key={schema} className="space-y-2">
                <span className="text-[10px] font-black text-emerald-500/80 px-2 uppercase italic">{schema}</span>
                <div className="space-y-1">
                  {tables.map(table => (
                    <button key={table} onClick={() => { setActiveLayer(table.toUpperCase()); setActiveSchema(schema.toLowerCase()); }}
                      className={`w-full text-left px-4 py-2.5 rounded-xl text-[11px] font-bold transition-all flex items-center justify-between ${
                        activeLayer === table.toUpperCase() && activeSchema === schema.toLowerCase() ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'text-slate-500 hover:bg-white/5'
                      }`}>
                      <span className="truncate">{table.toUpperCase()}</span>
                      {activeLayer === table.toUpperCase() && <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#4ade80]"></div>}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </aside>

        {/* MAIN DISPLAY */}
        <main className="flex-1 flex flex-col min-w-0 bg-slate-950">
          <section className={`relative border-b border-white/5 transition-all duration-500 ${showTable ? 'flex-[3]' : 'flex-1'}`}>
            <MapContainer activeLayer={activeLayer} activeSchema={activeSchema} onFeatureClick={(data) => { setIdentifyData(data); if(!showTable) setShowTable(true); }} />
            <button onClick={() => setShowTable(!showTable)} className="absolute bottom-6 right-6 bg-slate-900/90 hover:bg-emerald-600 text-white border border-white/10 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest z-10 transition-all">
              {showTable ? '↑ Maximize Map' : '↓ Show Table'}
            </button>
          </section>

          <section className={`flex flex-col overflow-hidden bg-slate-900/30 transition-all duration-500 ${showTable ? 'flex-1 opacity-100' : 'h-0 flex-none opacity-0'}`}>
            <DataTable activeLayer={activeLayer} activeSchema={activeSchema} overrideData={identifyData} />
          </section>
        </main>
      </div>
    </div>
  );
};

export default App;
