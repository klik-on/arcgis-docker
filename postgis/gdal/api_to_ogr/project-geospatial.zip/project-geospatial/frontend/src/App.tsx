/**
 * src/App.tsx
 * GeoAPI Portal V1.9 - Production Grade
 */

import React, { useEffect, useState } from 'react';
import MapContainer from './components/MapContainer';
import { fetchApi, ENDPOINTS, LayerTreeResponse } from './services/api';

const App: React.FC = () => {
  const [layers, setLayers] = useState<{ [schema: string]: string[] }>({});
  const [activeLayer, setActiveLayer] = useState<string>('');
  const [activeSchema, setActiveSchema] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [selectedFeature, setSelectedFeature] = useState<any>(null);

  // 1. Inisialisasi: Ambil struktur layer dari Backend
  useEffect(() => {
    const initializeData = async () => {
      try {
        const data = await fetchApi<LayerTreeResponse>(ENDPOINTS.LAYERS_TREE);
        if (data.status === 'success' && data.repository) {
          setLayers(data.repository);

          // Auto-select layer pertama agar peta tidak kosong saat load
          const schemas = Object.keys(data.repository);
          if (schemas.length > 0) {
            const firstSchema = schemas[0];
            const firstLayer = data.repository[firstSchema][0];
            setActiveSchema(firstSchema);
            setActiveLayer(firstLayer);
          }
        }
      } catch (err) {
        console.error("🔴 Gagal memuat repository layer:", err);
      } finally {
        setLoading(false);
      }
    };

    initializeData();
  }, []);

  return (
    <div className="flex h-screen w-full bg-slate-950 text-slate-200 overflow-hidden font-sans">
      
      {/* --- SIDEBAR: REPOSITORY & INSPECTOR --- */}
      <aside className="w-80 bg-slate-900 border-r border-slate-800 flex flex-col shadow-2xl z-20">
        
        {/* Header Branding */}
        <div className="p-6 border-b border-slate-800 bg-slate-900/50">
          <h1 className="text-xl font-black text-white italic tracking-tighter">
            GEOAPI <span className="text-emerald-500 underline decoration-2 underline-offset-4">V1.9</span>
          </h1>
          <p className="text-[10px] text-slate-500 font-bold uppercase mt-1 tracking-widest">
            Spatial Analysis Portal
          </p>
        </div>

        {/* Scrollable Layer List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
          {loading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="space-y-2">
                  <div className="h-2 bg-slate-800 rounded w-1/3"></div>
                  <div className="h-10 bg-slate-800 rounded-xl"></div>
                </div>
              ))}
            </div>
          ) : (
            Object.entries(layers).map(([schemaName, layerList]) => (
              <div key={schemaName} className="space-y-2">
                <h3 className="text-[10px] font-black text-emerald-500/70 uppercase tracking-[0.2em] px-2 flex items-center gap-2">
                  <span className="w-1 h-1 bg-emerald-500 rounded-full"></span>
                  {schemaName.replace(/_/g, ' ')}
                </h3>

                <div className="grid gap-1">
                  {layerList.map((layer) => (
                    <button
                      key={`${schemaName}-${layer}`}
                      onClick={() => {
                        setActiveLayer(layer);
                        setActiveSchema(schemaName);
                        setSelectedFeature(null); // Reset detail saat pindah layer
                      }}
                      className={`w-full text-left px-4 py-3 rounded-xl text-xs font-semibold transition-all duration-300 ${
                        activeLayer === layer && activeSchema === schemaName
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]'
                          : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200 border border-transparent'
                      }`}
                    >
                      {layer.replace(/_/g, ' ')}
                    </button>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Feature Detail Inspector (Sticky Bottom) */}
        <div className={`p-5 border-t border-slate-800 bg-slate-900/80 transition-all duration-500 ${selectedFeature ? 'h-72' : 'h-24'}`}>
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Feature Detail</h4>
            {selectedFeature && (
              <button 
                onClick={() => setSelectedFeature(null)}
                className="text-[10px] text-emerald-500 hover:text-white font-bold"
              >
                CLEAR
              </button>
            )}
          </div>
          
          <div className="overflow-y-auto h-48 pr-2 custom-scrollbar">
            {selectedFeature ? (
              <div className="space-y-2">
                {Object.entries(selectedFeature).map(([key, val]) => (
                  <div key={key} className="flex flex-col border-b border-slate-800/50 pb-1">
                    <span className="text-[9px] text-slate-500 font-mono uppercase tracking-tighter">{key}</span>
                    <span className="text-[11px] text-slate-200 font-medium break-words">
                      {val !== null && val !== undefined ? String(val) : '-'}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[10px] text-slate-600 italic leading-relaxed">
                Klik pada objek di peta untuk melihat informasi atribut detail di sini...
              </p>
            )}
          </div>
        </div>
      </aside>

      {/* --- MAIN CONTENT: MAP AREA --- */}
      <main className="flex-1 relative bg-slate-950 p-4">
        
        {/* Floating Active Context Info */}
        <div className="absolute top-8 left-8 z-10 pointer-events-none">
          <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700/50 p-5 rounded-3xl shadow-2xl flex items-center gap-4">
            <div className="w-10 h-10 bg-emerald-500/20 rounded-2xl flex items-center justify-center">
              <svg className="w-5 h-5 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
              </svg>
            </div>
            <div>
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">Current Layer</div>
              <div className="text-base font-black text-white leading-tight">
                {activeLayer ? activeLayer.replace(/_/g, ' ') : 'Pilih Layer...'}
              </div>
              <div className="text-[10px] font-mono text-emerald-500/70 mt-0.5">
                {activeSchema || 'No Schema Selected'}
              </div>
            </div>
          </div>
        </div>

        {/* Map Container Wrapper */}
        <div className="w-full h-full rounded-[2.5rem] overflow-hidden border border-slate-800 shadow-inner bg-slate-900">
          <MapContainer
            activeLayer={activeLayer}
            activeSchema={activeSchema}
            onFeatureClick={(data) => {
              // Jika data ada, ambil feature pertama yang ditemukan
              if (data && data.length > 0) {
                setSelectedFeature(data[0]);
              }
            }}
          />
        </div>

        {/* Custom Styling for Scrollbars */}
        <style>{`
          .custom-scrollbar::-webkit-scrollbar { width: 4px; }
          .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
          .custom-scrollbar::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 20px; }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #10b981; }
        `}</style>
      </main>
    </div>
  );
};

export default App;
