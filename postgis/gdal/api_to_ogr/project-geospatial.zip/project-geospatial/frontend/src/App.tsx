import React, { useEffect, useState } from 'react';
import MapContainer from './components/MapContainer';
import { fetchApi, ENDPOINTS, LayerTreeResponse } from './services/api';

const App: React.FC = () => {
  const [layers, setLayers] = useState<{ [schema: string]: string[] }>({});
  const [activeLayer, setActiveLayer] = useState<string>('');
  const [activeSchema, setActiveSchema] = useState<string>('');
  const [loading, setLoading] = useState(true);

  // 1. Ambil Data Tree dari API
  useEffect(() => {
    const loadLayers = async () => {
      try {
        const data = await fetchApi<LayerTreeResponse>(ENDPOINTS.LAYERS_TREE);
        if (data.status === 'success') {
          setLayers(data.repository);
          
          // Auto-select layer pertama jika ada data
          const schemas = Object.keys(data.repository);
          if (schemas.length > 0) {
            const firstSchema = schemas[0];
            const firstLayer = data.repository[firstSchema][0];
            setActiveSchema(firstSchema);
            setActiveLayer(firstLayer);
          }
        }
      } catch (err) {
        console.error("Failed to load layers tree", err);
      } finally {
        setLoading(false);
      }
    };
    loadLayers();
  }, []);

  return (
    <div className="flex h-screen w-full bg-slate-950 text-slate-200 overflow-hidden font-sans">
      
      {/* SIDEBAR */}
      <div className="w-72 bg-slate-900 border-r border-slate-800 flex flex-col shadow-2xl z-20">
        <div className="p-6 border-bottom border-slate-800">
          <h1 className="text-xl font-black text-white italic tracking-tighter">
            GEOAPI <span className="text-emerald-500 underline">V1.9</span>
          </h1>
          <p className="text-[10px] text-slate-500 font-bold uppercase mt-1">Spatial Analysis Portal</p>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {loading ? (
            <div className="animate-pulse space-y-3">
              {[1, 2, 3].map(i => <div key={i} className="h-8 bg-slate-800 rounded-lg w-full"></div>)}
            </div>
          ) : (
            Object.entries(layers).map(([schemaName, layerList]) => (
              <div key={schemaName} className="space-y-2">
                {/* Header Skema (e.g., datagis_3857 atau analisis_3857) */}
                <h3 className="text-[10px] font-black text-emerald-500/70 uppercase tracking-[0.2em] px-2">
                  {schemaName.replace('_3857', '').replace(/_/g, ' ')}
                </h3>
                
                <div className="space-y-1">
                  {layerList.map((layer) => (
                    <button
                      key={`${schemaName}-${layer}`}
                      onClick={() => {
                        setActiveLayer(layer);
                        setActiveSchema(schemaName);
                      }}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-all duration-200 ${
                        activeLayer === layer && activeSchema === schemaName
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.1)]'
                          : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200 border border-transparent'
                      }`}
                    >
                      {layer.replace(/_/g, ' ')}
                    </button>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* MAIN CONTENT (MAP) */}
      <div className="flex-1 relative bg-slate-950 p-4">
        <div className="absolute top-8 left-8 z-10 pointer-events-none">
          <div className="bg-slate-900/80 backdrop-blur-md border border-slate-700 p-4 rounded-2xl shadow-2xl">
            <div className="text-[10px] font-bold text-slate-500 uppercase">Active Context</div>
            <div className="text-lg font-black text-white">{activeLayer || 'No Layer Selected'}</div>
            <div className="text-[10px] font-mono text-emerald-500">{activeSchema}</div>
          </div>
        </div>

        <MapContainer 
          activeLayer={activeLayer} 
          activeSchema={activeSchema} 
        />
      </div>
    </div>
  );
};

export default App;
