import React, { useEffect, useState } from 'react';
import { fetchApi, ENDPOINTS } from '../services/api';

interface DataTableProps {
  activeLayer: string;
  activeSchema: string;
  overrideData?: any[] | null;
}

const DataTable: React.FC<DataTableProps> = ({ activeLayer, activeSchema, overrideData }) => {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      if (overrideData) { setData(overrideData); return; }
      if (!activeLayer) return;
      setLoading(true);
      try {
        const result = await fetchApi<any>(ENDPOINTS.GET_ATTRIBUTES(activeLayer, activeSchema));
        setData(Array.isArray(result) ? result : (result?.data || []));
      } catch (err) { setData([]); } finally { setLoading(false); }
    };
    loadData();
  }, [activeLayer, activeSchema, overrideData]);

  if (loading) return <div className="p-6 text-emerald-500 font-black animate-pulse text-[10px] uppercase">Syncing...</div>;
  if (data.length === 0) return <div className="p-10 text-center text-slate-600 text-[10px] uppercase italic">Empty Dataset</div>;

  const cols = Object.keys(data[0]).filter(c => !['geom', 'geometry', 'geometry_json'].includes(c.toLowerCase()));

  return (
    <div className="flex flex-col h-full">
      <div className="h-10 bg-white/5 flex items-center px-6 justify-between border-b border-white/5">
        <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">{overrideData ? 'IDENTIFIED OBJECT' : `REGISTRY: ${activeLayer}`}</span>
        <span className="text-[9px] text-slate-500 font-mono italic">{data.length} records</span>
      </div>
      <div className="flex-1 overflow-auto custom-scrollbar">
        <table className="w-full text-left text-[10px] border-collapse">
          <thead className="sticky top-0 bg-slate-900 z-10 shadow-lg">
            <tr>
              {cols.map(c => (
                <th key={c} className="p-4 border-b border-white/10 text-white uppercase font-black whitespace-nowrap">{c.replace(/_/g, ' ')}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5 text-slate-400">
            {data.map((row, i) => (
              <tr key={i} className="hover:bg-emerald-500/5 transition-colors">
                {cols.map(c => (
                  <td key={c} className="p-4 whitespace-nowrap truncate max-w-xs">{row[c] !== null ? String(row[c]) : '-'}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DataTable;
