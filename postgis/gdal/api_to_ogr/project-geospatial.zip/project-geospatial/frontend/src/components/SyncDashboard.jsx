import React, { useState, useEffect, useRef } from 'react';

const SyncDashboard = () => {
  const [currentTaskId, setCurrentTaskId] = useState(null);
  const [taskStatus, setTaskStatus] = useState("IDLE");
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedIgt, setSelectedIgt] = useState("PERSETUJUAN_KOMITMEN_PBPH");
  const logEndRef = useRef(null);

  const API_KEY = 'pgis-pass-2026';

  // 1. Fungsi Polling Status Berdasarkan Task ID
  const fetchTaskStatus = async (taskId) => {
    try {
      const res = await fetch(`/api/v1/sync/status/${taskId}`, {
        headers: { 'X-API-KEY': API_KEY }
      });
      const data = await res.json();
      setTaskStatus(data.status);
      
      // Jika task selesai atau gagal, berhenti memantau ID ini
      if (data.ready) {
        setCurrentTaskId(null);
        setLoading(false);
      }
    } catch (err) {
      console.error("Error fetching task status:", err);
    }
  };

  // 2. Fungsi Fetch Logs (Membaca file log di server)
  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/v1/sync/logs?lines=30', {
        headers: { 'X-API-KEY': API_KEY }
      });
      const data = await res.json();
      if (data.content) setLogs(data.content);
    } catch (err) {
      console.error("Error fetching logs");
    }
  };

  // Effect untuk polling berkala saat task sedang berjalan
  useEffect(() => {
    let interval;
    if (currentTaskId || taskStatus === 'STARTED' || taskStatus === 'PENDING') {
      interval = setInterval(() => {
        if (currentTaskId) fetchTaskStatus(currentTaskId);
        fetchLogs();
      }, 2000);
    } else {
      fetchLogs(); // Tetap fetch log sesekali untuk update terakhir
    }
    return () => clearInterval(interval);
  }, [currentTaskId, taskStatus]);

  // Auto-scroll log ke paling bawah
  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  // 3. Fungsi Menjalankan Script
  const handleRun = async (type) => {
    setLoading(true);
    setLogs(["Memulai permintaan ke server..."]);
    
    let payload = {};
    if (type === 'KUPS') {
      payload = { script_name: "integrasi/gpd_KUPS_gdbtopgis.py", args: [] };
    } else {
      payload = {
        script_name: "integrasi/pbph_integrated.py",
        env: { "IGT": selectedIgt }
      };
    }

    try {
      const res = await fetch('/api/v1/sync/run-script', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json', 
          'X-API-KEY': API_KEY 
        },
        body: JSON.stringify(payload)
      });
      
      const data = await res.json();
      
      if (res.ok) {
        setCurrentTaskId(data.task_id);
        setTaskStatus("QUEUED");
      } else {
        alert(data.detail || "Gagal menjalankan skrip");
        setLoading(false);
      }
    } catch (err) {
      alert("Koneksi ke API Backend terputus");
      setLoading(false);
    }
  };

  const pbphLayers = [
    { id: "PERSETUJUAN_KOMITMEN_PBPH", name: "Persetujuan Komitmen" },
    { id: "PBPH_DEFINITIF", name: "PBPH Definitif" }
  ];

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
      {/* Header Status Indicator */}
      <div className="p-5 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
        <h3 className="font-bold text-slate-700">ETL Control Panel</h3>
        <div className="flex items-center space-x-2">
          <span className={`h-3 w-3 rounded-full ${
            currentTaskId ? 'bg-amber-500 animate-pulse' : 
            taskStatus === 'SUCCESS' ? 'bg-emerald-500' : 'bg-slate-300'
          }`}></span>
          <span className="text-xs font-black uppercase tracking-widest text-slate-500">
            {currentTaskId ? `RUNNING: ${taskStatus}` : 'SYSTEM READY'}
          </span>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Tombol KUPS */}
        <div className="space-y-3">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">Master Data KUPS</label>
          <button
            onClick={() => handleRun('KUPS')}
            disabled={loading || currentTaskId}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-100 disabled:text-slate-400 text-white rounded-xl font-bold transition-all shadow-md hover:shadow-lg active:scale-[0.98]"
          >
            🚀 Sync Master KUPS
          </button>
        </div>

        {/* Tombol PBPH */}
        <div className="space-y-3">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">Integrasi PBPH (API PHL)</label>
          <div className="flex space-x-2">
            <select
              value={selectedIgt}
              onChange={(e) => setSelectedIgt(e.target.value)}
              disabled={loading || currentTaskId}
              className="flex-1 bg-slate-100 border-none rounded-xl px-4 py-3 text-sm font-semibold focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
            >
              {pbphLayers.map(layer => (
                <option key={layer.id} value={layer.id}>{layer.name}</option>
              ))}
            </select>
            <button
              onClick={() => handleRun('PBPH')}
              disabled={loading || currentTaskId}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-100 disabled:text-slate-400 text-white rounded-xl font-bold shadow-md transition-all"
            >
              Sync
            </button>
          </div>
        </div>

        {/* Terminal Log Output */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">Live Process Log</label>
            {currentTaskId && <span className="text-[9px] text-blue-500 font-mono animate-pulse">ID: {currentTaskId.slice(0,8)}...</span>}
          </div>
          <div className="bg-slate-900 rounded-xl p-4 h-72 overflow-y-auto font-mono text-[11px] leading-relaxed text-emerald-400 shadow-inner border border-slate-800">
            {logs.length > 0 ? (
              logs.map((line, i) => (
                <div key={i} className="mb-1 border-l-2 border-emerald-900/50 pl-3 py-0.5 hover:bg-emerald-500/5 transition-colors">
                  <span className="opacity-50 mr-2 text-[9px]">{i+1}</span>
                  {line}
                </div>
              ))
            ) : (
              <div className="flex h-full items-center justify-center text-slate-600 italic">
                Ready for next integration...
              </div>
            )}
            <div ref={logEndRef} />
          </div>
        </div>
      </div>
      
      {/* Footer info */}
      <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 text-[9px] text-slate-400 flex justify-between">
        <span>Worker: Celery@Redis</span>
        <span>v1.7.0-stable</span>
      </div>
    </div>
  );
};

export default SyncDashboard;
