import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import { fetchKups } from '../services/api';
import { Layers, Loader2, MapPin, Package, Trees, Info } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// FUNGSI UNTUK GENERATE SIMBOL WARNA DINAMIS
const createCustomIcon = (kelas) => {
    let color = '#3b82f6'; // Default BIRU
    if (kelas === 'EMAS') color = '#f59e0b'; // AMBER/GOLD
    if (kelas === 'PERAK') color = '#94a3b8'; // SLATE/SILVER

    return L.divIcon({
        html: `<div style="
            background-color: ${color};
            width: 14px;
            height: 14px;
            border: 2px solid white;
            border-radius: 50%;
            box-shadow: 0 0 4px rgba(0,0,0,0.4);
        "></div>`,
        className: 'custom-div-icon',
        iconSize: [14, 14],
        iconAnchor: [7, 7]
    });
};

const DataTable = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchKups(12000, 0).then(res => {
            setData(res.features || []);
            setLoading(false);
        }).catch(() => setLoading(false));
    }, []);

    const renderComplexData = (rawData, type) => {
        if (!rawData || rawData === "[]") return <span className="text-gray-400 italic">Tidak ada data</span>;
        try {
            const cleaned = typeof rawData === 'string' ? JSON.parse(rawData.replace(/'/g, '"')) : rawData;
            if (Array.isArray(cleaned)) {
                return cleaned.map((item, idx) => (
                    <div key={idx} className="bg-gray-50 border-l-2 border-green-300 px-2 py-1 mb-1 rounded-r text-[11px]">
                        <span className="font-semibold text-gray-800">
                            {type === 'produk' ? item.namaProduk : item.komoditas}
                        </span>
                        {item.deskripsi && <span className="text-gray-500 ml-1">- {item.deskripsi}</span>}
                    </div>
                ));
            }
            return <span className="text-gray-700">{rawData.replace(/[\[\]"']/g, '')}</span>;
        } catch (e) {
            return <span className="text-gray-700">{rawData.replace(/[\[\]"']/g, '')}</span>;
        }
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center p-20">
            <Loader2 className="animate-spin text-green-800 mb-4" size={48} />
            <p className="text-gray-600 font-bold uppercase tracking-widest">Memuat Simbol Geospasial...</p>
        </div>
    );

    return (
        <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
                <div className="bg-green-900 px-6 py-4 flex justify-between items-center text-white">
                    <div className="flex items-center gap-3">
                        <Layers size={24} />
                        <div>
                            <h2 className="text-xl font-bold leading-none">WebGIS KUPS Nasional</h2>
                            <p className="text-[10px] text-green-300 mt-1 uppercase tracking-wider">Menengah, Utama, Mandiri</p>
                        </div>
                    </div>
                    <div className="flex gap-4 items-center">
                        {/* Legend Simple */}
                        <div className="hidden md:flex gap-3 text-[10px] font-bold">
                            <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-amber-500"></div> EMAS</span>
                            <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-slate-400"></div> PERAK</span>
                            <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-blue-500"></div> BIRU</span>
                        </div>
                        <span className="bg-green-800 px-3 py-1 rounded text-xs font-mono border border-green-700">
                            {data.length.toLocaleString()} OBJ
                        </span>
                    </div>
                </div>
                
                <div style={{ height: '600px', width: '100%' }}>
                    <MapContainer center={[-0.7893, 113.9213]} zoom={5} style={{ height: '100%', width: '100%' }}>
                        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                        
                        <MarkerClusterGroup chunkedLoading>
                            {data.map((f, i) => (
                                <Marker 
                                    key={i} 
                                    position={[f.geometry.coordinates[1], f.geometry.coordinates[0]]}
                                    icon={createCustomIcon(f.properties.KELASKUPS)} // PENETAPAN SIMBOL DISINI
                                >
                                    <Popup minWidth={280}>
                                        <div className="p-1 font-sans">
                                            <div className="flex items-center justify-between mb-3 border-b pb-2">
                                                <div className={`px-3 py-1 rounded text-[10px] font-black text-white ${
                                                    f.properties.KELASKUPS === 'EMAS' ? 'bg-amber-500' :
                                                    f.properties.KELASKUPS === 'PERAK' ? 'bg-slate-400' : 'bg-blue-500'
                                                } uppercase`}>
                                                    KELAS {f.properties.KELASKUPS}
                                                </div>
                                                <code className="text-[10px] text-gray-400 uppercase">{f.properties.ID}</code>
                                            </div>

                                            <h3 className="text-lg font-extrabold text-green-900 leading-tight mb-4 uppercase">
                                                {f.properties.NAMAKUPS}
                                            </h3>

                                            <div className="space-y-4">
                                                <section>
                                                    <div className="flex items-center gap-1 text-amber-700 font-bold text-[9px] uppercase mb-1">
                                                        <Package size={12}/> Produk
                                                    </div>
                                                    {renderComplexData(f.properties.PRODUK, 'produk')}
                                                </section>
                                                <section>
                                                    <div className="flex items-center gap-1 text-green-700 font-bold text-[9px] uppercase mb-1">
                                                        <Trees size={12}/> Potensi
                                                    </div>
                                                    {renderComplexData(f.properties.POTENSI, 'potensi')}
                                                </section>
                                            </div>

                                            <div className="mt-4 pt-3 border-t flex items-center text-blue-600">
                                                <div className="flex items-center text-[10px] font-mono">
                                                    <MapPin size={12} className="mr-1"/>
                                                    {f.geometry.coordinates[1].toFixed(5)}, {f.geometry.coordinates[0].toFixed(5)}
                                                </div>
                                            </div>
                                        </div>
                                    </Popup>
                                </Marker>
                            ))}
                        </MarkerClusterGroup>
                    </MapContainer>
                </div>
            </div>
        </div>
    );
};

export default DataTable;
