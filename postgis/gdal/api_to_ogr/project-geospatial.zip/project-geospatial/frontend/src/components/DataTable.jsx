import React, { useEffect, useState, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import { fetchKups } from '../services/api';
import { Layers, Loader2, MapPin, Package, Trees, Filter, ChevronRight } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// 1. KOMPONEN LEGENDA MELAYANG
const MapLegend = () => (
    <div className="absolute bottom-6 left-6 z-[1000] bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-white/50 w-44 pointer-events-none">
        <div className="flex items-center gap-2 mb-3 text-gray-400">
            <Filter size={12}/>
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Legenda</span>
        </div>
        <div className="space-y-2.5">
            <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-amber-500 ring-4 ring-amber-100"></div>
                <span className="text-[10px] font-bold text-gray-600">EMAS</span>
            </div>
            <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-slate-400 ring-4 ring-slate-100"></div>
                <span className="text-[10px] font-bold text-gray-600">PERAK</span>
            </div>
            <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-blue-600 ring-4 ring-blue-100"></div>
                <span className="text-[10px] font-bold text-gray-600">BIRU</span>
            </div>
        </div>
    </div>
);

// 2. FUNGSI GENERATE SIMBOL WARNA
const createCustomIcon = (kelas) => {
    let color = '#3b82f6'; // Default BIRU
    if (kelas === 'EMAS') color = '#f59e0b'; // AMBER
    if (kelas === 'PERAK') color = '#94a3b8'; // SLATE

    return L.divIcon({
        html: `<div style="background-color: ${color}; width: 14px; height: 14px; border: 2px solid white; border-radius: 50%; box-shadow: 0 0 5px rgba(0,0,0,0.3);"></div>`,
        className: 'custom-div-icon',
        iconSize: [14, 14],
        iconAnchor: [7, 7]
    });
};

const DataTable = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeFilter, setActiveFilter] = useState('SEMUA');

    useEffect(() => {
        // Mengambil 12.000 data sesuai permintaan skrip kedua
        fetchKups(12000, 0).then(res => {
            setData(res.features || []);
            setLoading(false);
        }).catch(() => setLoading(false));
    }, []);

    // 3. LOGIKA FILTER DATA
    const filteredData = useMemo(() => {
        if (activeFilter === 'SEMUA') return data;
        return data.filter(f => f.properties.KELASKUPS === activeFilter);
    }, [data, activeFilter]);

    // 4. FUNGSI RENDER DATA KOMPLEKS (PRODUK & POTENSI)
    const renderComplexData = (rawData, type) => {
        if (!rawData || rawData === "[]") return <span className="text-gray-400 italic text-[10px]">Tidak ada data</span>;
        try {
            const cleaned = typeof rawData === 'string' ? JSON.parse(rawData.replace(/'/g, '"')) : rawData;
            if (Array.isArray(cleaned)) {
                return cleaned.map((item, idx) => (
                    <div key={idx} className="bg-gray-50 border-l-2 border-green-300 px-2 py-1 mb-1 rounded-r text-[11px] flex flex-col">
                        <span className="font-semibold text-gray-800">
                            {type === 'produk' ? item.namaProduk : item.komoditas}
                        </span>
                        {item.deskripsi && <span className="text-[10px] text-gray-500 italic">{item.deskripsi}</span>}
                    </div>
                ));
            }
            return <span className="text-gray-700 text-[11px]">{rawData.replace(/[\[\]"']/g, '')}</span>;
        } catch (e) {
            return <span className="text-gray-700 text-[11px]">{rawData.replace(/[\[\]"']/g, '')}</span>;
        }
    };

    if (loading) return (
        <div className="h-[600px] flex flex-col items-center justify-center p-20 bg-white rounded-2xl shadow-inner border border-dashed border-gray-300">
            <Loader2 className="animate-spin text-green-800 mb-4" size={48} />
            <p className="text-gray-600 font-bold uppercase tracking-widest text-xs">Memuat 12.000 Simbol Geospasial...</p>
        </div>
    );

    return (
        <div className="space-y-4">
            {/* HEADER & FILTER BAR */}
            <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-200 flex flex-wrap justify-between items-center gap-4">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-green-900 rounded-lg text-white">
                        <Layers size={20} />
                    </div>
                    <div>
                        <h2 className="text-sm font-bold text-gray-800 uppercase leading-none">WebGIS KUPS Nasional</h2>
                        <p className="text-[9px] text-gray-400 uppercase mt-1 tracking-tighter font-semibold">Menengah, Utama, Mandiri</p>
                    </div>
                </div>

                <div className="flex bg-gray-100 p-1 rounded-xl gap-1">
                    {['SEMUA', 'EMAS', 'PERAK', 'BIRU'].map(f => (
                        <button 
                            key={f} 
                            onClick={() => setActiveFilter(f)} 
                            className={`px-4 py-1.5 rounded-lg text-[10px] font-black transition-all ${
                                activeFilter === f ? 'bg-white text-green-800 shadow-sm' : 'text-gray-400 hover:text-gray-600'
                            }`}
                        >
                            {f}
                        </button>
                    ))}
                    <span className="ml-2 px-3 py-1.5 bg-green-800 text-white rounded-lg text-[10px] font-mono">
                        {filteredData.length.toLocaleString()} OBJ
                    </span>
                </div>
            </div>

            {/* AREA PETA */}
            <div className="relative bg-white rounded-[2rem] overflow-hidden shadow-2xl border border-gray-200" style={{ height: '650px' }}>
                <MapContainer center={[-0.7893, 113.9213]} zoom={5} style={{ height: '100%', width: '100%' }}>
                    <TileLayer 
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        attribution='&copy; Menlhk RI 2026'
                    />
                    
                    <MarkerClusterGroup chunkedLoading>
                        {filteredData.map((f, i) => (
                            <Marker 
                                key={i} 
                                position={[f.geometry.coordinates[1], f.geometry.coordinates[0]]}
                                icon={createCustomIcon(f.properties.KELASKUPS)}
                            >
                                <Popup minWidth={280}>
                                    <div className="p-1 font-sans">
                                        {/* Badge Kelas & ID */}
                                        <div className="flex items-center justify-between mb-3 border-b pb-2">
                                            <div className={`px-3 py-1 rounded text-[10px] font-black text-white uppercase ${
                                                f.properties.KELASKUPS === 'EMAS' ? 'bg-amber-500' :
                                                f.properties.KELASKUPS === 'PERAK' ? 'bg-slate-400' : 'bg-blue-600'
                                            }`}>
                                                KELAS {f.properties.KELASKUPS}
                                            </div>
                                            <code className="text-[10px] text-gray-400 uppercase">ID: {f.properties.ID}</code>
                                        </div>

                                        {/* Nama KUPS */}
                                        <h3 className="text-base font-extrabold text-green-900 leading-tight mb-4 uppercase">
                                            {f.properties.NAMAKUPS}
                                        </h3>

                                        {/* Grid Data Produk & Potensi */}
                                        <div className="space-y-4">
                                            <section>
                                                <div className="flex items-center gap-1 text-amber-700 font-bold text-[9px] uppercase mb-1">
                                                    <Package size={12}/> Produk Unggulan
                                                </div>
                                                {renderComplexData(f.properties.PRODUK, 'produk')}
                                            </section>
                                            <section>
                                                <div className="flex items-center gap-1 text-green-700 font-bold text-[9px] uppercase mb-1">
                                                    <Trees size={12}/> Potensi Wilayah
                                                </div>
                                                {renderComplexData(f.properties.POTENSI, 'potensi')}
                                            </section>
                                        </div>

                                        {/* Koordinat */}
                                        <div className="mt-4 pt-3 border-t flex items-center text-blue-600">
                                            <div className="flex items-center text-[10px] font-mono">
                                                <MapPin size={12} className="mr-1"/>
                                                {f.geometry.coordinates[1].toFixed(5)}, {f.geometry.coordinates[0].toFixed(5)}
                                            </div>
                                        </div>
                                    </div>
                                </Popup>
                            </Marker>
                        ))}
                    </MarkerClusterGroup>
                </MapContainer>

                {/* Legenda Melayang */}
                <MapLegend />
            </div>
        </div>
    );
};

export default DataTable;
