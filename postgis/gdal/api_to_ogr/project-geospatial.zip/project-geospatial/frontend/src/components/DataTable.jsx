import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import { fetchKups } from '../services/api';
import { Table as TableIcon, Layers, Loader2, MapPin, Info } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Konfigurasi Icon Marker agar muncul dengan benar setelah build
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';
let DefaultIcon = L.icon({
    iconUrl: markerIcon,
    shadowUrl: markerShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

const DataTable = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Mengambil seluruh data KUPS (Limit diatur di atas total record 11.636)
        fetchKups(12000, 0).then(res => {
            setData(res.features || []);
            setLoading(false);
        }).catch((err) => {
            console.error("Error fetching data:", err);
            setLoading(false);
        });
    }, []);

    // Fungsi helper untuk membersihkan format string array "[]" dari API
    const formatLabel = (str) => {
        if (!str || str === "[]") return "Tidak ada data";
        return str.replace(/[\[\]"]/g, '');
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center p-20 space-y-4">
            <Loader2 className="animate-spin text-green-800" size={48} />
            <p className="text-gray-600 font-medium text-lg text-center">
               Mengolah 11.636 Objek Spasial KUPS... <br/>
               <span className="text-sm font-normal text-gray-400">Menyiapkan cluster titik distribusi nasional</span>
            </p>
        </div>
    );

    return (
        <div className="space-y-6">
            {/* PANEL PETA */}
            <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
                <div className="bg-gray-50 px-6 py-3 border-b flex justify-between items-center">
                    <div className="flex items-center gap-2 text-green-800 font-bold">
                        <Layers size={18} />
                        <h2>Peta Distribusi Nasional KUPS</h2>
                    </div>
                    <div className="flex gap-2">
                        <span className="text-xs bg-green-100 text-green-800 px-3 py-1 rounded-full border border-green-200 font-semibold">
                            Total: {data.length.toLocaleString()} Titik
                        </span>
                    </div>
                </div>
                
                <div style={{ height: '550px', width: '100%' }}>
                    <MapContainer 
                        center={[-0.7893, 113.9213]} 
                        zoom={5} 
                        style={{ height: '100%', width: '100%' }}
                        scrollWheelZoom={true}
                    >
                        <TileLayer
                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        />
                        
                        {/* Grouping ribuan marker ke dalam Cluster */}
                        <MarkerClusterGroup chunkedLoading>
                            {data.map((f, i) => (
                                <Marker 
                                    key={i} 
                                    position={[f.geometry.coordinates[1], f.geometry.coordinates[0]]}
                                >
                                    <Popup>
                                        <div className="min-w-[220px] font-sans p-1">
                                            {/* Header & Badge Kelas */}
                                            <div className="flex justify-between items-start mb-2 gap-2">
                                                <h3 className="font-bold text-green-900 leading-tight">
                                                    {f.properties.NAMAKUPS}
                                                </h3>
                                                <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold text-white whitespace-nowrap ${
                                                    f.properties.KELASKUPS === 'EMAS' ? 'bg-yellow-500' :
                                                    f.properties.KELASKUPS === 'PERAK' ? 'bg-gray-400' :
                                                    'bg-blue-500'
                                                }`}>
                                                    {f.properties.KELASKUPS}
                                                </span>
                                            </div>

                                            {/* Detail Fields */}
                                            <div className="space-y-2 text-xs border-t pt-2 border-gray-100">
                                                <div>
                                                    <span className="text-gray-400 block uppercase text-[8px] font-bold">ID Unik</span>
                                                    <code className="text-gray-700 bg-gray-50 px-1 rounded font-mono">{f.properties.ID}</code>
                                                </div>

                                                <div>
                                                    <span className="text-gray-400 block uppercase text-[8px] font-bold">Produk</span>
                                                    <p className="text-gray-700">{formatLabel(f.properties.PRODUK)}</p>
                                                </div>

                                                <div>
                                                    <span className="text-gray-400 block uppercase text-[8px] font-bold">Potensi Wilayah</span>
                                                    <p className="text-gray-700 font-medium">{formatLabel(f.properties.POTENSI)}</p>
                                                </div>
                                            </div>

                                            {/* Footer Popup */}
                                            <div className="mt-3 pt-2 border-t border-dashed border-gray-200 flex justify-between items-center">
                                                <div className="flex items-center text-blue-600 font-mono text-[10px]">
                                                    <MapPin size={10} className="mr-1" />
                                                    {f.geometry.coordinates[1].toFixed(5)}, {f.geometry.coordinates[0].toFixed(5)}
                                                </div>
                                            </div>
                                        </div>
                                    </Popup>
                                </Marker>
                            ))}
                        </MarkerClusterGroup>
                    </MapContainer>
                </div>
            </div>

            {/* PANEL INFORMASI RINGKAS */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 flex items-center gap-3">
                    <div className="bg-blue-500 p-2 rounded-full text-white"><Info size={20}/></div>
                    <div>
                        <p className="text-xs text-blue-600 font-bold uppercase">Sistem Koordinat</p>
                        <p className="text-sm text-blue-900 font-medium">WGS 84 (EPSG:4326)</p>
                    </div>
                </div>
                {/* Anda bisa menambah widget ringkasan lain di sini */}
            </div>
        </div>
    );
};

export default DataTable;
