import React, { useEffect, useRef, useState, useCallback } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { API_KEY, ENDPOINTS } from '../services/api';

interface MapProps {
  activeLayer: string;   // Nama tabel (Misal: "PL_DKI_JAKARTA")
  activeSchema: string;  // Nama schema (Misal: "analisis_3857")
  onFeatureClick?: (data: any[] | null) => void;
}

const MapContainer: React.FC<MapProps> = ({ activeLayer, activeSchema, onFeatureClick }) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<maplibregl.Map | null>(null);
  const popupRef = useRef<maplibregl.Popup | null>(null);
  const [isRendering, setIsRendering] = useState(false);

  /**
   * Fungsi untuk merender Layer Geospasial (MVT)
   */
  const renderGeoLayer = useCallback(async () => {
    if (!map.current || !activeLayer || !activeSchema) return;

    setIsRendering(true);
    const m = map.current;

    const lName = activeLayer;
    const sName = activeSchema.toLowerCase();
    const sourceId = `src-${lName}-${sName}`; // ID unik per layer & schema

    // --- 1. Cleanup: Hapus layer dan source lama agar tidak tumpang tindih ---
    const layersToRemove = ['lyr-fill', 'lyr-outline', 'lyr-point'];
    layersToRemove.forEach(id => {
      if (m.getLayer(id)) m.removeLayer(id);
    });
    
    // Hapus semua source yang diawali 'src-' untuk memastikan memori bersih
    const existingSources = m.getStyle().sources;
    Object.keys(existingSources).forEach(id => {
      if (id.startsWith('src-')) m.removeSource(id);
    });

    if (popupRef.current) popupRef.current.remove();

    // --- 2. Tambahkan Source MVT Baru ---
    // Menggunakan ENDPOINTS.MVT_TILES yang sudah kita definisikan di api.ts
    const tileUrl = `${window.location.origin}/datagis/api/v1/mvt/{z}/{x}/{y}?layer=${lName}&schema=${sName}&api_key=${API_KEY}`;
    
    m.addSource(sourceId, {
      type: 'vector',
      tiles: [tileUrl],
      promoteId: 'id_gid' // Menggunakan ID dari database untuk feature-state
    });

    // --- 3. Tambahkan Layer Visualisasi ---

    // A. Fill Layer (Polygon)
    m.addLayer({
      id: 'lyr-fill',
      type: 'fill',
      source: sourceId,
      'source-layer': lName,
      paint: {
        'fill-color': '#10b981',
        'fill-opacity': ['case', ['boolean', ['feature-state', 'selected'], false], 0.7, 0.3]
      },
      filter: ['any', ['==', ['geometry-type'], 'Polygon'], ['==', ['geometry-type'], 'MultiPolygon']]
    });

    // B. Point Layer (Circle)
    m.addLayer({
      id: 'lyr-point',
      type: 'circle',
      source: sourceId,
      'source-layer': lName,
      paint: {
        'circle-radius': ['case', ['boolean', ['feature-state', 'selected'], false], 9, 6],
        'circle-color': '#10b981',
        'circle-stroke-width': 2,
        'circle-stroke-color': '#ffffff',
        'circle-opacity': 0.8
      },
      filter: ['any', ['==', ['geometry-type'], 'Point'], ['==', ['geometry-type'], 'MultiPoint']]
    });

    // C. Outline Layer
    m.addLayer({
      id: 'lyr-outline',
      type: 'line',
      source: sourceId,
      'source-layer': lName,
      paint: {
        'line-color': ['case', ['boolean', ['feature-state', 'selected'], false], '#fbbf24', '#ffffff'],
        'line-width': ['case', ['boolean', ['feature-state', 'selected'], false], 2.5, 0.5]
      }
    });

    // --- 4. Auto Zoom to Bounds ---
    try {
      const boundsUrl = `${window.location.origin}/datagis${ENDPOINTS.GET_BOUNDS(lName, sName)}&api_key=${API_KEY}`;
      const res = await fetch(boundsUrl);
      const data = await res.json();
      
      if (data.bounds) {
        // Regex untuk mengekstrak angka dari format BOX(x min, y min, x max, y max)
        const coords = data.bounds.match(/[-+]?\d*\.?\d+/g)?.map(Number);
        if (coords && coords.length === 4) {
          m.fitBounds(
            [[coords[0], coords[1]], [coords[2], coords[3]]], 
            { padding: 50, duration: 1200 }
          );
        }
      }
    } catch (e) {
      console.warn("Gagal mengambil jangkauan (bounds) layer:", e);
    }

    setIsRendering(false);
  }, [activeLayer, activeSchema]);

  /**
   * Inisialisasi MapLibre saat pertama kali load
   */
  useEffect(() => {
    if (!mapContainer.current) return;

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: {
        version: 8,
        sources: {
          'osm-tiles': {
            type: 'raster',
            tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
            tileSize: 256,
            attribution: '© OpenStreetMap'
          }
        },
        layers: [
          { id: 'osm-layer', type: 'raster', source: 'osm-tiles', minzoom: 0, maxzoom: 19 }
        ]
      },
      center: [118.0, -2.5], // Center of Indonesia
      zoom: 5
    });

    const m = map.current;

    m.on('load', () => {
      renderGeoLayer();
    });

    // --- Event Listener: Klik Fitur ---
    const interactiveLayers = ['lyr-fill', 'lyr-point'];

    m.on('click', interactiveLayers, (e) => {
      if (!e.features || e.features.length === 0) return;

      const feature = e.features[0];
      const props = feature.properties || {};
      
      if (popupRef.current) popupRef.current.remove();

      // Buat Baris Atribut untuk Popup
      const rowsHTML = Object.entries(props)
        .filter(([k]) => !['geom', 'st_asgeojson', 'id_gid'].includes(k.toLowerCase()))
        .map(([key, val]) => `
          <div style="display: flex; justify-content: space-between; gap: 12px; padding: 5px 0; border-bottom: 1px solid #1e293b;">
            <span style="color: #94a3b8; font-size: 10px; font-weight: 800; text-transform: uppercase;">${key}</span>
            <span style="color: #f8fafc; font-size: 10px; font-weight: 500;">${val ?? '-'}</span>
          </div>
        `).join('');

      const popupHTML = `
        <div style="padding: 10px; background: #0f172a; color: white; border-radius: 8px;">
          <h4 style="margin: 0 0 8px 0; color: #10b981; font-size: 11px; border-bottom: 1px solid #10b981;">DATA DETAIL</h4>
          ${rowsHTML}
        </div>
      `;

      popupRef.current = new maplibregl.Popup({ maxWidth: '300px' })
        .setLngLat(e.lngLat)
        .setHTML(popupHTML)
        .addTo(m);

      if (onFeatureClick) onFeatureClick([props]);
    });

    // Efek Hover Cursor
    m.on('mouseenter', interactiveLayers, () => { m.getCanvas().style.cursor = 'pointer'; });
    m.on('mouseleave', interactiveLayers, () => { m.getCanvas().style.cursor = ''; });

    return () => {
      if (map.current) map.current.remove();
    };
  }, [activeLayer, activeSchema]); // Update listener jika layer/schema berubah

  /**
   * Effect untuk update layer tanpa re-initialize map
   */
  useEffect(() => {
    if (map.current && map.current.isStyleLoaded()) {
      renderGeoLayer();
    }
  }, [activeLayer, activeSchema, renderGeoLayer]);

  return (
    <div className="w-full h-full relative bg-slate-900 rounded-2xl overflow-hidden shadow-2xl border border-slate-800">
      <div ref={mapContainer} className="absolute inset-0" />

      {isRendering && (
        <div className="absolute inset-0 bg-slate-950/30 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="flex flex-col items-center gap-2">
            <div className="w-10 h-10 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
            <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Fetching Tiles...</span>
          </div>
        </div>
      )}

      {/* Custom Popup Styling */}
      <style>{`
        .maplibregl-popup-content {
          background: #0f172a !important;
          color: #f8fafc !important;
          border: 1px solid #334155 !important;
          border-radius: 12px !important;
          padding: 5px !important;
          box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.5) !important;
        }
        .maplibregl-popup-tip { border-top-color: #0f172a !important; }
      `}</style>
    </div>
  );
};

export default MapContainer;
