import React, { useEffect, useRef, useState, useCallback } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { API_KEY } from '../services/api';

interface MapProps {
  activeLayer: string; // Nama tabel (Misal: "KWS_BALI")
  activeSchema: string; // Nama schema (Misal: "analisis_3857")
  onFeatureClick?: (data: any[] | null) => void;
}

const MapContainer: React.FC<MapProps> = ({ activeLayer, activeSchema, onFeatureClick }) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<maplibregl.Map | null>(null);
  const popupRef = useRef<maplibregl.Popup | null>(null);
  const [isRendering, setIsRendering] = useState(false);

  const renderGeoLayer = useCallback(async () => {
    if (!map.current || !activeLayer) return;

    setIsRendering(true);
    const m = map.current;

    const lName = activeLayer; 
    const sName = activeSchema.toLowerCase(); 
    const sourceId = `src-${lName}`;

    // --- Cleanup layer/source sebelumnya ---
    const layersToRemove = ['lyr-fill', 'lyr-outline', 'lyr-point'];
    layersToRemove.forEach(layerId => {
      if (m.getLayer(layerId)) m.removeLayer(layerId);
    });
    if (m.getSource(sourceId)) m.removeSource(sourceId);
    if (popupRef.current) popupRef.current.remove();

    // --- Add Source ---
    m.addSource(sourceId, {
      type: 'vector',
      tiles: [`${window.location.origin}/datagis/api/v1/mvt/{z}/{x}/{y}?layer=${lName}&schema=${sName}&api_key=${API_KEY}`],
      promoteId: 'ID_GID' // Pastikan kolom ID ini unik di database Anda
    });

    // 1. LAYER POLYGON (FILL)
    m.addLayer({
      id: 'lyr-fill',
      type: 'fill',
      source: sourceId,
      'source-layer': lName,
      paint: {
        'fill-color': '#10b981',
        'fill-opacity': ['case', ['boolean', ['feature-state', 'selected'], false], 0.7, 0.3]
      },
      filter: ['any', ['==', ['geometry-type'], 'Polygon'], ['==', ['geometry-type'], 'MultiPolygon']]
    });

    // 2. LAYER POINT (CIRCLE) - Solusi untuk data titik
    m.addLayer({
      id: 'lyr-point',
      type: 'circle',
      source: sourceId,
      'source-layer': lName,
      paint: {
        'circle-radius': ['case', ['boolean', ['feature-state', 'selected'], false], 8, 5],
        'circle-color': '#10b981',
        'circle-stroke-width': 2,
        'circle-stroke-color': ['case', ['boolean', ['feature-state', 'selected'], false], '#fbbf24', '#ffffff'],
        'circle-opacity': 0.8
      },
      filter: ['any', ['==', ['geometry-type'], 'Point'], ['==', ['geometry-type'], 'MultiPoint']]
    });

    // 3. LAYER LINE (OUTLINE)
    m.addLayer({
      id: 'lyr-outline',
      type: 'line',
      source: sourceId,
      'source-layer': lName,
      paint: {
        'line-color': ['case', ['boolean', ['feature-state', 'selected'], false], '#fbbf24', '#ffffff'],
        'line-width': ['case', ['boolean', ['feature-state', 'selected'], false], 2.5, 0.5]
      }
    });

    // --- Auto Zoom to Bounds ---
    try {
      const res = await fetch(`${window.location.origin}/datagis/api/v1/layers/bounds?layer=${lName}&schema=${sName}&api_key=${API_KEY}`);
      const bounds = await res.json();
      if (bounds && Array.isArray(bounds)) {
        m.fitBounds(bounds as any, { padding: 40, duration: 1500 });
      }
    } catch (e) {
      console.warn("Bounds failed to fetch");
    }

    setIsRendering(false);
  }, [activeLayer, activeSchema]);

  useEffect(() => {
    if (!mapContainer.current) return;

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: {
        version: 8,
        sources: {
          'osm-tiles': {
            type: 'raster',
            tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
            tileSize: 256,
            attribution: '© OpenStreetMap'
          }
        },
        layers: [
          { id: 'osm-layer', type: 'raster', source: 'osm-tiles', minzoom: 0, maxzoom: 19 }
        ]
      },
      center: [106.8456, -6.2088],
      zoom: 10
    });

    const m = map.current;

    m.on('load', () => {
      renderGeoLayer();
    });

    // --- Handler Klik untuk semua Layer (Fill & Point) ---
    const activeInteractiveLayers = ['lyr-fill', 'lyr-point'];

    m.on('click', activeInteractiveLayers, (e) => {
      if (!e.features || e.features.length === 0) return;

      const feature = e.features[0];
      const props = feature.properties || {};

      if (popupRef.current) popupRef.current.remove();

      // Filter atribut untuk tampilan popup
      const filteredEntries = Object.entries(props).filter(([key]) => {
        const k = key.toLowerCase();
        return !k.includes('geom') && !k.includes('st_asgeojson') && !['layer', 'id'].includes(k);
      });

      const rowsHTML = filteredEntries.map(([key, val]) => {
        const displayVal = typeof val === 'number' && !Number.isInteger(val)
          ? val.toLocaleString('id-ID', { maximumFractionDigits: 2 })
          : (val !== null ? String(val) : '-');

        return `
          <div style="display: flex; justify-content: space-between; gap: 15px; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.05);">
            <span style="color: #64748b; font-size: 9px; font-weight: bold; text-transform: uppercase;">${key.replace(/_/g, ' ')}</span>
            <span style="color: #f1f5f9; font-size: 10px; font-weight: 500; text-align: right;">${displayVal}</span>
          </div>
        `;
      }).join('');

      const popupHTML = `
        <div style="padding: 12px; min-width: 280px; max-height: 300px; overflow-y: auto; background: #0f172a; color: #fff; border-radius: 12px;">
          <div style="position: sticky; top: 0; background: #0f172a; padding-bottom: 8px; border-bottom: 1px solid #10b981; margin-bottom: 8px;">
             <div style="font-size: 9px; font-weight: 900; color: #10b981; text-transform: uppercase; letter-spacing: 1px;">Feature Detail</div>
          </div>
          <div style="display: flex; flex-direction: column;">${rowsHTML}</div>
        </div>
      `;

      popupRef.current = new maplibregl.Popup({ closeButton: true, maxWidth: '320px', className: 'custom-geo-popup' })
        .setLngLat(e.lngLat)
        .setHTML(popupHTML)
        .addTo(m);

      if (onFeatureClick) onFeatureClick([props]);

      // --- Feature State Management (Highliting) ---
      const featureId = props.ID_GID || props.id_gid || props.GID || feature.id;
      if (featureId) {
        // Karena feature-state terikat pada source, kita set untuk source yang aktif
        m.setFeatureState(
          { source: `src-${activeLayer}`, sourceLayer: activeLayer, id: featureId },
          { selected: true }
        );
      }
    });

    // Cursor interaction
    m.on('mouseenter', activeInteractiveLayers, () => { m.getCanvas().style.cursor = 'pointer'; });
    m.on('mouseleave', activeInteractiveLayers, () => { m.getCanvas().style.cursor = ''; });

    return () => {
      if (map.current) map.current.remove();
    };
  }, [activeLayer]); // Re-run effect jika activeLayer berubah untuk memperbarui listener

  // Effect untuk mendengarkan perubahan layer/schema
  useEffect(() => {
    if (map.current && map.current.isStyleLoaded()) {
      renderGeoLayer();
    }
  }, [activeLayer, activeSchema, renderGeoLayer]);

  return (
    <div className="w-full h-full relative min-h-[500px] bg-slate-900 rounded-xl overflow-hidden shadow-2xl border border-slate-800">
      <div ref={mapContainer} className="absolute inset-0 w-full h-full" />

      {isRendering && (
        <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center z-10">
          <div className="flex flex-col items-center gap-3">
            <div className="w-8 h-8 border-2 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
            <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest animate-pulse">Processing GeoData...</span>
          </div>
        </div>
      )}

      <style>{`
        .custom-geo-popup .maplibregl-popup-content {
          background: #0f172a !important;
          border: 1px solid rgba(16, 185, 129, 0.4) !important;
          border-radius: 16px !important;
          padding: 0 !important;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7) !important;
        }
        .custom-geo-popup .maplibregl-popup-tip { border-top-color: #0f172a !important; }
        .custom-geo-popup .maplibregl-popup-close-button { color: #ef4444; font-size: 16px; padding: 5px 10px; outline: none; }
      `}</style>
    </div>
  );
};

export default MapContainer;
