import React, { useEffect, useRef, useState, useCallback } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { ENDPOINTS, fetchApi } from '../services/api';

interface MapProps {
  activeLayer: string;   // Nama tabel (Misal: "PBPH_2024")
  activeSchema: string;  // Nama schema (Misal: "datagis")
  onFeatureClick?: (data: any[] | null) => void;
}

const MapContainer: React.FC<MapProps> = ({ activeLayer, activeSchema, onFeatureClick }) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<maplibregl.Map | null>(null);
  const popupRef = useRef<maplibregl.Popup | null>(null);
  const [isRendering, setIsRendering] = useState(false);

  /**
   * Fungsi Render Layer MVT Spasial
   */
  const renderGeoLayer = useCallback(async () => {
    if (!map.current || !activeLayer || !activeSchema) return;

    setIsRendering(true);
    const m = map.current;
    const lName = activeLayer.toUpperCase();
    const sName = activeSchema.toLowerCase();
    const sourceId = `src-${lName}-${sName}`;

    // --- 1. CLEANUP ---
    const layersToRemove = ['lyr-fill', 'lyr-outline', 'lyr-point'];
    layersToRemove.forEach(id => { if (m.getLayer(id)) m.removeLayer(id); });
    
    const existingSources = m.getStyle().sources;
    Object.keys(existingSources).forEach(id => {
      if (id.startsWith('src-')) m.removeSource(id);
    });
    if (popupRef.current) popupRef.current.remove();

    // --- 2. TAMBAH SOURCE ---
    m.addSource(sourceId, {
      type: 'vector',
      tiles: [ENDPOINTS.MVT_TILES(lName, sName)],
      promoteId: 'id_gid' // ID unik untuk interaksi
    });

    // --- 3. TAMBAH LAYERS (Styling) ---
    // Fill (Area)
    m.addLayer({
      id: 'lyr-fill',
      type: 'fill',
      source: sourceId,
      'source-layer': lName,
      paint: {
        'fill-color': '#10b981',
        'fill-opacity': 0.3
      },
      filter: ['any', ['==', ['geometry-type'], 'Polygon'], ['==', ['geometry-type'], 'MultiPolygon']]
    });

    // Outline
    m.addLayer({
      id: 'lyr-outline',
      type: 'line',
      source: sourceId,
      'source-layer': lName,
      paint: {
        'line-color': '#ffffff',
        'line-width': 0.5
      }
    });

    // Point
    m.addLayer({
      id: 'lyr-point',
      type: 'circle',
      source: sourceId,
      'source-layer': lName,
      paint: {
        'circle-radius': 6,
        'circle-color': '#10b981',
        'circle-stroke-width': 2,
        'circle-stroke-color': '#ffffff'
      },
      filter: ['any', ['==', ['geometry-type'], 'Point'], ['==', ['geometry-type'], 'MultiPoint']]
    });

    // --- 4. AUTO ZOOM KE LAYER ---
    try {
      const data = await fetchApi<{ bounds: string }>(ENDPOINTS.GET_BOUNDS(lName, sName));
      if (data?.bounds) {
        const coords = data.bounds.match(/[-+]?\d*\.?\d+/g)?.map(Number);
        if (coords && coords.length === 4) {
          m.fitBounds(
            [[coords[0], coords[1]], [coords[2], coords[3]]],
            { padding: 60, duration: 1500, essential: true }
          );
        }
      }
    } catch (err) {
      console.warn("FitBounds failed:", err);
    }

    setIsRendering(false);
  }, [activeLayer, activeSchema]);

  /**
   * Inisialisasi Peta Pertama Kali
   */
  useEffect(() => {
    if (!mapContainer.current) return;

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: {
        version: 8,
        sources: {
          'osm': {
            type: 'raster',
            tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
            tileSize: 256,
            attribution: '© OpenStreetMap'
          }
        },
        layers: [{ id: 'osm-layer', type: 'raster', source: 'osm' }]
      },
      center: [118.0, -2.5],
      zoom: 5
    });

    const m = map.current;

    m.on('click', ['lyr-fill', 'lyr-point'], (e) => {
      if (!e.features || e.features.length === 0) return;
      
      const feature = e.features[0];
      const props = feature.properties || {};

      // Popup Styling
      const html = `
        <div style="padding: 10px; font-family: sans-serif;">
          <h4 style="margin:0; color:#10b981;">DATA INFO</h4>
          <hr style="border:0; border-top:1px solid #eee; margin: 8px 0;">
          ${Object.entries(props).slice(0, 5).map(([k,v]) => 
            `<div style="font-size:11px;"><b>${k}:</b> ${v}</div>`
          ).join('')}
        </div>
      `;

      popupRef.current = new maplibregl.Popup()
        .setLngLat(e.lngLat)
        .setHTML(html)
        .addTo(m);

      if (onFeatureClick) onFeatureClick([props]);
    });

    return () => { if (map.current) map.current.remove(); };
  }, []);

  // Update layer saat props berubah
  useEffect(() => {
    if (map.current?.isStyleLoaded()) renderGeoLayer();
  }, [activeLayer, activeSchema, renderGeoLayer]);

  return (
    <div className="w-full h-full relative border border-slate-800 rounded-xl overflow-hidden">
      <div ref={mapContainer} className="absolute inset-0" />
      
      {isRendering && (
        <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-10">
          <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-emerald-500" />
        </div>
      )}
    </div>
  );
};

export default MapContainer;
