import axios from 'axios';

// Diarahkan ke Gateway (IP 130) yang akan meneruskan ke Backend
const API_BASE_URL = "/api/v1"; 

export const fetchKups = async (limit = 100, offset = 0) => {
    try {
        const response = await axios.get(`${API_BASE_URL}/layers/datagis/KUPS`, {
            params: { api_key: 'pgis-pass-2026', limit, offset }
        });
        return response.data;
    } catch (error) {
        console.error("Gagal mengambil data:", error);
        throw error;
    }
};
