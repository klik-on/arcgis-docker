import axios from 'axios';

const API_BASE_URL = "/api/v1";

export const fetchKups = async (limit = 15000, offset = 0) => {
    try {
        const response = await axios.get(`${API_BASE_URL}/IGT`, {
            params: {
                layer: 'KUPS',
                api_key: 'pgis-pass-2026',
                limit,
                offset
            },
            timeout: 60000 // Timeout 1 menit untuk stream data besar
        });
        return response.data;
    } catch (error) {
        console.error("Kesalahan API:", error);
        throw error;
    }
};
