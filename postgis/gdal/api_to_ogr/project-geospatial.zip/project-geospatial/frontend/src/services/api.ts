/**
 * src/services/api.ts
 * Dioptimalkan untuk Gateway (webgis.menlhk.go.id)
 */

// Menggunakan origin dinamis agar otomatis mendukung IP Lokal maupun Domain Publik
export const API_URL = `${window.location.origin}/datagis`;

// API Key sesuai konfigurasi backend 2026
export const API_KEY = 'pgis-pass-2026';

export interface LayerTreeResponse {
  status: string;
  repository: { [schema: string]: string[] };
}

/**
 * Header standar untuk setiap request API
 */
export const getHeaders = (): HeadersInit => ({
  'X-API-KEY': API_KEY,
  'Content-Type': 'application/json',
});

/**
 * Wrapper Fetch API dengan penanganan error yang lebih aman
 * Mencegah aplikasi crash jika server mengirimkan respons non-JSON (seperti error Nginx)
 */
export const fetchApi = async <T>(endpoint: string, options: RequestInit = {}): Promise<T> => {
  const separator = endpoint.includes('?') ? '&' : '?';
  const url = `${API_URL}${endpoint}${separator}api_key=${API_KEY}`;

  try {
    const response = await fetch(url, {
      ...options,
      headers: { ...getHeaders(), ...options.headers },
    });

    // 1. Cek jika server tidak merespons dengan JSON (misal: dilempar halaman error HTML oleh Nginx)
    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      console.warn(`⚠️ Respons dari [${endpoint}] bukan JSON. Mengembalikan data kosong.`);
      // Mengembalikan fallback agar .map() atau fungsi lain tidak error
      return { status: "error", repository: {} } as any;
    }

    // 2. Jika No Content (204)
    if (response.status === 204) return [] as any;

    // 3. Jika Error HTTP (404, 500, dll)
    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}));
      throw new Error(errorBody.detail || `HTTP Error: ${response.status}`);
    }

    // 4. Berhasil
    return await response.json() as T;

  } catch (error) {
    console.error(`🔴 API Error [${endpoint}]:`, error);
    
    // Fallback strategis agar aplikasi tetap bisa render UI dasar meskipun API mati
    if (endpoint.includes('tree')) {
      return { status: "error", repository: {} } as any;
    }
    
    throw error;
  }
};

/**
 * Daftar Endpoint API
 */
export const ENDPOINTS = {
  // Tree layers untuk sidebar
  LAYERS_TREE: '/api/v1/layers/tree',

  // Ambil data atribut tabel
  GET_ATTRIBUTES: (layer: string, schema: string, limit: number = 100) =>
    `/api/v1/IGT?layer=${layer.toUpperCase()}&schema=${schema.toLowerCase()}&limit=${limit}`,

  // Endpoint untuk MVT Tiles (digunakan langsung oleh MapLibre)
  MVT_TILES: (layer: string, schema: string) =>
    `${API_URL}/api/v1/mvt/{z}/{x}/{y}?layer=${layer.toUpperCase()}&schema=${schema.toLowerCase()}&api_key=${API_KEY}`,
    
  // Endpoint untuk mengambil jangkauan peta (bounds)
  GET_BOUNDS: (layer: string, schema: string) =>
    `/api/v1/layers/bounds?layer=${layer.toUpperCase()}&schema=${schema.toLowerCase()}`
};
