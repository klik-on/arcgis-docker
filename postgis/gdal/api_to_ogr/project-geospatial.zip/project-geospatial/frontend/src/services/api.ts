/**
 * src/services/api.ts
 */

export const API_URL = `${window.location.origin}/datagis`;
export const API_KEY = 'pgis-pass-2026';

export interface LayerTreeResponse {
  status: string;
  repository: { [schema: string]: string[] };
}

export const getHeaders = (): HeadersInit => ({
  'X-API-KEY': API_KEY,
  'Content-Type': 'application/json',
});

/**
 * Wrapper Fetch API untuk menangani Base URL dan Auth secara otomatis
 */
export const fetchApi = async <T>(endpoint: string, options: RequestInit = {}): Promise<T> => {
  const separator = endpoint.includes('?') ? '&' : '?';
  const url = `${API_URL}${endpoint}${separator}api_key=${API_KEY}`;

  try {
    const response = await fetch(url, {
      ...options,
      headers: { ...getHeaders(), ...options.headers },
    });

    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      throw new Error(`Respons bukan JSON dari ${endpoint}`);
    }

    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}));
      throw new Error(errorBody.detail || `HTTP Error: ${response.status}`);
    }

    return await response.json() as T;
  } catch (error) {
    console.error(`🔴 API Error [${endpoint}]:`, error);
    throw error;
  }
};

export const ENDPOINTS = {
  // Metadata & Tree
  LAYERS_TREE: '/api/v1/layers/tree/mvt',
  
  // Ambil atribut (untuk DataTable)
  GET_ATTRIBUTES: (layer: string, schema: string, limit: number = 100) =>
    `/api/v1/IGT?layer=${layer.toUpperCase()}&schema=${schema.toLowerCase()}&limit=${limit}`,

  // MVT Tiles untuk MapLibre
  MVT_TILES: (layer: string, schema: string) =>
    `${API_URL}/api/v1/mvt/{z}/{x}/{y}?layer=${layer.toUpperCase()}&schema=${schema.toLowerCase()}&api_key=${API_KEY}`,

  // Ambil luasan layer untuk auto-zoom
  GET_BOUNDS: (layer: string, schema: string) =>
    `/api/v1/layers/bounds?layer=${layer.toUpperCase()}&schema=${schema.toLowerCase()}`,
    
  // Monitoring (Health & Logs)
  HEALTH: '/health',
  LOGS: '/logs'
};
