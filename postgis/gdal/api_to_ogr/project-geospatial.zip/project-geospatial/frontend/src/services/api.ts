/**
 * src/services/api.ts
 * Dioptimalkan untuk Gateway (webgis.planologi.kehutanan.go.id / datagis)
 */

export const API_URL = `${window.location.origin}/datagis`;
export const API_KEY = 'pgis-pass-2026';

export interface LayerTreeResponse {
  status: string;
  repository: { [schema: string]: string[] };
}

export const getHeaders = (): HeadersInit => ({
  'X-API-KEY': API_KEY,
  'Content-Type': 'application/json',
});

/**
 * Wrapper Fetch API: Otomatis menangani Base URL, Header, dan API Key
 */
export const fetchApi = async <T>(endpoint: string, options: RequestInit = {}): Promise<T> => {
  const separator = endpoint.includes('?') ? '&' : '?';
  const url = `${API_URL}${endpoint}${separator}api_key=${API_KEY}`;

  try {
    const response = await fetch(url, {
      ...options,
      headers: { ...getHeaders(), ...options.headers },
    });

    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      console.warn(`⚠️ Respons dari [${endpoint}] bukan JSON.`);
      return { status: "error", repository: {} } as any;
    }

    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}));
      throw new Error(errorBody.detail || `HTTP Error: ${response.status}`);
    }

    return await response.json() as T;
  } catch (error) {
    console.error(`🔴 API Error [${endpoint}]:`, error);
    throw error;
  }
};

export const ENDPOINTS = {
  LAYERS_TREE: '/api/v1/layers/tree/mvt',
  GET_ATTRIBUTES: (layer: string, schema: string, limit: number = 100) =>
    `/api/v1/IGT?layer=${layer.toUpperCase()}&schema=${schema.toLowerCase()}&limit=${limit}`,
  
  // MVT menggunakan URL mentah karena MapLibre menangani fetch-nya sendiri
  MVT_TILES: (layer: string, schema: string) =>
    `${API_URL}/api/v1/mvt/{z}/{x}/{y}?layer=${layer.toUpperCase()}&schema=${schema.toLowerCase()}&api_key=${API_KEY}`,
    
  GET_BOUNDS: (layer: string, schema: string) =>
    `/api/v1/layers/bounds?layer=${layer.toUpperCase()}&schema=${schema.toLowerCase()}`
};
