import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'

/**
 * Fungsi untuk menghilangkan Splash Screen
 * Dipanggil setelah React berhasil melakukan mount ke DOM
 */
const hideLoader = () => {
  const loader = document.getElementById('initial-loader');
  if (loader) {
    // Memberikan efek fade out sebelum dihilangkan
    loader.style.opacity = '0';
    setTimeout(() => {
      loader.style.display = 'none';
    }, 500);
  }
};

// Inisialisasi Root
const root = ReactDOM.createRoot(document.getElementById('root')!);

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// EKSEKUSI: Hilangkan loader
// Jika aplikasi Anda melakukan fetch data di tingkat paling atas (Top-level await),
// loader ini akan tetap tampil sampai fetch tersebut selesai.
hideLoader();
