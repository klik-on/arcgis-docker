/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Menambahkan warna custom jika diperlukan
        slate: {
          950: '#020617',
        }
      }
    },
  },
  plugins: [],
}
