#!/bin/bash

# =================================================================
# 🚀 GEOSPATIAL DEPLOYMENT SCRIPT (V3 - PYTHON 3.13 STACK)
# =================================================================
# Author: Gemini Assistant / User Project
# Tahun: 2026
# =================================================================

# Mulai hitung waktu
START_TIME=$SECONDS
set -e # Berhenti jika ada error

# --- FUNGSI HELPER: LOGGING ---
log() {
    echo -e "\e[1;34m[$(date '+%Y-%m-%d %H:%M:%S')]\e[0m $1"
}

log "🚀 Memulai Deployment Sistem Geospasial..."

# 2. CLEANUP: Hentikan Layanan Lama
log "🔄 Menghentikan container lama dan membersihkan orphans..."
docker compose down --remove-orphans

# 3. BUILD STRATEGY: Sequential & Optimized
# Catatan: Karena geo-worker menggunakan image yang sama dengan api-backend,
# kita cukup build api-backend satu kali.
log "🏗️  [1/2] Membangun API Backend & Worker (Shared Image)..."
docker compose build --pull --no-cache api-backend

log "🏗️  [2/2] Membangun DBGIS (PostGIS 3.6+)..."
# DBGIS butuh build ulang jika ada perubahan di folder ./dbgis
docker compose build --no-cache dbgis

# 4. RUN STACK
log "🚢 Menjalankan seluruh stack layanan..."
docker compose up -d

# 5. POST-DEPLOY VERIFICATION (Fail Fast)
log "🔍 Melakukan verifikasi runtime..."
sleep 5 # Beri waktu container untuk init

ACTUAL_VER=$(docker exec geo-api python3 -V) || echo "❌ Gagal akses container!"
log "Sistem melaporkan: $ACTUAL_VER"

# 6. INTEGRASI SSL & RCLONE (NextCloud)
SSL_SCRIPT="./backend/scripts/utils/update_nc_ssl.sh"
if [ -f "$SSL_SCRIPT" ]; then
    log "🔒 Menjalankan pembaruan SSL & Konfigurasi Rclone..."
    bash "$SSL_SCRIPT"
else
    log "⚠️  Peringatan: Skrip $SSL_SCRIPT tidak ditemukan, melewati tahap SSL."
fi

# 7. CLEANUP IMAGE
log "🧹 Membersihkan image lama yang tidak terpakai (dangling)..."
docker image prune -f

# 8. FINAL HEALTH CHECK
log "🩺 Menjalankan pemeriksaan kesehatan GIS..."
if docker exec geo-api python3 /app/scripts/utils/health_check_gis.py; then
    log "✅ Health Check: PASSED"
else
    log "❌ Health Check: FAILED! Periksa logs segera."
fi

# 3. Ambil UID dari container secara dinamis
# Karena kita menggunakan non-root user (appuser UID:999), 
# kita pastikan folder data di host bisa ditulisi.
log "🔐 Verifikasi izin akses folder ./data..."
if [ ! -d "./data" ]; then
    mkdir -p ./data
fi

echo "Menyelaraskan izin folder data..."
CONTAINER_UID=$(docker exec geo-worker id -u appuser 2>/dev/null || echo "999")

# 4. Terapkan izin
sudo chown -R $CONTAINER_UID:$CONTAINER_UID data
sudo chmod -R 775 data

echo "✅ Selesai! Folder data siap digunakan oleh UID $CONTAINER_UID."

# --- KALKULASI WAKTU SELESAI ---
END_TIME=$SECONDS
DURATION=$((END_TIME - START_TIME))

HRS=$((DURATION / 3600))
MIN=$(( (DURATION % 3600) / 60 ))
SEC=$((DURATION % 60))

echo "------------------------------------------------"
log "✅ DEPLOYMENT SELESAI"
echo "⏱️  Total Waktu Proses: ${HRS} jam ${MIN} menit ${SEC} detik"
echo "------------------------------------------------"
docker compose ps
