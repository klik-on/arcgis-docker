#!/bin/bash

# Nama file output
OUTPUT_FILE="geospatial_stack_$(date +%Y%m%d).tar.gz"

echo "🔍 Mencari image kustom untuk proyek..."

# Mencari semua image yang memiliki prefix 'project-geospatial'
IMAGES=$(docker images --format "{{.Repository}}:{{.Tag}}" | grep "project-geospatial")

if [ -z "$IMAGES" ]; then
    echo "❌ Tidak ditemukan image dengan prefix 'project-geospatial'."
    exit 1
fi

echo "📦 Image yang akan diekspor:"
echo "$IMAGES"
echo "----------------------------------------------------"

# Proses Export dan Kompresi
echo "🚀 Memulai ekspor dan kompresi (ini mungkin memakan waktu)..."
docker save $IMAGES | gzip > $OUTPUT_FILE

if [ $? -eq 0 ]; then
    SIZE=$(du -sh $OUTPUT_FILE | cut -f1)
    echo "✅ Berhasil!"
    echo "📍 File: $(pwd)/$OUTPUT_FILE"
    echo "📊 Ukuran total: $SIZE"
    echo "----------------------------------------------------"
    echo "💡 Cara pindahkan ke server baru:"
    echo "   scp $OUTPUT_FILE user@ip-server-baru:/path/to/destination"
else
    echo "❌ Gagal mengekspor image."
fi

# Untuk restore
echo "Ekstrak dan masukkan ke Docker"
echo "zcat geospatial_stack_2026xxxx.tar.gz | docker load "
