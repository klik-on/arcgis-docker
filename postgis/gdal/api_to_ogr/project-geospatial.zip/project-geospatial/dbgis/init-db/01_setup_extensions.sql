-- 1. Skema Extensions
CREATE SCHEMA IF NOT EXISTS extensions;
CREATE EXTENSION IF NOT EXISTS postgis SCHEMA extensions;

-- 2. Setup Roles (Gunakan NOLOGIN agar tidak bisa dipakai login langsung, hanya untuk permission)
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'authenticated') THEN
        CREATE ROLE authenticated WITH NOLOGIN;
    END IF;
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'anon') THEN
        CREATE ROLE anon WITH NOLOGIN;
    END IF;
END $$;

-- 3. IZIN AKSES (Idempotent - bisa dijalankan berkali-kali tanpa error)
GRANT USAGE ON SCHEMA extensions TO authenticated, anon;
GRANT USAGE ON SCHEMA public TO authenticated, anon;

-- Izinkan eksekusi fungsi di skema extensions (PostGIS functions)
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA extensions TO authenticated, anon;

-- Setup Default Privileges agar tabel baru otomatis bisa diakses role ini
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO anon;

-- 4. Set Search Path (Agar psql/restore tidak bingung mencari fungsi PostGIS)
ALTER DATABASE gisdb SET search_path TO "$user", public, extensions, datagis, analisis, rekap;
