-- Extensions
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;
CREATE EXTENSION IF NOT EXISTS fuzzystrmatch; -- Berguna untuk pencarian nama wilayah

-- Schemas (Sesuai .env Anda)
CREATE SCHEMA IF NOT EXISTS datagis;   -- Tempat data mentah
CREATE SCHEMA IF NOT EXISTS analisis;  -- Output dari gpd_CLIP.py
CREATE SCHEMA IF NOT EXISTS rekap;     -- Output summary/rekapitulasi
CREATE SCHEMA IF NOT EXISTS kamusdata; -- Tempat master table

-- Permissions (Opsional, pastikan user punya akses)
-- GRANT ALL PRIVILEGES ON SCHEMA datagis TO current_user;

-- Tambahkan ini di akhir 01_setup_extensions.sql
DO $$ 
BEGIN
    IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'postgis') THEN
        ALTER EXTENSION postgis UPDATE;
    END IF;
END $$;
