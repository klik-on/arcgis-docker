-- =================================================================
-- 🛰️ GEOSPATIAL DATABASE INITIALIZATION (POSTGIS 3.6+)
-- =================================================================

-- 1. Setup Skema & Extensions
-- Kita pisahkan extension ke skema khusus agar tidak mengotori skema data
CREATE SCHEMA IF NOT EXISTS extensions;
COMMENT ON SCHEMA extensions IS 'Skema khusus untuk PostGIS dan Extension lainnya';

-- Aktifkan PostGIS Core
CREATE EXTENSION IF NOT EXISTS postgis SCHEMA extensions;

-- Aktifkan PostGIS Raster (Penting untuk analisis data Satelit/DEM)
CREATE EXTENSION IF NOT EXISTS postgis_raster SCHEMA extensions;

-- Aktifkan PostGIS Topology
CREATE EXTENSION IF NOT EXISTS postgis_topology SCHEMA extensions;

-- Aktifkan pg_trgm (Sangat berguna untuk pencarian teks/nama wilayah yang mirip)
CREATE EXTENSION IF NOT EXISTS pg_trgm SCHEMA extensions;

-- 2. Setup Skema Data (Sesuai .env DB_SCHEMA=datagis)
CREATE SCHEMA IF NOT EXISTS datagis;
CREATE SCHEMA IF NOT EXISTS analisis;
CREATE SCHEMA IF NOT EXISTS rekap;

-- 3. Setup Roles (Idempotent)
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'authenticated') THEN
        CREATE ROLE authenticated WITH NOLOGIN;
    END IF;
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'anon') THEN
        CREATE ROLE anon WITH NOLOGIN;
    END IF;
END $$;

-- 4. Manajemen Izin Akses (Permissions)
-- Izinkan penggunaan skema
GRANT USAGE ON SCHEMA extensions, public, datagis, analisis, rekap TO authenticated, anon;

-- Izinkan eksekusi fungsi geospasial (ST_Transform, ST_Buffer, dll)
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA extensions TO authenticated, anon;

-- Setup Default Privileges untuk Tabel Baru
-- Authenticated: Full DML (Data Manipulation)
ALTER DEFAULT PRIVILEGES IN SCHEMA datagis, analisis, rekap 
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO authenticated;
-- Anon: Read Only (Untuk Dashboard/Frontend umum)
ALTER DEFAULT PRIVILEGES IN SCHEMA datagis, analisis, rekap 
    GRANT SELECT ON TABLES TO anon;

-- 5. Konfigurasi Search Path (Sangat Penting)
-- Urutan: User -> Skema Data -> Public -> Extensions
-- Ini memastikan query 'SELECT * FROM wilayah' mencari di datagis dulu, 
-- dan fungsi 'ST_Area' ditemukan di extensions.
ALTER DATABASE gisdb SET search_path TO "$user", datagis, public, extensions, analisis, rekap;

-- Tambahkan metadata versi pada log database
DO $$
BEGIN
    RAISE NOTICE 'PostGIS version: %', PostGIS_Full_Version();
END $$;
