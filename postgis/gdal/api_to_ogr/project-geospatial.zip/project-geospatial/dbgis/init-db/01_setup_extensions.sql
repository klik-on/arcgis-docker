CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;
-- Jika Anda butuh ArcGIS ST_Geometry terdaftar sebagai library:
-- LOAD 'st_geometry';
