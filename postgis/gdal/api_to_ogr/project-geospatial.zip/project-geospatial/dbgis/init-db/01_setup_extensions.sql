-- 1. Buat skema untuk ekstensi (penting untuk PostGIS)
CREATE SCHEMA IF NOT EXISTS extensions;

-- 2. Instal PostGIS ke dalam skema extensions
CREATE EXTENSION IF NOT EXISTS postgis SCHEMA extensions;

-- 3. Setup Roles yang sering muncul di dump file
DO $$ 
BEGIN 
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'authenticated') THEN 
        CREATE ROLE authenticated; 
    END IF; 
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'anon') THEN 
        CREATE ROLE anon; 
    END IF; 
END $$;

-- 4. Set Search Path agar semua skema dikenali secara otomatis
-- Tambahkan skema lain yang Anda gunakan (analisis, datagis, rekap)
ALTER DATABASE gisdb SET search_path TO "$user", public, extensions, datagis, analisis, rekap;
