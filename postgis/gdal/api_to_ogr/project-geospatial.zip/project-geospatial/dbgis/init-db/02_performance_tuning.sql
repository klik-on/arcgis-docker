-- Optimalisasi Memori & Disk I/O
ALTER SYSTEM SET max_wal_size = '8GB';
ALTER SYSTEM SET min_wal_size = '2GB';
ALTER SYSTEM SET maintenance_work_mem = '2GB'; -- Ruang untuk indexing data 18GB
ALTER SYSTEM SET work_mem = '64MB';
ALTER SYSTEM SET checkpoint_timeout = '15min';

-- Optimalisasi Parallel Workers (Memanfaatkan 4 CPU limit Anda)
ALTER SYSTEM SET max_parallel_workers_per_gather = 4;
ALTER SYSTEM SET max_parallel_maintenance_workers = 2;

-- SSD Optimization (Asumsi menggunakan storage cepat)
ALTER SYSTEM SET random_page_cost = 1.1;
ALTER SYSTEM SET effective_cache_size = '12GB'; -- 75% dari RAM 16GB
