-- Ganti konfigurasi memori untuk mengoptimalkan penggunaan RAM 16GB
-- Berdasarkan aturan umum: shared_buffers = 25% dari total RAM

-- Memori utama untuk caching data
ALTER SYSTEM SET shared_buffers = '4GB';

-- Estimasi memori sistem operasi untuk caching (75% dari total RAM)
ALTER SYSTEM SET effective_cache_size = '12GB';

-- Memori untuk operasi sortir dan join kompleks (per user session)
ALTER SYSTEM SET work_mem = '64MB';

-- Memori untuk operasi maintenance seperti CREATE INDEX (GIST Spasial)
ALTER SYSTEM SET maintenance_work_mem = '1GB';

-- Optimasi penulisan log transaksi (WAL)
ALTER SYSTEM SET wal_buffers = '16MB';
ALTER SYSTEM SET min_wal_size = '1GB';
ALTER SYSTEM SET max_wal_size = '4GB';

-- Optimasi paralelisme (Memanfaatkan 4 vCPU)
ALTER SYSTEM SET max_worker_processes = 4;
ALTER SYSTEM SET max_parallel_workers_per_gather = 2;
ALTER SYSTEM SET max_parallel_workers = 4;

-- Memaksa perubahan dibaca saat restart
-- Catatan: Perintah ALTER SYSTEM memerlukan restart container untuk berlaku sepenuhnya.
