-- =================================================================
-- 🚀 POSTGRESQL & POSTGIS PERFORMANCE TUNING (OPTIMIZED 2026)
-- Target: 4 CPU Core | 16GB RAM | SSD Storage
-- docker exec -it dbgis psql -U dbgis -d gisdb -f /docker-entrypoint-initdb.d/02_performance_tuning.sql
-- # KEMUDIAN RESTART
-- docker compose restart dbgis
-- =================================================================

-- 1. Manajemen Memori (75% dari 16GB RAM)
ALTER SYSTEM SET shared_buffers = '4GB';       -- 25% dari total RAM
ALTER SYSTEM SET effective_cache_size = '12GB'; -- 75% dari total RAM
ALTER SYSTEM SET work_mem = '64MB';             -- Cukup besar untuk sort spasial rumit
ALTER SYSTEM SET maintenance_work_mem = '2GB';  -- Mempercepat CREATE INDEX GIST

-- 2. Optimalisasi Disk I/O & SSD
-- Karena Anda menggunakan SSD, random access hampir sama cepatnya dengan sequential
ALTER SYSTEM SET random_page_cost = 1.1;
ALTER SYSTEM SET effective_io_concurrency = 200; -- Sangat disarankan untuk SSD

-- 3. Write Ahead Log (WAL) & Checkpoints
-- Mengurangi frekuensi penulisan ke disk saat import data masif (PBPH/KUPS)
ALTER SYSTEM SET max_wal_size = '8GB';
ALTER SYSTEM SET min_wal_size = '2GB';
ALTER SYSTEM SET checkpoint_timeout = '15min';
ALTER SYSTEM SET checkpoint_completion_target = 0.9; -- Menghaluskan beban I/O

-- 4. Parallel Query (Memaksimalkan 4 vCPU Anda)
-- PostGIS 3.x mendukung parallel scan untuk fungsi ST_Intersects dll.
ALTER SYSTEM SET max_worker_processes = 8;
ALTER SYSTEM SET max_parallel_workers = 4;
ALTER SYSTEM SET max_parallel_workers_per_gather = 2; -- Idealnya setengah dari vCPU per query
ALTER SYSTEM SET max_parallel_maintenance_workers = 2;

-- 5. Planner Statistics (Kritikal untuk Geometri)
-- Meningkatkan akurasi estimasi jumlah baris dalam poligon kompleks
ALTER SYSTEM SET default_statistics_target = 500;

-- 6. JIT (Just-In-Time Compilation)
-- Matikan JIT jika sering terjadi overhead pada query spasial kecil/menengah
-- (Opsional, aktifkan jika query analisis Anda berjalan sangat lama > 10 detik)
-- ALTER SYSTEM SET jit = off;

-- 7. Logging & Monitoring
ALTER SYSTEM SET log_min_duration_statement = '500ms'; -- Log query yang lambat
ALTER SYSTEM SET log_checkpoints = on;

-- CATATAN: Perubahan ALTER SYSTEM memerlukan RESTART kontainer untuk berlaku sepenuhnya.
