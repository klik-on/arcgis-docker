#!/bin/bash

# === 1. Konfigurasi ===
CONTAINER_NAME="db-pgis"
DB_USER="dbgis"
DB_NAME="gisdb"
PG_PASS="password00" 

# Daftar skema yang ingin di-backup secara terpisah
SCHEMAS=("kamusdata" "rekap" "analisis" "datagis")

BACKUP_DIR="/home/dbgis/project-geospatial/dbgis/backup"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p "$BACKUP_DIR"

echo "🚀 Memulai Backup Terpisah untuk ${#SCHEMAS[@]} skema..."
echo "------------------------------------------------"

# === 2. Looping Backup per Skema ===
for SCHEMA in "${SCHEMAS[@]}"; do
    FILENAME="${BACKUP_DIR}/backup_db_${DB_NAME}_sch_${SCHEMA}_${TIMESTAMP}.dump"
    
    echo "📦 Backup Skema: [$SCHEMA] -> $(basename "$FILENAME")"

    docker exec -e PGPASSWORD="$PG_PASS" $CONTAINER_NAME pg_dump \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        -n "$SCHEMA" \
        -Fc > "$FILENAME"

    # Validasi per file
    if [ $? -eq 0 ] && [ -s "$FILENAME" ]; then
        echo "   ✅ Berhasil ($(du -sh "$FILENAME" | cut -f1))"
    else
        echo "   ❌ GAGAL: Terjadi kesalahan pada skema $SCHEMA"
        [ -f "$FILENAME" ] && rm "$FILENAME"
    fi
done

# === 3. Cleanup (Rotasi 7 Hari) ===
echo "------------------------------------------------"
echo "🧹 Membersihkan file lama (> 7 hari)..."
find "$BACKUP_DIR" -name "backup_db_${DB_NAME}_sch_*.dump" -mtime +7 -exec rm {} \;
echo "✅ Semua proses selesai!"
