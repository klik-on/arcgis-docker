#!/bin/bash

# === 1. Konfigurasi ===
CONTAINER_NAME="db-pgis"
DB_USER="dbgis"
DB_NAME="gisdb"

# Menggunakan Array untuk Skema
SCHEMAS=("analisis" "rekap" "datagis" "kodefikasi")

BACKUP_DIR="/home/dbgis/project-geospatial/dbgis/backup"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
FILENAME="${BACKUP_DIR}/backup_multi_schema_${TIMESTAMP}.dump"

mkdir -p "$BACKUP_DIR"

# === 2. Membangun Argumen Skema secara Dinamis ===
# Ini akan menghasilkan string: -n datagis -n analisis -n kodefikasi
SCHEMA_ARGS=()
for s in "${SCHEMAS[@]}"; do
    SCHEMA_ARGS+=("-n" "$s")
done

echo "==> Memulai backup skema: ${SCHEMAS[*]} dari container $CONTAINER_NAME..."

# === 3. Eksekusi pg_dump via Docker ===
# Menggunakan "${SCHEMA_ARGS[@]}" untuk memasukkan semua skema dari array
docker exec -e PGPASSWORD='password00' $CONTAINER_NAME pg_dump -U $DB_USER \
    "${SCHEMA_ARGS[@]}" \
    -Fc $DB_NAME > "$FILENAME"

# === 4. Validasi Hasil ===
if [ ${PIPESTATUS[0]} -eq 0 ]; then
    echo "------------------------------------------------"
    echo "SUCCESS: Backup array skema berhasil!"
    echo "File: $FILENAME"
    echo "Ukuran: $(du -sh "$FILENAME" | cut -f1)"
    echo "------------------------------------------------"
else
    echo "❌ ERROR: Terjadi kesalahan saat backup container!"
    [ -f "$FILENAME" ] && rm "$FILENAME"
    exit 1
fi
