#!/bin/bash

# =================================================================
# SCRIPT POST-RESTORE CLEANUP & OPTIMIZATION
# Deskripsi: Mengembalikan settingan produksi & Update statistik
# =================================================================

echo "--- Memulai Normalisasi Database Pasca Restore ---"

# 1. Mengembalikan Parameter Operasional (Mode Aman & Stabil)
echo "[1/3] Mengembalikan parameter produksi..."
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET autovacuum = 'on';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET synchronous_commit = 'on';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET full_page_writes = 'on';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET checkpoint_timeout = '5min';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER DATABASE gisdb SET search_path TO datagis, analisis, extensions, public;"

# Terapkan perubahan
docker exec -i db-pgis psql -U dbgis -d gisdb -c "SELECT pg_reload_conf();"

# 2. Re-indexing & Cleaning (Opsional tapi disarankan)
echo "[2/3] Menjalankan VACUUM ANALYZE (Ini penting untuk performa query)..."
# Analyze akan memperbarui statistik tabel agar Query Planner bekerja optimal
docker exec -i db-pgis psql -U dbgis -d gisdb -c "VACUUM ANALYZE;"

# 3. Verifikasi Jumlah Tabel
echo "[3/3] Ringkasan Database Saat Ini:"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "
SELECT 
    schemaname, 
    count(*) as total_tabel 
FROM pg_tables 
WHERE schemaname IN ('datagis', 'analisis') 
GROUP BY schemaname;"

echo "--------------------------------------------------------"
echo " STATUS: DATABASE KEMBALI KE MODE NORMAL "
echo "--------------------------------------------------------"
