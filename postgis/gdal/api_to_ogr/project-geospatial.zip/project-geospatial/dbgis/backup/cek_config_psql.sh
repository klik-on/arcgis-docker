#!/bin/bash
# -------------------------------------------------------------------
# Script: config_psql_final.sh
# Deskripsi: Optimasi PostgreSQL untuk Mode Produksi Spasial
# -------------------------------------------------------------------

CONTAINER="db-pgis"
DB_USER="dbgis"
DB_NAME="gisdb"


# Fungsi untuk mengambil nilai verifikasi
get_val() {
    docker exec "$CONTAINER" psql -U "$DB_USER" -d "$DB_NAME" -t -A -c "$1" 2>/dev/null
}

echo ""
echo "==================== VERIFIKASI OPTIMASI FINAL ===================="
printf "%-35s | %s\n" "PARAMETER" "NILAI BARU"
echo "-------------------------------------------------------------------"
printf "%-35s | %s\n" "shared_buffers (RAM)" "$(get_val "SHOW shared_buffers;")"
printf "%-35s | %s\n" "effective_cache_size" "$(get_val "SHOW effective_cache_size;")"
printf "%-35s | %s\n" "work_mem (Query Join)" "$(get_val "SHOW work_mem;")"
printf "%-35s | %s\n" "maintenance_work_mem" "$(get_val "SHOW maintenance_work_mem;")"
printf "%-35s | %s\n" "max_parallel_workers" "$(get_val "SHOW max_parallel_workers_per_gather;")"
printf "%-35s | %s\n" "temp_buffers" "$(get_val "SHOW temp_buffers;")"
printf "%-35s | %s\n" "max_connections" "$(get_val "SHOW max_connections;")"
echo "==================================================================="
echo ""

echo "==> Selesai! Database siap digunakan dalam mode performa tinggi."
