#!/bin/bash

# Konfigurasi
DB_USER="dbgis"
export PGPASSWORD="password00"
DB_HOST="172.16.2.122"
DB_PORT="5432"
DB_NAME="gisdb"
SCHEMA1="datagis"
SCHEMA2="analisis"
SCHEMA3="kodefikasi"

# Nama file yang mencakup ketiga skema
FILENAME="backup_${SCHEMA1}_${SCHEMA2}_${SCHEMA3}_$(date +%Y%m%d_%H%M%S).dump"

echo "==> Memulai backup skema: $SCHEMA1, $SCHEMA2, dan $SCHEMA3..."

# Perintah pg_dump dengan flag -n untuk masing-masing skema
pg_dump -h $DB_HOST -p $DB_PORT -U $DB_USER \
        -n $SCHEMA1 \
        -n $SCHEMA2 \
        -n $SCHEMA3 \
        -Fc $DB_NAME > $FILENAME

if [ $? -eq 0 ]; then
  echo "------------------------------------------------"
  echo "SUCCESS: Backup berhasil dibuat!"
  echo "File: $FILENAME"
  echo "Ukuran: $(du -sh $FILENAME | cut -f1)"
  echo "------------------------------------------------"
else
  echo "ERROR: Terjadi kesalahan saat proses backup!"
  # Menghapus file backup yang gagal/setengah jadi jika ada
  [ -f "$FILENAME" ] && rm "$FILENAME"
fi

# Bersihkan password dari environment
unset PGPASSWORD
