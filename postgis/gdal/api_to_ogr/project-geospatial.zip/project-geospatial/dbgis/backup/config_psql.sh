#!/bin/bash
# -------------------------------------------------------------------
# Script: config_psql_final.sh (Optimasi 16GB RAM)
# -------------------------------------------------------------------

CONTAINER="db-pgis"
DB_USER="dbgis"
DB_NAME="gisdb"

echo "==> [1/4] Mendeteksi lokasi konfigurasi..."
CONF=$(docker exec "$CONTAINER" psql -U "$DB_USER" -d "$DB_NAME" -t -A -c "SHOW config_file;")
CONF_BAK="${CONF}.bak"

if [ -z "$CONF" ]; then
    echo "Error: File konfigurasi tidak ditemukan."
    exit 1
fi

echo "==> [2/4] Membuat backup konfigurasi..."
docker exec "$CONTAINER" cp "$CONF" "$CONF_BAK"

echo "==> [3/4] Menerapkan optimasi (Sesuai Docker Limit 16GB)..."
# Nilai ini dihitung berdasarkan Best Practice PostgreSQL untuk 16GB RAM
docker exec "$CONTAINER" sed -i "s/^#*shared_buffers.*/shared_buffers = 4GB/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*effective_cache_size.*/effective_cache_size = 12GB/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*work_mem.*/work_mem = 64MB/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*maintenance_work_mem.*/maintenance_work_mem = 1GB/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*max_parallel_workers_per_gather.*/max_parallel_workers_per_gather = 4/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*temp_buffers.*/temp_buffers = 128MB/" "$CONF"
docker exec "$CONTAINER" sed -i "s/^#*max_connections.*/max_connections = 300/" "$CONF"
# Optimasi Index Spasial
docker exec "$CONTAINER" sed -i "s/^#*random_page_cost.*/random_page_cost = 1.1/" "$CONF"

echo "==> [4/4] Restarting container..."
docker restart "$CONTAINER"

echo "Menunggu PostgreSQL siap..."
sleep 10

get_val() {
    docker exec "$CONTAINER" psql -U "$DB_USER" -d "$DB_NAME" -t -A -c "$1" 2>/dev/null
}

echo ""
echo "==================== VERIFIKASI OPTIMASI (16GB RAM) ===================="
printf "%-35s | %s\n" "PARAMETER" "NILAI BARU"
echo "-------------------------------------------------------------------"
printf "%-35s | %s\n" "shared_buffers (25% RAM)" "$(get_val "SHOW shared_buffers;")"
printf "%-35s | %s\n" "effective_cache_size" "$(get_val "SHOW effective_cache_size;")"
printf "%-35s | %s\n" "maintenance_work_mem" "$(get_val "SHOW maintenance_work_mem;")"
printf "%-35s | %s\n" "max_connections" "$(get_val "SHOW max_connections;")"
printf "%-35s | %s\n" "random_page_cost" "$(get_val "SHOW random_page_cost;")"
echo "==================================================================="
