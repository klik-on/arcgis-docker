#!/bin/bash

# === 1. Konfigurasi ===
CONTAINER_NAME="db-pgis"
DB_USER="dbgis"
DB_NAME="gisdb"
PG_PASS="password00"
BACKUP_DIR="/home/dbgis/project-geospatial/dbgis/backup"

# === 2. Validasi Input ===
SCHEMA_NAME=$1

if [ -z "$SCHEMA_NAME" ]; then
    echo "❌ ERROR: Nama skema tidak didefinisikan!"
    echo "Usage: $0 [nama_skema]"
    echo "Contoh: $0 datagis"
    exit 1
fi

# === 3. Mencari File Backup Terbaru ===
LATEST_BACKUP=$(ls -t ${BACKUP_DIR}/backup_db_${DB_NAME}_sch_${SCHEMA_NAME}_*.dump 2>/dev/null | head -n 1)

if [ -z "$LATEST_BACKUP" ]; then
    echo "❌ ERROR: File backup untuk skema [$SCHEMA_NAME] tidak ditemukan di $BACKUP_DIR"
    exit 1
fi

echo "------------------------------------------------"
echo "🔄 MEMULAI RESTORASI TEROPTIMASI (SYNC READY)"
echo "------------------------------------------------"
echo "🌍 Database : $DB_NAME"
echo "🏗️  Skema    : $SCHEMA_NAME"
echo "📂 File     : $(basename "$LATEST_BACKUP")"
echo "------------------------------------------------"

read -p "⚠️  Lanjut restorasi ke skema [$SCHEMA_NAME]? (y/n): " confirm
if [[ $confirm != [yY] ]]; then
    echo "❌ Restorasi dibatalkan."
    exit 1
fi

# === 3.5 Persiapan Skema (Krusial untuk Environment Baru) ===
echo "🛠️  Menyiapkan skema [$SCHEMA_NAME] di database..."
docker exec -e PGPASSWORD="$PG_PASS" $CONTAINER_NAME psql -U "$DB_USER" -d "$DB_NAME" \
    -c "CREATE SCHEMA IF NOT EXISTS $SCHEMA_NAME; ALTER SCHEMA $SCHEMA_NAME OWNER TO $DB_USER;"

# === 4. Eksekusi pg_restore ===
# -n: Memastikan hanya skema target yang diproses
# --no-owner: Mencegah error jika user di file dump berbeda dengan container
echo "🚀 Mentransfer data dan membangun indeks spasial..."



docker exec -e PGPASSWORD="$PG_PASS" -i $CONTAINER_NAME pg_restore \
    -U "$DB_USER" \
    -d "$DB_NAME" \
    --clean \
    --if-exists \
    --no-owner \
    -n "$SCHEMA_NAME" \
    -v < "$LATEST_BACKUP"

# === 5. Validasi Hasil ===
if [ $? -eq 0 ]; then
    echo "------------------------------------------------"
    echo "✅ SUCCESS: Skema [$SCHEMA_NAME] berhasil direstorasi!"
    echo "🛠️  Library DB: $(docker exec $CONTAINER_NAME psql -U $DB_USER -d $DB_NAME -t -c 'SELECT postgis_lib_version();')"
    echo "------------------------------------------------"
else
    echo "❌ ERROR: Terjadi kegagalan saat proses pg_restore."
    exit 1
fi
