#!/bin/bash

# === 1. Konfigurasi ===
CONTAINER_NAME="db-pgis"
DB_USER="dbgis"
DB_NAME="gisdb"
PG_PASS="password00"
BACKUP_DIR="/home/dbgis/project-geospatial/dbgis/backup"

# === 2. Validasi Input ===
SCHEMA_NAME=$1

if [ -z "$SCHEMA_NAME" ]; then
    echo "❌ ERROR: Nama skema tidak didefinisikan!"
    echo "Usage: $0 [nama_skema]"
    echo "Contoh: $0 rekap"
    exit 1
fi

# === 3. Mencari File Backup Terbaru untuk Skema Tersebut ===
LATEST_BACKUP=$(ls -t ${BACKUP_DIR}/backup_db_${DB_NAME}_sch_${SCHEMA_NAME}_*.dump 2>/dev/null | head -n 1)

if [ -z "$LATEST_BACKUP" ]; then
    echo "❌ ERROR: File backup untuk skema [$SCHEMA_NAME] tidak ditemukan di $BACKUP_DIR"
    echo "Pastikan pola nama file adalah: backup_db_${DB_NAME}_sch_${SCHEMA_NAME}_*.dump"
    exit 1
fi

echo "------------------------------------------------"
echo "🔄 MEMULAI RESTORASI UNIVERSAL"
echo "------------------------------------------------"
echo "🌍 Database : $DB_NAME"
echo "🏗️  Skema    : $SCHEMA_NAME"
echo "📂 File     : $(basename "$LATEST_BACKUP")"
echo "------------------------------------------------"

# Konfirmasi pengguna (Opsional, hapus 4 baris di bawah jika ingin fully automated)
read -p "⚠️  Hati-hati! Data lama di skema [$SCHEMA_NAME] akan ditimpa. Lanjut? (y/n): " confirm
if [[ $confirm != [yY] ]]; then
    echo "❌ Restorasi dibatalkan."
    exit 1
fi

# === 4. Eksekusi pg_restore ===
# --clean: Menghapus objek (tabel/view) sebelum restore
# --if-exists: Mencegah error jika objek belum ada
# -v: Menampilkan proses secara detail
docker exec -e PGPASSWORD="$PG_PASS" -i $CONTAINER_NAME pg_restore \
    -U "$DB_USER" \
    -d "$DB_NAME" \
    --clean \
    --if-exists \
    --no-owner \
    -v < "$LATEST_BACKUP"

# === 5. Validasi Hasil ===
if [ $? -eq 0 ]; then
    echo "------------------------------------------------"
    echo "✅ SUCCESS: Skema [$SCHEMA_NAME] berhasil direstorasi!"
    echo "------------------------------------------------"
else
    echo "❌ ERROR: Terjadi kegagalan saat proses pg_restore."
    exit 1
fi
