#!/bin/bash

# Konfigurasi Akses
DB_USER="dbgis"
export PGPASSWORD="password00"
DB_HOST="172.16.2.122"
DB_PORT="5432"
NEW_DB="gisdb"

# Daftar skema yang biasanya terlibat (untuk opsi pembersihan otomatis)
SCHEMAS=("analisis" "rekap" "kodefikasi")
echo "Daftar file .dump di folder ini:"
ls *.dump 2>/dev/null || echo "Tidak ada file .dump ditemukan."
echo "--------------------------------"
read -p "Masukkan nama file backup yang ingin di-migrate: " FILE_INPUT

if [ -f "$FILE_INPUT" ]; then
    echo "--- PERSIAPAN ---"
    # Opsi: Membersihkan skema sebelum restore untuk memastikan tidak ada konflik
    read -p "Hapus skema lama (${SCHEMAS[*]}) sebelum restore? (y/n): " CONFIRM
    if [[ "$CONFIRM" == "y" ]]; then
        echo "Menghapus skema lama..."
        for s in "${SCHEMAS[@]}"; do
            psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $NEW_DB -c "DROP SCHEMA IF EXISTS $s CASCADE;"
        done
    fi

    echo "--------------------------------"
    echo "🚀 Memulai restorasi ke $NEW_DB..."

    # Menambahkan flag --if-exists agar pg_restore tidak error jika mencoba drop sesuatu yang tidak ada
    # Tetap menggunakan -j 8 karena ini eksekusi binary langsung (bukan piping stdin)
    pg_restore -h $DB_HOST -p $DB_PORT -U $DB_USER \
               -d $NEW_DB \
               -j 8 \
               --clean \
               --if-exists \
               --no-owner \
               --no-privileges \
               --verbose \
               "$FILE_INPUT"

    if [ $? -eq 0 ]; then
        echo "-------------------------------------------"
        echo "✅ Migrasi ke $NEW_DB Berhasil!"
        echo "💡 Tips: Jalankan ./post_restore_cleanup.sh untuk refresh views/indeks."
    else
        echo "-------------------------------------------"
        echo "⚠️ Restorasi selesai, namun ada beberapa peringatan."
        echo "Hal ini normal jika ada dependensi extension (seperti postgis) yang sudah ada."
    fi
else
    echo "❌ Error: File $FILE_INPUT tidak ditemukan!"
fi

unset PGPASSWORD
