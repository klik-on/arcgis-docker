package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.net.*;
import java.util.*;

@WebServlet("/*")
public class datagisProxyServlet extends HttpServlet {

    private static String DATAGIS_REST_BASE;
    private static String API_KEY;

    @Override
    public void init() throws ServletException {
        super.init();
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            Properties prop = new Properties();
            if (input == null) throw new FileNotFoundException("config.properties not found");
            prop.load(input);

            // 1. Ambil API Key dari config (Pastikan sama dengan di FastAPI)
            API_KEY = prop.getProperty("datagis.api.key");

            // 2. Logika Deteksi IP Backend
            String forcedIp = prop.getProperty("datagis.backend.ip");
            if (forcedIp != null && !forcedIp.isEmpty()) {
                DATAGIS_REST_BASE = "http://" + forcedIp + ":8000";
            } else {
                String autoIp = InetAddress.getLocalHost().getHostAddress();
                DATAGIS_REST_BASE = autoIp.equals("127.0.0.1") ? "http://localhost:8000" : "http://" + autoIp + ":8000";
            }

            System.out.println("LOG: Proxy Secure Target set to -> " + DATAGIS_REST_BASE);

        } catch (IOException e) {
            throw new ServletException("Failed to load config", e);
        }
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pathInfo = request.getPathInfo();
        // Redirect ke /docs jika root diakses
        String targetPath = (pathInfo == null || pathInfo.equals("/")) ? "/docs" : pathInfo;

        // --- VALIDASI KEAMANAN (MODIFIKASI UTAMA) ---
        
        // Izinkan akses ke /docs dan / (Dashboard) tanpa API Key agar tim bisa cek status
        // Namun kunci semua akses ke /api/v1/...
        if (targetPath.contains("/api/")) {
            String clientApiKey = request.getHeader("X-API-KEY");
            
            if (clientApiKey == null || !clientApiKey.equals(API_KEY)) {
                System.out.println("SECURITY ALERT: Unauthorized access attempt to " + targetPath);
                response.setContentType("application/json");
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                response.getWriter().write("{\"detail\":\"Akses Ditolak: API Key tidak valid melalui Proxy LHK.\"}");
                return;
            }
        }

        // 1. CORS Headers
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, X-API-KEY");

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        // 2. Build URL Target
        String queryString = request.getQueryString();
        String targetUrlStr = DATAGIS_REST_BASE + targetPath + (queryString != null ? "?" + queryString : "");

        HttpURLConnection connection = null;
        try {
            URL url = new URL(targetUrlStr);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(request.getMethod());

            // 3. Forward Headers dari Client ke FastAPI
            Enumeration<String> hs = request.getHeaderNames();
            while (hs.hasMoreElements()) {
                String h = hs.nextElement();
                // Jangan forward Host dan Content-Length karena dikelola oleh HttpURLConnection
                if (!h.equalsIgnoreCase("Host") && !h.equalsIgnoreCase("Content-Length")) {
                    connection.setRequestProperty(h, request.getHeader(h));
                }
            }

            // Injeksi API Key untuk otentikasi internal ke FastAPI
            connection.setRequestProperty("X-API-KEY", API_KEY);

            // 4. Forward Body (untuk POST seperti run-script)
            if (request.getContentLength() > 0 || "POST".equalsIgnoreCase(request.getMethod())) {
                connection.setDoOutput(true);
                try (InputStream in = request.getInputStream(); OutputStream out = connection.getOutputStream()) {
                    in.transferTo(out);
                }
            }

            // 5. Tangkap Response dari FastAPI
            int code = connection.getResponseCode();
            response.setStatus(code);

            String contentType = connection.getContentType();
            if (contentType != null) response.setContentType(contentType);

            String contentEncoding = connection.getContentEncoding();
            if (contentEncoding != null) {
                response.setHeader("Content-Encoding", contentEncoding);
            }

            // Forward Stream Data
            try (InputStream is = (code >= 400) ? connection.getErrorStream() : connection.getInputStream()) {
                if (is != null) {
                    if (contentType != null && contentType.contains("text/html") && contentEncoding == null) {
                        String body = new String(is.readAllBytes(), "UTF-8");
                        // Sinkronisasi path UI
                        body = body.replace("\"/openapi.json\"", "\"/datagis/openapi.json\"")
                                   .replace("'./openapi.json'", "'/datagis/openapi.json'")
                                   .replace("/static", "/datagis/static");
                        response.getWriter().write(body);
                    } else {
                        try (OutputStream os = response.getOutputStream()) {
                            is.transferTo(os);
                            os.flush();
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            if (!response.isCommitted()) {
                response.sendError(502, "Proxy Gateway Error: " + e.getMessage());
            }
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
