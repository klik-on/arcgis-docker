package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.net.*;
import java.util.*;

@WebServlet("/*")
public class datagisProxyServlet extends HttpServlet {

    private static String DATAGIS_REST_BASE;
    private static String API_KEY;

    @Override
    public void init() throws ServletException {
        super.init();
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            Properties prop = new Properties();
            if (input == null) throw new FileNotFoundException("config.properties not found");
            prop.load(input);
            
            // 1. Ambil API Key dari config
            API_KEY = prop.getProperty("datagis.api.key");

            // 2. Logika Deteksi IP Otomatis
            String forcedIp = prop.getProperty("datagis.backend.ip"); // Cek jika ada IP manual di config
            
            if (forcedIp != null && !forcedIp.isEmpty()) {
                DATAGIS_REST_BASE = "http://" + forcedIp + ":8000";
            } else {
                // Mencari IP address server ini secara dinamis
                String autoIp = InetAddress.getLocalHost().getHostAddress();
                
                // Jika terdeteksi loopback (127.0.0.1) dan bukan itu yang diinginkan, 
                // kita bisa memaksa ke IP jaringan atau tetap menggunakan localhost
                if (autoIp.equals("127.0.0.1")) {
                    DATAGIS_REST_BASE = "http://localhost:8000";
                } else {
                    DATAGIS_REST_BASE = "http://" + autoIp + ":8000";
                }
            }
            
            System.out.println("LOG: Proxy target set to -> " + DATAGIS_REST_BASE);

        } catch (IOException e) {
            throw new ServletException("Failed to load config", e);
        }
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pathInfo = request.getPathInfo();
        // Sesuai dengan root_path="/datagis" di FastAPI Anda
        String targetPath = (pathInfo == null || pathInfo.equals("/")) ? "/docs" : pathInfo;

        // 1. CORS Headers
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, X-API-TOKEN, apikey");

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        // 2. Build URL menggunakan Base yang sudah dideteksi otomatis
        String queryString = request.getQueryString();
        String targetUrlStr = DATAGIS_REST_BASE + targetPath + (queryString != null ? "?" + queryString : "");

        HttpURLConnection connection = null;
        try {
            URL url = new URL(targetUrlStr);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(request.getMethod());

            // Forward Headers
            Enumeration<String> hs = request.getHeaderNames();
            while (hs.hasMoreElements()) {
                String h = hs.nextElement();
                if (!h.equalsIgnoreCase("Host") && !h.equalsIgnoreCase("Content-Length")) {
                    connection.setRequestProperty(h, request.getHeader(h));
                }
            }
            
            // Mengirim token ke backend (FastAPI mengharap X-API-TOKEN atau apikey)
            connection.setRequestProperty("X-API-TOKEN", API_KEY);
            connection.setRequestProperty("apikey", API_KEY);

            // Forward Body (untuk POST run-script)
            if (request.getContentLength() > 0) {
                connection.setDoOutput(true);
                try (InputStream in = request.getInputStream(); OutputStream out = connection.getOutputStream()) {
                    in.transferTo(out);
                }
            }

            int code = connection.getResponseCode();
            response.setStatus(code);

            String contentType = connection.getContentType();
            if (contentType != null) response.setContentType(contentType);

            try (InputStream is = (code >= 400) ? connection.getErrorStream() : connection.getInputStream()) {
                if (is != null) {
                    if (contentType != null && contentType.contains("text/html")) {
                        String body = new String(is.readAllBytes(), "UTF-8");
                        // Sinkronisasi dengan root_path FastAPI "/datagis"
                        body = body.replace("\"/openapi.json\"", "\"/datagis/openapi.json\"")
                                   .replace("'./openapi.json'", "'/datagis/openapi.json'")
                                   .replace("/static", "/datagis/static");
                        response.getWriter().write(body);
                    } else {
                        try (OutputStream os = response.getOutputStream()) {
                            is.transferTo(os);
                        }
                    }
                }
            }
        } catch (Exception e) {
            response.sendError(502, "Proxy Error (Backend " + DATAGIS_REST_BASE + "): " + e.getMessage());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
