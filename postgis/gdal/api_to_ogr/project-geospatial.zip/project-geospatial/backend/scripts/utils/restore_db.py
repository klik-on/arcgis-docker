import os
import sys
import boto3
import subprocess
import multiprocessing

def list_available_backups(s3_client, bucket):
    """Menampilkan daftar file backup yang ada di MinIO"""
    print(f"\n🔍 Mencari file backup di bucket: {bucket}...")
    try:
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix='database_backups/')
        if 'Contents' in response:
            print(f"\n{'NO':<3} | {'NAMA FILE (Path S3)':<70} | {'UKURAN'}")
            print("-" * 90)
            backups = [obj['Key'] for obj in response['Contents']]
            for i, key in enumerate(backups, 1):
                size_mb = round(response['Contents'][i-1]['Size'] / (1024 * 1024), 2)
                print(f"{i:<3} | {key:<70} | {size_mb:>7} MB")
            return backups
        else:
            print("❌ Tidak ada file backup ditemukan.")
            return []
    except Exception as e:
        print(f"❌ Gagal mengambil list: {e}")
        return []

def run_restore():
    # --- 1. Load Konfigurasi ---
    DB_HOST = os.getenv("DB_HOST", "dbgis")
    DB_USER = os.getenv("DB_USER", "postgres")
    DB_NAME = os.getenv("DB_NAME", "gisdb")
    DB_PASS = os.getenv("DB_PASS", "password00")

    S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")
    S3_USER = os.getenv("S3_USER", "geobackup")
    S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
    S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")

    s3 = boto3.client('s3',
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS
    )

    # --- 2. Cek Argumen atau Tampilkan List ---
    s3_file_path = None
    if len(sys.argv) > 1:
        s3_file_path = sys.argv[1]
    else:
        # Jika tidak ada argumen, tampilkan list dan minta input
        backups = list_available_backups(s3, S3_BUCKET)
        if not backups:
            sys.exit(1)
        
        print("\n💡 Tips: Salin path file di atas atau masukkan nomor.")
        choice = input("\n👉 Masukkan Nomor atau Path File S3: ").strip()
        
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(backups):
                s3_file_path = backups[idx]
            else:
                print("❌ Nomor tidak valid.")
                sys.exit(1)
        else:
            s3_file_path = choice

    if not s3_file_path:
        sys.exit(1)

    # --- 3. Proses Restore ---
    local_filename = "/tmp/restore_temp.dump"
    cpu_cores = max(1, multiprocessing.cpu_count() - 1)

    try:
        print(f"\n🚀 Memulai Download: {s3_file_path}")
        s3.download_file(S3_BUCKET, s3_file_path, local_filename)

        print(f"🔄 Memulai Restore ({cpu_cores} threads) ke: {DB_NAME}...")
        
        # Opsi -j (jobs) digunakan untuk mempercepat file 18GB
        cmd = [
            "pg_restore", "-h", DB_HOST, "-U", DB_USER, "-d", DB_NAME,
            "-j", str(cpu_cores), "--clean", "--if-exists", "--no-owner", "--no-privileges ","-v", 
            local_filename
        ]

        env_vars = os.environ.copy()
        env_vars["PGPASSWORD"] = DB_PASS

        # Stream output pg_restore agar bisa dipantau
        process = subprocess.Popen(cmd, stderr=subprocess.PIPE, env=env_vars, text=True)
        for line in process.stderr:
            if "error" in line.lower():
                print(f"  [!] {line.strip()}")
            elif "processing" in line.lower():
                print(f"  [v] {line.strip()}")

        process.wait()

        if process.returncode == 0:
            print("\n✅ RESTORE BERHASIL SELESAI!")
        else:
            print(f"\n⚠️ Restore selesai dengan exit code: {process.returncode}")

    except Exception as e:
        print(f"\n❌ ERROR KRITIS: {str(e)}")
    finally:
        if os.path.exists(local_filename):
            print(f"🧹 Membersihkan file dump di /tmp...")
            os.remove(local_filename)

if __name__ == "__main__":
    run_restore()
