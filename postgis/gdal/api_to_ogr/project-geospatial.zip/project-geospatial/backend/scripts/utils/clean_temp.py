#!/usr/bin/env python3
import os
import sys
import time
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# Memuat variabel lingkungan dari file .env
load_dotenv()

def run_cleanup():
    start_time = time.time()
    
    # Konfigurasi Database
    db_url = f"postgresql+psycopg://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}"
    schema = os.getenv("SCHEMA_DATA", "datagis")
    
    # Engine standar untuk operasi DDL (Tabel & Indeks)
    engine = create_engine(db_url)

    # 1. Query untuk menghapus tabel sisa _temp
    drop_tables_query = f"""
    DO $$ 
    DECLARE r RECORD;
    BEGIN
        FOR r IN (SELECT tablename FROM pg_tables WHERE schemaname = '{schema}' AND tablename LIKE '%%_temp') LOOP
            EXECUTE 'DROP TABLE IF EXISTS {schema}.' || quote_ident(r.tablename) || ' CASCADE';
            RAISE NOTICE 'Tabel temp dihapus: %', r.tablename;
        END LOOP;
    END $$;"""

    # 2. Query untuk menghapus indeks duplikat
    drop_indexes_query = f"""
    DO $$
    DECLARE
        r_idx RECORD;
        i INTEGER;
        idx_name TEXT;
    BEGIN
        FOR r_idx IN (
            SELECT 
                array_agg(indexrelid::regclass::text ORDER BY indexrelid) AS duplicate_indexes
            FROM pg_index
            WHERE indrelid::regnamespace = '{schema}'::regnamespace
            GROUP BY indrelid, indkey, indisunique
            HAVING COUNT(*) > 1
        )
        LOOP
            FOR i IN 2..array_length(r_idx.duplicate_indexes, 1) LOOP
                idx_name := r_idx.duplicate_indexes[i];
                EXECUTE 'DROP INDEX IF EXISTS ' || idx_name;
                RAISE NOTICE 'Indeks duplikat dihapus: %', idx_name;
            END LOOP;
        END LOOP;
    END $$;"""

    try:
        # FASE 1: Pembersihan Struktur (DDL)
        with engine.begin() as conn:
            print(f"🧹 Memulai pembersihan schema: {schema}")
            conn.execute(text(drop_tables_query))
            conn.execute(text(drop_indexes_query))
        
        engine.dispose()

        # FASE 2: Optimasi Penyimpanan (VACUUM)
        # Catatan: VACUUM tidak bisa dijalankan di dalam blok transaksi (BEGIN/COMMIT)
        print("🚀 Menata ulang penyimpanan (VACUUM ANALYZE)...")
        vacuum_start = time.time()
        
        vacuum_engine = create_engine(db_url).execution_options(isolation_level="AUTOCOMMIT")
        with vacuum_engine.connect() as conn:
            conn.execute(text("VACUUM ANALYZE;"))
        
        vacuum_duration = time.time() - vacuum_start
        total_duration = time.time() - start_time

        print(f"✅ VACUUM ANALYZE selesai dalam {vacuum_duration:.2f} detik.")
        print(f"✨ Database cleanup and optimization successful! (Total: {total_duration:.2f} detik)")

    except Exception as e:
        print(f"❌ Cleanup failed: {str(e)}")
        sys.exit(1)
    finally:
        if 'vacuum_engine' in locals():
            vacuum_engine.dispose()

if __name__ == "__main__":
    run_cleanup()
