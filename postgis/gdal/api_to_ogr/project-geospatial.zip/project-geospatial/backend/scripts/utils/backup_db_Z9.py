import os
import sys
import boto3
import subprocess
import logging
from datetime import datetime

# Setup Logging agar lebih profesional
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("BackupDB")

def run_backup():
    # --- 1. Load Konfigurasi (Tanpa Hardcoded Password) ---
    DB_HOST = os.getenv("DB_HOST", "dbgis")
    DB_USER = os.getenv("DB_USER", "dbgis")
    DB_NAME = os.getenv("DB_NAME", "gisdb")
    DB_PASS = os.getenv("DB_PASS") # Sebaiknya jangan ada default pass di kode

    S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")
    S3_USER = os.getenv("S3_USER")
    S3_PASS = os.getenv("S3_PASS")
    S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")

    if not DB_PASS or not S3_PASS:
        logger.error("❌ Kredensial DB_PASS atau S3_PASS tidak ditemukan di Environment!")
        sys.exit(1)

    # Argumen skema
    target_schemas = sys.argv[1:] if len(sys.argv) > 1 else [
        os.getenv("SCHEMA_DATA", "datagis"),
        os.getenv("OUT_SCHEMA", "analisis"),
        "kamusdata"
    ]

    # --- 2. S3 Client dengan Config Optimasi ---
    from botocore.client import Config
    s3 = boto3.client('s3',
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS,
        config=Config(s3={'addressing_style': 'path'}, signature_version='s3v4')
    )

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    logger.info(f"🚀 Memulai Backup Database: {DB_NAME}")

    overall_success = True
    processed_count = 0

    for schema in target_schemas:
        if not schema: continue
        
        filename = f"backup_{DB_NAME}_{schema}_{timestamp}.dump"
        local_path = f"/tmp/{filename}"
        s3_path = f"database_backups/{schema}/{filename}"

        try:
            logger.info(f"🔹 Processing Schema: [{schema}]")

            # 3. pg_dump dengan kompresi maksimal (-Z 9)
            cmd = [
                "pg_dump", "-h", DB_HOST, "-U", DB_USER, "-d", DB_NAME, 
                "-n", schema, "-Fc", "-Z", "9"
            ]

            env_vars = os.environ.copy()
            env_vars["PGPASSWORD"] = DB_PASS

            # Eksekusi dengan capture_output agar log lebih bersih
            with open(local_path, "wb") as out_file:
                result = subprocess.run(cmd, stdout=out_file, stderr=subprocess.PIPE, env=env_vars)

            if result.returncode != 0:
                logger.error(f"❌ Error pg_dump [{schema}]: {result.stderr.decode()}")
                overall_success = False
                continue

            # 4. Upload dengan verifikasi ukuran
            filesize = os.path.getsize(local_path)
            if filesize > 0:
                logger.info(f"  📤 Uploading {filename} ({filesize / 1024 / 1024:.2f} MB) to MinIO...")
                s3.upload_file(local_path, S3_BUCKET, s3_path)
                logger.info(f"  ✅ Sukses Terunggah")
                processed_count += 1
            else:
                logger.warning(f"  ⚠️ File dump kosong untuk skema {schema}")
                overall_success = False

        except Exception as e:
            logger.error(f"  ❌ Error Sistem pada {schema}: {str(e)}")
            overall_success = False
        finally:
            if os.path.exists(local_path):
                os.remove(local_path)

    logger.info("================================================")
    if overall_success:
        logger.info(f"✅ SEMUA PROSES BERHASIL")
        sys.exit(0)
    else:
        logger.error(f"⚠️ PROSES SELESAI DENGAN BEBERAPA ERROR")
        sys.exit(1)
