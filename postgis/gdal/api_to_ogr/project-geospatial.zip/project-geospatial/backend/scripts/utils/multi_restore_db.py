import os
import sys
import boto3
import subprocess
import multiprocessing

def run_master_restore():
    # --- 1. Load Konfigurasi ---
    DB_HOST = os.getenv("DB_HOST", "dbgis")
    DB_USER = os.getenv("DB_USER", "postgres")
    DB_NAME = os.getenv("DB_NAME", "gisdb")
    DB_PASS = os.getenv("DB_PASS", "password00")

    S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")
    S3_USER = os.getenv("S3_USER", "geobackup")
    S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
    S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")

    # Ambil list file dari args
    if len(sys.argv) < 2:
        print("❌ ERROR: Tidak ada daftar file S3 dalam argumen 'args'.")
        sys.exit(1)
    
    backup_files = sys.argv[1:]
    cpu_cores = max(1, multiprocessing.cpu_count() - 1)

    s3 = boto3.client('s3',
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS
    )

    print(f"🚀 MEMULAI MASTER RESTORE - TOTAL {len(backup_files)} FILE")
    print(f"----------------------------------------------------------")

    for s3_path in backup_files:
        local_filename = f"/tmp/restore_{os.path.basename(s3_path)}"
        
        try:
            print(f"\n📦 Processing: {s3_path}")
            
            # 2. Download
            print(f"   📥 Downloading dari MinIO...")
            s3.download_file(S3_BUCKET, s3_path, local_filename)

            # 3. Restore
            print(f"   🔄 Restoring ke {DB_NAME} (Threads: {cpu_cores})...")
            cmd = [
                "pg_restore", "-h", DB_HOST, "-U", DB_USER, "-d", DB_NAME,
                "-j", str(cpu_cores), "--clean", "--if-exists", "--no-owner", "-v", 
                local_filename
            ]

            env_vars = os.environ.copy()
            env_vars["PGPASSWORD"] = DB_PASS

            # Jalankan restore
            result = subprocess.run(cmd, env=env_vars, stderr=subprocess.PIPE, text=True)

            if result.returncode == 0:
                print(f"   ✅ Sukses Merestore {os.path.basename(s3_path)}")
            else:
                # Ambil sedikit log error terakhir jika gagal
                error_msg = result.stderr[-300:] if result.stderr else "Unknown Error"
                print(f"   ⚠️ Selesai dengan peringatan/log: {error_msg}")

        except Exception as e:
            print(f"   ❌ GAGAL pada file {s3_path}: {str(e)}")
        finally:
            if os.path.exists(local_filename):
                os.remove(local_filename)

    print(f"\n----------------------------------------------------------")
    print(f"🏁 MASTER RESTORE SELESAI")

if __name__ == "__main__":
    run_master_restore()
