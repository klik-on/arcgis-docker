#!/bin/bash

# Load variabel dari .env jika dijalankan di luar docker
# source ../../.env 

echo "----------------------------------------------------------"
echo "🚀 SINKRONISASI DATA KE S3 STORAGE (MinIO)"
echo "----------------------------------------------------------"

# Menjalankan rclone dari dalam kontainer geo-api
# Karena geo-api sudah punya library rclone dan akses ke /app/data
docker exec -it geo-api rclone copy /app/data mys3:geospatial-bucket \
    --include "*.zip" \
    --s3-provider=Minio \
    --s3-endpoint=http://192.168.70.50:9000 \
    --s3-access-key-id=$S3_USER \
    --s3-secret-access-key=$S3_PASS \
    --progress

echo "----------------------------------------------------------"
echo "✅ Sinkronisasi Selesai!"
