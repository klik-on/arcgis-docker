#!/bin/bash

# =================================================================
# 🧹 LOG CLEANUP UTILITY (Maintenance Script)
# =================================================================
# Deskripsi: Menghapus file log rotasi lama yang sudah berusia
#            lebih dari X hari untuk menjaga kapasitas disk.
# =================================================================

# --- 1. KONFIGURASI ---
LOG_DIR="/app/data"
LOG_PATTERN="sync.log.*.old"
RETENTION_DAYS=7  # Simpan log lama selama 7 hari, hapus sisanya
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

echo "----------------------------------------------------------"
echo "[$TIMESTAMP] [CLEANUP] Memulai pembersihan log lama..."
echo "[$TIMESTAMP] [CLEANUP] Direktori target: $LOG_DIR"
echo "[$TIMESTAMP] [CLEANUP] Retensi: $RETENTION_DAYS hari"

# --- 2. VALIDASI DIREKTORI ---
if [ ! -d "$LOG_DIR" ]; then
    echo "[$TIMESTAMP] [CLEANUP] ❌ Error: Direktori $LOG_DIR tidak ditemukan."
    exit 1
fi

# --- 3. PROSES PENGHAPUSAN ---
# Mencari file berdasarkan pola nama dan waktu modifikasi terakhir
# -mtime +7 berarti file yang dimodifikasi lebih dari 7 hari yang lalu
FILES_TO_DELETE=$(find "$LOG_DIR" -name "$LOG_PATTERN" -type f -mtime +$RETENTION_DAYS)

if [ -z "$FILES_TO_DELETE" ]; then
    echo "[$TIMESTAMP] [CLEANUP] ✅ Tidak ada file log lama yang perlu dihapus."
else
    echo "[$TIMESTAMP] [CLEANUP] Menghapus file berikut:"
    echo "$FILES_TO_DELETE"
    
    # Eksekusi penghapusan
    find "$LOG_DIR" -name "$LOG_PATTERN" -type f -mtime +$RETENTION_DAYS -delete
    
    if [ $? -eq 0 ]; then
        echo "[$TIMESTAMP] [CLEANUP] ✅ Pembersihan berhasil selesai."
    else
        echo "[$TIMESTAMP] [CLEANUP] ⚠️ Terjadi kesalahan saat menghapus beberapa file."
    fi
fi

echo "----------------------------------------------------------"
exit 0
