import requests
import urllib3
import json

# Menonaktifkan peringatan SSL (karena penggunaan verify=False)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_URL = "https://sinergy.planologi.kehutanan.go.id/main-api/data_srtprmn"
ASA_TOKEN = "Asa-Token 0beb25bddf59.7.1716190054609"
HEADERS = {"Authorization": ASA_TOKEN}

def peek_raw_json():
    try:
        print(f"🚀 Menghubungi API: {API_URL}...")
        response = requests.get(API_URL, headers=HEADERS, verify=False, timeout=30)
        response.raise_for_status()

        # Parse string respons ke JSON Object (Dictionary)
        json_data = response.json()

        print("✅ Respons Berhasil Diterima!")
        print("=" * 60)
        
        # --- BAGIAN 1: PRETTY PRINT (JSON Rapi) ---
        # Menampilkan 5000 karakter pertama dengan indentasi 4 spasi
        pretty_output = json.dumps(json_data, indent=4)
        print("📄 PREVIEW JSON (TERFORMAT):")
        print(pretty_output[:5000]) 
        print("\n... (output dipotong agar terminal tidak penuh) ...")
        
        print("=" * 60)

        # --- BAGIAN 2: RINGKASAN DATA (EXTRACTION) ---
        # Mengambil list data utama dari struktur: data -> data
        daftar_permohonan = json_data.get('data', {}).get('data', [])
        
        if not daftar_permohonan:
            print("⚠️ Tidak ada data permohonan yang ditemukan.")
        else:
            print(f"🔍 Ditemukan {len(daftar_permohonan)} entri. Berikut ringkasannya:")
            print(f"{'ID':<6} | {'Status':<25} | {'File .zip'}")
            print("-" * 60)

            for item in daftar_permohonan:
                permohonan_id = item.get('id', 'N/A')
                status = item.get('status', 'N/A')[:23] # Potong jika terlalu panjang
                
                # Cek file zip di dalam PermohonanTitik
                titik_list = item.get('PermohonanTitik', [])
                shpl_file = "❌ Tidak Ada"
                
                for titik in titik_list:
                    if titik.get('UpldShpl'):
                        shpl_file = titik.get('UpldShpl')
                        break # Ambil yang pertama ditemukan
                
                print(f"{permohonan_id:<6} | {status:<25} | {shpl_file}")

        print("=" * 60)
        print("💡 Tips: Jika ingin mendownload file, gabungkan domain dengan path di atas.")

    except requests.exceptions.HTTPError as err:
        print(f"❌ HTTP Error: {err}")
    except json.JSONDecodeError:
        print("❌ Gagal memproses JSON. Respons mungkin bukan format JSON yang valid.")
    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")

if __name__ == "__main__":
    peek_raw_json()
