import requests
import urllib3
import json

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_URL = "https://sinergy.planologi.kehutanan.go.id/main-api/data_srtprmn"
ASA_TOKEN = "Asa-Token 0beb25bddf59.7.1716190054609"
HEADERS = {"Authorization": ASA_TOKEN}

def peek_raw_json():
    try:
        print(f"🚀 Meminta data mentah dari: {API_URL}...")
        response = requests.get(API_URL, headers=HEADERS, verify=False, timeout=30)
        response.raise_for_status()
        
        # Ambil teks mentah untuk menghindari error parsing di terminal
        raw_text = response.text
        
        print("✅ Respons Diterima!")
        print("-" * 50)
        # Cetak 2000 karakter pertama saja agar terminal tidak hang
        print(raw_text[:2000]) 
        print("-" * 50)
        print("💡 Cek teks di atas, cari kata '.zip' atau 'http'")
        
    except Exception as e:
        print(f"❌ Error Detail: {e}")

if __name__ == "__main__":
    peek_raw_json()
