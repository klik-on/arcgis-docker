#!/bin/bash
# Simpan di: ~/project-geospatial/dbgis/backup/post_restore_cleanup.sh

echo "--- [1/2] MENGEMBALIKAN SETINGAN PRODUKSI ---"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET autovacuum = 'on';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET synchronous_commit = 'on';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET full_page_writes = 'on';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET checkpoint_timeout = '5min';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER DATABASE gisdb SET search_path TO datagis, analisis, extensions, public;"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "SELECT pg_reload_conf();"

echo "--- [2/2] UPDATE STATISTIK (ANALYZE) ---"
echo "Menjalankan ANALYZE VERBOSE... (Tunggu sebentar agar query nantinya cepat)"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ANALYZE VERBOSE;"

echo "------------------------------------------------"
echo "📊 RINGKASAN TABEL:"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "
SELECT schemaname, count(*) as total_tabel FROM pg_tables 
WHERE schemaname IN ('datagis', 'analisis', 'rekap', 'kamusdata') GROUP BY schemaname;"

echo "✅ DATABASE KEMBALI KE MODE NORMAL & OPTIMAL."
