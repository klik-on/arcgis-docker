#!/bin/bash
echo "--- [1/2] RESET TOTAL DATABASE & KONFIGURASI ---"

# 1. Paksa hapus database agar bersih total
docker exec -i db-pgis psql -U dbgis -d postgres -c "DROP DATABASE IF EXISTS gisdb WITH (FORCE);"
docker exec -i db-pgis psql -U dbgis -d postgres -c "CREATE DATABASE gisdb;"

# 2. Setup PostGIS dan Search Path
echo "Konfigurasi PostGIS dan Search Path..."
docker exec -i db-pgis psql -U dbgis -d gisdb -c "CREATE SCHEMA IF NOT EXISTS extensions;"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "CREATE EXTENSION IF NOT EXISTS postgis SCHEMA extensions;"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER DATABASE gisdb SET search_path TO datagis, analisis, extensions, public;"

# 3. Setup Roles
docker exec -i db-pgis psql -U dbgis -d gisdb -c "DO \$\$ BEGIN IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'authenticated') THEN CREATE ROLE authenticated; END IF; IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'anon') THEN CREATE ROLE anon; END IF; END \$\$;"

# 4. OPTIMASI SPEED (Dipisah agar tidak error transaction block)
echo "Menerapkan Optimasi Performa Restore..."
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET max_wal_size = '8GB';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET maintenance_work_mem = '2GB';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET autovacuum = 'off';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET synchronous_commit = 'off';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET checkpoint_timeout = '15min';"
docker exec -i db-pgis psql -U dbgis -d gisdb -c "ALTER SYSTEM SET full_page_writes = 'off';"

# Reload konfigurasi agar perubahan ALTER SYSTEM aktif
docker exec -i db-pgis psql -U dbgis -d gisdb -c "SELECT pg_reload_conf();"

echo "--- SELESAI: DATABASE SIAP DENGAN PERFORMA MAKSIMAL ---"
