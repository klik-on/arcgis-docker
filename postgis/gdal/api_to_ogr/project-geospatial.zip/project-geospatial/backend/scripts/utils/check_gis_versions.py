#!/usr/bin/env python3
import os
import sys
import geopandas
import pandas as pd
import io
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# Konfigurasi Direktori Log
LOG_DIR = "/app/data/logs"
FILE_NAME = "gis_version_report.txt"

def get_gis_report():
    output = io.StringIO()
    
    # Header Report
    output.write("=" * 75 + "\n")
    output.write("           GEOSPATIAL STACK VERSION REPORT (FULL)\n")
    output.write("=" * 75 + "\n\n")

    # 1. PYTHON SIDE (GEOPANDAS & DEPENDENCIES)
    output.write("[PART 1: PYTHON ENVIRONMENT]\n")
    # Redirect geopandas.show_versions() output ke string buffer
    original_stdout = sys.stdout
    sys.stdout = output
    try:
        geopandas.show_versions()
    finally:
        sys.stdout = original_stdout
    
    output.write("\n" + "-" * 75 + "\n")

    # 2. SERVER SIDE (POSTGRESQL & POSTGIS)
    output.write("[PART 2: DATABASE & POSTGIS STACK]\n")
    load_dotenv()
    
    db_user = os.getenv('DB_USER')
    db_pass = os.getenv('DB_PASS')
    db_host = os.getenv('DB_HOST', 'dbgis')
    db_port = os.getenv('DB_PORT', '5432')
    db_name = os.getenv('DB_NAME')

    try:
        conn_str = f"postgresql+psycopg://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}"
        engine = create_engine(conn_str)

        with engine.connect() as conn:
            # Query Detail PostGIS
            res_full = conn.execute(text("SELECT postgis_full_version();")).fetchone()
            res_ver = conn.execute(text("SELECT postgis_version();")).fetchone()
            pg_ver = conn.execute(text("SELECT version();")).fetchone()

            output.write(f"🐘 PostgreSQL Version:\n   {pg_ver[0]}\n\n")
            output.write(f"🌍 PostGIS Simple Version: {res_ver[0]}\n\n")
            output.write(f"🛠️  PostGIS Full Library Info:\n")
            
            # Merapikan output full_version (split by space)
            clean_info = res_full[0].replace(' ', '\n   - ')
            output.write(f"   - {clean_info}\n")

    except Exception as e:
        output.write(f"❌ Database Connection Error: {str(e)}\n")

    output.write("\n" + "=" * 75 + "\n")
    output.write(f"REPORT GENERATED: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    output.write("=" * 75 + "\n")

    return output.getvalue()

if __name__ == "__main__":
    # Pastikan folder log tersedia
    os.makedirs(LOG_DIR, exist_ok=True)
    
    report_content = get_gis_report()
    
    # Tampilkan di layar terminal
    print(report_content)
    
    # Simpan ke file teks di LOG_DIR
    full_path = os.path.join(LOG_DIR, FILE_NAME)
    with open(full_path, "w") as f:
        f.write(report_content)
    
    print(f"✅ Laporan lengkap telah disimpan di: {full_path}")
