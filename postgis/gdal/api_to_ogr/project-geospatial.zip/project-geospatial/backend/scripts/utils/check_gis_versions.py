#!/usr/bin/env python3
import os
import sys
import io

# ===========================================================================
# BOOTSTRAP: Harus dilakukan sebelum import pyproj/fiona/gdal
# ===========================================================================
OS_PROJ_PATH = '/usr/local/share/proj'
OS_GDAL_PATH = '/usr/local/share/gdal'

# Set environment variables pada level OS
os.environ['PROJ_DATA'] = OS_PROJ_PATH
os.environ['PROJ_LIB'] = OS_PROJ_PATH
os.environ['GDAL_DATA'] = OS_GDAL_PATH

# Mencegah pyproj mencari ke internet yang sering menyebabkan warning/delay
os.environ['PROJ_NETWORK'] = 'OFF'

try:
    import pyproj
    # Paksa pyproj menggunakan direktori yang kita tentukan
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)
except ImportError:
    pass

import shapely
import geopandas
import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

def get_gis_report():
    output = io.StringIO()
    output.write("=" * 75 + "\n")
    output.write("            GEOSPATIAL STACK VERSION REPORT (ULTIMATE SYNC)\n")
    output.write("=" * 75 + "\n\n")

    output.write("[PART 0: SYSTEM PATHS & FILES]\n")
    output.write(f"PROJ_DATA Env   : {os.environ.get('PROJ_DATA')}\n")
    output.write(f"GDAL_DATA Env   : {os.environ.get('GDAL_DATA')}\n")

    # Cek fisik file proj.db
    db_path = os.path.join(OS_PROJ_PATH, 'proj.db')
    db_exists = os.path.exists(db_path)
    output.write(f"proj.db exists  : {'✅' if db_exists else '❌'} ({db_path})\n")

    # Cek aksesibilitas database PROJ via pyproj
    try:
        p_dir = pyproj.datadir.get_data_dir()
        output.write(f"pyproj Data Dir : {p_dir} ✅\n")
        # Test validasi transformasi sederhana
        test_proj = pyproj.Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
        output.write("PROJ Context    : ✅ Functional (EPSG:3857 test passed)\n")
    except Exception as e:
        output.write(f"PROJ Context    : ❌ Error: {e}\n")

    output.write(f"Shapely GEOS    : {shapely.geos_version_string} ✅\n\n")

    output.write("[PART 1: PYTHON ENVIRONMENT]\n")
    # Redirect stdout geopandas.show_versions() ke buffer kita
    old_stdout = sys.stdout
    sys.stdout = output
    geopandas.show_versions()
    sys.stdout = old_stdout

    output.write("\n" + "-" * 75 + "\n")
    output.write("[PART 2: DATABASE STACK]\n")
    load_dotenv()
    
    # Cek koneksi DB menggunakan variabel env dari .env
    try:
        db_url = f"postgresql+psycopg://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST', 'dbgis')}:{os.getenv('DB_PORT', '5432')}/{os.getenv('DB_NAME')}"
        engine = create_engine(db_url)
        with engine.connect() as conn:
            res = conn.execute(text("SELECT postgis_full_version();")).fetchone()
            # Merapikan output PostGIS agar lebih scannable
            clean_version = res[0].replace(' ', '\n    - ')
            output.write(f"🛠️ PostGIS Full Info:\n    - {clean_version}\n")
    except Exception as e:
        output.write(f"❌ DB Error: {e}\n")

    return output.getvalue()

if __name__ == "__main__":
    print(get_gis_report())
