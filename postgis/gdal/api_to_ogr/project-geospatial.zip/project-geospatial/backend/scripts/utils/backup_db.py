import os
import sys
import boto3
import subprocess
from datetime import datetime

# Akses langsung
# docker exec -it -e DB_HOST=dbgis -e S3_ENDPOINT=http://s3-storage:9000 geo-api python3 scripts/utils/backup_db.py kamusdata datagis

def run_backup():
    # --- 1. Load Konfigurasi dari Environment ---
    DB_HOST = os.getenv("DB_HOST", "dbgis")
    DB_USER = os.getenv("DB_USER", "dbgis")
    DB_NAME = os.getenv("DB_NAME", "gisdb")
    DB_PASS = os.getenv("DB_PASS", "password00")

    S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")
    S3_USER = os.getenv("S3_USER", "geobackup")
    S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
    S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")

    # Ambil skema dari argumen command line, jika kosong gunakan default dari .env/list
    if len(sys.argv) > 1:
        target_schemas = sys.argv[1:]
    else:
        target_schemas = [
            os.getenv("SCHEMA_DATA", "datagis"),
            os.getenv("OUT_SCHEMA", "analisis"),
            os.getenv("RKP_SCHEMA", "rekap"),
            "kamusdata"
        ]

    # --- 2. Inisialisasi S3 Client ---
    try:
        s3 = boto3.client('s3',
            endpoint_url=S3_ENDPOINT,
            aws_access_key_id=S3_USER,
            aws_secret_access_key=S3_PASS
        )
    except Exception as e:
        print(f"❌ Gagal koneksi ke MinIO: {e}")
        sys.exit(1)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    print(f"🚀 Memulai Backup Database: {DB_NAME} pada {timestamp}")
    print(f"🔗 Target Host: {DB_HOST}")
    print(f"📂 Skema: {', '.join(target_schemas)}")

    overall_success = True
    processed_count = 0

    for schema in target_schemas:
        if not schema: continue
        
        filename = f"backup_{DB_NAME}_{schema}_{timestamp}.dump"
        local_path = f"/tmp/{filename}"
        s3_path = f"database_backups/{schema}/{filename}"

        try:
            print(f"\n🔹 Processing Schema: [{schema}]")
            
            # 3. Eksekusi pg_dump
            cmd = ["pg_dump", "-h", DB_HOST, "-U", DB_USER, "-d", DB_NAME, "-n", schema, "-Fc"]
            
            env_vars = os.environ.copy()
            env_vars["PGPASSWORD"] = DB_PASS

            # Jalankan proses
            result = subprocess.run(cmd, stdout=open(local_path, "wb"), stderr=subprocess.PIPE, env=env_vars)

            if result.returncode != 0:
                error_output = result.stderr.decode()
                print(f"  ❌ Error pg_dump: {error_output}")
                overall_success = False
                continue

            # 4. Upload ke MinIO
            if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
                print(f"  📤 Uploading {filename} to MinIO...")
                s3.upload_file(local_path, S3_BUCKET, s3_path)
                print(f"  ✅ Sukses Terunggah")
                processed_count += 1
            else:
                print(f"  ⚠️ File dump kosong untuk skema {schema}")
                overall_success = False

        except FileNotFoundError:
            print("  ❌ CRITICAL: 'pg_dump' tidak ditemukan di sistem!")
            print("     Pastikan sudah menjalankan: apt-get install postgresql-client")
            overall_success = False
            break # Hentikan loop karena tool utama tidak ada
        except Exception as e:
            print(f"  ❌ Error Sistem pada {schema}: {str(e)}")
            overall_success = False
        finally:
            if os.path.exists(local_path):
                os.remove(local_path)

    print("\n================================================")
    if overall_success and processed_count > 0:
        print(f"✅ SEMUA PROSES SELESAI ({processed_count} skema)")
        sys.exit(0) # Beri sinyal sukses ke Task Runner
    else:
        print(f"⚠️ PROSES SELESAI DENGAN ERROR (Berhasil: {processed_count})")
        sys.exit(1) # Beri sinyal GAGAL ke Task Runner

if __name__ == "__main__":
    run_backup()
