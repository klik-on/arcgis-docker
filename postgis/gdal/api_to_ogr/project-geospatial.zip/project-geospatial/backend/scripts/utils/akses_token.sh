# Buat Token Akses Mapserviice
# Login ke Portal ==> buat username dan password
curl -k -X POST \
-d "username=api_akses" \
-d "password=APIakses2025" \
-d "client=referer" \
-d "referer=https://dbgis.planologi.kehutanan.go.id" \
-d "expiration=60" \
-d "f=json" \
"https://dbgis.planologi.kehutanan.go.id/portal/sharing/rest/generateToken"


## Akses .../MapServer/0?f=json&token=xxx

## https://dbgis.planologi.kehutanan.go.id/server/rest/services/DataSIG/PAPH_AR_250K/MapServer?f=json&token=cDhEW9blpadaREHsW_q1UWmBGZy_CcgsBKuhCATkmjjzBeHd1g1PKZ4Drr3McEGLZ0Tthigp4kSyk0tpobp65z2kPWR5W8Qox6gGoRwo7_KHrs0KCbzL1RqNj4Q-Ai61lkFcHUAB0fCWtD5PdpG2UadndWgwhN-_AdPngBQJSEJFV7zIfO2HnknJYTL6LuuCxxWpmgJIuSNmZXN4Q9jYTw..
