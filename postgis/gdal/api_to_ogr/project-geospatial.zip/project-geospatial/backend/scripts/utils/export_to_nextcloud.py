#!/usr/bin/env python3
import os
import sys
import shutil
import subprocess
from sqlalchemy import create_engine, text
import geopandas as gpd
from dotenv import load_dotenv

def export_to_nextcloud():
    # 1. Validasi Input
    if len(sys.argv) < 3:
        print("❌ Error: Argumen tidak lengkap!")
        print(f"💡 Penggunaan: {sys.argv[0]} NAMA_SKEMA NAMA_TABEL")
        sys.exit(1)

    schema = sys.argv[1]
    table = sys.argv[2]

    load_dotenv()
    db_url = os.getenv("DATABASE_URL")

    if not db_url:
        print("❌ Error: DATABASE_URL tidak ditemukan di .env")
        sys.exit(1)

    # 2. Konfigurasi Path
    data_dir = "/app/data"
    os.makedirs(data_dir, exist_ok=True)

    gdb_name = f"{table}.gdb"
    gdb_path = os.path.join(data_dir, gdb_name)
    zip_path = f"{gdb_path}.zip"

    nc_remote = os.getenv("NC_REMOTE", "nextcloud")
    nc_path = os.getenv("NC_PATH", "GIS/Export")

    try:
        # 3. Inisialisasi Database Engine
        engine = create_engine(db_url)

        # 4. Membaca data menggunakan GeoPandas
        print(f"🚀 Menghubungkan ke database...")
        with engine.connect() as conn:
            query = f'SELECT * FROM "{schema}"."{table}"'
            print(f"📡 Membaca tabel {schema}.{table}...")
            gdf = gpd.read_postgis(text(query), con=conn, geom_col='geom')

        if gdf.empty:
            print("⚠️ Tabel kosong, proses dihentikan.")
            sys.exit(0)

        # 5. Cleanup folder GDB lama jika ada
        if os.path.exists(gdb_path):
            shutil.rmtree(gdb_path)

        # 6. Export ke FileGDB menggunakan pyogrio
        print(f"📦 Mengekspor {len(gdf)} baris ke FileGDB...")
        
        # Perbaikan di sini: Melewatkan opsi langsung ke to_file
        # Jika menggunakan engine="pyogrio", opsi ini diteruskan dengan benar
        gdf.to_file(
            gdb_path,
            driver="OpenFileGDB",
            engine="pyogrio",
            layer=table,
            # Penulisan opsi yang benar untuk pyogrio engine:
            layer_options={"TARGET_ARCGIS_VERSION": "ARCGIS_PRO_3_2_OR_LATER"},
            dataset_options={"METHOD": "SKIP"}
        )

        # 7. Kompresi
        print("🗜️ Mengompres hasil...")
        subprocess.run(["zip", "-rq", f"{table}.gdb.zip", gdb_name], cwd=data_dir, check=True)

        # 8. Upload via rclone
        print(f"☁️ Mengunggah ke Nextcloud ({nc_remote})...")
        subprocess.run([
            "rclone", "copy",
            zip_path,
            f"{nc_remote}:{nc_path}",
            "--progress"
        ], check=True)

        print(f"✅ Berhasil! Tabel {table} sudah diunggah ke {nc_path}")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {str(e)}")
        sys.exit(1)

    finally:
        # 9. Cleanup
        print("🧹 Membersihkan file lokal...")
        if os.path.exists(gdb_path):
            shutil.rmtree(gdb_path)
        if os.path.exists(zip_path):
            os.remove(zip_path)

if __name__ == "__main__":
    export_to_nextcloud()
