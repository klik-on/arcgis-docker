#!/usr/bin/env python3
import os
import sys
import subprocess
from dotenv import load_dotenv

def export_to_nextcloud():
    if len(sys.argv) < 3:
        print("❌ Error: Argumen tidak lengkap! (Gunakan: SCHEMA TABLE_NAME)")
        sys.exit(1)

    schema = sys.argv[1]
    table = sys.argv[2] 

    load_dotenv()

    data_dir = "/app/data/output_gdb"
    zip_path = os.path.join(data_dir, f"{table}.gdb.zip")
    txt_path = os.path.join(data_dir, f"SUMMARY_{table}.txt")

    nc_remote = os.getenv("NC_REMOTE", "nextcloud")
    nc_path = os.getenv("NC_PATH", "GIS/Export")

    try:
        if not os.path.exists(zip_path):
            print(f"❌ File ZIP tidak ditemukan: {zip_path}")
            sys.exit(1)

        print(f"☁️ Mengunggah ke Nextcloud ({nc_remote}:{nc_path})...")

        # Upload ZIP
        subprocess.run(["rclone", "copy", zip_path, f"{nc_remote}:{nc_path}"], check=True)
        
        # Upload TXT
        if os.path.exists(txt_path):
            subprocess.run(["rclone", "copy", txt_path, f"{nc_remote}:{nc_path}"], check=True)
            print(f"✅ Berhasil mengunggah ZIP dan SUMMARY.")
        else:
            print(f"✅ Berhasil mengunggah ZIP (Summary TXT tidak ditemukan).")

    except Exception as e:
        print(f"❌ Kesalahan: {e}"); sys.exit(1)
    finally:
        # Hapus file lokal setelah diunggah
        for f in [zip_path, txt_path]:
            if os.path.exists(f): os.remove(f)

if __name__ == "__main__":
    export_to_nextcloud()
