#!/bin/bash

# Load variabel dari .env dengan cara yang lebih aman
if [ -f .env ]; then
    set -a            # Otomatis export semua variabel yang didefinisikan
    source .env
    set +a            # Matikan fitur auto-export
else
    echo "❌ Error: File .env tidak ditemukan!"
    exit 1
fi

CONTAINER_NAME="geo-worker"
CERT_SOURCE="/home/dbgis/menlhk_go_id_reissue/Chain_RootCA_Bundle.crt"

if [ ! -f "$CERT_SOURCE" ]; then
    echo "❌ Error: File sertifikat tidak ditemukan di $CERT_SOURCE"
    exit 1
fi

echo "==> [1/3] Mengunggah Sertifikat CA ke Container..."
docker cp "$CERT_SOURCE" ${CONTAINER_NAME}:/usr/local/share/ca-certificates/menlhk-ca.crt

echo "==> [2/3] Memperbarui Trust Store..."
docker exec -u root "$CONTAINER_NAME" bash -c "chmod 644 /usr/local/share/ca-certificates/menlhk-ca.crt && update-ca-certificates"

echo "==> [3/3] Konfigurasi Rclone..."
# Hapus config lama
docker exec "$CONTAINER_NAME" rclone config delete nextcloud 2>/dev/null

# Kirim variabel NC_USER dan NC_PASS ke dalam perintah docker exec
docker exec -e NC_USER="$NC_USER" -e NC_PASS="$NC_PASS" "$CONTAINER_NAME" /bin/bash -c 'rclone config create nextcloud webdav \
    url=https://dbgis.menlhk.go.id:8080/remote.php/dav/files/datagis/ \
    vendor=nextcloud \
    user="$NC_USER" \
    pass=$(rclone obscure "$NC_PASS")'

echo "==> ✅ Selesai! Mengetes koneksi ke Nextcloud..."
docker exec "$CONTAINER_NAME" rclone lsf nextcloud:
