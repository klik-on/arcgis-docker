#!/usr/bin/env python3
import os
import sys
import shutil
import subprocess
import zipfile
import warnings
from sqlalchemy import create_engine, text
import geopandas as gpd
from dotenv import load_dotenv

def import_from_nextcloud():
    # 1. Validasi Input
    if len(sys.argv) < 3:
        print("❌ Error: Argumen tidak lengkap!")
        print(f"💡 Penggunaan: {sys.argv[0]} NAMA_SKEMA NAMA_TABEL")
        sys.exit(1)

    schema = sys.argv[1]
    table = sys.argv[2]

    load_dotenv()
    db_url = os.getenv("DATABASE_URL")
    nc_remote = os.getenv("NC_REMOTE", "nextcloud")
    nc_path = os.getenv("NC_PATH", "GIS/Export")

    data_dir = "/app/data"
    os.makedirs(data_dir, exist_ok=True)
    
    zip_name = f"{table}.gdb.zip"
    zip_path = os.path.join(data_dir, zip_name)
    extract_path = os.path.join(data_dir, f"tmp_{table}")

    try:
        # 2. Download dari Nextcloud via rclone
        print(f"☁️ Menarik {zip_name} dari Nextcloud...")
        subprocess.run([
            "rclone", "copy",
            f"{nc_remote}:{nc_path}/{zip_name}",
            data_dir,
            "--quiet" # Mengurangi noise di log jika tidak perlu progress detail
        ], check=True)

        # 3. Ekstraksi ZIP
        print(f"🗜️ Mengekstrak {zip_name}...")
        if os.path.exists(extract_path):
            shutil.rmtree(extract_path)
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)

        # 4. Cari folder .gdb (Rekursif)
        found_gdb = None
        for root, dirs, files in os.walk(extract_path):
            for d in dirs:
                if d.endswith(".gdb"):
                    found_gdb = os.path.join(root, d)
                    break
        
        if not found_gdb:
            raise Exception("Folder .gdb tidak ditemukan di dalam file ZIP!")

        # 5. Baca GDB menggunakan GeoPandas
        # Perbaikan: Menghapus argumen driver="OpenFileGDB" untuk menghilangkan RuntimeWarning 
        # karena engine pyogrio sudah otomatis mendeteksinya.
        print(f"📡 Membaca FileGDB: {found_gdb}...")
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=RuntimeWarning)
            gdf = gpd.read_file(found_gdb, engine="pyogrio")

        if gdf.empty:
            print("⚠️ Data di GDB kosong, proses dihentikan.")
            sys.exit(0)

        # 6. Tulis ke PostGIS
        print(f"🚀 Menghubungkan ke database...")
        engine = create_engine(db_url)
        
        print(f"📥 Mengunggah {len(gdf)} baris ke {schema}.\"{table}\"...")
        
        # Menggunakan format yang lebih aman untuk penulisan spasial
        gdf.to_postgis(
            name=table,
            con=engine,
            schema=schema,
            if_exists='replace',
            index=False,
            chunksize=1000,
            # Memastikan SRID terdefinisi (asumsi 4326 jika tidak ada, sesuaikan jika perlu)
            # srid=4326 
        )

        # 7. Memberikan hak akses & Indexing (Penting untuk GIS)
        with engine.connect() as conn:
            # Gunakan double quotes untuk case-sensitivity yang aman
            sql_grant = text(f'GRANT SELECT ON TABLE "{schema}"."{table}" TO PUBLIC')
            conn.execute(sql_grant)
            
            # Opsional: Buat spatial index agar query GIS cepat
            # conn.execute(text(f'CREATE INDEX IF NOT EXISTS "{table}_geom_idx" ON "{schema}"."{table}" USING GIST (geometry)'))
            
            conn.commit()

        print(f"✅ Berhasil! Data diperbarui di tabel: {schema}.{table}")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {str(e)}")
        sys.exit(1)

    finally:
        # 8. Cleanup file lokal
        print("🧹 Membersihkan file sementara...")
        if os.path.exists(zip_path):
            os.remove(zip_path)
        if os.path.exists(extract_path):
            shutil.rmtree(extract_path)

if __name__ == "__main__":
    import_from_nextcloud()
