import os
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

# 1. Load Konfigurasi
load_dotenv()

DB_URL = os.getenv("DATABASE_URL")
# Standarisasi URL untuk SQLAlchemy + Psycopg 3
if DB_URL and "postgresql://" in DB_URL and "+psycopg" not in DB_URL:
    DB_URL = DB_URL.replace("postgresql://", "postgresql+psycopg://")

SCHEMA_ASAL = os.getenv("OUT_SCHEMA", "analisis")
SCHEMA_TUJUAN = os.getenv("RKP_SCHEMA", "rekap")

def proses_pindahan_tabel():
    engine = create_engine(DB_URL)
    count_success = 0
    
    try:
        with engine.begin() as conn:
            # --- LANGKAH 1: CEK & BUAT SKEMA TUJUAN ---
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA_TUJUAN}"'))
            print(f"[*] Skema '{SCHEMA_TUJUAN}' diverifikasi/dibuat.")

            # --- LANGKAH 2: CARI TABEL DENGAN PREFIX SUM_ ---
            # Menggunakan query ke information_schema untuk mendapatkan nama tabel presisi
            find_query = text("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = :schema 
                AND table_name LIKE 'SUM_%'
            """)
            result = conn.execute(find_query, {"schema": SCHEMA_ASAL})
            tables = [row[0] for row in result]

            if not tables:
                print(f"[!] Tidak ditemukan tabel ber-prefix 'SUM_' di skema '{SCHEMA_ASAL}'.")
                return

            # --- LANGKAH 3: PEMINDAHAN ---
            print(f"[*] Memulai pemindahan {len(tables)} tabel...")
            for table_name in tables:
                try:
                    # Menggunakan double quotes untuk menjaga huruf besar/kecil
                    move_sql = text(f'ALTER TABLE "{SCHEMA_ASAL}"."{table_name}" SET SCHEMA "{SCHEMA_TUJUAN}"')
                    conn.execute(move_sql)
                    print(f"    [OK] {table_name}")
                    count_success += 1
                except Exception as e_inner:
                    print(f"    [GAGAL] {table_name}: {e_inner}")

            # --- LANGKAH 4: RINGKASAN ---
            print("-" * 40)
            print(f"TOTAL TABEL DITEMUKAN   : {len(tables)}")
            print(f"TOTAL BERHASIL DIPINDAH : {count_success}")
            print(f"TOTAL GAGAL             : {len(tables) - count_success}")
            print("-" * 40)

            # --- LANGKAH 5: VERIFIKASI AKHIR ---
            print(f"[*] Melakukan verifikasi di skema '{SCHEMA_TUJUAN}'...")
            verify_query = text("""
                SELECT count(*) 
                FROM information_schema.tables 
                WHERE table_schema = :schema
            """)
            total_di_tujuan = conn.execute(verify_query, {"schema": SCHEMA_TUJUAN}).scalar()
            print(f"[*] Saat ini terdapat {total_di_tujuan} tabel di skema '{SCHEMA_TUJUAN}'.")

    except Exception as e:
        print(f"[ERROR KRITIKAL] Terjadi kesalahan sistem: {e}")

if __name__ == "__main__":
    proses_pindahan_tabel()
