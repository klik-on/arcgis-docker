#!/usr/bin/env python3
import sys
import os
import warnings
from sqlalchemy import create_engine, text, inspect, exc as sa_exc
from datetime import datetime
from dotenv import load_dotenv

# Membungkam warning terkait tipe geometry PostGIS
warnings.filterwarnings("ignore", category=sa_exc.SAWarning)

load_dotenv()

# Konfigurasi Database
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')

DB_URL = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
LOG_DIR = "/app/data/logs/properties"
os.makedirs(LOG_DIR, exist_ok=True)

def get_table_metadata(conn, schema, table):
    """Mengambil metadata spasial dan jumlah row langsung dari katalog sistem."""
    meta = {"count": 0, "srid": "N/A", "geom_type": "N/A"}
    try:
        # Hitung row
        meta["count"] = conn.execute(text(f'SELECT COUNT(*) FROM "{schema}"."{table}"')).scalar()
        
        # Ambil info geometri dari geometry_columns (lebih akurat dari inspector)
        res_geo = conn.execute(text(f"""
            SELECT srid, type FROM geometry_columns 
            WHERE f_table_schema = :s AND f_table_name = :t
        """), {"s": schema, "t": table}).first()
        
        if res_geo:
            meta["srid"] = res_geo[0]
            meta["geom_type"] = res_geo[1]
    except:
        pass
    return meta

def process_standardization(target_schema, target_table=None):
    engine = create_engine(DB_URL)
    
    try:
        inspector = inspect(engine)
        all_tables = inspector.get_table_names(schema=target_schema)
        
        # Cari tabel (case-insensitive)
        tables = [t for t in all_tables if t.lower() == target_table.lower()] if target_table else all_tables

        if not tables:
            print(f"⚠️  Tabel {target_table} tidak ditemukan di skema {target_schema}")
            return

        for table_name in tables:
            print(f"--- Processing: {table_name} ---")
            columns = inspector.get_columns(table_name, schema=target_schema)
            
            with engine.begin() as conn:
                meta = get_table_metadata(conn, target_schema, table_name)
                
                prop_file_path = os.path.join(LOG_DIR, f"{table_name.upper()}_PROPERTIES.txt")
                with open(prop_file_path, "w") as f:
                    f.write(f"METADATA ATRIBUT TABEL: {target_schema}.{table_name.upper()}\n")
                    f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Rows: {meta['count']}\n")
                    f.write(f"Geometry : {meta['geom_type']} (SRID: {meta['srid']})\n")
                    f.write("="*90 + "\n")
                    f.write(f"{'COLUMN_NAME':<30} | {'TYPE':<25} | {'WIDTH/PREC'}\n")
                    f.write("-" * 90 + "\n")

                    for col in columns:
                        c_name = col['name']
                        # Standardisasi nama: geom tetap kecil, lainnya BESAR
                        new_name = c_name.lower() if c_name.lower() in ['geom', 'geometry'] else c_name.upper()
                        
                        # Handle deteksi tipe data
                        raw_type = str(col['type']).upper()
                        width_info = "-"

                        # Perbaikan: Jika inspector baca NULL tapi nama adalah geom, paksa jadi GEOMETRY
                        if c_name.lower() in ['geom', 'geometry']:
                            raw_type = "GEOMETRY"
                            width_info = f"SRID:{meta['srid']}"
                        else:
                            # Ekstrak Width/Precision
                            if hasattr(col['type'], 'length') and col['type'].length:
                                width_info = f"L: {col['type'].length}"
                            elif hasattr(col['type'], 'precision') and col['type'].precision:
                                p = col['type'].precision
                                s = col['type'].scale if col['type'].scale is not None else 0
                                width_info = f"P: {p}, S: {s}"
                            elif "INT" in raw_type:
                                width_info = "Fixed"
                            elif "DOUBLE" in raw_type or "FLOAT" in raw_type:
                                width_info = "64-bit"

                        f.write(f"{new_name:<30} | {raw_type:<25} | {width_info}\n")

                        # Eksekusi Rename di Database
                        if c_name != new_name:
                            conn.execute(text(f'ALTER TABLE "{target_schema}"."{table_name}" RENAME COLUMN "{c_name}" TO "{new_name}"'))

                    # Rename Tabel ke UPPERCASE di akhir
                    if table_name != table_name.upper():
                        conn.execute(text(f'ALTER TABLE "{target_schema}"."{table_name}" RENAME TO "{table_name.upper()}"'))

            print(f"✅ Log Generated: {os.path.basename(prop_file_path)}")

    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    # Menangkap argumen: 1=skema, 2=tabel
    schema_input = sys.argv[1] if len(sys.argv) > 1 else "analisis"
    table_input = sys.argv[2] if len(sys.argv) > 2 else None
    process_standardization(schema_input, table_input)
