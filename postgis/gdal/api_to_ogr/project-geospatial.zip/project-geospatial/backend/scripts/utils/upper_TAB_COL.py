#!/usr/bin/env python3
import sys
import os
import warnings
from sqlalchemy import create_engine, text, inspect, exc as sa_exc
from dotenv import load_dotenv

# Membungkam warning terkait tipe geometry PostGIS
warnings.filterwarnings("ignore", category=sa_exc.SAWarning)

# 1. LOAD KONFIGURASI DARI .ENV
load_dotenv()

DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')

# Default schema jika tidak ada argumen dari JSON/Command Line
DEFAULT_SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
LOG_DIR = "/app/data/logs/properties"
os.makedirs(LOG_DIR, exist_ok=True)

def process_schema_standardization(target_schema):
    """
    Fungsi utama untuk mengubah semua tabel dan kolom dalam satu skema 
    menjadi UPPERCASE (kecuali kolom geom).
    """
    # Koneksi Database
    engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")
    
    try:
        inspector = inspect(engine)
        # 1. Ambil daftar semua tabel di skema target
        tables = inspector.get_table_names(schema=target_schema)

        if not tables:
            print(f"⚠️  Tidak ada tabel ditemukan di skema: '{target_schema}'")
            return

        print(f"🚀 Memulai standardisasi skema: {target_schema}")
        print(f"📊 Ditemukan {len(tables)} tabel untuk diproses.\n")

        for table_name in tables:
            print(f"--- Memproses Tabel: {table_name} ---")
            
            # Ambil informasi kolom
            columns = inspector.get_columns(table_name, schema=target_schema)

            # --- A. GENERATE PROPERTIES FILE (LOG) ---
            prop_file_path = os.path.join(LOG_DIR, f"{table_name.upper()}_PROPERTIES.txt")
            print(f"  📄 Menghasilkan file properti: {os.path.basename(prop_file_path)}")

            with open(prop_file_path, "w") as f:
                f.write(f"METADATA ATRIBUT TABEL: {target_schema}.{table_name.upper()}\n")
                f.write("="*80 + "\n")
                f.write(f"{'COLUMN_NAME':<30} | {'TYPE':<25} | {'WIDTH/PREC'}\n")
                f.write("-"*80 + "\n")

                for col in columns:
                    c_name = col['name']
                    # Skip kolom spasial dari log TXT jika diperlukan (opsional)
                    if c_name.lower() in ['geom', 'geometry']:
                        continue

                    raw_type = str(col['type']).upper()
                    width_info = ""
                    if "DOUBLE PRECISION" in raw_type:
                        width_info = "Floating Point (53-bit)"
                    elif hasattr(col['type'], 'length') and col['type'].length:
                        width_info = f"{col['type'].length}"
                    elif hasattr(col['type'], 'precision') and col['type'].precision:
                        p = col['type'].precision
                        s = col['type'].scale if col['type'].scale is not None else 0
                        width_info = f"Prec: {p}, Scale: {s}"

                    f.write(f"{c_name.upper():<30} | {raw_type:<25} | {width_info}\n")

            # --- B. RENAME COLUMNS & TABLE DI DATABASE ---
            with engine.begin() as conn:
                # Loop untuk setiap kolom
                for col in columns:
                    old_col = col['name']
                    # Logika: geometry kecil, atribut lain BESAR
                    new_col = old_col.lower() if old_col.lower() in ['geom', 'geometry'] else old_col.upper()

                    if old_col != new_col:
                        print(f"    🔄 Kolom: {old_col} -> {new_col}")
                        # Gunakan double quotes untuk menangani case-sensitivity PostgreSQL
                        conn.execute(text(f'ALTER TABLE "{target_schema}"."{table_name}" RENAME COLUMN "{old_col}" TO "{new_col}";'))

                # Rename Nama Tabel menjadi UPPERCASE
                new_table_name = table_name.upper()
                if table_name != new_table_name:
                    print(f"    🔄 Tabel: {table_name} -> {new_table_name}")
                    conn.execute(text(f'ALTER TABLE "{target_schema}"."{table_name}" RENAME TO "{new_table_name}";'))
            
            print(f"✅ Selesai: {table_name}\n")

        print(f"✨ Sukses! Seluruh tabel di skema '{target_schema}' telah distandardisasi.")

    except Exception as e:
        print(f"❌ ERROR pada skema '{target_schema}': {e}")
        sys.exit(1)

# --- ENTRY POINT ---
if __name__ == "__main__":
    # Menangkap argumen pertama sebagai nama skema (untuk penggunaan JSON args)
    # Contoh: python3 upper_TAB_COL.py skema_saya
    if len(sys.argv) > 1:
        selected_schema = sys.argv[1]
    else:
        selected_schema = DEFAULT_SCHEMA

    # Menjalankan fungsi tanpa konfirmasi input (Non-Interactive Mode)
    # Cocok untuk dipanggil oleh backend runner via JSON
    process_schema_standardization(selected_schema)
