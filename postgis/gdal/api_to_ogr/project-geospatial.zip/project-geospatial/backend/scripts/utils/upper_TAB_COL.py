#!/usr/bin/env python3
import sys
import os
import warnings
from sqlalchemy import create_engine, text, inspect, exc as sa_exc
from dotenv import load_dotenv

# Membungkam warning terkait tipe geometry PostGIS
warnings.filterwarnings("ignore", category=sa_exc.SAWarning)

# 1. LOAD KONFIGURASI
load_dotenv()

DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')

SCHEMA_NAME = os.getenv("SCHEMA_DATA", "datagis")
LOG_DIR = "/app/data/logs/properties"
os.makedirs(LOG_DIR, exist_ok=True)

def process_table_standardization(table_name):
    engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")
    
    try:
        inspector = inspect(engine)
        columns = inspector.get_columns(table_name, schema=SCHEMA_NAME)
        
        if not columns:
            print(f"❌ Tabel {SCHEMA_NAME}.{table_name} tidak ditemukan.")
            return

        # --- 1. GENERATE PROPERTIES FILE ---
        prop_file_path = os.path.join(LOG_DIR, f"{table_name.upper()}_PROPERTIES.txt")
        print(f"📄 [1/3] Menghasilkan file properti: {prop_file_path}")
        
        with open(prop_file_path, "w") as f:
            f.write(f"METADATA ATRIBUT TABEL: {SCHEMA_NAME}.{table_name.upper()}\n")
            f.write("="*80 + "\n")
            f.write(f"{'COLUMN_NAME':<30} | {'TYPE':<25} | {'WIDTH/PREC'}\n")
            f.write("-"*80 + "\n")
            
            for col in columns:
                c_name = col['name']
                
                # Saring kolom spasial (tidak masuk log TXT)
                if c_name.lower() in ['geom', 'geometry']:
                    continue
                
                # Tentukan Tipe Data (Tetap Double Precision jika asli)
                raw_type = str(col['type']).upper()
                
                # Logic penentuan Width agar lebih rapi
                width_info = ""
                if "DOUBLE PRECISION" in raw_type:
                    width_info = "Floating Point (53-bit)"
                elif hasattr(col['type'], 'length') and col['type'].length:
                    width_info = f"{col['type'].length}"
                elif hasattr(col['type'], 'precision') and col['type'].precision:
                    p = col['type'].precision
                    s = col['type'].scale if col['type'].scale is not None else 0
                    width_info = f"Prec: {p}, Scale: {s}"
                
                f.write(f"{c_name.upper():<30} | {raw_type:<25} | {width_info}\n")

        # --- 2. RENAME COLUMNS & TABLE IN DB ---
        with engine.begin() as conn:
            print(f"⏳ [2/3] Sinkronisasi Database (Upper Atribut, Lower Geom)...")
            for col in columns:
                old_col = col['name']
                
                # Aturan main: geom/geometry harus kecil, lainnya BESAR
                if old_col.lower() in ['geom', 'geometry']:
                    new_col = old_col.lower()
                else:
                    new_col = old_col.upper()

                if old_col != new_col:
                    print(f"   🔄 Rename Kolom: {old_col} -> {new_col}")
                    conn.execute(text(f'ALTER TABLE "{SCHEMA_NAME}"."{table_name}" RENAME COLUMN "{old_col}" TO "{new_col}";'))

            # Rename Tabel menjadi UPPERCASE
            new_table_name = table_name.upper()
            if table_name != new_table_name:
                print(f"⏳ [3/3] Rename Tabel: {table_name} -> {new_table_name}")
                conn.execute(text(f'ALTER TABLE "{SCHEMA_NAME}"."{table_name}" RENAME TO "{new_table_name}";'))
        
        print(f"✅ Selesai! Log properti diperbarui.")

    except Exception as e:
        print(f"❌ ERROR: {e}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("💡 Gunakan: python3 upper_TAB_COL.py <nama_tabel>")
        sys.exit(1)

    target_table = sys.argv[1]
    process_table_standardization(target_table)
