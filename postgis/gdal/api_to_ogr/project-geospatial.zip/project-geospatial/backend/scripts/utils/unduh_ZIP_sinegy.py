#!/usr/bin/env python3
import os
import sys
import time
import logging
import boto3
import pandas as pd
import requests
import urllib3
from io import BytesIO
from sqlalchemy import create_engine, text, URL
from dotenv import load_dotenv
from botocore.client import Config

# --- 1️⃣ KONFIGURASI ENVIRONMENT ---
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
load_dotenv()

# Koneksi Database merujuk dari standar dbgis (172.16.2.122)
connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", ""),
    host=os.getenv("DB_HOST", "172.16.2.122"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "geodb")
)


SCHEMA = os.getenv("RKP_SCHEMA", "rekap")

TABLE_NAME = "SRTPRMN_DATA" # Nama Tabel UPPERCASE

S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_KEY = "metadata_sinergy/master_data_sinergy.xlsx"
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")
S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")

API_URL = "https://sinergy.planologi.kehutanan.go.id/main-api/data_srtprmn"
ASA_TOKEN = "Asa-Token 0beb25bddf59.7.1716190054609"

logging.basicConfig(
    level=logging.INFO, 
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("Sinergy-Sync")

# --- 2️⃣ UTILITY: S3 UPLOAD ---
def upload_excel_to_s3(df, bucket, key):
    s3_config = Config(
        signature_version='s3v4', 
        max_pool_connections=20, 
        retries={'max_attempts': 5}
    )
    s3_client = boto3.client(
        's3', 
        endpoint_url=S3_ENDPOINT, 
        aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS, 
        config=s3_config, 
        verify=False
    )
    
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    
    try:
        s3_client.put_object(Bucket=bucket, Key=key, Body=output.getvalue())
        logger.info(f"✅ S3 UPLOAD SUCCESS: {key}")
    except Exception as e:
        logger.error(f"❌ S3 ERROR: {e}")

# --- 3️⃣ PROSES UTAMA ---
def main():
    start_time = time.time()
    headers = {
        'Authorization': ASA_TOKEN,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    # One-Shot Pull dengan limit maksimal
    params = {'page': 1, 'limit': 2000}

    try:
        logger.info(f"📡 Menghubungi API Sinergy (Limit: {params['limit']})...")
        res = requests.get(API_URL, headers=headers, params=params, verify=False, timeout=60)
        res.raise_for_status()
        
        raw_items = res.json().get('data', {}).get('data', [])
        if not raw_items:
            logger.warning("⚠️ Tidak ada data ditemukan di API.")
            return

        # 1. Transformasi JSON ke DataFrame (Flatten detail titik)
        df = pd.json_normalize(
            raw_items, 
            record_path=['PermohonanTitik'], 
            meta=['id', 'nmpmhn', 'nomor', 'tanggal', 'status'],
            errors='ignore'
        )
        
        # 2. Standarisasi Kolom ke UPPERCASE
        df.columns = [c.upper() for c in df.columns]

        # 3. FIX: Menangani Duplikasi Nama Kolom (Penyebab error 'ID' already present)
        # Menghapus kolom dengan nama yang sama, hanya menyisakan yang pertama
        df = df.loc[:, ~df.columns.duplicated()]
        
        # 4. Bersihkan Baris Duplikat berdasarkan ID unik
        if 'ID' in df.columns:
            df = df.drop_duplicates(subset=['ID'], keep='first')

        # --- DATABASE UPLOAD ---
        engine = create_engine(connection_url)
        
        with engine.begin() as conn:
            # Pastikan skema tersedia
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
            
            # Kirim data ke PostgreSQL (Replace Table)
            logger.info(f"🐘 Mengirim {len(df)} baris ke {SCHEMA}.{TABLE_NAME}...")
            df.to_sql(
                name=TABLE_NAME, 
                con=conn, 
                schema=SCHEMA, 
                if_exists='replace', 
                index=False,
                method='multi'
            )

        # --- S3 UPLOAD ---
        upload_excel_to_s3(df, S3_BUCKET, S3_KEY)

        dur = time.time() - start_time
        logger.info(f"✨ Sinkronisasi SELESAI | Total: {len(df)} baris | Durasi: {int(dur)} detik")

    except Exception as e:
        logger.error(f"❌ Terjadi kesalahan: {e}")

if __name__ == "__main__":
    main()
