import os
import sys
import datetime
import re
import pyproj
import shapely
import fiona
import rasterio
import geopandas as gpd
from sqlalchemy import create_engine, text
from celery import Celery
import boto3
from botocore.client import Config
from botocore.exceptions import ClientError

# Path PROJ Docker
OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    try:
        pyproj.datadir.set_data_dir(OS_PROJ_PATH)
    except:
        pass

def get_ver(pattern, text):
    """Helper untuk parsing string versi menggunakan regex"""
    match = re.search(pattern, text)
    return match.group(1) if match else "Unknown"

def test_gis_stack():
    # Variable untuk melacak kesehatan sistem secara keseluruhan
    is_healthy = True 
    
    print("\n" + "="*70)
    print(f"    GEOSPATIAL STACK HEALTH CHECK - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)

    try:
        # 1. Python Core & JIT Status
        print(f"[*] Python Version : {sys.version.split()[0]}")

        jit_status = "Not Supported"
        if hasattr(sys, "is_jit_enabled"):
            jit_status = "Enabled" if sys.is_jit_enabled() else "Disabled"
        elif hasattr(sys, "_get_status_jit"):
            jit_status = "Active" if sys._get_status_jit() else "Inactive"
        print(f"[*] JIT Status      : {jit_status}")

        # 2. GIS Libraries
        print(f"✅ PROJ/Pyproj      : {pyproj.__version__} (Engine: {pyproj.proj_version_str})")
        print(f"✅ Shapely/GEOS     : {shapely.__version__} (GEOS: {shapely.geos_version_string})")
        print(f"✅ GDAL (Fiona)     : {fiona.__gdal_version__}")
        print(f"✅ Rasterio         : {rasterio.__version__}")
        print(f"✅ Geopandas        : {gpd.__version__}")

        # 3. Database PostGIS
        print("-" * 70)
        db_url = os.getenv("DATABASE_URL")
        if db_url:
            try:
                engine = create_engine(db_url)
                with engine.connect() as conn:
                    raw_version = conn.execute(text("SELECT PostGIS_Full_Version();")).fetchone()[0]
                    postgis_ver = get_ver(r"POSTGIS=\"([^\"]+)\"", raw_version)
                    pg_ver_raw  = get_ver(r"PGSQL=\"(\d+)\"", raw_version)
                    geos_ver    = get_ver(r"GEOS=\"([^\"]+)\"", raw_version)
                    proj_ver    = get_ver(r"PROJ=\"([^\"]+)\"", raw_version)
                    libxml_ver  = get_ver(r"LIBXML=\"([^\"]+)\"", raw_version)
                    formatted_pg = f"{pg_ver_raw[:2]}.{pg_ver_raw[2:] if len(pg_ver_raw)>2 else '0'}"

                    print(f"✅ PostGIS Connect  : SUCCESS")
                    print(f"    - PostGIS Version: {postgis_ver.split()[0]}")
                    print(f"    - PostgreSQL     : {formatted_pg}")
                    print(f"    - Engine GEOS    : {geos_ver.split('-')[0]}")
                    print(f"    - Engine PROJ    : {proj_ver.split()[0]}")
                    print(f"    - LibXML Support : {libxml_ver}")
            except Exception as e:
                print(f"❌ PostGIS Connect  : FAILED ({str(e)})")
                is_healthy = False
        else:
            print("⚠️  PostGIS Connect  : SKIPPED (DATABASE_URL missing)")

        # 4. Celery & Redis
        print("-" * 70)
        redis_url = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
        try:
            celery_app = Celery("health", broker=redis_url)
            stats = celery_app.control.inspect().stats()
            if stats:
                print(f"✅ Celery Workers   : ONLINE ({len(stats.keys())} node active)")
                for node in stats.keys():
                    print(f"    - Node: {node}")
            else:
                print("❌ Celery Workers   : OFFLINE (No workers detected)")
                is_healthy = False
        except Exception:
            print("❌ Celery Error     : Connection to Redis failed")
            is_healthy = False

        # 5. S3 Storage (Minio) dengan Auto-Create Bucket
        print("-" * 70)
        s3_endpoint = os.getenv("S3_ENDPOINT")
        s3_bucket = os.getenv("S3_BUCKET")

        if s3_endpoint:
            try:
                s3_resource = boto3.resource('s3',
                    endpoint_url=s3_endpoint,
                    aws_access_key_id=os.getenv("S3_USER"),
                    aws_secret_access_key=os.getenv("S3_PASS"),
                    config=Config(signature_version='s3v4'),
                    region_name='us-east-1'
                )
                bucket = s3_resource.Bucket(s3_bucket)
                
                try:
                    # Cek apakah bucket bisa diakses
                    for _ in bucket.objects.limit(1): pass
                    print(f"✅ S3/Minio Storage : SUCCESS (Bucket: {s3_bucket})")
                except ClientError as e:
                    # Jika error karena bucket tidak ada (404), coba buat
                    if e.response['Error']['Code'] == 'NoSuchBucket' or e.response['Error']['Code'] == '404':
                        print(f"⚠️  Bucket '{s3_bucket}' tidak ditemukan. Mencoba membuat...")
                        bucket.create()
                        print(f"✨ S3/Minio Storage : SUCCESS (Bucket '{s3_bucket}' berhasil dibuat)")
                    else:
                        raise e
            except Exception as e:
                print(f"❌ S3 Storage Error : {str(e)}")
                is_healthy = False
        else:
            print("⚠️  S3 Storage      : SKIPPED (Credentials missing)")

        # FINAL STATUS
        print("-" * 70)
        if is_healthy:
            print("🎉 STATUS: SEMUA SISTEM NORMAL & SINKRON")
            print("="*70)
        else:
            print("report: ⚠️  STATUS: BEBERAPA SISTEM BERMASALAH")
            print("="*70)
            sys.exit(1) # Keluar dengan error code agar CI/CD atau script lain tahu

    except Exception as e:
        print(f"\n❌ CRITICAL ERROR: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    test_gis_stack()
