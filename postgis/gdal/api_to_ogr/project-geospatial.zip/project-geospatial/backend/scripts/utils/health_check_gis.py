import os
import sys
import datetime
import pyproj
import shapely
import fiona
import rasterio
import geopandas as gpd
from sqlalchemy import create_engine, text
from celery import Celery
import boto3
from botocore.client import Config

# Path PROJ Docker
OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    try: pyproj.datadir.set_data_dir(OS_PROJ_PATH)
    except: pass

def test_gis_stack():
    print("\n" + "="*70)
    print(f"   GEOSPATIAL STACK HEALTH CHECK - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)

    try:
        # 1. GIS Core Libraries
        print(f"[*] Python Version : {sys.version.split()[0]}")
        print(f"✅ PROJ/Pyproj      : {pyproj.__version__} (Engine: {pyproj.proj_version_str})")
        print(f"✅ Shapely/GEOS     : {shapely.__version__} (GEOS: {shapely.geos_version_string})")
        print(f"✅ GDAL (Fiona)     : {fiona.__gdal_version__}")
        print(f"✅ Rasterio         : {rasterio.__version__}")

        # 2. Database PostGIS
        db_url = os.getenv("DATABASE_URL")
        if db_url:
            engine = create_engine(db_url)
            with engine.connect() as conn:
                res = conn.execute(text("SELECT PostGIS_Full_Version();")).fetchone()[0]
                print(f"✅ PostGIS Connect  : SUCCESS")
                print(f"   PostGIS Info     : {res[:85]}...")
        else:
            print("⚠️  PostGIS Connect  : SKIPPED (DATABASE_URL missing)")

        # 3. Celery & Redis (Monitoring Worker)
        print("-" * 70)
        redis_url = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
        try:
            celery_app = Celery("health", broker=redis_url)
            stats = celery_app.control.inspect().stats()
            if stats:
                print(f"✅ Celery Workers   : ONLINE ({len(stats.keys())} node active)")
                for node in stats.keys(): print(f"   - Node: {node}")
            else:
                print("❌ Celery Workers   : OFFLINE (No workers detected)")
        except:
            print("❌ Celery Error     : Connection to Redis failed")

        # 4. S3 Storage (Minio) - SINKRON DENGAN .ENV ANDA
        print("-" * 70)
        s3_endpoint = os.getenv("S3_ENDPOINT")
        s3_user = os.getenv("S3_USER")   # Dari .env: geobackup
        s3_pass = os.getenv("S3_PASS")   # Dari .env: minio-pass-2026
        s3_bucket = os.getenv("S3_BUCKET") # Dari .env: geospatial-bucket
        
        if s3_endpoint and s3_user:
            try:
                s3 = boto3.resource('s3',
                    endpoint_url=s3_endpoint,
                    aws_access_key_id=s3_user,
                    aws_secret_access_key=s3_pass,
                    config=Config(signature_version='s3v4'),
                    region_name='us-east-1'
                )
                bucket = s3.Bucket(s3_bucket)
                # Test koneksi dengan list minimal
                for _ in bucket.objects.limit(1): pass
                print(f"✅ S3/Minio Storage : SUCCESS (Bucket: {s3_bucket})")
            except Exception as e:
                print(f"❌ S3 Storage Error : {str(e)}")
        else:
            print("⚠️  S3 Storage      : SKIPPED (Credentials missing)")

        print("-" * 70)
        print("🎉 STATUS: SEMUA SISTEM NORMAL & SINKRON")
        print("="*70)

    except Exception as e:
        print(f"\n❌ CRITICAL ERROR: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    test_gis_stack()
