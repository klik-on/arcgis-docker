import os
import sys
import datetime
import pyproj
import shapely
import fiona
import rasterio
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from shapely.ops import transform
from sqlalchemy import create_engine, text

# =================================================================
# docker exec -it geo-api python3 /app/scripts/utils/health_check_gis.py
# CONFIGURATION & LOGGING SETUP
# =================================================================
LOG_DIR = "/app/data/logs" if os.path.exists("/app/data") else "./logs"
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, f"gis_health_{datetime.date.today()}.log")

# Override PROJ agar sinkron dengan PostGIS (sesuai arsitektur Docker Anda)
OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    try:
        pyproj.datadir.set_data_dir(OS_PROJ_PATH)
    except:
        pass

class Logger:
    """Helper untuk menulis ke terminal dan file secara bersamaan."""
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, "a", encoding="utf-8")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        self.terminal.flush()
        self.log.flush()

def test_gis_stack():
    # Mulai logging
    original_stdout = sys.stdout
    sys.stdout = Logger(LOG_FILE)

    print("\n" + "="*70)
    print(f"   GEOSPATIAL STACK HEALTH CHECK - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)

    try:
        # 1. Verifikasi Runtime & JIT
        print(f"[*] Python Version : {sys.version.split()[0]}")
        jit_status = "ACTIVE 🚀" if hasattr(sys, '_jit') else "Not Enabled (Standard Mode)"
        print(f"[*] JIT Status      : {jit_status}")

        # 2. Verifikasi PROJ & Transformasi
        print(f"[*] PROJ Data Dir   : {pyproj.datadir.get_data_dir()}")
        wgs84 = pyproj.CRS('EPSG:4326')
        utm = pyproj.CRS('EPSG:32748') # UTM 48S (Jakarta)

        transformer = pyproj.Transformer.from_crs(wgs84, utm, always_xy=True)
        p1 = Point(106.8272, -6.1751) # Monas
        p2 = transform(transformer.transform, p1)

        print(f"✅ PROJ/Pyproj      : {pyproj.__version__} (Engine: {pyproj.proj_version_str})")
        print(f"   Transform Test   : {p1} -> {p2}")

        # 3. Verifikasi GEOS & Shapely
        print(f"✅ Shapely/GEOS     : {shapely.__version__} (GEOS: {shapely.geos_version_string})")

        # 4. Verifikasi GDAL
        print(f"✅ GDAL (Fiona)     : {fiona.__gdal_version__}")
        print(f"✅ Rasterio         : {rasterio.__version__}")

        # 5. Verifikasi Koneksi PostGIS
        db_url = os.getenv("DATABASE_URL")
        if db_url:
            engine = create_engine(db_url)
            with engine.connect() as conn:
                result = conn.execute(text("SELECT PostGIS_Full_Version();"))
                postgis_ver = result.fetchone()[0]
                print(f"✅ PostGIS Connect  : SUCCESS")
                # Ambil bagian penting saja agar log tidak berantakan
                print(f"   PostGIS Info     : {postgis_ver[:90]}...")
        else:
            print("⚠️  PostGIS Connect  : SKIPPED (DATABASE_URL not found)")

        # 6. Test Geopandas
        data = {'City': ['Jakarta'], 'geometry': [p1]}
        gdf = gpd.GeoDataFrame(data, crs="EPSG:4326")
        print(f"✅ Geopandas        : {gpd.__version__} (GDF creation OK)")

        print("\n" + "="*70)
        print("🎉 STATUS: SEMUA SISTEM NORMAL & SINKRON")
        print("="*70)

    except Exception as e:
        print("\n" + "!"*70)
        print(f"❌ ERROR TERDETEKSI: {str(e)}")
        print("!"*70)
        sys.exit(1)
    finally:
        sys.stdout = original_stdout

if __name__ == "__main__":
    test_gis_stack()
