#!/usr/bin/env python3
import os
import sys
import datetime
import re
import pyproj
import shapely
import fiona
import rasterio
import geopandas as gpd
import dask
import dask_geopandas as dgpd
from sqlalchemy import create_engine, text
from celery import Celery
import boto3
from botocore.client import Config
from botocore.exceptions import ClientError

# --- 1. PROJ DATA CONFIGURATION ---
OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    try:
        pyproj.datadir.set_data_dir(OS_PROJ_PATH)
    except:
        pass

def get_ver(pattern, text):
    """Helper untuk parsing string versi menggunakan regex"""
    match = re.search(pattern, text)
    return match.group(1) if match else "Unknown"

def test_gis_stack():
    is_healthy = True
    output_report = []

    def log(msg):
        print(msg)
        output_report.append(msg)

    log("\n" + "="*70)
    log(f"    GEOSPATIAL STACK HEALTH CHECK - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log("="*70)

    try:
        # --- A. PYTHON & CORE LIBRARIES ---
        log(f"[*] Python Version : {sys.version.split()[0]}")
        log(f"✅ PROJ/Pyproj      : {pyproj.__version__} (Engine: {pyproj.proj_version_str})")
        log(f"✅ Shapely/GEOS     : {shapely.__version__} (GEOS: {shapely.geos_version_string})")
        log(f"✅ GDAL (Fiona)     : {fiona.__gdal_version__}")
        log(f"✅ Rasterio          : {rasterio.__version__}")
        log(f"✅ Geopandas         : {gpd.__version__}")

        # --- B. POSTGIS DATABASE ---
        log("-" * 70)
        db_url = os.getenv("DATABASE_URL")
        if db_url:
            if db_url.startswith("postgresql://") and "+psycopg" not in db_url:
                db_url = db_url.replace("postgresql://", "postgresql+psycopg://", 1)

            try:
                engine = create_engine(db_url, pool_pre_ping=True, connect_args={'connect_timeout': 5})
                with engine.connect() as conn:
                    raw_version = conn.execute(text("SELECT PostGIS_Full_Version();")).fetchone()[0]
                    postgis_ver = get_ver(r"POSTGIS=\"([^\"]+)\"", raw_version)
                    pg_ver_raw  = get_ver(r"PGSQL=\"(\d+)\"", raw_version)
                    geos_ver    = get_ver(r"GEOS=\"([^\"]+)\"", raw_version)

                    formatted_pg = f"{pg_ver_raw[:2]}.{pg_ver_raw[2:] if len(pg_ver_raw)>2 else '0'}"

                    log(f"✅ PostGIS Connect  : SUCCESS")
                    log(f"    - PostGIS Version: {postgis_ver.split()[0]}")
                    log(f"    - PostgreSQL     : {formatted_pg}")
                    log(f"    - Engine GEOS    : {geos_ver.split('-')[0]}")
            except Exception as e:
                log(f"❌ PostGIS Connect  : FAILED ({str(e)})")
                is_healthy = False
        else:
            log("⚠️  PostGIS Connect  : SKIPPED (DATABASE_URL missing)")

        # --- C. DASK PARALLEL ENGINE (NEW) ---
        log("-" * 70)
        try:
            cpu_count = os.cpu_count() or 0
            log(f"✅ Dask Framework    : {dask.__version__}")
            log(f"✅ Dask-GeoPandas   : {dgpd.__version__}")
            log(f"    - Parallelism    : {cpu_count} CPU Cores available")
            log(f"    - Scheduler      : {dask.config.get('scheduler', 'threaded (default)')}")
        except Exception as e:
            log(f"❌ Dask Status      : FAILED ({str(e)})")
            is_healthy = False

        # --- D. CELERY & REDIS ---
        log("-" * 70)
        redis_url = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
        try:
            celery_app = Celery("health", broker=redis_url)
            inspector = celery_app.control.inspect(timeout=1.0)
            stats = inspector.stats()

            if stats:
                log(f"✅ Celery Workers    : ONLINE ({len(stats.keys())} node active)")
                for node in stats.keys():
                    log(f"    - Node: {node}")
            else:
                log("❌ Celery Workers    : OFFLINE (No workers detected)")
                is_healthy = False
        except Exception as e:
            log(f"❌ Celery/Redis      : FAILED ({str(e)})")
            is_healthy = False

        # --- E. S3 STORAGE (MINIO) ---
        log("-" * 70)
        s3_endpoint = os.getenv("S3_ENDPOINT")
        s3_bucket = os.getenv("S3_BUCKET")

        if s3_endpoint:
            try:
                s3_resource = boto3.resource('s3',
                    endpoint_url=s3_endpoint,
                    aws_access_key_id=os.getenv("S3_USER"),
                    aws_secret_access_key=os.getenv("S3_PASS"),
                    config=Config(signature_version='s3v4', connect_timeout=5, retries={'max_attempts': 1}),
                    region_name='us-east-1'
                )
                bucket = s3_resource.Bucket(s3_bucket)
                for _ in bucket.objects.limit(1): pass
                log(f"✅ S3/Minio Storage : SUCCESS (Bucket: {s3_bucket})")
            except Exception as e:
                log(f"❌ S3 Storage Error : {str(e)}")
                is_healthy = False
        else:
            log("⚠️  S3 Storage       : SKIPPED (Credentials missing)")

        # --- FINAL VERDICT ---
        log("-" * 70)
        if is_healthy:
            log("🎉 STATUS: ALL SYSTEMS OPERATIONAL")
            log("="*70)
            sys.exit(0)
        else:
            log("🚨 STATUS: SYSTEM DEGRADED (Issues found)")
            log("="*70)
            sys.exit(1)

    except Exception as e:
        print(f"\n❌ CRITICAL SYSTEM ERROR: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    test_gis_stack()
