#!/usr/bin/env python3
import requests
import json
import os

def jalankan_proses_sipdas():
    # --- 1. KONFIGURASI ---
    base_url = "http://172.16.2.175:8180"
    auth_endpoint = f"{base_url}/api/authenticate"
    data_endpoint = f"{base_url}/services/sipdasrh-proxy/sicerdas/permohonan"

    # Kredensial
    payload_auth = {
        "username": "pdasrh_jagarimba",
        "password": "pdasrhJagarimba123!@#",
        "rememberMe": True
    }

    headers_base = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    try:
        # --- 2. STEP 1: LOGIN (GET TOKEN) ---
        print(f"[*] Melakukan autentikasi ke: {auth_endpoint}")
        auth_resp = requests.post(auth_endpoint, json=payload_auth, headers=headers_base, timeout=15)
        
        if auth_resp.status_code != 200:
            print(f"[-] Gagal Login. Status: {auth_resp.status_code}, Msg: {auth_resp.text}")
            return

        token = auth_resp.json().get("id_token")
        if not token:
            print("[-] Token tidak ditemukan dalam respon.")
            return

        print("[+] Token berhasil didapatkan.")

        # --- 3. STEP 2: GET DATA (MENGGUNAKAN TOKEN) ---
        print(f"[*] Mengambil data permohonan dari: {data_endpoint}")
        
        # Header dengan Bearer Token
        headers_with_auth = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        data_resp = requests.get(data_endpoint, headers=headers_with_auth, timeout=30)

        if data_resp.status_code == 200:
            data_permohonan = data_resp.json()
            print("[+] Data Permohonan berhasil diambil!")
            
            # Menampilkan ringkasan data (misal 2 data pertama)
            print("-" * 50)
            print(json.dumps(data_permohonan[:2] if isinstance(data_permohonan, list) else data_permohonan, indent=2))
            print("-" * 50)
            
            return data_permohonan
        else:
            print(f"[-] Gagal mengambil data. Status: {data_resp.status_code}")
            print(f"Respon Error: {data_resp.text}")

    except requests.exceptions.Timeout:
        print("[-] Error: Request time out (Server internal lambat).")
    except Exception as e:
        print(f"[-] Terjadi kesalahan sistem: {str(e)}")

if __name__ == "__main__":
    jalankan_proses_sipdas()
