import os
import boto3

# docker exec -it geo-api python3 scripts/utils/list_backups.py

def list_backups():
    # Load konfigurasi dari env
    S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")
    S3_USER = os.getenv("S3_USER", "geobackup")
    S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
    S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")

    s3 = boto3.client('s3',
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS
    )

    print(f"🔍 Mencari file backup di bucket: {S3_BUCKET}...\n")
    
    try:
        # List objek dengan prefix folder backup
        response = s3.list_objects_v2(Bucket=S3_BUCKET, Prefix='database_backups/')

        if 'Contents' in response:
            print(f"{'NAMA FILE':<60} | {'UKURAN':<10} | {'TANGGAL'}")
            print("-" * 90)
            for obj in response['Contents']:
                size_mb = round(obj['Size'] / (1024 * 1024), 2)
                print(f"{obj['Key']:<60} | {size_mb:>7} MB | {obj['LastModified']}")
        else:
            print("❌ Tidak ada file backup ditemukan.")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    list_backups()
