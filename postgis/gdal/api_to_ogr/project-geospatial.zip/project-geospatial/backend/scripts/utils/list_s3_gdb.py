#!/usr/bin/env python3
import os
import sys
import boto3
import logging
from botocore.client import Config
from dotenv import load_dotenv

# Akses CLI
# docker exec -it geo-worker python3 /app/scripts/utils/list_s3_gdb.py
# --- 1. INISIALISASI ---
load_dotenv()

# Setup Logging sederhana ke Console
logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("S3-Lister")

# --- 2. KONFIGURASI S3 ---
S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

def list_gdb_files():
    """
    Hanya melist file dengan ekstensi .gdb.zip di bucket S3
    """
    logger.info(f"🔍 Menghubungkan ke S3: {S3_ENDPOINT}")
    logger.info(f"📂 Memeriksa Bucket: {S3_BUCKET}\n")

    # Inisialisasi Client
    s3 = boto3.client('s3', 
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS,
        config=Config(signature_version='s3v4'),
        verify=False # Set True jika menggunakan SSL resmi
    )

    try:
        # Ambil daftar objek
        response = s3.list_objects_v2(Bucket=S3_BUCKET)
        
        if 'Contents' not in response:
            logger.warning(f"⚠️ Bucket '{S3_BUCKET}' kosong atau tidak ditemukan.")
            return

        # Filter file
        gdb_files = [
            obj for obj in response['Contents'] 
            if obj['Key'].lower().endswith('.gdb.zip')
        ]

        if not gdb_files:
            logger.info("ℹ️ Tidak ditemukan file dengan ekstensi .gdb.zip")
            return

        # Tampilkan Hasil dalam Tabel Sederhana
        logger.info(f"{'NAMA FILE':<50} | {'UKURAN (MB)':<12} | {'TERAKHIR DIUBAH'}")
        logger.info("-" * 90)
        
        for file in gdb_files:
            name = file['Key']
            size_mb = round(file['Size'] / (1024 * 1024), 2)
            last_mod = file['LastModified'].strftime("%Y-%m-%d %H:%M:%S")
            
            logger.info(f"{name:<50} | {size_mb:<12} | {last_mod}")

        logger.info("-" * 90)
        logger.info(f"✅ Total ditemukan: {len(gdb_files)} file.")

    except Exception as e:
        logger.error(f"❌ Error saat mengakses S3: {e}")

if __name__ == "__main__":
    list_gdb_files()
