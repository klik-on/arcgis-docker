#!/bin/bash

# --- KONFIGURASI ---
CONTAINER_NAME="geo-api"
DB_USER="dbgis"
DB_PASS="password00"
DB_HOST="172.16.2.122" # Pastikan host ini bisa dijangkau dari DALAM container
DB_PORT="5432"
NEW_DB="gisdb"
SCHEMAS=("analisis" "rekap" "kamusdata" "datagis")

echo "------------------------------------------------"
echo "🔍 Mengambil daftar backup dari S3..."
echo "------------------------------------------------"

docker exec $CONTAINER_NAME python3 scripts/utils/list_backups.py

echo "------------------------------------------------"
read -p "Copy & Paste NAMA FILE (Key) yang ingin di-restore: " S3_FILE_KEY

if [ -z "$S3_FILE_KEY" ]; then
    echo "❌ Error: Nama file tidak boleh kosong."
    exit 1
fi

echo "--- PERSIAPAN DATABASE ---"
read -p "Hapus skema lama (${SCHEMAS[*]})? (y/n): " CONFIRM
if [[ "$CONFIRM" == "y" ]]; then
    for s in "${SCHEMAS[@]}"; do
        echo "Menghapus skema $s..."
        docker exec -e PGPASSWORD=$DB_PASS $CONTAINER_NAME psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $NEW_DB -c "DROP SCHEMA IF EXISTS $s CASCADE;"
    done
fi

echo "------------------------------------------------"
echo "🚀 Memulai restorasi via Container (No version mismatch)..."

# Pipe langsung dari Python (S3) ke pg_restore di dalam container
docker exec -i -e PGPASSWORD=$DB_PASS $CONTAINER_NAME bash -c "
python3 -c \"
import boto3, os, sys
s3 = boto3.client('s3', 
    endpoint_url=os.getenv('S3_ENDPOINT', 'http://s3-storage:9000'),
    aws_access_key_id=os.getenv('S3_USER', 'geobackup'),
    aws_secret_access_key=os.getenv('S3_PASS', 'minio-pass-2026'))
s3.download_fileobj(os.getenv('S3_BUCKET', 'geospatial-bucket'), '$S3_FILE_KEY', sys.stdout.buffer)
\" | pg_restore -h $DB_HOST -p $DB_PORT -U $DB_USER -d $NEW_DB --clean --if-exists --no-owner --no-privileges --verbose
"

if [ $? -eq 0 ]; then
    echo "✅ Restore Berhasil!"
else
    echo "⚠️ Restore selesai dengan peringatan/error."
fi

echo "------------------------------------------------"
echo "🏁 Proses Selesai."
