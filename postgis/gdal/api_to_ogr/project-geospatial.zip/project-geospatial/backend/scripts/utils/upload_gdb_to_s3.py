#!/usr/bin/env python3
import os
import sys
import boto3
from dotenv import load_dotenv
from botocore.client import Config
from botocore.exceptions import NoCredentialsError

# --- 1️⃣ KONFIGURASI ---
load_dotenv()

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

def upload_local_to_s3(file_path, bucket_name):
    """Fungsi utama untuk upload file ke S3"""
    
    # Validasi keberadaan file
    if not os.path.exists(file_path):
        print(f"❌ Error: File '{file_path}' tidak ditemukan.")
        return

    file_name = os.path.basename(file_path)

    # Inisialisasi Client S3
    s3_client = boto3.client(
        's3',
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS,
        config=Config(signature_version='s3v4'),
        verify=False  # Set ke True jika menggunakan SSL resmi
    )

    try:
        print(f"🚀 Memulai upload: {file_name} -> {bucket_name}")
        
        # Proses Upload
        s3_client.upload_file(
            file_path, 
            bucket_name, 
            file_name,
            ExtraArgs={'ACL': 'private'} # Opsional: sesuaikan izin akses
        )
        
        print(f"✅ Upload Berhasil!")
        print(f"📍 S3 Path: s3://{bucket_name}/{file_name}")

    except NoCredentialsError:
        print("❌ Error: Kredensial S3 tidak valid.")
    except Exception as e:
        print(f"❌ Error saat upload: {e}")

# --- 2️⃣ ENTRY POINT ---
if __name__ == "__main__":
    if len(sys.argv) > 1:
        target_file = sys.argv[1]
        # Jika argumen kedua diberikan, gunakan sebagai nama bucket
        target_bucket = sys.argv[2] if len(sys.argv) > 2 else S3_BUCKET
        
        upload_local_to_s3(target_file, target_bucket)
    else:
        print("💡 Cara Penggunaan:")
        print("   python3 upload_gdb_to_s3.py <path_file_lokal> [nama_bucket]")
        print("\n   Contoh:")
        print("   python3 upload_gdb_to_s3.py /app/data/KUPS.gdb.zip")
