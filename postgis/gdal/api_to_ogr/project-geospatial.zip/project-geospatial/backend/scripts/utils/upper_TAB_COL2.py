#!/usr/bin/env python3
import sys, os, warnings
from sqlalchemy import create_engine, text, inspect
from datetime import datetime
from dotenv import load_dotenv

warnings.filterwarnings("ignore")
load_dotenv()

DB_URL = f"postgresql+psycopg://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST', 'dbgis')}:{os.getenv('DB_PORT', '5432')}/{os.getenv('DB_NAME')}"
LOG_DIR = "/app/data/logs/properties"
SUM_DIR = "/app/data/output_gdb"
os.makedirs(LOG_DIR, exist_ok=True)

def process_unified_report(schema, table):
    engine = create_engine(DB_URL)
    # Nama file laporan sekarang identik dengan nama tabel hasil clip
    report_path = os.path.join(LOG_DIR, f"{table}_REPORT.txt")
    
    try:
        inspector = inspect(engine)
        columns = inspector.get_columns(table, schema=schema)
        
        with engine.begin() as conn:
            row_count = conn.execute(text(f'SELECT COUNT(*) FROM "{schema}"."{table}"')).scalar()
            res_geo = conn.execute(text(f"""
                SELECT srid, type FROM geometry_columns 
                WHERE f_table_schema = :s AND f_table_name = :t
            """), {"s": schema, "t": table}).first()
            
            with open(report_path, "w") as f:
                f.write("="*95 + "\n")
                f.write(f" CONSOLIDATED REPORT: {schema}.{table}\n")
                f.write("="*95 + "\n")
                f.write(f" Timestamp    : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f" Geometry     : {res_geo[1] if res_geo else 'N/A'} (SRID: {res_geo[0] if res_geo else 'N/A'})\n")
                f.write(f" Records      : {row_count} rows\n\n")
                
                f.write(" [SECTION A] METADATA STRUKTUR\n")
                f.write("-" * 95 + "\n")
                f.write(f"{'COLUMN_NAME':<30} | {'TYPE':<25} | {'PRECISION'}\n")
                f.write("-" * 95 + "\n")

                for col in columns:
                    c_name = col['name']
                    # Standardisasi nama kolom ke UPPER, kecuali geom
                    new_name = c_name.lower() if c_name.lower() in ['geom', 'geometry'] else c_name.upper()
                    raw_type = str(col['type']).upper()
                    
                    f.write(f"{new_name:<30} | {raw_type:<25} | -\n")
                    if c_name != new_name:
                        conn.execute(text(f'ALTER TABLE "{schema}"."{table}" RENAME COLUMN "{c_name}" TO "{new_name}"'))

                # GABUNGKAN DATA SUMMARY
                sum_file = os.path.join(SUM_DIR, f"SUMMARY_{table}.txt")
                if os.path.exists(sum_file):
                    f.write("\n\n [SECTION B] STATISTIK LUAS (HA)\n")
                    f.write("-" * 95 + "\n")
                    with open(sum_file, 'r') as sf:
                        f.write(sf.read())
                    os.remove(sum_file)

                f.write("\n" + "="*95 + "\n")

        print(f"✅ Unified Report created: {report_path}")
    except Exception as e:
        print(f"❌ Report Error: {e}")

if __name__ == "__main__":
    process_unified_report(sys.argv[1], sys.argv[2])
