#!/bin/bash

# =================================================================
# SKRIP CEK STATUS TABEL DATAGIS
# =================================================================

# Nama tabel (Default jika tidak ada argumen)
TABLE_NAME=${1:-"PERSETUJUAN_KOMITMEN_PBPH"}
SCHEMA_NAME="datagis"

echo "----------------------------------------------------------"
echo "🔍 Mengecek tabel: $SCHEMA_NAME.\"$TABLE_NAME\""
echo "----------------------------------------------------------"

# Eksekusi query ke Docker
docker exec -it db-pgis bash -c "psql -U \$POSTGRES_USER -d \$POSTGRES_DB -c \"
SELECT 
    schemaname as skema, 
    tablename as tabel, 
    pg_size_pretty(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(tablename))) as ukuran_total,
    (SELECT count(*) FROM \\\"$SCHEMA_NAME\\\".\\\"$TABLE_NAME\\\") as jumlah_baris,
    (SELECT pg_size_pretty(pg_relation_size(quote_ident(schemaname) || '.' || quote_ident(tablename)))) as ukuran_data_saja
FROM pg_tables 
WHERE schemaname = '$SCHEMA_NAME' AND tablename = '$TABLE_NAME';\""

echo "----------------------------------------------------------"
