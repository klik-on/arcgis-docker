import logging
import os
import redis
from sqlalchemy import text

# --- CONFIGURATION ---
logger = logging.getLogger("geo-worker")
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")

def clear_layer_cache(layer, schema, log_func):
    """
    Menghapus cache MVT di Redis untuk layer tertentu.
    """
    try:
        r = redis.from_url(REDIS_URL)
        target_schema = f"{schema.lower()}_3857"
        pattern = f"mvt:{target_schema}:{layer}:*"
        keys = r.keys(pattern)
        if keys:
            r.delete(*keys)
            log_func(f"REDIS: {len(keys)} tile cache dibersihkan untuk {layer}.")
            return len(keys)
        log_func(f"REDIS: Cache sudah bersih untuk {layer}.")
        return 0
    except Exception as e:
        log_func(f"REDIS ERROR: Gagal membersihkan cache: {str(e)}")
        return 0

def optimize_layer_logic(engine, source_schema, layer, log_to_file_func):
    """
    Mengelola Materialized View (MV) dalam proyeksi EPSG:3857.
    MODIFIKASI: Menggunakan row_number() sebagai 'gid' untuk menjamin Unique Index.
    """
    target_schema = f"{source_schema.lower()}_3857"
    view_full_name = f'"{target_schema}"."{layer}"'

    log_to_file_func(f"--- START OPTIMIZATION: {view_full_name} ---")

    try:
        status_action = "error"

        with engine.begin() as conn:
            # 1. Cek apakah Materialized View sudah ada
            check_sql = text("""
                SELECT 1 FROM pg_matviews
                WHERE schemaname = :s AND matviewname = :l
            """)
            exists = conn.execute(check_sql, {"s": target_schema, "l": layer}).fetchone()

            if exists:
                # 2. REFRESH DATA (TANPA DOWNTIME)
                log_to_file_func(f"Refreshing data secara CONCURRENTLY untuk {view_full_name}...")
                try:
                    conn.execute(text(f"REFRESH MATERIALIZED VIEW CONCURRENTLY {view_full_name};"))
                    log_to_file_func(f"DATABASE: Refresh sukses (No downtime).")
                except Exception as e:
                    log_to_file_func(f"WARNING: Gagal refresh concurrent, mencoba refresh standar: {e}")
                    conn.execute(text(f"REFRESH MATERIALIZED VIEW {view_full_name};"))
                status_action = "refreshed"

            else:
                # 3. INISIALISASI MATERIALIZED VIEW BARU
                log_to_file_func(f"Inisialisasi awal. Membuat MV baru: {view_full_name}")
                conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{target_schema}";'))

                # Ambil semua kolom kecuali geometri (untuk dipindahkan ke MV)
                col_res = conn.execute(text(f"""
                    SELECT column_name FROM information_schema.columns
                    WHERE table_schema = :s AND table_name = :t
                    AND column_name NOT IN ('geom', 'geometry')
                """), {"s": source_schema, "t": layer})

                cols = [f'"{r[0]}"' for r in col_res]
                if not cols:
                    raise Exception(f"Tabel {source_schema}.{layer} tidak ditemukan atau kosong.")

                # MODIFIKASI: Tambahkan row_number() sebagai 'gid' unik
                # Gunakan ST_MakeValid untuk memastikan geometri bersih sebelum ditransform
                sql_create = f"""
                    CREATE MATERIALIZED VIEW {view_full_name} AS
                    SELECT 
                        row_number() OVER () as gid, 
                        {", ".join(cols)},
                        ST_Transform(ST_MakeValid(geom), 3857)::geometry(Geometry, 3857) as geom
                    FROM "{source_schema}"."{layer}";
                """
                conn.execute(text(sql_create))

                # --- INDEXING (WAJIB UNTUK PERFORMA & REFRESH CONCURRENT) ---

                # A. Unique Index pada kolom 'gid' yang baru dibuat
                # Ini dijamin berhasil karena gid dibuat oleh database saat itu juga
                idx_u_name = f"ux_{target_schema}_{layer.lower()}_gid"
                conn.execute(text(f'CREATE UNIQUE INDEX "{idx_u_name}" ON {view_full_name} (gid);'))
                log_to_file_func(f"INDEX: Unique Index dijamin berhasil pada kolom 'gid'.")

                # B. GIST Spatial Index (Untuk Performa MVT)
                idx_gist_name = f"idx_gist_{target_schema}_{layer.lower()}_3857"
                conn.execute(text(f'CREATE INDEX "{idx_gist_name}" ON {view_full_name} USING GIST (geom);'))

                log_to_file_func(f"DATABASE: {view_full_name} berhasil dibuat dengan GID unik.")
                status_action = "created"

            # ANALYZE untuk mempercepat query planner
            conn.execute(text(f"ANALYZE {view_full_name};"))

        # 4. INVALIDASI CACHE REDIS
        cleared_count = clear_layer_cache(layer, source_schema, log_to_file_func)

        return {
            "status": status_action,
            "layer": layer,
            "schema_target": target_schema,
            "cache_cleared": cleared_count
        }

    except Exception as e:
        log_to_file_func(f"🚨 OPTIMIZER ERROR: {str(e)}")
        raise e
