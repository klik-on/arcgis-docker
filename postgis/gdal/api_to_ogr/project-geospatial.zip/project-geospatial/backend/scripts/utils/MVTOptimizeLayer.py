import logging
import os
import redis
from sqlalchemy import text

# Konfigurasi Logging
logger = logging.getLogger("geo-worker")

# Konfigurasi Redis dari Environment
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")

def clear_layer_cache(layer, schema, log_func):
    """
    Menghapus cache MVT di Redis yang terkait dengan layer tertentu.
    Format key di main.py: mvt:{schema_3857}:{layer}:{z}:{x}:{y}
    """
    try:
        r = redis.from_url(REDIS_URL)
        # Target schema yang dioptimasi (selalu berakhiran _3857)
        target_schema = f"{schema.lower()}_3857"
        
        # Pola pencarian key: mvt:datagis_3857:KUPS:*
        pattern = f"mvt:{target_schema}:{layer}:*"
        
        # Cari semua keys yang cocok
        keys = r.keys(pattern)
        
        if keys:
            r.delete(*keys)
            log_func(f"REDIS: {len(keys)} tile cache dihapus untuk layer {layer}.")
            return len(keys)
        
        log_func(f"REDIS: Tidak ada cache yang ditemukan untuk layer {layer}.")
        return 0
    except Exception as e:
        log_func(f"REDIS ERROR: Gagal membersihkan cache: {str(e)}")
        return 0

def optimize_layer_logic(engine, source_schema, layer, log_to_file_func):
    """
    Fungsi inti untuk membuat atau me-refresh Materialized View EPSG:3857
    dan membersihkan cache Redis setelahnya.
    """
    target_schema = f"{source_schema.lower()}_3857"
    view_full_name = f'"{target_schema}"."{layer}"'

    log_to_file_func(f"--- START OPTIMIZATION: {view_full_name} ---")

    try:
        status_action = "error"
        
        with engine.begin() as conn:
            # 1. Cek keberadaan Materialized View
            check_sql = text("""
                SELECT 1 FROM pg_matviews 
                WHERE schemaname = :s AND matviewname = :l
            """)
            exists = conn.execute(check_sql, {"s": target_schema, "l": layer}).fetchone()

            if exists:
                # REFRESH DATA
                log_to_file_func(f"View ditemukan. Refreshing data untuk {view_full_name}...")
                conn.execute(text(f"REFRESH MATERIALIZED VIEW {view_full_name};"))
                log_to_file_func(f"DATABASE: Data dalam {view_full_name} berhasil di-refresh.")
                status_action = "refreshed"

            else:
                # INITIALIZE NEW MATERIALIZED VIEW
                log_to_file_func(f"View tidak ditemukan. Membuat MV baru: {view_full_name}...")
                conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{target_schema}";'))

                # Deteksi Primary Key dari tabel asal
                pk_query = text("""
                    SELECT a.column_name FROM information_schema.key_column_usage a
                    JOIN information_schema.table_constraints b ON a.constraint_name = b.constraint_name
                    WHERE a.table_schema = :s AND a.table_name = :t AND b.constraint_type = 'PRIMARY KEY'
                    LIMIT 1
                """)
                pk_res = conn.execute(pk_query, {"s": source_schema, "t": layer}).fetchone()
                pk_col = pk_res[0] if pk_res else None

                # Ambil daftar kolom selain kolom geometri
                col_res = conn.execute(text(f"""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_schema = :s AND table_name = :t AND column_name != 'geom'
                """), {"s": source_schema, "t": layer})

                cols = [f'"{r[0]}"' for r in col_res]
                if not cols:
                    raise Exception(f"Tabel sumber {source_schema}.{layer} tidak ditemukan atau tidak memiliki kolom.")

                # Create MV dengan transformasi ke 3857 dan validasi geometri
                sql_create = f"""
                    CREATE MATERIALIZED VIEW {view_full_name} AS
                    SELECT {", ".join(cols)}, ST_Transform(ST_MakeValid(geom), 3857)::geometry(Geometry, 3857) as geom
                    FROM "{source_schema}"."{layer}";
                """
                conn.execute(text(sql_create))

                # --- INDEXING ---
                # 1. Unique Index untuk performa refresh dan identifikasi
                unique_col = pk_col
                if not unique_col:
                    potential_ids = [c.strip('"') for c in cols if c.lower().strip('"') in ['id', 'gid', 'objectid', 'ogc_fid']]
                    if potential_ids: unique_col = potential_ids[0]

                if unique_col:
                    idx_u_name = f"ux_{target_schema}_{layer.lower()}_id"
                    conn.execute(text(f'CREATE UNIQUE INDEX "{idx_u_name}" ON {view_full_name} ("{unique_col}");'))

                # 2. GIST Spatial Index (Wajib untuk performa MVT)
                idx_gist_name = f"idx_{target_schema}_{layer.lower()}_3857"
                conn.execute(text(f'CREATE INDEX "{idx_gist_name}" ON {view_full_name} USING GIST (geom);'))

                log_to_file_func(f"DATABASE: {view_full_name} berhasil dibuat dan di-index.")
                status_action = "created"

        # 2. AUTOMATIC CACHE INVALIDATION
        # Jalankan pembersihan cache setelah transaksi database sukses (commit)
        cleared_count = clear_layer_cache(layer, source_schema, log_to_file_func)

        return {
            "status": status_action, 
            "layer": layer, 
            "schema": target_schema, 
            "cache_cleared": cleared_count
        }

    except Exception as e:
        log_to_file_func(f"ERROR SYSTEM: {str(e)}")
        raise e
