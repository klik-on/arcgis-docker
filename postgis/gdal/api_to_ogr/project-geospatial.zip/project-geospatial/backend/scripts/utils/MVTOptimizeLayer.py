import logging
import os
import redis
from sqlalchemy import text

# --- CONFIGURATION ---
logger = logging.getLogger("geo-worker")
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")

def clear_layer_cache(layer, schema, log_func):
    """
    Menghapus cache MVT di Redis untuk layer tertentu.
    Pattern: mvt:datagis_3857:nama_layer:*
    """
    try:
        r = redis.from_url(REDIS_URL)
        target_schema = f"{schema.lower()}_3857"
        pattern = f"mvt:{target_schema}:{layer}:*"
        
        keys = r.keys(pattern)
        if keys:
            r.delete(*keys)
            log_func(f"REDIS: {len(keys)} tile cache dibersihkan untuk {layer}.")
            return len(keys)
        
        log_func(f"REDIS: Cache sudah bersih untuk {layer}.")
        return 0
    except Exception as e:
        log_func(f"REDIS ERROR: Gagal membersihkan cache: {str(e)}")
        return 0

def optimize_layer_logic(engine, source_schema, layer, log_to_file_func):
    """
    Mengelola Materialized View (MV) dalam proyeksi EPSG:3857.
    Mendukung REFRESH CONCURRENTLY agar API tetap responsif saat update.
    """
    target_schema = f"{source_schema.lower()}_3857"
    view_full_name = f'"{target_schema}"."{layer}"'

    log_to_file_func(f"--- START OPTIMIZATION: {view_full_name} ---")

    try:
        status_action = "error"

        with engine.begin() as conn:
            # 1. Cek apakah Materialized View sudah ada
            check_sql = text("""
                SELECT 1 FROM pg_matviews 
                WHERE schemaname = :s AND matviewname = :l
            """)
            exists = conn.execute(check_sql, {"s": target_schema, "l": layer}).fetchone()

            if exists:
                # 2. REFRESH DATA (TANPA DOWNTIME)
                # Syarat CONCURRENTLY: Harus ada setidaknya 1 Unique Index
                log_to_file_func(f"Refreshing data secara CONCURRENTLY untuk {view_full_name}...")
                try:
                    conn.execute(text(f"REFRESH MATERIALIZED VIEW CONCURRENTLY {view_full_name};"))
                    log_to_file_func(f"DATABASE: Refresh sukses (No downtime).")
                except Exception as e:
                    # Fallback jika Unique Index hilang/error
                    log_to_file_func(f"WARNING: Gagal refresh secara concurrent, mencoba refresh standar: {e}")
                    conn.execute(text(f"REFRESH MATERIALIZED VIEW {view_full_name};"))
                
                status_action = "refreshed"

            else:
                # 3. INISIALISASI MATERIALIZED VIEW BARU
                log_to_file_func(f"Inisialisasi awal. Membuat MV baru: {view_full_name}")
                conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{target_schema}";'))

                # Ambil Primary Key (PK) dari tabel asal
                pk_query = text("""
                    SELECT a.column_name FROM information_schema.key_column_usage a
                    JOIN information_schema.table_constraints b ON a.constraint_name = b.constraint_name
                    WHERE a.table_schema = :s AND a.table_name = :t AND b.constraint_type = 'PRIMARY KEY'
                    LIMIT 1
                """)
                pk_res = conn.execute(pk_query, {"s": source_schema, "t": layer}).fetchone()
                pk_col = pk_res[0] if pk_res else None

                # Ambil semua kolom kecuali geometri
                col_res = conn.execute(text(f"""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_schema = :s AND table_name = :t 
                    AND column_name NOT IN ('geom', 'geometry')
                """), {"s": source_schema, "t": layer})

                cols = [f'"{r[0]}"' for r in col_res]
                if not cols:
                    raise Exception(f"Tabel {source_schema}.{layer} tidak ditemukan atau kosong.")

                # Create MV: Transform ke 3857 + Validasi Geometri
                sql_create = f"""
                    CREATE MATERIALIZED VIEW {view_full_name} AS
                    SELECT {", ".join(cols)}, 
                           ST_Transform(ST_MakeValid(geom), 3857)::geometry(Geometry, 3857) as geom
                    FROM "{source_schema}"."{layer}";
                """
                conn.execute(text(sql_create))

                # --- INDEXING (WAJIB UNTUK PERFORMA & REFRESH CONCURRENT) ---
                
                # A. Unique Index (Syarat REFRESH CONCURRENTLY)
                unique_col = pk_col
                if not unique_col:
                    # Cari kolom alternatif jika PK tidak ditemukan
                    potential_ids = [c.strip('"') for c in cols if c.lower().strip('"') in ['id', 'gid', 'objectid', 'ogc_fid']]
                    if potential_ids: 
                        unique_col = potential_ids[0]

                if unique_col:
                    idx_u_name = f"ux_{target_schema}_{layer.lower()}_{unique_col.lower()}"
                    conn.execute(text(f'CREATE UNIQUE INDEX "{idx_u_name}" ON {view_full_name} ("{unique_col}");'))
                    log_to_file_func(f"INDEX: Unique Index dibuat pada kolom '{unique_col}'.")
                else:
                    log_to_file_func("WARNING: Tidak ada kolom unik ditemukan. Refresh di masa depan akan mengunci tabel!")

                # B. GIST Spatial Index (Untuk Performa MVT)
                idx_gist_name = f"idx_gist_{target_schema}_{layer.lower()}_3857"
                conn.execute(text(f'CREATE INDEX "{idx_gist_name}" ON {view_full_name} USING GIST (geom);'))
                
                log_to_file_func(f"DATABASE: {view_full_name} berhasil dibuat dan di-index.")
                status_action = "created"

        # 4. INVALIDASI CACHE REDIS
        # Setelah DB Commit, hapus tile lama agar perubahan langsung terlihat di map
        cleared_count = clear_layer_cache(layer, source_schema, log_to_file_func)

        return {
            "status": status_action,
            "layer": layer,
            "schema_target": target_schema,
            "cache_cleared": cleared_count
        }

    except Exception as e:
        log_to_file_func(f"🚨 OPTIMIZER ERROR: {str(e)}")
        raise e
