#!/usr/bin/env python3
import os
import sys

# --- 1. INISIALISASI PROJ ---
try:
    import pyproj
    os.environ['PROJ_LIB'] = pyproj.datadir.get_data_dir()
except ImportError:
    pass

import time
import datetime
import subprocess
import shutil
import pandas as pd
import warnings
import boto3
import geopandas as gpd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text, inspect, exc as sa_exc
from botocore.client import Config

# --- KONFIGURASI WARNING ---
warnings.filterwarnings("ignore", category=sa_exc.SAWarning)

# 2. LOAD KONFIGURASI
load_dotenv()

# Database
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')

# Schemas
SCHEMA_DATA = os.getenv("SCHEMA_DATA", "datagis")
SCHEMA_OUT = os.getenv("OUT_SCHEMA", "analisis")
RKP_SCHEMA = os.getenv("RKP_SCHEMA", "rekap")
MASTER_SCHEMA = os.getenv("MASTER_SCHEMA", "kamusdata")

# Tables & Fields
PREFIX_TAB = os.getenv("PREFIX_TAB", "KWS")
TABLE_A = os.getenv("TABLE_A", "KWSHUTAN_AR_250K_DES2025")
FIELD_CATEGORY_A = os.getenv("FIELD_CATEGORY_A", "FUNGSIKWS")
TABLE_B = os.getenv("TABLE_B", "ADM_KAB_KOTA")
FIELD_FILTER_B = os.getenv("FIELD_FILTER_B", "WADMPR")

# Master/Kamus Data Parameters
MASTER_TABLE = os.getenv("MASTER_TABLE")
MASTER_JOIN_FIELD = os.getenv("MASTER_JOIN_FIELD")
SUM_SORT = os.getenv("SUM_SORT")

# Cloud Config
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")
S3_USER = os.getenv("S3_USER", "geobackup")
S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
NC_REMOTE = os.getenv("NC_REMOTE", "nextcloud")
NC_PATH = os.getenv("NC_PATH", "GIS/Export")

# Parameter Dinamis
USE_SUBDIVIDE = os.getenv("SUBDIVIDE", "true").lower() == "true"
MAX_VERTICES = int(os.getenv("MAX_VERTICES", 200))

BASE_OUTPUT = "/app/data/output_gdb"
os.makedirs(BASE_OUTPUT, exist_ok=True)

engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

# --- 3. FUNGSI UTILITY ---
def get_table_columns(engine, schema, table):
    query = text("SELECT column_name FROM information_schema.columns WHERE table_schema = :s AND table_name = :t")
    with engine.connect() as conn:
        result = conn.execute(query, {"s": schema, "t": table})
        forbidden = ('geom', 'geometry', 'shape', 'raw_geom')
        return [row[0] for row in result if row[0].lower() not in forbidden]

# 4. PENANGANAN ARGUMEN
if len(sys.argv) < 2:
    print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = " ".join(sys.argv[1:])
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

OUT_TABLE_NAME = f"{PREFIX_TAB}_{SAFE_NAME}".upper()
GDB_NAME = f"{OUT_TABLE_NAME}.gdb"
SUMMARY_TXT_PATH = os.path.join(BASE_OUTPUT, f"SUMMARY_{OUT_TABLE_NAME}.txt")
FINAL_ZIP_PATH = os.path.join(BASE_OUTPUT, f"{OUT_TABLE_NAME}.gdb.zip")

try:
    DATA_COLUMNS = get_table_columns(engine, SCHEMA_DATA, TABLE_A)
    ST_SELECT_DATA_COLS = ", ".join([f'a."{c}"' for c in DATA_COLUMNS])

    # 5. PROSES SPASIAL (CLIP)
    print(f"⏳ [1/7] Processing Spasial Clip PostGIS: {PROVINSI_TARGET}...")
    mask_sql = f"ST_Subdivide(ST_MakeValid(ST_Union(geom)), {MAX_VERTICES})" if USE_SUBDIVIDE else "ST_MakeValid(ST_Union(geom))"
    method_msg = f"ST_Subdivide (Max Vertices: {MAX_VERTICES})" if USE_SUBDIVIDE else "ST_Union (Metode Standar)"

    with engine.begin() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA_OUT}";'))
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{RKP_SCHEMA}";'))

        query_clip = text(f"""
            WITH mask AS (
                SELECT {mask_sql} as geom_mask FROM "{SCHEMA_DATA}"."{TABLE_B}" WHERE "{FIELD_FILTER_B}" ILIKE :prov
            ),
            intersected AS (
                SELECT {ST_SELECT_DATA_COLS}, ST_Intersection(a.geom, m.geom_mask) as raw_geom
                FROM "{SCHEMA_DATA}"."{TABLE_A}" a
                JOIN mask m ON ST_Intersects(a.geom, m.geom_mask)
            )
            SELECT {", ".join([f'"{c}"' for c in DATA_COLUMNS])},
                   ST_Multi(ST_Force2D(ST_MakeValid(ST_CollectionExtract(raw_geom, 3))))::geometry(MultiPolygon, 4326) as geom,
                   ST_Area(ST_Transform(raw_geom, 54034)) / 10000 as "LUAS_CEA_HA"
            FROM intersected WHERE NOT ST_IsEmpty(raw_geom);
        """)
        gdf = gpd.read_postgis(query_clip, conn, params={"prov": PROVINSI_TARGET}, geom_col='geom')

    if gdf.empty:
        print(f"⚠️ Data tidak ditemukan."); sys.exit(0)

    # 6. STANDARDISASI ATRIBUT & SIMPAN (OPTIMIZED)
    print(f"📊 [2/7] Menerapkan Standardisasi Atribut & Simpan ke DB...")
    new_cols = {col: ('geom' if col.lower() in ['geom', 'geometry'] else col.upper()) for col in gdf.columns}
    gdf = gdf.rename(columns=new_cols)
    
    # Chunksize ditambahkan untuk stabilitas memori
    gdf.to_postgis(OUT_TABLE_NAME, engine, schema=SCHEMA_OUT, if_exists='replace', index=False, chunksize=5000)

    # 7. EKSPOR KE GDB
    print(f"📦 [3/7] Ekspor ke FileGeodatabase...")
    GDB_PATH = os.path.join(BASE_OUTPUT, GDB_NAME)
    if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
    gdf.to_file(GDB_PATH, driver="OpenFileGDB", engine="pyogrio",
                layer_options={"TARGET_ARCGIS_VERSION": "ARCGIS_PRO_3_2_OR_LATER"})

    # 8. SUMMARY DENGAN MASTER JOIN (OPTIMIZED WITH INDEX)
    print(f"📈 [4/7] Generate Summary & Metadata Properties...")
    CAT_FIELD = FIELD_CATEGORY_A.upper()
    inspector = inspect(engine)
    order_clause = f'"{SUM_SORT.upper()}" ASC' if SUM_SORT else '"TOTAL_LUAS_HA" DESC'

    if MASTER_TABLE and MASTER_JOIN_FIELD:
        print(f"🔗 Optimasi Index & Join ke Master Table: {MASTER_TABLE}")
        
        idx_name = f"idx_{MASTER_TABLE}_{MASTER_JOIN_FIELD}".lower()
        with engine.begin() as conn:
            conn.execute(text(f'CREATE INDEX IF NOT EXISTS "{idx_name}" ON "{MASTER_SCHEMA}"."{MASTER_TABLE}" ("{MASTER_JOIN_FIELD.upper()}");'))

        master_cols_info = inspector.get_columns(MASTER_TABLE, schema=MASTER_SCHEMA)
        master_cols_names = [f'b."{c["name"].upper()}"' for c in master_cols_info]
        all_master_cols_str = ", ".join(master_cols_names)

        summary_sql = f"""
            SELECT a."{CAT_FIELD}", {all_master_cols_str}, SUM(a."LUAS_CEA_HA") as "TOTAL_LUAS_HA"
            FROM "{SCHEMA_OUT}"."{OUT_TABLE_NAME}" a
            LEFT JOIN "{MASTER_SCHEMA}"."{MASTER_TABLE}" b ON a."{CAT_FIELD}"::text = b."{MASTER_JOIN_FIELD.upper()}"::text
            GROUP BY a."{CAT_FIELD}", {all_master_cols_str}
            ORDER BY {order_clause}
        """
    else:
        summary_sql = f'SELECT "{CAT_FIELD}", SUM("LUAS_CEA_HA") as "TOTAL_LUAS_HA" FROM "{SCHEMA_OUT}"."{OUT_TABLE_NAME}" GROUP BY "{CAT_FIELD}" ORDER BY {order_clause}'

    with engine.connect() as conn:
        summary_df = pd.read_sql(text(summary_sql), conn)
        summary_df.to_sql(f"SUM_{OUT_TABLE_NAME}", engine, schema=RKP_SCHEMA, if_exists='replace', index=False)
        cols_info = inspector.get_columns(OUT_TABLE_NAME, schema=SCHEMA_OUT)

    # Tulis file SUMMARY.txt
    with open(SUMMARY_TXT_PATH, 'w') as f:
        f.write(f"REKAPITULASI PROSES: {OUT_TABLE_NAME}\n")
        f.write(f"Metode Geometri: {method_msg}\n")
        f.write(f"Waktu: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n" + "-"*80 + "\n")

        fmt_df = summary_df.copy()
        if 'TOTAL_LUAS_HA' in fmt_df.columns:
            fmt_df['TOTAL_LUAS_HA'] = fmt_df['TOTAL_LUAS_HA'].map('{:,.2f}'.format)

        f.write(fmt_df.to_string(index=False) + "\n" + "-"*80 + "\n")
        f.write(f"TOTAL LUAS KESELURUHAN: {summary_df['TOTAL_LUAS_HA'].sum():,.2f} HA\n\n")

        f.write("DETAIL PROPERTIES ATRIBUT (STANDARDISASI UPPERCASE):\n" + "="*80 + "\n")
        f.write(f"{'COLUMN_NAME':<30} | {'TYPE':<25} | {'WIDTH/PREC'}\n" + "-"*80 + "\n")
        for col in cols_info:
            c_name = col['name']
            if c_name.lower() == 'geom': continue
            raw_type = str(col['type']).upper()
            info = col['type'].length if hasattr(col['type'], 'length') and col['type'].length else ""
            f.write(f"{c_name.upper():<30} | {raw_type:<25} | {info}\n")

    # 9. PACKING & UPLOAD
    print(f"🗜️ [5/7] Packing & ☁️ [6/7] Uploading...")
    subprocess.run(["zip", "-rq", f"{OUT_TABLE_NAME}.gdb.zip", GDB_NAME], cwd=BASE_OUTPUT, check=True)

    s3_client = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER, aws_secret_access_key=S3_PASS,
                             config=Config(signature_version='s3v4'))
    
    for path in [FINAL_ZIP_PATH, SUMMARY_TXT_PATH]:
        s3_client.upload_file(path, S3_BUCKET, f"{SCHEMA_OUT}/{datetime.date.today()}/{os.path.basename(path)}")
        subprocess.run(["rclone", "copy", path, f"{NC_REMOTE}:{NC_PATH}"], check=True)
        os.remove(path)

    if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
    print(f"\n✅ PROSES SELESAI dalam {time.time() - start_time:.2f} detik!")

except Exception as e:
    print(f"\n❌ ERROR: {e}"); sys.exit(1)
