#!/usr/bin/env python3
import sys
import os
import time
import datetime
import subprocess
import shutil
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

# 1. LOAD KONFIGURASI
load_dotenv()

DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')

SCHEMA_DATA = os.getenv("SCHEMA_DATA", "datagis")
SCHEMA_OUT  = os.getenv("OUT_SCHEMA", "analisis")
RKP_SCHEMA  = os.getenv("RKP_SCHEMA", "rekap")
MASTER_SCHEMA = os.getenv("MASTER_SCHEMA", "kamusdata")

PREFIX_TAB       = os.getenv("PREFIX_TAB", "KWS")
TABLE_A          = os.getenv("TABLE_A", "KWSHUTAN_AR_250K_DES2025")
FIELD_CATEGORY_A = os.getenv("FIELD_CATEGORY_A", "FUNGSIKWS")
MASTER_TABLE      = os.getenv("MASTER_TABLE", "KODE_KWS")
MASTER_JOIN_FIELD = os.getenv("MASTER_JOIN_FIELD", "KD_KWS")
TABLE_B          = os.getenv("TABLE_B", "ADM_KAB_KOTA")
FIELD_FILTER_B   = os.getenv("FIELD_FILTER_B", "WADMPR")

# Penamaan kolom urutan secara dinamis
SORT_FIELD = f"NOURUT_{PREFIX_TAB}"

BASE_OUTPUT = "/app/data/output_gdb"
os.makedirs(BASE_OUTPUT, exist_ok=True)

engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

def get_table_columns(engine, schema, table):
    query = text("""
        SELECT column_name FROM information_schema.columns
        WHERE table_schema = :schema AND table_name = :table
        ORDER BY ordinal_position
    """)
    with engine.connect() as conn:
        result = conn.execute(query, {"schema": schema, "table": table})
        cols = [row[0] for row in result]
        forbidden = ('geom', 'geometry', 'shape', 'raw_geom', 'poly_geom', 'clean_poly')
        return [c for c in cols if c.lower() not in forbidden]

# 2. PENANGANAN ARGUMEN
if len(sys.argv) < 2:
    print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = " ".join(sys.argv[1:])
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

OUT_TABLE = f"{PREFIX_TAB}_{SAFE_NAME}"
RESULT_TABLE_FULL = f'"{SCHEMA_OUT}"."{OUT_TABLE}"'
GDB_NAME = f"{OUT_TABLE}.gdb"
SUMMARY_TXT_PATH = os.path.join(BASE_OUTPUT, f"SUMMARY_{OUT_TABLE}.txt")
FINAL_ZIP_PATH = os.path.join(BASE_OUTPUT, f"{OUT_TABLE}.gdb.zip")

try:
    DATA_COLUMNS = get_table_columns(engine, SCHEMA_DATA, TABLE_A)
    ST_SELECT_DATA_COLS = ", ".join([f'a."{c}"' for c in DATA_COLUMNS])

    # 3. PROSES SPASIAL (CLIP)
    with engine.begin() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA_OUT}";'))
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{RKP_SCHEMA}";'))
        conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL} CASCADE;'))

        print(f"⏳ [1/4] Processing {PREFIX_TAB} for: {PROVINSI_TARGET}...")
        query_create = text(f"""
            CREATE TABLE {RESULT_TABLE_FULL} AS
            WITH mask AS (
                SELECT ST_MakeValid(ST_Union(geom)) as geom_mask
                FROM "{SCHEMA_DATA}"."{TABLE_B}"
                WHERE "{FIELD_FILTER_B}" ILIKE :prov
            ),
            intersected AS (
                SELECT {ST_SELECT_DATA_COLS}, ST_Intersection(a.geom, m.geom_mask) as raw_geom
                FROM "{SCHEMA_DATA}"."{TABLE_A}" a
                JOIN mask m ON ST_Intersects(a.geom, m.geom_mask)
            )
            SELECT {", ".join([f'"{c}"' for c in DATA_COLUMNS])},
                   ST_Multi(ST_Force2D(ST_MakeValid(ST_CollectionExtract(raw_geom, 3))))::geometry(MultiPolygon, 4326) as geom,
                   ST_Area(ST_Transform(raw_geom, 54034)) / 10000 as "LUAS_CEA_HA"
            FROM intersected WHERE NOT ST_IsEmpty(raw_geom);
        """)
        conn.execute(query_create, {"prov": PROVINSI_TARGET})

    # 4. EKSPOR KE GDB
    print(f"📦 [2/4] Ekspor ke GDB...")
    GDB_PATH = os.path.join(BASE_OUTPUT, GDB_NAME)
    if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
    subprocess.run([
        "ogr2ogr", "-f", "OpenFileGDB", GDB_PATH,
        f"PG:host={DB_HOST} user={DB_USER} dbname={DB_NAME} password={DB_PASS} port={DB_PORT}",
        "-nln", OUT_TABLE, "-nlt", "MULTIPOLYGON", "-skipfailures",
        "-sql", f"SELECT * FROM {RESULT_TABLE_FULL}"
    ], check=True)

    # 5. SUMMARY (Sorted by NOURUT_$PREFIX_TAB)
    print(f"📊 [3/4] Generate Summary (Sorted by {SORT_FIELD})...")
    MASTER_COLS = get_table_columns(engine, MASTER_SCHEMA, MASTER_TABLE)
    
    # Pastikan SORT_FIELD ada di dalam MASTER_COLS
    if SORT_FIELD not in MASTER_COLS:
        print(f"⚠️ Warning: Kolom {SORT_FIELD} tidak ditemukan di master, sorting default ke Luas.")
        order_clause = '"TOTAL_LUAS_HA" DESC'
    else:
        order_clause = f'b."{SORT_FIELD}" ASC'

    ST_SELECT_MASTER = ", ".join([f'b."{c}"' for c in MASTER_COLS if c != MASTER_JOIN_FIELD])
    
    # Grouping berdasarkan semua kolom yang di-select
    group_indices = ", ".join([str(i+1) for i in range(len(MASTER_COLS))])

    query_summary = f"""
        SELECT 
            a."{FIELD_CATEGORY_A}" AS "{MASTER_JOIN_FIELD}", 
            {ST_SELECT_MASTER},
            SUM(a."LUAS_CEA_HA") AS "TOTAL_LUAS_HA"
        FROM {RESULT_TABLE_FULL} a
        LEFT JOIN "{MASTER_SCHEMA}"."{MASTER_TABLE}" b 
            ON a."{FIELD_CATEGORY_A}"::text = b."{MASTER_JOIN_FIELD}"::text
        GROUP BY {group_indices} 
        ORDER BY {order_clause}
    """
    
    summary_df = pd.read_sql(query_summary, engine)
    summary_df.to_sql(f"SUM_{OUT_TABLE}", engine, schema=RKP_SCHEMA, if_exists='replace', index=False)

    with open(SUMMARY_TXT_PATH, 'w') as f:
        f.write(f"REKAPITULASI LUAS: {PREFIX_TAB} {PROVINSI_TARGET}\n")
        f.write(f"Berdasarkan Urutan: {SORT_FIELD}\n")
        f.write(f"Tanggal Cetak: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("-" * 75 + "\n")
        f.write(summary_df.to_string(index=False))
        f.write("\n" + "-" * 75 + "\n")
        f.write(f"TOTAL LUAS: {summary_df['TOTAL_LUAS_HA'].sum():,.2f} HA\n")

    # 6. ZIPPING
    print(f"🗜️ [4/4] Packing Archive...")
    subprocess.run(["zip", "-rq", f"{OUT_TABLE}.gdb.zip", GDB_NAME], cwd=BASE_OUTPUT, check=True)
    if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)

    print(f"\n✅ SELESAI! File: {SUMMARY_TXT_PATH}")

except Exception as e:
    print(f"\n❌ ERROR: {e}"); sys.exit(1)
