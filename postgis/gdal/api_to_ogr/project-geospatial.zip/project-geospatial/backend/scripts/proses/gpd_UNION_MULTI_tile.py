#!/usr/bin/env python3
import os
import sys
import time
import math
import logging
import shutil
import subprocess
import datetime
import warnings
import boto3
import geopandas as gpd
from datetime import timedelta
from concurrent.futures import ProcessPoolExecutor
from sqlalchemy import create_engine, text, inspect, exc as sa_exc
from botocore.client import Config
from dotenv import load_dotenv

# --- KONFIGURASI WARNING & LOGGING ---
warnings.filterwarnings("ignore", category=sa_exc.SAWarning)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- 1. PARAMETER & ENV ---
load_dotenv()
TILE_SIZE = 0.5
AREA_THRESHOLD = 0.00000001
SRID_CEA = 54034

DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
OUT_SCHEMA = os.getenv("OUT_SCHEMA", "analisis")

S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")
S3_USER = os.getenv("S3_USER", "geobackup")
S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")

BASE_OUTPUT = "/app/data/output_gdb"
os.makedirs(BASE_OUTPUT, exist_ok=True)
MAX_WORKERS = os.cpu_count()

def get_engine(is_worker=True):
    url = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    return create_engine(url, pool_size=1, max_overflow=0) if is_worker else create_engine(url)

def check_and_report_index(engine, schema, table):
    """Memastikan indeks GIST tersedia untuk join spasial cepat."""
    query = text("""
        SELECT count(*) FROM pg_class t
        JOIN pg_index ix ON t.oid = ix.indrelid
        JOIN pg_class i ON i.oid = ix.indexrelid
        JOIN pg_attribute a ON a.attrelid = t.oid AND a.attnum = ANY(ix.indkey)
        JOIN pg_namespace n ON n.oid = t.relnamespace
        WHERE n.nspname = :schema AND t.relname = :table 
          AND a.attname IN ('geom', 'geometry')
          AND (SELECT amname FROM pg_am WHERE oid = i.relam) = 'gist';
    """)
    with engine.begin() as conn:
        count = conn.execute(query, {"schema": schema, "table": table}).scalar()
        if count == 0:
            print(f"⚠️  Membuat indeks GIST pada {schema}.{table}...")
            conn.execute(text(f'CREATE INDEX IF NOT EXISTS "{table}_gidx" ON "{schema}"."{table}" USING GIST(geom);'))
            conn.execute(text(f'ANALYZE "{schema}"."{table}";'))

def process_tile_union(tile_coords, table_a, table_b, out_table, names_a, names_b, null_a, null_b):
    """Fungsi worker untuk memproses Union dua tabel per ubin."""
    xmin, ymin, xmax, ymax = tile_coords
    engine = get_engine(is_worker=True)
    union_sql = text(f"""
        INSERT INTO "{OUT_SCHEMA}"."{out_table}"
        WITH
        tile_boundary AS (SELECT ST_MakeEnvelope(:x1, :y1, :x2, :y2, 4326) as geom),
        a_clipped AS (
            SELECT {", ".join(['"' + n + '"' for n in names_a])},
                   ST_Multi(ST_CollectionExtract(ST_Intersection(a.geom, t.geom), 3)) as geom
            FROM "{OUT_SCHEMA}"."{table_a}" a, tile_boundary t WHERE ST_Intersects(a.geom, t.geom)
        ),
        b_clipped AS (
            SELECT {", ".join(['"' + n + '"' for n in names_b])},
                   ST_Multi(ST_CollectionExtract(ST_Intersection(b.geom, t.geom), 3)) as geom
            FROM "{OUT_SCHEMA}"."{table_b}" b, tile_boundary t WHERE ST_Intersects(b.geom, t.geom)
        )
        -- INTERSECTION
        SELECT {", ".join(['a."' + n + '"' for n in names_a])}, {", ".join(['b."' + n + '"' for n in names_b])},
               ST_Multi(ST_CollectionExtract(ST_Intersection(a.geom, b.geom), 3)) as geom
        FROM a_clipped a JOIN b_clipped b ON ST_Intersects(a.geom, b.geom)
        UNION ALL
        -- DIFFERENCE A (A but not B)
        SELECT {", ".join(['a."' + n + '"' for n in names_a])}, {null_b},
               ST_Multi(ST_CollectionExtract(ST_Difference(a.geom, COALESCE((SELECT ST_Union(bx.geom) FROM b_clipped bx WHERE ST_Intersects(bx.geom, a.geom)), ST_GeomFromText('GEOMETRYCOLLECTION EMPTY', 4326))), 3))
        FROM a_clipped a
        UNION ALL
        -- DIFFERENCE B (B but not A)
        SELECT {null_a}, {", ".join(['b."' + n + '"' for n in names_b])},
               ST_Multi(ST_CollectionExtract(ST_Difference(b.geom, COALESCE((SELECT ST_Union(ax.geom) FROM a_clipped ax WHERE ST_Intersects(ax.geom, b.geom)), ST_GeomFromText('GEOMETRYCOLLECTION EMPTY', 4326))), 3))
        FROM b_clipped b;
    """)
    try:
        with engine.begin() as conn:
            conn.execute(union_sql, {"x1": xmin, "y1": ymin, "x2": xmax, "y2": ymax})
        return True
    except Exception: return False

def main():
    if len(sys.argv) < 2:
        print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
        sys.exit(1)

    PROVINSI_TARGET = " ".join(sys.argv[1:]).strip()
    SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
    
    layers_env = os.getenv("LAYERS_PREFIX", "KWS,PL,DAS")
    LAYERS_PREFIX = [p.strip().upper() for p in layers_env.split(",")]
    
    if len(LAYERS_PREFIX) < 2:
        print("❌ Butuh minimal 2 prefix untuk melakukan UNION."); sys.exit(1)

    all_target_tables = [f"{p}_{SAFE_NAME}" for p in LAYERS_PREFIX]
    FINAL_OUT_TABLE = f"UNION_{'_'.join(LAYERS_PREFIX)}_{SAFE_NAME}"[:62]
    
    main_engine = get_engine(is_worker=False)
    inspector = inspect(main_engine)

    print("-" * 85)
    print(f"🧩 CHAIN UNION ENGINE v6.7 | {PROVINSI_TARGET}")
    print(f"Layers: {' + '.join(all_target_tables)}")
    print("-" * 85)

    start_time_total = time.time()

    # Inisialisasi: Gunakan tabel pertama sebagai base
    current_temp_table = all_target_tables[0]

    for i in range(1, len(all_target_tables)):
        next_table = all_target_tables[i]
        step_out_table = f"tmp_union_step_{i}"
        
        print(f"\n🔄 [STEP {i}] Menggabungkan {current_temp_table} dengan {next_table}...")
        
        # Validasi Indeks
        check_and_report_index(main_engine, OUT_SCHEMA, current_temp_table)
        check_and_report_index(main_engine, OUT_SCHEMA, next_table)

        # Hitung Tile Grid berdasarkan extent gabungan kedua tabel
        with main_engine.begin() as conn:
            bounds = conn.execute(text(f"""
                SELECT MIN(xmin), MIN(ymin), MAX(xmax), MAX(ymax) FROM (
                    SELECT ST_XMin(ext) as xmin, ST_YMin(ext) as ymin, ST_XMax(ext) as xmax, ST_YMax(ext) as ymax 
                    FROM (SELECT ST_Extent(geom) as ext FROM "{OUT_SCHEMA}"."{current_temp_table}") a
                    UNION ALL
                    SELECT ST_XMin(ext), ST_YMin(ext), ST_XMax(ext), ST_YMax(ext)
                    FROM (SELECT ST_Extent(geom) as ext FROM "{OUT_SCHEMA}"."{next_table}") b
                ) t
            """)).fetchone()

            tile_query = text(f"""
                SELECT ST_XMin(g), ST_YMin(g), ST_XMax(g), ST_YMax(g) FROM (
                    SELECT ST_MakeEnvelope(x, y, x + {TILE_SIZE}, y + {TILE_SIZE}, 4326) as g 
                    FROM generate_series({math.floor(bounds[0])}, {math.ceil(bounds[2])}, {TILE_SIZE}) x 
                    CROSS JOIN generate_series({math.floor(bounds[1])}, {math.ceil(bounds[3])}, {TILE_SIZE}) y
                ) grid 
                WHERE EXISTS (SELECT 1 FROM "{OUT_SCHEMA}"."{current_temp_table}" WHERE ST_Intersects(geom, g)) 
                   OR EXISTS (SELECT 1 FROM "{OUT_SCHEMA}"."{next_table}" WHERE ST_Intersects(geom, g))
            """)
            tiles = conn.execute(tile_query).fetchall()
            total_tiles = len(tiles)

            # Metadata Kolom
            cols_a = [c for c in inspector.get_columns(current_temp_table, schema=OUT_SCHEMA) if c['name'].lower() not in ['geom','geometry']]
            cols_b = [c for c in inspector.get_columns(next_table, schema=OUT_SCHEMA) if c['name'].lower() not in ['geom','geometry']]
            names_a = [c["name"] for c in cols_a]
            names_b = [c["name"] for c in cols_b if c["name"] not in names_a]

            # Re-create Temp Table per Step
            conn.execute(text(f'DROP TABLE IF EXISTS "{OUT_SCHEMA}"."{step_out_table}" CASCADE;'))
            col_defs = [f'"{c["name"]}" {c["type"]}' for c in cols_a] + [f'"{c["name"]}" {c["type"]}' for c in cols_b if c["name"] not in names_a]
            conn.execute(text(f'CREATE TABLE "{OUT_SCHEMA}"."{step_out_table}" ({", ".join(col_defs)}, geom geometry(MultiPolygon, 4326));'))

        # Eksekusi Paralel per Tile
        null_a, null_b = ", ".join(['NULL' for _ in names_a]), ", ".join(['NULL' for _ in names_b])
        with ProcessPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = [executor.submit(process_tile_union, t, current_temp_table, next_table, step_out_table, names_a, names_b, null_a, null_b) for t in tiles]
            for idx, f in enumerate(futures):
                if (idx + 1) % 20 == 0 or (idx + 1) == total_tiles:
                    print(f"   Progress: {idx + 1}/{total_tiles} tile selesai...")

        # Pembersihan step: hapus tabel perantara sebelumnya (kecuali tabel input asli)
        if current_temp_table.startswith("tmp_union_step_"):
            with main_engine.begin() as conn:
                conn.execute(text(f'DROP TABLE IF EXISTS "{OUT_SCHEMA}"."{current_temp_table}" CASCADE;'))
        
        current_temp_table = step_out_table

    # FINALISASI: Rename step terakhir menjadi nama tabel final
    print("\n🏁 Finalisasi Data...")
    with main_engine.begin() as conn:
        conn.execute(text(f'DROP TABLE IF EXISTS "{OUT_SCHEMA}"."{FINAL_OUT_TABLE}" CASCADE;'))
        conn.execute(text(f'ALTER TABLE "{OUT_SCHEMA}"."{current_temp_table}" RENAME TO "{FINAL_OUT_TABLE}";'))
        conn.execute(text(f'DELETE FROM "{OUT_SCHEMA}"."{FINAL_OUT_TABLE}" WHERE ST_IsEmpty(geom) OR ST_Area(geom) < {AREA_THRESHOLD};'))
        conn.execute(text(f'ALTER TABLE "{OUT_SCHEMA}"."{FINAL_OUT_TABLE}" ADD COLUMN IF NOT EXISTS "LUAS_HA" float8;'))
        conn.execute(text(f'UPDATE "{OUT_SCHEMA}"."{FINAL_OUT_TABLE}" SET "LUAS_HA" = ST_Area(ST_Transform(geom, {SRID_CEA})) / 10000;'))

    # EXPORT KE GDB & S3
    GDB_NAME = f"{FINAL_OUT_TABLE}.gdb"
    GDB_PATH = os.path.join(BASE_OUTPUT, GDB_NAME)
    ZIP_PATH = os.path.join(BASE_OUTPUT, f"{FINAL_OUT_TABLE}.gdb.zip")

    print(f"📦 Exporting to FileGDB: {GDB_NAME}...")
    if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
    gdf = gpd.read_postgis(f'SELECT * FROM "{OUT_SCHEMA}"."{FINAL_OUT_TABLE}"', main_engine, geom_col='geom')
    gdf.to_file(GDB_PATH, driver="OpenFileGDB", engine="pyogrio", layer=FINAL_OUT_TABLE)

    subprocess.run(["zip", "-rq", os.path.basename(ZIP_PATH), GDB_NAME], cwd=BASE_OUTPUT, check=True)
    
    s3 = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER, aws_secret_access_key=S3_PASS, config=Config(signature_version='s3v4'))
    s_key = f"{OUT_SCHEMA}/{datetime.date.today()}/{os.path.basename(ZIP_PATH)}"
    s3.upload_file(ZIP_PATH, S3_BUCKET, s_key)

    # Cleanup Local
    if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
    if os.path.exists(ZIP_PATH): os.remove(ZIP_PATH)

    durasi = str(timedelta(seconds=round(time.time() - start_time_total)))
    print("-" * 85)
    print(f"✅ CHAIN UNION SELESAI! Waktu Total: {durasi}")
    print(f"S3: {s_key}")

if __name__ == "__main__":
    main()
