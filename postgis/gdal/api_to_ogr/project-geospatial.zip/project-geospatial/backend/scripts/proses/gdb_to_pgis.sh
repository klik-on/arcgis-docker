#!/bin/bash
set -e

# Ambil nama layer dari argumen pertama
LAYER_NAME=$1
DATA_DIR="/app/data"

if [ -z "$LAYER_NAME" ]; then
  echo "❌ Error: Nama layer tidak disertakan!"
  exit 1
fi

OUTPUT_GDB="${DATA_DIR}/${LAYER_NAME}.gdb"
ZIP_PATH="${DATA_DIR}/${LAYER_NAME}.gdb.zip"

echo "📂 Memproses File: ${ZIP_PATH}"

# 1. Ekstrak ZIP
if [ -f "$ZIP_PATH" ]; then
    unzip -o "$ZIP_PATH" -d "$DATA_DIR"
else
    echo "❌ File ZIP tidak ditemukan!"
    exit 1
fi

# 2. Cari nama layer di dalam GDB
# Seringkali nama layer di dalam GDB berbeda dengan nama file ZIP
INTERNAL_LAYERS=$(ogrinfo -q "$OUTPUT_GDB" | grep -oE '^Layer: .+' | cut -d' ' -f2)

# 3. Import ke PostGIS
for LAYER in $INTERNAL_LAYERS; do
  echo "---------------------------------------------------"
  echo "📥 Mengimpor Layer: $LAYER"
  
  ogr2ogr -f "PostgreSQL" \
    PG:"host=${DB_HOST} port=${DB_PORT} dbname=${DB_NAME} user=${DB_USER} password=${DB_PASS}" \
    "$OUTPUT_GDB" \
    "$LAYER" \
    -nlt PROMOTE_TO_MULTI \
    -nln "$LAYER" \
    -dim 2 \
    -lco SCHEMA=${DB_SCHEMA} \
    -lco GEOMETRY_NAME=geom \
    -lco SPATIAL_INDEX=GIST \
    -lco LAUNDER=NO \
    -lco OVERWRITE=YES \
    -t_srs EPSG:4326 \
    -progress \
    --config OGR_ENABLE_CURVE_REDUCTION YES \
    --config OGR_FORCE_GML_MULTISURFACE_AS_MULTIPOLYGON YES \
    --config OGR_ORGANIZE_POLYGONS SKIP  # <--- Tambahkan ini
done

# 4. Bersihkan folder GDB setelah selesai
rm -rf "$OUTPUT_GDB"
echo "---------------------------------------------------"
echo "✅ Migrasi Selesai: $(date)"
