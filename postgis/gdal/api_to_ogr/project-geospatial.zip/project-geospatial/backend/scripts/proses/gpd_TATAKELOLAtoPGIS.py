#!/usr/bin/env python3
import os
# Paksa GDAL untuk melewati organisasi poligon demi kecepatan
os.environ['OGR_ORGANIZE_POLYGONS'] = 'SKIP'
import sys
import json
import zipfile
import shutil
import requests
import logging
import time
import datetime
import warnings
import geopandas as gpd
import pyogrio
from shapely import force_2d
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL
from dotenv import load_dotenv

# --- 1. SETUP & CONFIG ---
warnings.filterwarnings("ignore", category=UserWarning)
load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

def get_token(url, user, password):
    logger.info(f"🔑 Auth SIGAP: {url}")
    try:
        res = requests.post(f"{url}/api/auth/signin", 
                           json={"username": user, "password": password}, 
                           timeout=30)
        res.raise_for_status()
        return res.json().get("accessToken")
    except Exception as e:
        logger.error(f"❌ Login Gagal: {e}")
        return None

def download_and_migrate(uuid, layer_input, config):
    start_time = time.time()
    token = get_token(config['sigap_url'], config['sigap_user'], config['sigap_pass'])
    if not token: return

    # Standarisasi Nama
    base_name = layer_input.replace(".gdb.zip", "").replace(".zip", "")
    data_dir = "/app/data/output_sigap"
    os.makedirs(data_dir, exist_ok=True)
    
    zip_path = os.path.join(data_dir, f"{base_name}_temp.zip")
    extract_path = os.path.join(data_dir, f"ext_{base_name}")

    try:
        # 1. DOWNLOAD
        logger.info(f"📥 Downloading UUID: {uuid}")
        headers = {"x-access-token": token}
        r = requests.get(f"{config['sigap_url']}/api/data-produsen/unduhFile/{uuid}", 
                         headers=headers, stream=True, timeout=300)
        r.raise_for_status()
        with open(zip_path, 'wb') as f:
            for chunk in r.iter_content(8192): f.write(chunk)
            
        # 2. EXTRACT
        with zipfile.ZipFile(zip_path, 'r') as z:
            z.extractall(extract_path)
        
        found_gdb = next((os.path.join(r, d) for r, dirs, _ in os.walk(extract_path) 
                          for d in dirs if d.lower().endswith(".gdb")), None)
        if not found_gdb:
            logger.error("❌ GDB tidak ditemukan di dalam ZIP.")
            return

        # 3. DATABASE ENGINE
        db_url = f"postgresql+psycopg://{config['db_user']}:{config['db_pass']}@{config['db_host']}:{config['db_port']}/{config['db_name']}"
        engine = create_engine(db_url)
        schema = config['db_schema']

        # 4. PROCESSING LAYERS
        layers = pyogrio.list_layers(found_gdb)
        for layer_name in layers[:, 0]:
            logger.info(f"⏳ Processing Layer: {layer_name}")
            gdf = gpd.read_file(found_gdb, layer=layer_name, engine="pyogrio")
            if gdf.empty: continue

            # --- Sinkronisasi Sesuai skrip GDBtoPGIS ---
            # A. Force 2D & Rename Geometry
            gdf.geometry = gdf.geometry.apply(force_2d)
            if gdf.geometry.name != 'geom': 
                gdf = gdf.rename_geometry('geom')
            
            # B. Standarisasi Field: HURUF BESAR kecuali geom
            gdf.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf.columns]
            
            # C. CRS Check
            gdf = gdf.to_crs(epsg=4326) if gdf.crs else gdf.set_crs(epsg=4326)

            # D. Table Naming (HURUF BESAR)
            final_table = layer_name.upper()
            temp_table = f"{final_table.lower()}_temp"
            idx_final = f"idx_{final_table.lower()}_geom"

            # 5. UPLOAD TO POSTGIS
            gdf.to_postgis(
                name=temp_table,
                con=engine,
                schema=schema,
                if_exists='replace',
                index=False
            )

            with engine.begin() as conn:
                # Bypass type constraint awal
                conn.execute(text(f'ALTER TABLE "{schema}"."{temp_table}" ALTER COLUMN geom TYPE geometry;'))

                # Deteksi Tipe Geometri untuk ST_CollectionExtract
                res = conn.execute(text(f'SELECT ST_GeometryType(geom) FROM "{schema}"."{temp_table}" WHERE geom IS NOT NULL LIMIT 1')).first()
                geom_type_raw = res[0] if res else "ST_MultiPolygon"

                t_type, e_code = ("MultiPolygon", 3) if "Polygon" in geom_type_raw else \
                                 (("MultiPoint", 1) if "Point" in geom_type_raw else ("MultiLineString", 2))

                # SQL Processing (Cleaning, Fix Multi, Swap Table, Indexing)
                conn.execute(text(f"""
                    UPDATE "{schema}"."{temp_table}"
                    SET geom = ST_Multi(ST_CollectionExtract(ST_MakeValid(geom), {e_code}))
                    WHERE geom IS NOT NULL;

                    ALTER TABLE "{schema}"."{temp_table}"
                    ALTER COLUMN geom TYPE geometry({t_type}, 4326) USING ST_SetSRID(geom, 4326);

                    DROP INDEX IF EXISTS "{schema}"."{idx_final}";
                    DROP TABLE IF EXISTS "{schema}"."{final_table}" CASCADE;
                    ALTER TABLE "{schema}"."{temp_table}" RENAME TO "{final_table}";

                    CREATE INDEX "{idx_final}" ON "{schema}"."{final_table}" USING GIST (geom);
                    GRANT SELECT ON TABLE "{schema}"."{final_table}" TO PUBLIC;
                """))
            
            logger.info(f"✅ Success: {final_table} ({t_type})")

    except Exception as e:
        logger.error(f"❌ Error during migration: {e}")
    finally:
        if os.path.exists(extract_path): shutil.rmtree(extract_path)
        if os.path.exists(zip_path): os.remove(zip_path)
        if 'engine' in locals(): engine.dispose()
        duration = str(datetime.timedelta(seconds=int(time.time()-start_time)))
        logger.info(f"🏁 Finished in {duration}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        logger.error("❌ Membutuhkan input JSON atau Argumen Posisi!")
        sys.exit(1)

    input_param = sys.argv[1]
    uuid_val = None
    layer_val = None
    env_over = {}

    # Support JSON Payload
    if input_param.strip().startswith('{'):
        try:
            data = json.loads(input_param)
            uuid_val = data.get("args", [])[0] if data.get("args") else None
            layer_val = data.get("args", [])[1] if len(data.get("args", [])) > 1 else None
            env_over = data.get("env", {})
        except: pass
    else:
        # Support Positional Args
        uuid_val = sys.argv[1]
        layer_val = sys.argv[2] if len(sys.argv) > 2 else "LAYER_SIGAP"

    if not uuid_val:
        logger.error("❌ UUID tidak ditemukan.")
        sys.exit(1)

    config = {
        "sigap_url": env_over.get("SIGAP_URL", os.getenv("SIGAP_URL")),
        "sigap_user": env_over.get("SIGAP_USER", os.getenv("SIGAP_USER")),
        "sigap_pass": env_over.get("SIGAP_PASS", os.getenv("SIGAP_PASS")),
        "db_user": os.getenv("DB_USER"),
        "db_pass": os.getenv("DB_PASS"),
        "db_host": os.getenv("DB_HOST"),
        "db_port": os.getenv("DB_PORT", "5432"),
        "db_name": os.getenv("DB_NAME"),
        "db_schema": env_over.get("DB_SCHEMA", os.getenv("SCHEMA_DATA", "datagis"))
    }

    download_and_migrate(uuid_val, layer_val, config)
