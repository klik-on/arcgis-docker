#!/bin/bash
set -e

# === 1. PENGATURAN ARGUMEN DINAMIS ===
# Mengambil argumen pertama ($1) sebagai LAYER_NAME
# Jika kosong, skrip akan berhenti dan memberikan instruksi
LAYER_NAME=$1

if [ -z "$LAYER_NAME" ]; then
    echo "❌ Error: Nama layer tidak ditentukan."
    echo "💡 Penggunaan: $0 nama_tabel_anda"
    echo "Contoh: $0 admin_desa_indonesia"
    exit 1
fi

# === 2. KONFIGURASI DIREKTORI & DB ===
DATA_DIR="/app/data"
OUTPUT_GDB="${DATA_DIR}/${LAYER_NAME}.gdb"
ZIP_PATH="${DATA_DIR}/${LAYER_NAME}.gdb.zip"

# Konfigurasi Database (Gunakan Environment Variables jika ada)
PG_HOST="${PG_HOST:-172.16.3.106}"
PG_PORT="${PG_PORT:-8057}"
PG_DB="${PG_DB:-dkss_dev}"
PG_USER="${PG_USER:-postgres}"
PG_PASS="${PG_PASS:-DSS@2024!!}"
PG_SCHEMA="${PG_SCHEMA:-public}"

PG_CONN="PG:host=${PG_HOST} port=${PG_PORT} dbname=${PG_DB} user=${PG_USER} password=${PG_PASS}"

# === 3. START ENGINE ===
START_TIME=$(date +%s)
DRIVER="OpenFileGDB"

echo "🚀 Memulai Export Layer: [${LAYER_NAME}]"
echo "📂 Lokasi Output: ${ZIP_PATH}"
echo "🐘 Menghubungi: ${PG_HOST}:${PG_PORT}"

# Bersihkan folder lama jika ada
mkdir -p "$DATA_DIR"
rm -rf "$OUTPUT_GDB"

# === 4. EKSEKUSI OGR2OGR (FIXED VERSION) ===
# Menggunakan -nlt MULTIPOLYGON untuk menghindari "Unsupported geometry type"
# Menggunakan -gt 50000 untuk efisiensi penulisan disk
ogr2ogr \
  -f "$DRIVER" \
  "$OUTPUT_GDB" \
  "$PG_CONN" \
  -sql "SELECT * FROM ${PG_SCHEMA}.${LAYER_NAME}" \
  -nln "$LAYER_NAME" \
  -nlt MULTIPOLYGON \
  -t_srs EPSG:4326 \
  -gt 50000 \
  -progress \
  --config GDAL_CACHEMEM 512 \
  --config OGR_ORGANIZE_POLYGONS SKIP

# === 5. KOMPRESI & CLEANUP ===
if [ -d "$OUTPUT_GDB" ]; then
    echo "📦 Mengompres hasil ke ZIP..."
    # cd ke data_dir agar struktur folder dalam ZIP bersih (langsung .gdb)
    (cd "$DATA_DIR" && zip -r -q "$(basename "$ZIP_PATH")" "$(basename "$OUTPUT_GDB")")
    
    # Hapus folder GDB mentah
    rm -rf "$OUTPUT_GDB"
    
    END_TIME=$(date +%s)
    DURATION=$((END_TIME - START_TIME))
    
    echo "------------------------------------------------"
    echo "✅ PROSES BERHASIL!"
    echo "🕒 Durasi: $((DURATION / 60)) menit $((DURATION % 60)) detik"
    echo "📏 Ukuran ZIP: $(du -h "$ZIP_PATH" | cut -f1)"
    echo "------------------------------------------------"
else
    echo "❌ Gagal menghasilkan FileGDB."
    exit 1
fi
