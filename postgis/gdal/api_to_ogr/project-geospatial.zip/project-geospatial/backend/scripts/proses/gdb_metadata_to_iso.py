import os
from lxml import etree
from osgeo import ogr
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ISO_CONVERTER")

def convert_esri_to_iso(gdb_path, layer_name, xslt_path, output_path):
    try:
        # 1. Ekstrak dari GDB
        driver = ogr.GetDriverByName("OpenFileGDB")
        ds = driver.Open(gdb_path, 0)
        if not ds:
            raise Exception("GDB tidak dapat dibuka")
        
        sql = f"SELECT Documentation FROM GDB_Items WHERE Name = '{layer_name}'"
        res = ds.ExecuteSQL(sql)
        feature = res.GetNextFeature()
        if not feature:
            raise Exception(f"Layer {layer_name} tidak ditemukan di GDB_Items")
        
        esri_xml_raw = feature.GetField("Documentation")
        
        # 2. Persiapkan XSLT dengan Access Control untuk file lokal (import/include)
        # lxml butuh parser dengan access ke network/file untuk 'include'
        parser = etree.XMLParser(remove_blank_text=True, resolve_entities=True)
        xslt_doc = etree.parse(xslt_path, parser)
        
        # 'network=False' tapi 'read_file=True' secara default untuk security
        transform = etree.XSLT(xslt_doc)
        
        # 3. Jalankan Transformasi
        source_xml = etree.fromstring(esri_xml_raw.encode('utf-8'))
        result_xml = transform(source_xml)
        
        # 4. Simpan hasil
        with open(output_path, 'wb') as f:
            f.write(etree.tostring(result_xml, pretty_print=True, xml_declaration=True, encoding='UTF-8'))
            
        logger.info(f"✅ Transformasi Berhasil: {output_path}")

    except Exception as e:
        logger.error(f"❌ Error: {str(e)}")

if __name__ == "__main__":
    # Sesuaikan path dengan struktur tree Anda
    GDB = "/app/data/my_data.gdb"
    LAYER = "Batas_Administrasi"
    XSLT_FILE = "/app/resources/metadata/Export/ISO19139_Full_Stack.xslt"
    OUT = "/app/data/metadata_iso.xml"
    
    convert_esri_to_iso(GDB, LAYER, XSLT, OUT)
