import os
import argparse
import logging
import zipfile
import shutil
import tempfile
from lxml import etree
from osgeo import ogr

# Konfigurasi Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("ISO_CONVERTER")

def convert_esri_to_iso(zip_path, layer_name, xslt_path, output_path):
    temp_dir = tempfile.mkdtemp()
    try:
        # 1. Validasi Keberadaan File Input
        if not os.path.exists(zip_path):
            raise FileNotFoundError(f"File ZIP tidak ditemukan: {zip_path}")
        if not os.path.exists(xslt_path):
            raise FileNotFoundError(f"File XSLT tidak ditemukan: {xslt_path}")

        # 2. Ekstrak ZIP ke Folder Temporer
        logger.info(f"📦 Mengekstrak {zip_path}...")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)

        # Cari folder .gdb di dalam hasil ekstrak
        gdb_folder = None
        for root, dirs, files in os.walk(temp_dir):
            for d in dirs:
                if d.lower().endswith(".gdb"):
                    gdb_folder = os.path.join(root, d)
                    break
        
        if not gdb_folder:
            raise Exception("Tidak ditemukan folder .gdb di dalam file ZIP.")

        # 3. Ekstrak Metadata dari GDB menggunakan OGR
        driver = ogr.GetDriverByName("OpenFileGDB")
        ds = driver.Open(gdb_folder, 0)
        if not ds:
            raise Exception("GDB tidak dapat dibuka. Pastikan format GDB valid.")

        sql = f"SELECT Documentation FROM GDB_Items WHERE Name = '{layer_name}'"
        res = ds.ExecuteSQL(sql)
        feature = res.GetNextFeature()
        
        if not feature:
            raise Exception(f"Layer '{layer_name}' tidak ditemukan di metadata GDB.")

        esri_xml_raw = feature.GetField("Documentation")
        if not esri_xml_raw:
            raise Exception(f"Metadata untuk '{layer_name}' kosong.")

        # 4. Persiapkan XSLT Transformer
        parser = etree.XMLParser(remove_blank_text=True, resolve_entities=True)
        xslt_doc = etree.parse(xslt_path, parser)
        transform = etree.XSLT(xslt_doc)

        # 5. Jalankan Transformasi
        source_xml = etree.fromstring(esri_xml_raw.encode('utf-8'))
        result_xml = transform(source_xml)

        # 6. Simpan Hasil
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, 'wb') as f:
            f.write(etree.tostring(result_xml, pretty_print=True, xml_declaration=True, encoding='UTF-8'))

        logger.info(f"✅ BERHASIL: ISO Metadata disimpan di -> {output_path}")

    except Exception as e:
        logger.error(f"❌ GAGAL: {str(e)}")
    finally:
        # Bersihkan folder temporer
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
            logger.info("🧹 Folder temporer dibersihkan.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Konversi Metadata ESRI GDB (ZIP) ke ISO 19139")
    
    parser.add_argument("--input", required=True, help="Path ke file LAYER.gdb.zip")
    parser.add_argument("--layer", required=True, help="Nama layer di dalam GDB")
    parser.add_argument("--xslt", default="/app/resources/metadata/Export/ISO19139_Full_Stack.xslt", help="Path ke file XSLT")
    parser.add_argument("--out", help="Path output XML")

    args = parser.parse_args()

    # Default output path jika tidak diisi
    output_file = args.out if args.out else f"/app/data/{args.layer}_iso.xml"

    convert_esri_to_iso(args.input, args.layer, args.xslt, output_file)
