#!/usr/bin/env python3
import sys
import os
import time
from sqlalchemy import create_engine, text, inspect
from dotenv import load_dotenv

# --- 1. UTILITY: FORMAT WAKTU ---
def format_duration(seconds):
    minutes = int(seconds // 60)
    secs = seconds % 60
    if minutes > 0:
        return f"{minutes} Menit {secs:.2f} Detik"
    return f"{secs:.2f} Detik"

# --- 2. INISIALISASI & KONFIGURASI ---
load_dotenv()
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
OUT_SCHEMA = os.getenv("OUT_SCHEMA", "analisis")

engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

if len(sys.argv) < 2:
    print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = " ".join(sys.argv[1:]).strip()
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

layers_env = os.getenv("LAYERS_PREFIX", "KWS,PL")
LAYERS_PREFIX = [p.strip().upper() for p in layers_env.split(",")]
INPUT_TABLES = [f"{p}_{SAFE_NAME}" for p in LAYERS_PREFIX]
total_steps = len(INPUT_TABLES) + 1 # Inisialisasi + Loop Layer + Finalisasi

raw_out_name = f"{'_'.join(LAYERS_PREFIX)}_{SAFE_NAME}"
OUT_TABLE = raw_out_name[:62].rstrip('_') 

print("-" * 85)
print(f"🚀 GEOSPATIAL OVERLAY ENGINE v4 (OPTIMIZED: SUBDIVIDE & SIMPLIFY)")
print(f"📍 Wilayah: {PROVINSI_TARGET}")
print(f"🔗 Total Layer: {len(INPUT_TABLES)}")
print("-" * 85)

try:
    inspector = inspect(engine)
    existing_tables = inspector.get_table_names(schema=OUT_SCHEMA)
    
    missing_tables = [t for t in INPUT_TABLES if t not in existing_tables]
    if missing_tables:
        print(f"❌ ERROR: Tabel tidak ditemukan di schema '{OUT_SCHEMA}': {missing_tables}")
        sys.exit(1)

    with engine.begin() as conn:
        # --- a. STEP 1: INISIALISASI DENGAN SUBDIVIDE ---
        # Subdivide memecah poligon raksasa menjadi kepingan kecil agar ST_Intersection jauh lebih cepat.
        first_table = INPUT_TABLES[0]
        print(f"⏳ [1/{total_steps}] Inisialisasi & Subdividing Base: {first_table}...")
        conn.execute(text("DROP TABLE IF EXISTS temp_overlay CASCADE;"))
        conn.execute(text(f"""
            CREATE TEMP TABLE temp_overlay AS 
            SELECT *, ST_Subdivide(ST_MakeValid(geom), 255) as geom_res 
            FROM "{OUT_SCHEMA}"."{first_table}";
            CREATE INDEX idx_tmp_geom ON temp_overlay USING GIST(geom_res);
        """))

        # --- b. STEP 2: LOOPING INTERSECTION ---
        for i in range(1, len(INPUT_TABLES)):
            next_table = INPUT_TABLES[i]
            curr_time = time.time()
            progress = ((i + 1) / total_steps) * 100
            print(f"⏳ [{i+1}/{total_steps}] Overlaying {next_table} ({progress:.0f}%)...", end=" ", flush=True)
            
            # Anti-Collision Logic
            res_cols_query = conn.execute(text("SELECT * FROM temp_overlay LIMIT 0"))
            existing_cols = [col for col in res_cols_query.keys() if col.lower() not in ['geom_res', 'geom']]
            select_a = ", ".join([f'a."{c}"' for c in existing_cols])
            
            existing_col_names_upper = [c.upper() for c in existing_cols]
            next_cols = inspector.get_columns(next_table, schema=OUT_SCHEMA)
            
            new_cols_to_add = []
            for c in next_cols:
                c_name = c['name']
                if c_name.upper() not in existing_col_names_upper and c_name.lower() not in ['geom', 'geometry', 'shape']:
                    new_cols_to_add.append(f'b."{c_name}"')
            
            select_b = ", " + ", ".join(new_cols_to_add) if new_cols_to_add else ""

            # Core Spatial Logic: Simplify -> Intersect -> MakeValid -> Filter Area
            conn.execute(text(f"""
                CREATE TEMP TABLE temp_overlay_new AS
                SELECT 
                    {select_a} {select_b}, 
                    ST_Multi(ST_CollectionExtract(
                        ST_Intersection(
                            ST_SimplifyPreserveTopology(a.geom_res, 0.00001), 
                            ST_SimplifyPreserveTopology(ST_MakeValid(b.geom), 0.00001)
                        ), 3
                    )) as geom_next
                FROM temp_overlay a
                JOIN "{OUT_SCHEMA}"."{next_table}" b ON ST_Intersects(a.geom_res, b.geom)
                WHERE ST_Area(ST_Intersection(a.geom_res, b.geom)) > 0.00000001;
                
                DROP TABLE temp_overlay;
                ALTER TABLE temp_overlay_new RENAME TO temp_overlay;
                ALTER TABLE temp_overlay RENAME COLUMN geom_next TO geom_res;
                CREATE INDEX idx_tmp_geom_{i} ON temp_overlay USING GIST(geom_res);
            """))
            print(f"Selesai! ({time.time() - curr_time:.2f}s)")

        # --- c. STEP 3: FINALISASI (CLEANUP & AGGREGATE) ---
        print(f"⏳ [{total_steps}/{total_steps}] Finalisasi & Dissolve ke {OUT_TABLE}...")
        conn.execute(text(f'DROP TABLE IF EXISTS "{OUT_SCHEMA}"."{OUT_TABLE}" CASCADE;'))
        
        # Di sini kita melakukan Union kembali (ST_Union) berdasarkan atribut agar kepingan Subdivide menyatu kembali
        res_cols_query = conn.execute(text("SELECT * FROM temp_overlay LIMIT 0"))
        final_cols = [f'"{col}"' for col in res_cols_query.keys() if col.lower() != 'geom_res']
        group_by_cols = ", ".join(final_cols)

        conn.execute(text(f"""
            CREATE TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" AS 
            SELECT 
                {group_by_cols},
                ST_Multi(ST_Union(geom_res)) as geom
            FROM temp_overlay 
            WHERE ST_GeometryType(geom_res) LIKE '%Polygon%'
            GROUP BY {group_by_cols};
            
            ALTER TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" ADD COLUMN "LUAS_OVERLAY_HA" float;
            UPDATE "{OUT_SCHEMA}"."{OUT_TABLE}" 
            SET "LUAS_OVERLAY_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000;
            
            CREATE INDEX ON "{OUT_SCHEMA}"."{OUT_TABLE}" USING GIST(geom);
            ANALYZE "{OUT_SCHEMA}"."{OUT_TABLE}";
        """))

    total_duration = time.time() - start_time
    print("-" * 85)
    print(f"✅ BERHASIL DIOPTIMASI (v4)!")
    print(f"⏱️  Waktu Total: {format_duration(total_duration)}")
    print(f"📊 Tabel Hasil: {OUT_SCHEMA}.{OUT_TABLE}")
    print("-" * 85)

except Exception as e:
    print(f"\n❌ ERROR UTAMA: {e}")
    sys.exit(1)
