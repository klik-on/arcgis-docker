#!/usr/bin/env python3
import os
import sys
import time
import datetime
import subprocess
import shutil
import warnings
import pandas as pd
import geopandas as gpd
import boto3
from sqlalchemy import create_engine, text, inspect, exc as sa_exc
from sqlalchemy.types import Float
from botocore.client import Config
from dotenv import load_dotenv

# --- KONFIGURASI WARNING ---
warnings.filterwarnings("ignore", category=sa_exc.SAWarning)

# --- 1. INISIALISASI & SYNC PROJ ---
try:
    import pyproj
    OS_PROJ_PATH = '/usr/local/share/proj'
    if os.path.exists(OS_PROJ_PATH):
        os.environ['PROJ_DATA'] = OS_PROJ_PATH
        pyproj.datadir.set_data_dir(OS_PROJ_PATH)
except ImportError:
    pass

load_dotenv()

# --- 2. KONFIGURASI DINAMIS ---
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')

SCHEMA_DATA = os.getenv("SCHEMA_DATA", "datagis")
SCHEMA_OUT = os.getenv("OUT_SCHEMA", "analisis")
RKP_SCHEMA = os.getenv("RKP_SCHEMA", "rekap")
MASTER_SCHEMA = os.getenv("MASTER_SCHEMA", "kamusdata")

PREFIX_TAB = os.getenv("PREFIX_TAB", "INT_KWS")
TABLE_A = os.getenv("TABLE_A", "KWSHUTAN_AR_250K_DES2025")
FIELD_CATEGORY_A = os.getenv("FIELD_CATEGORY_A", "FUNGSIKWS")
TABLE_B = os.getenv("TABLE_B", "ADM_KAB_KOTA")
FIELD_FILTER_B = os.getenv("FIELD_FILTER_B", "WADMPR")

# Fitur Baru: SUBDIVIDE (Default: true)
USE_SUBDIVIDE = os.getenv("SUBDIVIDE", "true").lower() == "true"

MASTER_TABLE = os.getenv("MASTER_TABLE", "KODE_KWS")
MASTER_JOIN_FIELD = os.getenv("MASTER_JOIN_FIELD", "KD_KWS")
SUM_SORT = os.getenv("SUM_SORT", "NOURUT_KWS")

S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")
S3_USER = os.getenv("S3_USER", "geobackup")
S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")

BASE_OUTPUT = "/app/data/output_gdb"
os.makedirs(BASE_OUTPUT, exist_ok=True)

engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

# --- 3. UTILITY ---
def get_source_metadata(engine, schema, table):
    inspector = inspect(engine)
    columns = inspector.get_columns(table, schema=schema)
    forbidden = ('geom', 'geometry', 'shape', 'raw_geom')
    source_cols = [col for col in columns if col['name'].lower() not in forbidden]
    dtype_map = {col['name'].upper(): col['type'] for col in source_cols}
    return source_cols, dtype_map

# --- 4. PENANGANAN ARGUMEN ---
if len(sys.argv) < 2:
    print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = " ".join(sys.argv[1:])
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

OUT_TABLE_NAME = f"{PREFIX_TAB}_{SAFE_NAME}".upper()
GDB_NAME = f"{OUT_TABLE_NAME}.gdb"
FINAL_ZIP_PATH = os.path.join(BASE_OUTPUT, f"{OUT_TABLE_NAME}.gdb.zip")
SUMMARY_TXT_PATH = os.path.join(BASE_OUTPUT, f"SUMMARY_{OUT_TABLE_NAME}.txt")
GDB_PATH = os.path.join(BASE_OUTPUT, GDB_NAME)
prop_path = os.path.join("/app/data/logs/properties", f"{OUT_TABLE_NAME}_PROPERTIES.txt")

try:
    print("-" * 65)
    print(f"🚀 PROSES INTERSECT: {PROVINSI_TARGET}")
    print(f"⚙️  SUBDIVIDE MODE : {'ENABLED' if USE_SUBDIVIDE else 'DISABLED'}")
    print("-" * 65)

    # 5. SPASIAL INTERSECT & CEA
    SOURCE_COLS, DTYPE_MAP = get_source_metadata(engine, SCHEMA_DATA, TABLE_A)
    ST_SELECT_DATA_COLS = ", ".join([f'a."{c["name"]}"::{str(c["type"])}' for c in SOURCE_COLS])
    COL_NAMES_ONLY = ", ".join([f'"{c["name"]}"' for c in SOURCE_COLS])

    # Logika Masking dengan atau tanpa Subdivide
    mask_geom_sql = "ST_Subdivide(ST_MakeValid(ST_Union(geom)), 200)" if USE_SUBDIVIDE else "ST_MakeValid(ST_Union(geom))"

    print(f"⏳ [1/6] Processing Spasial Intersect (PostGIS Engine)...")
    query_intersect = text(f"""
        WITH mask AS (
            SELECT {mask_geom_sql} as geom_mask
            FROM "{SCHEMA_DATA}"."{TABLE_B}" WHERE "{FIELD_FILTER_B}" ILIKE :prov
        ),
        intersected AS (
            SELECT {ST_SELECT_DATA_COLS}, ST_Intersection(a.geom, m.geom_mask) as raw_geom
            FROM "{SCHEMA_DATA}"."{TABLE_A}" a
            JOIN mask m ON ST_Intersects(a.geom, m.geom_mask)
        )
        SELECT {COL_NAMES_ONLY},
               ST_Multi(ST_Force2D(ST_MakeValid(ST_CollectionExtract(raw_geom, 3))))::geometry(MultiPolygon, 4326) as geom,
               (ST_Area(ST_Transform(raw_geom, 54034)) / 10000)::float as "LUAS_CEA_HA"
        FROM intersected WHERE NOT ST_IsEmpty(raw_geom);
    """)

    gdf = gpd.read_postgis(query_intersect, engine, params={"prov": PROVINSI_TARGET}, geom_col='geom')

    if gdf.empty:
        print(f"⚠️ Data tidak ditemukan."); sys.exit(0)

    # 6. EXPORT DATABASE & GDB
    print(f"📊 [2/6] Simpan PostGIS & Ekspor GDB...")
    gdf.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf.columns]
    DTYPE_MAP["LUAS_CEA_HA"] = Float(precision=53)
    
    with engine.begin() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA_OUT}";'))
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{RKP_SCHEMA}";'))

    gdf.to_postgis(OUT_TABLE_NAME, engine, schema=SCHEMA_OUT, if_exists='replace', index=False, dtype=DTYPE_MAP)

    if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
    gdf.to_file(GDB_PATH, driver="OpenFileGDB", engine="pyogrio",
                layer_options={"TARGET_ARCGIS_VERSION": "ARCGIS_PRO_3_2_OR_LATER"})

    # --- 7. METADATA TRIGGER ---
    print(f"🔗 [3/6] Menjalankan Metadata Trigger...")
    subprocess.run(["python3", os.path.join(os.path.dirname(__file__), "..", "utils", "upper_TAB_COL.py"),
                    SCHEMA_OUT, OUT_TABLE_NAME], check=False)

    # --- 8. GABUNG SUMMARY & PROPERTIES ---
    print(f"📈 [4/6] Menggabungkan Summary & Metadata Log...")
    inspector = inspect(engine)
    m_cols = [f'b."{c["name"].upper()}"' for c in inspector.get_columns(MASTER_TABLE, schema=MASTER_SCHEMA)]

    summary_sql = f"""
        SELECT a."{FIELD_CATEGORY_A.upper()}", {", ".join(m_cols)}, SUM(a."LUAS_CEA_HA") as "TOTAL_LUAS_HA"
        FROM "{SCHEMA_OUT}"."{OUT_TABLE_NAME}" a
        LEFT JOIN "{MASTER_SCHEMA}"."{MASTER_TABLE}" b ON a."{FIELD_CATEGORY_A.upper()}"::text = b."{MASTER_JOIN_FIELD.upper()}"::text
        GROUP BY a."{FIELD_CATEGORY_A.upper()}", {", ".join(m_cols)}
        ORDER BY b."{SUM_SORT.upper()}" ASC NULLS LAST
    """

    with engine.connect() as conn:
        summary_df = pd.read_sql(text(summary_sql), conn)
        summary_df.to_sql(f"SUM_{OUT_TABLE_NAME}", engine, schema=RKP_SCHEMA, if_exists='replace', index=False)

    summary_txt_df = summary_df.copy()
    summary_txt_df['TOTAL_LUAS_HA'] = summary_txt_df['TOTAL_LUAS_HA'].apply(lambda x: f"{x:,.2f}" if pd.notnull(x) else "0.00")
    prop_content = open(prop_path, 'r').read() if os.path.exists(prop_path) else "N/A"

    with open(SUMMARY_TXT_PATH, 'w') as f:
        f.write(f"==========================================================\n")
        f.write(f"   SUMMARY ANALISIS INTERSECT: {PROVINSI_TARGET}\n")
        f.write(f"   Subdivide: {'Enabled' if USE_SUBDIVIDE else 'Disabled'}\n")
        f.write(f"   Waktu: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"==========================================================\n\n")
        f.write(f"--- [ Log Properti ] ---\n{prop_content}\n")
        f.write(f"\n--- [ Rekapitulasi Luasan (CEA) ] ---\n")
        f.write(summary_txt_df.to_string(index=False, justify='left'))
        f.write(f"\n\nTOTAL LUAS ESTIMASI: {summary_df['TOTAL_LUAS_HA'].sum():,.2f} Ha\n")

    # 9. PACKING & UPLOAD
    print(f"🗜️ [5/6] Zipping GDB...")
    subprocess.run(["zip", "-rq", f"{OUT_TABLE_NAME}.gdb.zip", GDB_NAME], cwd=BASE_OUTPUT, check=True)

    print(f"☁️ [6/6] Uploading ke MinIO Storage...")
    s3 = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER, aws_secret_access_key=S3_PASS, config=Config(signature_version='s3v4'))

    for path in [FINAL_ZIP_PATH, SUMMARY_TXT_PATH]:
        if os.path.exists(path):
            s_key = f"{SCHEMA_OUT}/INTERSECT/{datetime.date.today()}/{os.path.basename(path)}"
            s3.upload_file(path, S3_BUCKET, s_key)

    print(f"\n✅ SELESAI dalam {time.time() - start_time:.2f} detik!")

except Exception as e:
    print(f"\n❌ ERROR: {e}"); sys.exit(1)

finally:
    print(f"🧹 Membersihkan file temporer...")
    if 'GDB_PATH' in locals() and os.path.exists(GDB_PATH):
        shutil.rmtree(GDB_PATH)
    if 'prop_path' in locals() and os.path.exists(prop_path):
        try: os.remove(prop_path)
        except: pass
