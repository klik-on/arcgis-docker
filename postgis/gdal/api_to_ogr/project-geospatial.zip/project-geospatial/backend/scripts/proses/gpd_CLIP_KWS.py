import sys
import os
import time
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

# Memuat variabel lingkungan dari file .env
load_dotenv()

# =================================================================
# 1. KONFIGURASI DATABASE & PARAMETER
# =================================================================
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')

SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
OUT_SCHEMA = os.getenv("SCHEMA_OUT", "analisis")
REF_SCHEMA = "kodefikasi"

# --- PARAMETER PENAMAAN TABEL ---
PREFIX_TAB = "KWS" 
TABLE_A = "KWSHUTAN_AR_250K_v18102025"
FIELD_CATEGORY_A = "FUNGSIKWS"

TABLE_B = "ADM_KAB_KOTA"
FIELD_FILTER_B = "WADMPR"

REF_TABLE = "KODE_KWS"
REF_JOIN_FIELD = "KD_KWS"

# --- PARAMETER SORTING ---
SORT_BY_SEQUENCE = True 
COL_SORT_NAME = "NOURUT_KWS"

if not all([DB_USER, DB_PASS, DB_HOST, DB_NAME]):
    print("❌ ERROR: Konfigurasi database di file .env tidak lengkap!")
    sys.exit(1)

engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

# =================================================================
# 2. PENGAMBILAN METADATA KOLOM (DINAMIS)
# =================================================================
def get_table_columns(engine, schema, table):
    """Mengambil daftar kolom tabel kecuali geometri untuk SELECT eksplisit"""
    query = text("""
        SELECT column_name FROM information_schema.columns
        WHERE table_schema = :schema AND table_name = :table
        ORDER BY ordinal_position
    """)
    with engine.connect() as conn:
        result = conn.execute(query, {"schema": schema, "table": table})
        cols = [row[0] for row in result]
        # Kecualikan kolom spasial agar tidak duplikat saat SELECT
        return [c for c in cols if c.lower() not in ('geom', 'geometry', 'shape', 'raw_geom', 'geom_new', 'clipped_geom')]

try:
    # Ambil kolom untuk Tabel Referensi
    REF_COLUMNS = get_table_columns(engine, REF_SCHEMA, REF_TABLE)
    
    # Ambil kolom untuk Tabel Data
    DATA_COLUMNS = get_table_columns(engine, SCHEMA, TABLE_A)
    
    # Membuat string kolom untuk query SELECT
    ST_SELECT_DATA_COLS = ", ".join([f'"{c}"' for c in DATA_COLUMNS])
    
    print(f"🔗 Kolom data terdeteksi: {len(DATA_COLUMNS)} kolom.")
    print(f"🔗 Kolom referensi terdeteksi: {len(REF_COLUMNS)} kolom.")
except Exception as e:
    print(f"⚠️ Gagal mendapatkan metadata: {e}")
    sys.exit(1)

# =================================================================
# 3. PENANGANAN ARGUMEN
# =================================================================
if len(sys.argv) < 2:
    print(f"\n💡 PENGGUNAAN: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = sys.argv[1]
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

OUT_TABLE = f"{PREFIX_TAB}_{SAFE_NAME}"
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE}"'
SUMMARY_TABLE_FULL = f'"{OUT_SCHEMA}"."SUM_{OUT_TABLE}"'

# =================================================================
# 4. PROSES SPASIAL (CLEAN GEOMETRY)
# =================================================================
print("-" * 75)
print(f"✂️  Memproses CLIP: {TABLE_A} -> {PROVINSI_TARGET}")
print("-" * 75)

try:
    with engine.begin() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))
        conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL} CASCADE;'))

        # Menggunakan SELECT eksplisit untuk menghindari raw_geom terbawa ke QGIS
        query_create = text(f"""
            CREATE TABLE {RESULT_TABLE_FULL} AS
            WITH mask AS (
                SELECT ST_MakeValid(ST_Union(geom)) as geom_mask
                FROM "{SCHEMA}"."{TABLE_B}"
                WHERE "{FIELD_FILTER_B}" ILIKE :prov
            ),
            intersected AS (
                SELECT
                    {ST_SELECT_DATA_COLS},
                    ST_Intersection(a.geom, m.geom_mask) as clipped_geom
                FROM "{SCHEMA}"."{TABLE_A}" a
                JOIN mask m ON ST_Intersects(a.geom, m.geom_mask)
            )
            SELECT
                {ST_SELECT_DATA_COLS},
                ST_Multi(ST_CollectionExtract(clipped_geom, 3)) as geom,
                ST_Area(ST_Transform(ST_CollectionExtract(clipped_geom, 3), 54034)) / 10000 as "LUAS_CEA_HA"
            FROM intersected
            WHERE NOT ST_IsEmpty(clipped_geom);
        """)

        print(f"⏳ Menjalankan ST_Intersection di database...")
        conn.execute(query_create, {"prov": PROVINSI_TARGET})

        print(f"⚡ Membuat indeks spasial GIST...")
        conn.execute(text(f'CREATE INDEX ON {RESULT_TABLE_FULL} USING GIST(geom);'))

    with engine.connect() as conn:
        conn.execution_options(isolation_level="AUTOCOMMIT")
        conn.execute(text(f'VACUUM ANALYZE {RESULT_TABLE_FULL};'))

# =================================================================
# 5. RINGKASAN DATA
# =================================================================
    print(f"📊 Menghasilkan ringkasan data...")

    select_parts = []
    for col in REF_COLUMNS:
        if col.upper() == REF_JOIN_FIELD.upper():
            select_parts.append(f"COALESCE(CAST(ref.\"{col}\" AS TEXT), 'N/A') AS \"{col}\"")
        else:
            select_parts.append(f"ref.\"{col}\"")

    select_clause = ", ".join(select_parts)
    group_limit = len(REF_COLUMNS) + 1
    order_clause = f"ref.\"{COL_SORT_NAME}\" ASC NULLS LAST" if SORT_BY_SEQUENCE and COL_SORT_NAME in REF_COLUMNS else "total_ha DESC"

    query_summary = f"""
        SELECT
            {select_clause},
            CAST(res."{FIELD_CATEGORY_A}" AS TEXT) AS "{FIELD_CATEGORY_A}",
            SUM(res."LUAS_CEA_HA") as total_ha
        FROM {RESULT_TABLE_FULL} res
        LEFT JOIN "{REF_SCHEMA}"."{REF_TABLE}" ref
            ON CAST(res."{FIELD_CATEGORY_A}" AS TEXT) = CAST(ref."{REF_JOIN_FIELD}" AS TEXT)
        GROUP BY {', '.join(map(str, range(1, group_limit + 1)))}
        ORDER BY {order_clause}
    """

    summary_df = pd.read_sql(query_summary, engine)

    if not summary_df.empty:
        # Merapikan kolom nomor urut agar menjadi integer (bukan float/NaN)
        if COL_SORT_NAME in summary_df.columns:
            summary_df[COL_SORT_NAME] = pd.to_numeric(summary_df[COL_SORT_NAME], errors='coerce').fillna(99).astype(int)

        pd.options.display.float_format = '{:,.2f}'.format
        print("\n" + "="*100)
        print(f"HASIL ANALISIS: {PROVINSI_TARGET}")
        print("="*100)
        print(summary_df.to_string(index=False))
        print("-" * 100)
        print(f"TOTAL LUAS: {summary_df['total_ha'].sum():,.2f} HA")
        
        # Simpan tabel ringkasan ke database
        summary_df.to_sql(f"SUM_{OUT_TABLE}", engine, schema=OUT_SCHEMA, if_exists='replace', index=False)

        print(f"\n✅ BERHASIL!")
        print(f"📍 Layer Peta: {RESULT_TABLE_FULL}")
        print(f"📍 Tabel Ringkasan: {SUMMARY_TABLE_FULL}")
    else:
        print(f"⚠️ Data tidak ditemukan untuk wilayah: {PROVINSI_TARGET}")

    print(f"\n⏱️ Selesai dalam {time.time() - start_time:.2f} detik.")

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    sys.exit(1)
