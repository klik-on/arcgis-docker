#!/usr/bin/env python3
import os
import sys
import time
import logging
import geopandas as gpd
import pyogrio
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# --- 1. SETUP LOGGING ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("UNION-FINAL")

# --- 2. KONFIGURASI DATABASE ---
load_dotenv()
DB_USER, DB_PASS = os.getenv('DB_USER'), os.getenv('DB_PASS')
DB_HOST, DB_PORT = os.getenv('DB_HOST', 'dbgis'), os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
OUT_SCHEMA = os.getenv("OUT_SCHEMA", "analisis")

db_engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")
PYOGRIO_URI = f"postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# Definisi Proyeksi sesuai screenshot: Cylindrical Equal Area
# Kita gunakan string ESRI agar pyproj mencoba mencarinya secara global
TARGET_PROJ = "ESRI:54034"

# --- 3. PARAMETER INPUT ---
PROVINSI_TARGET = " ".join(sys.argv[1:]).strip()
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
LAYERS_PREFIX = [p.strip().upper() for p in os.getenv("LAYERS_PREFIX", "KWS,PL").split(",")]
INPUT_TABLES = [f"{p}_{SAFE_NAME}" for p in LAYERS_PREFIX]
OUT_TABLE = f"UNION_{'_'.join(LAYERS_PREFIX)}_{SAFE_NAME}"[:62].rstrip('_')

def run_geospatial_union():
    start_time = time.time()
    try:
        gdfs = []
        for table in INPUT_TABLES:
            logger.info(f"📥 Loading {table}...")
            # Menggunakan pyogrio untuk loading data secepat kilat
            gdf = pyogrio.read_dataframe(PYOGRIO_URI, layer=f"{OUT_SCHEMA}.{table}")
            if gdf.empty: continue
            
            if 'geom' in gdf.columns: gdf = gdf.rename(columns={'geom': 'geometry'})
            gdf = gdf.set_geometry('geometry')
            if gdf.crs is None: gdf.set_crs(epsg=4326, inplace=True)
            
            pfx = table.split('_')[0]
            gdf.columns = [f"{pfx}_{c}" if c != 'geometry' else c for c in gdf.columns]
            gdf['geometry'] = gdf['geometry'].make_valid()
            gdfs.append(gdf)

        if len(gdfs) < 2: raise ValueError("Butuh minimal 2 layer untuk melakukan UNION.")

        # --- STEP 2: OVERLAY ---
        logger.info(f"⚡ Processing Overlay Union...")
        res_gdf = gdfs[0]
        for i in range(1, len(gdfs)):
            # keep_geom_type=True krn kita hanya butuh hasil Polygon (KWS & PL)
            res_gdf = res_gdf.overlay(gdfs[i], how='union', keep_geom_type=True)

        # --- STEP 3: ANALYTICS ---
        logger.info(f"📏 Calculating LUAS_HA using {TARGET_PROJ}...")
        
        # Bersihkan geometri hasil union (hapus poligon kosong/sliver)
        res_gdf = res_gdf[~res_gdf.is_empty]
        
        # Konversi ke Cylindrical Equal Area untuk hitung luas
        try:
            res_gdf_meter = res_gdf.to_crs(TARGET_PROJ)
        except Exception as e:
            logger.warning(f"⚠️ {TARGET_PROJ} direct failed, using Proj4 string fallback...")
            # Fallback Proj4 string untuk Cylindrical Equal Area (World)
            cea_world = "+proj=cea +lon_0=0 +lat_ts=0 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs"
            res_gdf_meter = res_gdf.to_crs(cea_world)
            
        res_gdf['LUAS_HA'] = res_gdf_meter.area / 10000

        # --- STEP 4: DB EXPORT ---
        logger.info(f"📤 Exporting to {OUT_SCHEMA}.{OUT_TABLE}...")
        with db_engine.begin() as conn:
            conn.execute(text(f'DROP TABLE IF EXISTS "{OUT_SCHEMA}"."{OUT_TABLE}" CASCADE;'))
        
        # Simpan dalam WGS84 (Standard PostGIS)
        res_gdf = res_gdf.to_crs(epsg=4326).rename_geometry('geom')
        
        res_gdf.to_postgis(
            name=OUT_TABLE, 
            con=db_engine, 
            schema=OUT_SCHEMA, 
            if_exists='replace', 
            index=False
        )
        
        # Re-index secara spasial
        with db_engine.begin() as conn:
            conn.execute(text(f'CREATE INDEX ON "{OUT_SCHEMA}"."{OUT_TABLE}" USING GIST(geom);'))

        duration = time.time() - start_time
        logger.info("=" * 70)
        logger.info(f"✅ SUCCESS!")
        logger.info(f"⏱️ Total Time   : {duration:.2f} seconds")
        logger.info(f"📊 Rows Created : {len(res_gdf)}")
        logger.info("=" * 70)
        
    except Exception as e:
        logger.error(f"❌ ERROR: {str(e)}", exc_info=True)

if __name__ == "__main__":
    run_geospatial_union()
