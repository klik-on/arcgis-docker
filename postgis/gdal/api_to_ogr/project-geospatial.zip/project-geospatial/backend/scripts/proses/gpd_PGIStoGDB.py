#!/usr/bin/env python3
import os
import sys
import json
import warnings
import time
import datetime
import shutil
import boto3
import pyproj
import geopandas as gpd
import pyogrio
from sqlalchemy import create_engine, text, inspect
from dotenv import load_dotenv
from botocore.client import Config

# --- 1️⃣ INISIALISASI PROJ (Path Statis) ---
OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)
    os.environ['PROJ_LIB'] = OS_PROJ_PATH
else:
    proj_path = pyproj.datadir.get_data_dir()
    os.environ['PROJ_LIB'] = proj_path
    os.environ['PROJ_DATA'] = proj_path

warnings.filterwarnings("ignore", category=UserWarning)
load_dotenv()

# --- 2️⃣ CONFIG ---
DATA_DIR = "/app/data/output_export"
os.makedirs(DATA_DIR, exist_ok=True)

def upload_to_s3(file_path, bucket_name, is_log=False):
    """Mengunggah file (ZIP atau TXT) ke S3/MinIO."""
    s3 = boto3.client('s3', 
                      endpoint_url=os.getenv("S3_ENDPOINT"),
                      aws_access_key_id=os.getenv("S3_USER"),
                      aws_secret_access_key=os.getenv("S3_PASS"),
                      config=Config(signature_version='s3v4'))
    
    file_name = os.path.basename(file_path)
    # Simpan log di folder logs/properties agar rapi
    s3_key = f"logs/properties/{file_name}" if is_log else file_name
    
    try:
        print(f"☁️ Uploading {file_name} to S3 as {s3_key}...")
        s3.upload_file(file_path, bucket_name, s3_key)
        print(f"✅ Upload success: {s3_key}")
    except Exception as e:
        print(f"⚠️ S3 Upload Error: {e}")

def generate_table_properties(engine, schema, table_name):
    """Menghasilkan metadata atribut tabel (geom tidak ditampilkan karena format GDB)."""
    inspector = inspect(engine)
    columns = inspector.get_columns(table_name, schema=schema)
    prop_file_path = os.path.join(DATA_DIR, f"{table_name.upper()}_PROPERTIES_EXPORT.txt")
    
    with engine.connect() as conn:
        count = conn.execute(text(f'SELECT COUNT(*) FROM "{schema}"."{table_name}"')).scalar()
        res_geo = conn.execute(text(f"""
            SELECT srid, type FROM geometry_columns 
            WHERE f_table_schema = :s AND f_table_name = :t
        """), {"s": schema, "t": table_name}).first()
        srid = res_geo[0] if res_geo else "4326"
        g_type = res_geo[1] if res_geo else "GEOMETRY"

    with open(prop_file_path, "w") as f:
        f.write(f"METADATA EXPORT GDB: {table_name.upper()}\n")
        f.write(f"Export Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Rows: {count}\n")
        f.write(f"Geometry   : {g_type} (SRID: {srid})\n")
        f.write("="*90 + "\n")
        f.write(f"{'COLUMN_NAME':<30} | {'TYPE':<25} | {'INFO'}\n")
        f.write("-" * 90 + "\n")

        for col in columns:
            c_name = col['name']
            
            # --- FILTER: Jangan tampilkan kolom geometri di daftar atribut log GDB ---
            if c_name.lower() in ['geom', 'geometry', 'shape']:
                continue
                
            raw_type = str(col['type']).upper()
            width_info = "-"
            
            if hasattr(col['type'], 'length') and col['type'].length:
                display_type = f"VARCHAR({col['type'].length})"
                width_info = f"L: {col['type'].length}"
            else:
                display_type = raw_type
            
            f.write(f"{c_name.upper():<30} | {display_type:<25} | {width_info}\n")
            
    return prop_file_path

# --- 3️⃣ CORE EXPORT ---
def migrate_postgis_to_gdb(input_param):
    start_time = time.time()
    try:
        # Parsing input (mendukung JSON atau string mentah)
        try:
            data = json.loads(input_param)
            table_name = data.get("layer")
            bucket_name = data.get("bucket", os.getenv("S3_BUCKET", "geospatial-bucket"))
        except (json.JSONDecodeError, TypeError):
            table_name = input_param
            bucket_name = os.getenv("S3_BUCKET", "geospatial-bucket")

        gdb_name = f"{table_name.upper()}.gdb"
        gdb_path = os.path.join(DATA_DIR, gdb_name)
        zip_path = f"{gdb_path}.zip"

        # Cleanup sisa proses sebelumnya
        if os.path.exists(gdb_path): shutil.rmtree(gdb_path)
        if os.path.exists(zip_path): os.remove(zip_path)

        # Inisialisasi Database
        db_url = f"postgresql+psycopg://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}"
        engine = create_engine(db_url)
        schema = os.getenv("SCHEMA_DATA", "datagis")

        print(f"📥 Reading table {schema}.{table_name} from PostGIS...")
        query = f'SELECT * FROM "{schema}"."{table_name}"'
        gdf = gpd.read_postgis(query, con=engine, geom_col='geom')

        if gdf.empty:
            print(f"⚠️ Tabel {table_name} kosong. Ekspor dibatalkan.")
            return

        # Pastikan koordinat terdefinisi
        if gdf.crs is None:
            gdf.set_crs(epsg=4326, inplace=True)

        print(f"💾 Writing to FileGDB: {gdb_name}...")
        # Simpan ke GDB (Geometri masuk ke sistem internal GDB)
        gdf.to_file(gdb_path, layer=table_name.upper(), driver="OpenFileGDB", engine="pyogrio")

        print(f"📦 Zipping GDB folder...")
        shutil.make_archive(gdb_path, 'zip', DATA_DIR, gdb_name)

        # Upload File ZIP utama
        upload_to_s3(zip_path, bucket_name, is_log=False)

        # Generate dan Upload Log Properties (Hanya kolom atribut)
        print(f"📄 Generating clean metadata log...")
        prop_path = generate_table_properties(engine, schema, table_name)
        upload_to_s3(prop_path, bucket_name, is_log=True)

    except Exception as e:
        print(f"💥 Ekspor Gagal: {e}")
    finally:
        # Pembersihan lokal
        if os.path.exists(gdb_path): shutil.rmtree(gdb_path)
        if os.path.exists(zip_path): 
            try: os.remove(zip_path)
            except: pass
        if 'engine' in locals(): engine.dispose()
        
        duration = str(datetime.timedelta(seconds=int(time.time()-start_time)))
        print(f"🏁 SELESAI! Durasi Total: {duration}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        migrate_postgis_to_gdb(sys.argv[1])
    else:
        print("💡 Cara penggunaan: python3 gpd_PGIStoGDB.py <nama_tabel>")
