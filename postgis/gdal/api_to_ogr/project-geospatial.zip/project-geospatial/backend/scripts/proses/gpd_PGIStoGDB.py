#!/usr/bin/env python3
import os
import sys
import json
import warnings
import time
import datetime
import shutil
import boto3
import pyproj
import geopandas as gpd
import pyogrio
from sqlalchemy import create_engine, text, inspect
from sqlalchemy.exc import SAWarning
from dotenv import load_dotenv
from botocore.client import Config

# --- 1️⃣ INISIALISASI & KONFIGURASI ---
load_dotenv()

# Sembunyikan warning tipe data geometry dari SQLAlchemy dan UserWarning umum
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=SAWarning)

# Konfigurasi Path Proj agar transformasi koordinat akurat
OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)
else:
    proj_path = pyproj.datadir.get_data_dir()
    os.environ['PROJ_LIB'] = proj_path

# Direktori kerja lokal untuk output sementara
DATA_DIR = "/app/data/output_export"
os.makedirs(DATA_DIR, exist_ok=True)

# --- 2️⃣ UTILITY FUNCTIONS ---

def upload_to_s3(file_path, bucket_name, is_log=False):
    """Mengunggah file ke S3/MinIO."""
    if not os.path.exists(file_path):
        return

    s3 = boto3.client('s3',
                      endpoint_url=os.getenv("S3_ENDPOINT"),
                      aws_access_key_id=os.getenv("S3_USER"),
                      aws_secret_access_key=os.getenv("S3_PASS"),
                      config=Config(signature_version='s3v4'),
                      verify=False)

    file_name = os.path.basename(file_path)
    # File log (.txt) akan disimpan di subfolder agar rapi
    s3_key = f"logs/properties/{file_name}" if is_log else file_name

    try:
        print(f"☁️ Uploading {file_name} to S3...")
        s3.upload_file(file_path, bucket_name, s3_key)
        print(f"✅ Success: {s3_key}")
    except Exception as e:
        print(f"⚠️ S3 Error: {e}")

def generate_table_properties(engine, schema, table_name):
    """Menghasilkan file metadata atribut (TXT)."""
    inspector = inspect(engine)
    prop_file_path = os.path.join(DATA_DIR, f"{table_name.upper()}_PROPERTIES.txt")

    with engine.connect() as conn:
        # Ambil info koordinat dan jumlah baris
        res_geo = conn.execute(text(f"""
            SELECT srid, type FROM geometry_columns 
            WHERE f_table_schema = :s AND f_table_name = :t
        """), {"s": schema, "t": table_name}).first()
        
        count = conn.execute(text(f'SELECT COUNT(*) FROM "{schema}"."{table_name}"')).scalar()
        
        srid = res_geo[0] if res_geo else "4326"
        g_type = res_geo[1] if res_geo else "GEOMETRY"

    columns = inspector.get_columns(table_name, schema=schema)

    with open(prop_file_path, "w") as f:
        f.write(f"METADATA EXPORT GDB: {table_name.upper()}\n")
        f.write(f"Export Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Total Rows: {count}\n")
        f.write(f"Geometry   : {g_type} (SRID: {srid})\n")
        f.write("="*90 + "\n")
        f.write(f"{'COLUMN_NAME':<30} | {'TYPE':<25} | {'INFO'}\n")
        f.write("-" * 90 + "\n")

        for col in columns:
            c_name = col['name']
            # Abaikan kolom geometri di dalam daftar atribut text
            if c_name.lower() in ['geom', 'geometry', 'shape']:
                continue

            try:
                raw_type = str(col['type']).upper()
            except:
                raw_type = "UNKNOWN"
                
            width = f"L: {col['type'].length}" if hasattr(col['type'], 'length') and col['type'].length else "-"
            f.write(f"{c_name.upper():<30} | {raw_type:<25} | {width}\n")

    return prop_file_path

# --- 3️⃣ CORE PROCESS ---

def migrate_postgis_to_gdb(input_param):
    start_time = time.time()
    gdb_path = None
    zip_path = None
    prop_path = None

    try:
        # 1. Parsing Input (Tabel Name atau JSON)
        try:
            data = json.loads(input_param)
            table_name = data.get("layer")
            bucket_name = data.get("bucket", os.getenv("S3_BUCKET", "geospatial-bucket"))
        except:
            table_name = input_param
            bucket_name = os.getenv("S3_BUCKET", "geospatial-bucket")

        # 2. Inisialisasi Path
        gdb_name = f"{table_name.upper()}.gdb"
        gdb_path = os.path.join(DATA_DIR, gdb_name)
        zip_path = f"{gdb_path}.zip"
        prop_path = os.path.join(DATA_DIR, f"{table_name.upper()}_PROPERTIES.txt")

        # Cleanup sisa proses sebelumnya jika ada
        if os.path.exists(gdb_path): shutil.rmtree(gdb_path)
        if os.path.exists(zip_path): os.remove(zip_path)
        if os.path.exists(prop_path): os.remove(prop_path)

        # 3. Database Connection
        db_url = f"postgresql+psycopg://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}"
        engine = create_engine(db_url)
        schema = os.getenv("SCHEMA_DATA", "datagis")

        # 4. Ambil Data dari PostGIS
        print(f"📥 Reading table {schema}.{table_name}...")
        query = f'SELECT * FROM "{schema}"."{table_name}"'
        gdf = gpd.read_postgis(query, con=engine, geom_col='geom')

        if gdf.empty:
            print(f"⚠️ Tabel {table_name} kosong. Ekspor dibatalkan."); return

        if gdf.crs is None: 
            gdf.set_crs(epsg=4326, inplace=True)

        # 5. Export ke FileGDB lokal
        print(f"💾 Writing to FileGDB: {gdb_name}...")
        gdf.to_file(gdb_path, layer=table_name.upper(), driver="OpenFileGDB", engine="pyogrio")

        # 6. Kompres ke ZIP
        print(f"📦 Zipping GDB...")
        shutil.make_archive(gdb_path, 'zip', root_dir=DATA_DIR, base_dir=gdb_name)

        # 7. Upload File GDB ZIP ke S3
        upload_to_s3(zip_path, bucket_name, is_log=False)

        # 8. Generate & Upload Metadata TXT
        print(f"📄 Generating metadata log...")
        current_prop_path = generate_table_properties(engine, schema, table_name)
        upload_to_s3(current_prop_path, bucket_name, is_log=True)

    except Exception as e:
        print(f"💥 FATAL ERROR: {e}")
    finally:
        # --- 4️⃣ CLEANUP (Hapus semua file lokal) ---
        print("🗑️ Cleaning up local files...")
        if gdb_path and os.path.exists(gdb_path):
            shutil.rmtree(gdb_path)
        
        if zip_path and os.path.exists(zip_path):
            try: os.remove(zip_path)
            except: pass
            
        if prop_path and os.path.exists(prop_path):
            try:
                os.remove(prop_path)
                print(f"✅ Local log deleted: {os.path.basename(prop_path)}")
            except: pass
        
        duration = str(datetime.timedelta(seconds=int(time.time()-start_time)))
        print(f"🏁 FINISHED! Total Duration: {duration}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        migrate_postgis_to_gdb(sys.argv[1])
    else:
        print("💡 Usage: python3 gpd_PGIStoGDB.py <TABLE_NAME>")
