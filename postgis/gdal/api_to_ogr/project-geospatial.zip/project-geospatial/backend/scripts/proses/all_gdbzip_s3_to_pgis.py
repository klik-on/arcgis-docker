#!/usr/bin/env python3
import os
import sys
import logging
import boto3
from botocore.client import Config
from dotenv import load_dotenv

# Import fungsi migrasi dari skrip yang sudah kita buat sebelumnya
# Pastikan path folder 'proses' ada di sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from gpd_GDBtoPGIS import migrate_gdb_to_postgis

load_dotenv()

# --- CONFIGURATION ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("MASTER-S3-SYNC")

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

def run_master_sync():
    logger.info(f"🚀 Memulai Master Sync untuk bucket: {S3_BUCKET}")
    
    # 1. Inisialisasi S3 Client
    s3 = boto3.client('s3', 
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS,
        config=Config(signature_version='s3v4')
    )

    try:
        # 2. List semua objek di dalam bucket
        response = s3.list_objects_v2(Bucket=S3_BUCKET)
        
        if 'Contents' not in response:
            logger.warning(f"⚠️ Bucket {S3_BUCKET} kosong.")
            return

        # 3. Filter file .gdb.zip
        files_to_process = [
            obj['Key'] for obj in response['Contents'] 
            if obj['Key'].lower().endswith('.gdb.zip')
        ]

        if not files_to_process:
            logger.info("ℹ️ Tidak ada file .gdb.zip yang ditemukan untuk diproses.")
            return

        logger.info(f"📂 Ditemukan {len(files_to_process)} file GDB. Memulai antrean proses...")

        # 4. Iterasi dan jalankan migrasi untuk setiap file
        success_count = 0
        fail_count = 0

        for file_key in files_to_process:
            logger.info(f"\n--- 🔄 PROCESSING: {file_key} ---")
            try:
                # Memanggil fungsi dari gpd_GDBtoPGIS.py
                migrate_gdb_to_postgis(file_key)
                success_count += 1
                logger.info(f"✅ Selesai memproses {file_key}")
            except Exception as e:
                fail_count += 1
                logger.error(f"❌ Gagal memproses {file_key}: {e}")

        # 5. Ringkasan Akhir
        logger.info(f"\n========================================")
        logger.info(f"📊 RINGKASAN MASTER SYNC")
        logger.info(f"✅ Berhasil: {success_count}")
        logger.info(f"❌ Gagal   : {fail_count}")
        logger.info(f"📂 Total   : {len(files_to_process)}")
        logger.info(f"========================================")

    except Exception as e:
        logger.error(f"🚨 Master Sync Error: {e}")

if __name__ == "__main__":
    run_master_sync()
