import os
import sys
import pandas as pd
import geopandas as gpd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
import urllib.parse

# --- 1. LOAD KONFIGURASI .ENV ---
load_dotenv()

DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")

safe_pass = urllib.parse.quote_plus(DB_PASS) if DB_PASS else ""
# Tetap gunakan +psycopg karena library Psycopg 3 Anda sudah terinstal
conn_string = f"postgresql+psycopg://{DB_USER}:{safe_pass}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(conn_string)

SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
OUT_SCHEMA = os.getenv("OUT_SCHEMA", "analisis")
TABLE_A = "ADM_KAB_KOTA"
FIELD_DISS = "WADMPR"
TABLE_OUTPUT = "ADM_KAB_KOTA_DISS"

def run_process():
    try:
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{OUT_SCHEMA}";'))
        
        print(f"📂 Membaca data dari {SCHEMA}.{TABLE_A}...")
        sql_read = f'SELECT "{FIELD_DISS}", geom FROM "{SCHEMA}"."{TABLE_A}"'
        gdf = gpd.read_postgis(sql_read, engine, geom_col='geom')

        if gdf.empty:
            print("❌ Data kosong.")
            return

        print(f"🧩 Melakukan dissolve berdasarkan: {FIELD_DISS}...")
        gdf_dissolved = gdf.dissolve(by=FIELD_DISS).reset_index()

        print("🧹 Membersihkan geometri (Explode & Filter Polygon)...")
        gdf_exploded = gdf_dissolved.explode(index_parts=False)
        gdf_polygons = gdf_exploded[gdf_exploded.geometry.type == 'Polygon'].copy()

        gdf_final = gdf_polygons.dissolve(by=FIELD_DISS).reset_index()

        if gdf_final.geometry.name != 'geom':
            gdf_final = gdf_final.rename_geometry('geom')

        gdf_output = gdf_final[[FIELD_DISS, 'geom']]

        # --- PERBAIKAN DI SINI ---
        print(f"💾 Menyimpan hasil ke {OUT_SCHEMA}.{TABLE_OUTPUT}...")
        gdf_output.to_postgis(
            TABLE_OUTPUT,
            engine,
            schema=OUT_SCHEMA,
            if_exists='replace',
            index=False,
            dtype={'geom': 'MultiPolygon'}
        )

        print(f"📏 Menghitung Luas (CEA) & Validasi Geometri...")
        full_table_path = f'"{OUT_SCHEMA}"."{TABLE_OUTPUT}"'

        sql_commands = [
            f'ALTER TABLE {full_table_path} ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;',
            f'UPDATE {full_table_path} SET geom = ST_Multi(ST_MakeValid(ST_CollectionExtract(geom, 3)));',
            f'UPDATE {full_table_path} SET "LUAS_CEA_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000;'
        ]

        with engine.begin() as conn:
            for cmd in sql_commands:
                conn.execute(text(cmd))

        print(f"✅ Selesai! Data provinsi tersimpan di {OUT_SCHEMA}.{TABLE_OUTPUT}")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")
        sys.exit(1)

if __name__ == "__main__":
    run_process()
