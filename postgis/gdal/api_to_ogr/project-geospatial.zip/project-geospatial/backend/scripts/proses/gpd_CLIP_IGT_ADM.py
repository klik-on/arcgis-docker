#!/usr/bin/env python3
import sys
import os
import time
import datetime
import subprocess
import shutil
import pandas as pd
# Gunakan sqlalchemy 2.x style
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

# 1. LOAD KONFIGURASI
load_dotenv()

DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')

SCHEMA_DATA = os.getenv("SCHEMA_DATA", "datagis")
SCHEMA_OUT = os.getenv("OUT_SCHEMA", "analisis")
RKP_SCHEMA = os.getenv("RKP_SCHEMA", "rekap")

BASE_OUTPUT = "/app/data/output_gdb"
os.makedirs(BASE_OUTPUT, exist_ok=True)

PREFIX_TAB = "KWS"
TABLE_A = "KWSHUTAN_AR_250K_DES2025"
FIELD_CATEGORY_A = "FUNGSIKWS"
MASTER_SCHEMA = "kodefikasi"
MASTER_TABLE = "KODE_KWS"
MASTER_JOIN_FIELD = "KD_KWS"
TABLE_B = "ADM_KAB_KOTA"
FIELD_FILTER_B = "WADMPR"

# Inisialisasi Engine
engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

# 2. HELPER FUNCTIONS
def get_table_columns(engine, schema, table):
    """Mengambil daftar kolom dari tabel tertentu kecuali kolom geometri."""
    query = text("""
        SELECT column_name FROM information_schema.columns
        WHERE table_schema = :schema AND table_name = :table
        ORDER BY ordinal_position
    """)
    with engine.connect() as conn:
        result = conn.execute(query, {"schema": schema, "table": table})
        cols = [row[0] for row in result]
        forbidden = ('geom', 'geometry', 'shape', 'raw_geom', 'poly_geom', 'clean_poly')
        return [c for c in cols if c.lower() not in forbidden]

# 3. PENANGANAN ARGUMEN
if len(sys.argv) < 2:
    print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = " ".join(sys.argv[1:])
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

OUT_TABLE = f"{PREFIX_TAB}_{SAFE_NAME}"
RESULT_TABLE_FULL = f'"{SCHEMA_OUT}"."{OUT_TABLE}"'
GDB_NAME = f"{OUT_TABLE}.gdb"
GDB_PATH = os.path.join(BASE_OUTPUT, GDB_NAME)
ZIP_BASE_NAME = os.path.join(BASE_OUTPUT, GDB_NAME)
FINAL_ZIP_PATH = f"{ZIP_BASE_NAME}.zip"

try:
    # Ambil kolom dari tabel data utama
    DATA_COLUMNS = get_table_columns(engine, SCHEMA_DATA, TABLE_A)
    ST_SELECT_DATA_COLS = ", ".join([f'a."{c}"' for c in DATA_COLUMNS])

    # 4. PROSES SPASIAL (CLIPPING)
    with engine.begin() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA_OUT}";'))
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{RKP_SCHEMA}";'))
        conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL} CASCADE;'))

        print(f"⏳ [1/4] Clipping & Cleaning: {PROVINSI_TARGET}...")
        query_create = text(f"""
            CREATE TABLE {RESULT_TABLE_FULL} AS
            WITH mask AS (
                SELECT ST_MakeValid(ST_Union(geom)) as geom_mask
                FROM "{SCHEMA_DATA}"."{TABLE_B}"
                WHERE "{FIELD_FILTER_B}" ILIKE :prov
            ),
            intersected AS (
                SELECT {ST_SELECT_DATA_COLS}, ST_Intersection(a.geom, m.geom_mask) as raw_geom
                FROM "{SCHEMA_DATA}"."{TABLE_A}" a
                JOIN mask m ON ST_Intersects(a.geom, m.geom_mask)
            ),
            extracted AS (
                SELECT {", ".join([f'"{c}"' for c in DATA_COLUMNS])},
                       ST_MakeValid(ST_CollectionExtract(raw_geom, 3)) as clean_poly
                FROM intersected
            )
            SELECT {", ".join([f'"{c}"' for c in DATA_COLUMNS])},
                   ST_Multi(ST_Force2D(clean_poly))::geometry(MultiPolygon, 4326) as geom,
                   ST_Area(ST_Transform(clean_poly, 54034)) / 10000 as "LUAS_CEA_HA"
            FROM extracted
            WHERE clean_poly IS NOT NULL AND NOT ST_IsEmpty(clean_poly);
        """)
        conn.execute(query_create, {"prov": PROVINSI_TARGET})

    # 5. EKSPOR KE GDB
    print(f"📦 [2/4] Ekspor ke GDB: {GDB_NAME}...")
    if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)

    ogr_cmd = [
        "ogr2ogr", "-f", "OpenFileGDB", GDB_PATH,
        f"PG:host={DB_HOST} user={DB_USER} dbname={DB_NAME} password={DB_PASS} port={DB_PORT}",
        "-nln", OUT_TABLE, "-nlt", "MULTIPOLYGON", "-dim", "XY", "-skipfailures",
        "-sql", f"SELECT * FROM {RESULT_TABLE_FULL}"
    ]
    subprocess.run(ogr_cmd, check=True)

    # 6. SUMMARY (MODIFIKASI: AMBIL SEMUA FIELD MASTER)
    print(f"📊 [3/4] Update Rekapitulasi (Seluruh Atribut Master)...")
    
    # Ambil daftar kolom master secara dinamis
    MASTER_COLS = get_table_columns(engine, MASTER_SCHEMA, MASTER_TABLE)
    # Buat string SELECT untuk kolom master (kecuali kolom kunci join agar tidak double)
    ST_SELECT_MASTER = ", ".join([f'b."{c}"' for c in MASTER_COLS if c != MASTER_JOIN_FIELD])
    
    # Hitung jumlah kolom untuk grouping (Indeks 1 adalah kunci, sisanya atribut b)
    # Total kolom yang di-group adalah 1 (kunci) + jumlah MASTER_COLS - 1
    group_indices = ", ".join([str(i+1) for i in range(len(MASTER_COLS))])

    query_summary = f"""
        SELECT 
            a."{FIELD_CATEGORY_A}" AS "{MASTER_JOIN_FIELD}",
            {ST_SELECT_MASTER},
            SUM(a."LUAS_CEA_HA") AS "TOTAL_LUAS_HA"
        FROM {RESULT_TABLE_FULL} a
        LEFT JOIN "{MASTER_SCHEMA}"."{MASTER_TABLE}" b 
            ON a."{FIELD_CATEGORY_A}"::text = b."{MASTER_JOIN_FIELD}"::text
        GROUP BY {group_indices}
        ORDER BY "TOTAL_LUAS_HA" DESC
    """
    
    summary_df = pd.read_sql(query_summary, engine)
    summary_df.to_sql(f"SUM_{OUT_TABLE}", engine, schema=RKP_SCHEMA, if_exists='replace', index=False)

    # 7. ZIPPING
    print(f"🗜️ [4/4] Membuat Archive: {os.path.basename(FINAL_ZIP_PATH)}...")
    if os.path.exists(FINAL_ZIP_PATH): os.remove(FINAL_ZIP_PATH)
    shutil.make_archive(ZIP_BASE_NAME, 'zip', root_dir=BASE_OUTPUT, base_dir=GDB_NAME)

    # Cleanup GDB Folder setelah di-zip
    if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)

    # OUTPUT FINAL
    duration = time.time() - start_time
    formatted_time = str(datetime.timedelta(seconds=int(duration)))
    print(f"\n✅ SELESAI!")
    print(f"📍 Lokasi Zip : {FINAL_ZIP_PATH}")
    print(f"📍 Tabel Rekap: {RKP_SCHEMA}.SUM_{OUT_TABLE}")
    print(f"⏱️ Waktu Kerja: {formatted_time} ({duration:.2f} detik)")

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    sys.exit(1)
