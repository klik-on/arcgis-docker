#!/usr/bin/env python3
import sys
import os
import time
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

# 1. LOAD KONFIGURASI
load_dotenv()

DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')

SCHEMA_DATA = os.getenv("SCHEMA_DATA", "datagis")
SCHEMA_OUT = os.getenv("SCHEMA_OUT", "analisis")
RKP_SCHEMA = os.getenv("RKP_SCHEMA", "rekap")

# Parameter Tabel
PREFIX_TAB = "KWS"
TABLE_A = "KWSHUTAN_AR_250K_v18102025"
FIELD_CATEGORY_A = "FUNGSIKWS"

# Parameter Master Kodefikasi
MASTER_SCHEMA = "kodefikasi"
MASTER_TABLE = "KODE_KWS"
MASTER_JOIN_FIELD = "KD_KWS"

TABLE_B = "ADM_KAB_KOTA"
FIELD_FILTER_B = "WADMPR"

# Koneksi Database
engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

# 2. FUNGSI METADATA
def get_table_columns(engine, schema, table):
    query = text("""
        SELECT column_name FROM information_schema.columns
        WHERE table_schema = :schema AND table_name = :table
        ORDER BY ordinal_position
    """)
    with engine.connect() as conn:
        result = conn.execute(query, {"schema": schema, "table": table})
        cols = [row[0] for row in result]
        forbidden = ('geom', 'geometry', 'shape', 'raw_geom', 'geom_new', 'clipped_geom')
        return [c for c in cols if c.lower() not in forbidden]

# 3. PENANGANAN ARGUMEN
if len(sys.argv) < 2:
    print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = " ".join(sys.argv[1:])
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

OUT_TABLE = f"{PREFIX_TAB}_{SAFE_NAME}"
RESULT_TABLE_FULL = f'"{SCHEMA_OUT}"."{OUT_TABLE}"'
SUMMARY_TABLE_FULL = f'"{RKP_SCHEMA}"."SUM_{OUT_TABLE}"'

try:
    DATA_COLUMNS = get_table_columns(engine, SCHEMA_DATA, TABLE_A)
    ST_SELECT_DATA_COLS = ", ".join([f'a."{c}"' for c in DATA_COLUMNS])

    # 4. PROSES SPASIAL (CLIP)
    with engine.begin() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA_OUT}";'))
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{RKP_SCHEMA}";'))
        conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL} CASCADE;'))

        # MODIFIKASI UTAMA: Penambahan Casting ::geometry(MultiPolygon, 4326)
        query_create = text(f"""
            CREATE TABLE {RESULT_TABLE_FULL} AS
            WITH mask AS (
                SELECT ST_MakeValid(ST_Union(geom)) as geom_mask
                FROM "{SCHEMA_DATA}"."{TABLE_B}"
                WHERE "{FIELD_FILTER_B}" ILIKE :prov
            ),
            intersected AS (
                SELECT 
                    {ST_SELECT_DATA_COLS}, 
                    ST_Intersection(a.geom, m.geom_mask) as clipped_geom
                FROM "{SCHEMA_DATA}"."{TABLE_A}" a
                JOIN mask m ON ST_Intersects(a.geom, m.geom_mask)
            )
            SELECT 
                {", ".join([f'"{c}"' for c in DATA_COLUMNS])},
                -- Memastikan output adalah MultiPolygon yang valid dan terdaftar
                ST_Multi(ST_CollectionExtract(clipped_geom, 3))::geometry(MultiPolygon, 4326) as geom,
                ST_Area(ST_Transform(ST_CollectionExtract(clipped_geom, 3), 54034)) / 10000 as "LUAS_CEA_HA"
            FROM intersected 
            WHERE NOT ST_IsEmpty(clipped_geom)
              AND ST_GeometryType(ST_CollectionExtract(clipped_geom, 3)) IN ('ST_Polygon', 'ST_MultiPolygon');
        """)
        
        print(f"⏳ Clipping {PROVINSI_TARGET} ke {RESULT_TABLE_FULL}...")
        conn.execute(query_create, {"prov": PROVINSI_TARGET})
        conn.execute(text(f'CREATE INDEX ON {RESULT_TABLE_FULL} USING GIST(geom);'))

    # 5. GENERATE SUMMARY
    print(f"📊 Menghasilkan rekapitulasi dengan join ke {MASTER_TABLE}...")

    query_summary = f"""
        SELECT
            a."{FIELD_CATEGORY_A}" AS kode,
            COALESCE(b."LABEL_KWS", 'KODE ' || a."{FIELD_CATEGORY_A}" || ' (BELUM TERDAFTAR)') AS fungsi_hutan,
            SUM(a."LUAS_CEA_HA") AS luas_ha
        FROM {RESULT_TABLE_FULL} a
        LEFT JOIN "{MASTER_SCHEMA}"."{MASTER_TABLE}" b
            ON a."{FIELD_CATEGORY_A}"::text = b."{MASTER_JOIN_FIELD}"::text
        GROUP BY a."{FIELD_CATEGORY_A}", b."LABEL_KWS"
        ORDER BY luas_ha DESC
    """

    summary_df = pd.read_sql(query_summary, engine)

    if not summary_df.empty:
        print("\n" + "="*85)
        print(f"RINGKASAN HASIL ANALISIS: {PROVINSI_TARGET}")
        print("="*85)
        print(summary_df[['fungsi_hutan', 'luas_ha']].to_string(index=False, formatters={'luas_ha': '{:,.2f}'.format}))
        print("-" * 85)
        print(f"TOTAL LUAS: {summary_df['luas_ha'].sum():,.2f} HA")

        summary_df.to_sql(f"SUM_{OUT_TABLE}", engine, schema=RKP_SCHEMA, if_exists='replace', index=False)
        print(f"\n✅ Berhasil! Tabel rekap tersimpan di {SUMMARY_TABLE_FULL}")
    else:
        print(f"⚠️ Tidak ada irisan data untuk wilayah {PROVINSI_TARGET}.")

    print(f"\n⏱️ Selesai dalam {time.time() - start_time:.2f} detik.")

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    sys.exit(1)
