#!/bin/bash
# run_metadata_sync.sh

GDB_PATH="/app/data/input.gdb"
XSLT_PATH="/app/resources/metadata/arcgis_to_iso19139.xsl"
OUTPUT_DIR="/app/data/metadata_output"

# Ambil daftar layer dari GDB (bisa dikembangkan menggunakan ogrinfo)
LAYER_NAME="Nama_Layer_Anda"

echo "Processing Metadata for $LAYER_NAME..."
python3 /app/scripts/proses/gdb_metadata_to_iso.py \
    --gdb "$GDB_PATH" \
    --layer "$LAYER_NAME" \
    --xslt "$XSLT_PATH" \
    --out "$OUTPUT_DIR/${LAYER_NAME}_ISO19139.xml"
