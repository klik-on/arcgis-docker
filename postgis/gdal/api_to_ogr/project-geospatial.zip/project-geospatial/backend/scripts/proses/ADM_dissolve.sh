#!/bin/bash
# ADM_dissolve.sh — dissolve kab/kota menjadi provinsi
# Fitur:
# ✅ Auto deteksi SRID
# ✅ Auto transform ke EPSG:4326
# ✅ Auto hapus tabel lama
# ✅ Auto index
# ✅ Validasi & auto-repair geometri
# ✅ Summary akhir: record, multipolygon count, total area
# ✅ Logging ke /var/log/adm_dissolve.log

# === Konfigurasi koneksi ===
HOST="172.16.2.122"
DBNAME="postgres"
USER="postgres.67888"
PASS="password00"
SCHEMA="datagis"
SOURCE_TABLE="ADM_KAB_KOTA"
TARGET_TABLE="adm_provinsi_clean"

LOG_FILE="/var/log/adm_dissolve.log"
mkdir -p "$(dirname "$LOG_FILE")"

function log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "🚀 Memulai ADM dissolve job..."
START_TIME=$(date +%s)

# === Cek SRID ===
log "🔍 Mengecek SRID tabel sumber..."
SRID=$(ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" "$SCHEMA.$SOURCE_TABLE" 2>/dev/null \
  | grep -i "SRID=" | head -n 1 | sed -E 's/.*SRID=([0-9]+).*/\1/')
[ -z "$SRID" ] && SRID=4326
log "📐 SRID sumber: $SRID"

# === Hapus tabel lama ===
log "🧹 Mengecek dan menghapus tabel lama..."
ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  DROP TABLE IF EXISTS $SCHEMA.\"$TARGET_TABLE\" CASCADE;
" >> "$LOG_FILE" 2>&1

# === SQL dissolve ===
if [ "$SRID" -eq 4326 ]; then
  SQL="
    SELECT
      \"WADMPR\" AS nama_provinsi,
      \"kdppum\" AS kode_provinsi,
      ST_Multi(ST_Union(ST_MakeValid(geom)))::geometry(MultiPolygon, 4326) AS geom
    FROM $SCHEMA.\"$SOURCE_TABLE\"
    GROUP BY \"WADMPR\", \"kdppum\"
  "
else
  SQL="
    SELECT
      \"WADMPR\" AS nama_provinsi,
      \"kdppum\" AS kode_provinsi,
      ST_Multi(ST_Union(ST_Transform(ST_MakeValid(geom), 4326)))::geometry(MultiPolygon, 4326) AS geom
    FROM $SCHEMA.\"$SOURCE_TABLE\"
    GROUP BY \"WADMPR\", \"kdppum\"
  "
  log "♻️  Transform SRID $SRID → 4326."
fi

# === Jalankan dissolve ===
log "🏗️  Menjalankan proses dissolve..."
TEMP_LOG=$(mktemp)
{ time ogr2ogr -f "PostgreSQL" \
  "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" \
  "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" \
  -dialect PostgreSQL \
  -sql "$SQL" \
  -nln $SCHEMA.$TARGET_TABLE \
  -nlt PROMOTE_TO_MULTI \
  -overwrite 2>&1; } | tee -a "$TEMP_LOG" "$LOG_FILE"

if [ ${PIPESTATUS[0]} -ne 0 ]; then
  log "❌ Gagal menjalankan ogr2ogr."
  exit 1
fi

# === Buat index ===
log "🧱 Membuat index..."
ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  CREATE INDEX IF NOT EXISTS ${TARGET_TABLE}_geom_idx ON $SCHEMA.\"$TARGET_TABLE\" USING GIST(geom);
  CREATE INDEX IF NOT EXISTS ${TARGET_TABLE}_kode_idx ON $SCHEMA.\"$TARGET_TABLE\"(kode_provinsi);
  CREATE INDEX IF NOT EXISTS ${TARGET_TABLE}_nama_idx ON $SCHEMA.\"$TARGET_TABLE\"(nama_provinsi);
" >> "$LOG_FILE" 2>&1

# === Validasi & Auto-Repair Geometri ===
log "🔎 Memvalidasi geometri..."
INVALID_COUNT=$(ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  SELECT COUNT(*) AS invalid_count
  FROM $SCHEMA.\"$TARGET_TABLE\"
  WHERE NOT ST_IsValid(geom);
" 2>/dev/null | grep -E "invalid_count" | sed -E 's/.*invalid_count *= *([0-9.]+).*/\1/' | tr -d '\r')
[ -z "$INVALID_COUNT" ] && INVALID_COUNT=0

if [[ "$INVALID_COUNT" =~ ^[0-9]+$ ]] && [ "$INVALID_COUNT" -gt 0 ]; then
  log "⚠️  Ditemukan $INVALID_COUNT geometri tidak valid, memperbaiki..."
  ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
    UPDATE $SCHEMA.\"$TARGET_TABLE\"
    SET geom = ST_MakeValid(geom)
    WHERE NOT ST_IsValid(geom);
  " >> "$LOG_FILE" 2>&1
  log "✅ Semua geometri sekarang valid."
else
  log "✅ Semua geometri valid."
fi

# === Summary akhir ===
log "📊 Menghitung summary akhir..."
RECORD_COUNT=$(ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  SELECT COUNT(*) AS count FROM $SCHEMA.\"$TARGET_TABLE\";
" 2>/dev/null | grep -E "count" | sed -E 's/.*count *= *([0-9.]+).*/\1/' | tr -d '\r')

MULTIPOLYGON_COUNT=$(ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  SELECT COUNT(*) AS multi_count FROM $SCHEMA.\"$TARGET_TABLE\" WHERE GeometryType(geom)='MULTIPOLYGON';
" 2>/dev/null | grep -E "multi_count" | sed -E 's/.*multi_count *= *([0-9.]+).*/\1/' | tr -d '\r')

TOTAL_AREA=$(ogrinfo "PG:host=$HOST dbname=$DBNAME user=$USER password=$PASS" -sql "
  SELECT SUM(ST_Area(ST_Transform(geom,54034))) AS total_area_m2 FROM $SCHEMA.\"$TARGET_TABLE\";
" 2>/dev/null | grep -E "total_area_m2" | sed -E 's/.*total_area_m2 *= *([0-9.]+).*/\1/' | tr -d '\r')

log "📝 Summary:"
log "  - Total record: $RECORD_COUNT"
log "  - Multipolygon: $MULTIPOLYGON_COUNT"
log "  - Total area (m²): $TOTAL_AREA"

# === Selesai ===
END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))
log "🎉 Proses selesai dalam $((ELAPSED / 60)) menit $((ELAPSED % 60)) detik."
log "📁 Output: $SCHEMA.$TARGET_TABLE"
log "📝 Log: $LOG_FILE"
