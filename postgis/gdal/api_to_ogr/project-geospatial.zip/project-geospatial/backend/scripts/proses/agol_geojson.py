#!/usr/bin/env python3
# ==============================
# AGOL → GeoJSON (Field Uppercase) dengan Resume & Retry
# ==============================
import requests
import json
import urllib3
import os
import time
from datetime import datetime

# ----------------------------------------
# Konfigurasi
# cek Field => https://dbgis.planologi.kehutanan.go.id/server/rest/services/DataSIG//PAPH_AR_250K/FeatureServer/0?f=pjson
# ----------------------------------------
IGT = "PAPH_AR_250K"
DATA_DIR = "/app/data"
GEOJSON_PATH = f"{DATA_DIR}/{IGT}.geojson"
BASE_URL = f"https://dbgis.planologi.kehutanan.go.id/server/rest/services/DataSIG/{IGT}/FeatureServer/0/query"

TOKEN = os.environ.get("AGOL_TOKEN")
if not TOKEN:
    raise ValueError("Environment variable AGOL_TOKEN belum diset!")

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
os.makedirs(DATA_DIR, exist_ok=True)

# ----------------------------------------
# Logging helper
# ----------------------------------------
def log(msg):
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}")

# ----------------------------------------
# Normalisasi geometry → MultiPolygon
# ----------------------------------------
def normalize_geometry(feature):
    geom = feature.get("geometry")
    if not geom:
        return None
    gtype = geom.get("type")
    if gtype == "Polygon":
        return {"type": "MultiPolygon", "coordinates": [geom["coordinates"]]}
    if gtype == "MultiPolygon":
        return geom
    return None  # skip geometry lain

# ----------------------------------------
# Ambil semua OBJECTID
# ----------------------------------------
def fetch_objectids():
    params = {"where": "1=1", "returnIdsOnly": "true", "f": "json", "token": TOKEN}
    r = requests.get(BASE_URL, params=params, verify=False, timeout=30)
    r.raise_for_status()
    data = r.json()
    return sorted(data.get("objectIds", []))

# ----------------------------------------
# Ambil fitur per chunk dengan retry
# ----------------------------------------
def fetch_features_by_id_chunk(chunk, retries=3, backoff=5):
    oid_list = ",".join(map(str, chunk))
    params = {
        "objectIds": oid_list,
        "outFields": "*",
        "returnGeometry": "true",
        "f": "geojson",
        "token": TOKEN
    }
    for attempt in range(1, retries + 1):
        try:
            r = requests.get(BASE_URL, params=params, verify=False, timeout=30)
            r.raise_for_status()
            data = r.json()
            if "error" in data:
                raise Exception(data["error"])
            return data
        except Exception as e:
            log(f"❌ Gagal fetch chunk {chunk[:5]}... (attempt {attempt}/{retries}): {e}")
            if attempt < retries:
                sleep_time = backoff * attempt
                log(f"⏳ Menunggu {sleep_time} detik sebelum retry...")
                time.sleep(sleep_time)
            else:
                log(f"⚠️ Melewati chunk ini setelah {retries} percobaan.")
                return None

# ----------------------------------------
# MAIN
# ----------------------------------------
try:
    log("🔎 Mengambil daftar OBJECTID...")
    objectids = fetch_objectids()
    if not objectids:
        raise Exception("Tidak ada OBJECTID ditemukan")
    log(f"✅ Jumlah OBJECTID ditemukan: {len(objectids)}")

    # ----------------------------------------
    # Resume jika GeoJSON sudah ada
    # ----------------------------------------
    if os.path.exists(GEOJSON_PATH):
        log(f"🔄 File GeoJSON sudah ada. Melanjutkan dari yang tersimpan...")
        with open(GEOJSON_PATH, "r", encoding="utf-8") as f:
            ALL_FEATURES = json.load(f)
        fetched_oids = {f.get("properties", {}).get("OBJECTID") for f in ALL_FEATURES["features"]}
    else:
        ALL_FEATURES = {"type": "FeatureCollection", "features": []}
        fetched_oids = set()

    CHUNK_SIZE = 50
    total_chunks = (len(objectids) + CHUNK_SIZE - 1) // CHUNK_SIZE

    log("🚀 Mulai mengambil fitur dalam chunk...")
    for i in range(0, len(objectids), CHUNK_SIZE):
        chunk = objectids[i:i + CHUNK_SIZE]
        if all(oid in fetched_oids for oid in chunk):
            log(f"✅ Chunk {i} - {i + len(chunk) - 1} sudah ada, dilewati.")
            continue

        log(f"📦 Mengambil chunk {i} - {i + len(chunk) - 1} ...")
        batch = fetch_features_by_id_chunk(chunk)
        if not batch or "features" not in batch:
            log(f"⚠️ Chunk gagal, dilewati.")
            continue

        for f in batch["features"]:
            geom = normalize_geometry(f)
            if not geom:
                continue

            # --- ubah field ke huruf besar ---
            props = {k.upper(): v for k, v in f.get("properties", f.get("attributes", {})).items()}
            props.pop("SHAPE__LENGTH", None)
            props.pop("SHAPE__AREA", None)
            f["properties"] = props
            f["geometry"] = geom
            ALL_FEATURES["features"].append(f)

            oid_val = props.get("OBJECTID")
            if oid_val is not None:
                fetched_oids.add(oid_val)

        # Simpan GeoJSON sementara setiap chunk
        with open(GEOJSON_PATH, "w", encoding="utf-8") as f:
            json.dump(ALL_FEATURES, f, ensure_ascii=False, indent=2)
        log(f"💾 Chunk {i} - {i + len(chunk) - 1} berhasil disimpan ke GeoJSON.")

    log(f"🎉 Semua chunk selesai. GeoJSON final tersimpan di {GEOJSON_PATH}")

except Exception as e:
    log(f"❌ ERROR FATAL: {e}")
