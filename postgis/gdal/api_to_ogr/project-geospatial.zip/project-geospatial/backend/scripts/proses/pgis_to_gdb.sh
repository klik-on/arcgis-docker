#!/bin/bash
set -e

# === Konfigurasi Internal ===
LAYER_NAME=$1
DATA_DIR="/app/data"

# Validasi Input
if [ -z "$LAYER_NAME" ]; then
  echo "❌ Error: Nama layer tidak disertakan!"
  exit 1
fi

# === Jalur File ===
OUTPUT_GDB="${DATA_DIR}/${LAYER_NAME}.gdb"
ZIP_PATH="${DATA_DIR}/${LAYER_NAME}.gdb.zip"

# === Deteksi Driver (Optimasi) ===
# Kita prioritaskan OpenFileGDB karena GDAL 3.6+ sangat stabil untuk menulis GDB
if ogrinfo --formats | grep -q "OpenFileGDB"; then
  DRIVER="OpenFileGDB"
  echo "✅ Menggunakan driver OpenFileGDB"
else
  DRIVER="FileGDB"
  echo "⚠️ Menggunakan driver FileGDB (Fallback)"
fi

# === Siapkan folder ===
mkdir -p "$DATA_DIR"
# Hapus folder GDB lama jika ada agar tidak konflik saat overwrite
rm -rf "$OUTPUT_GDB"

echo "🚀 Mengekspor ${DB_SCHEMA}.${LAYER_NAME} ke GDB..."

# === Jalankan ekspor ogr2ogr ===
# Perubahan: Menggunakan -overwrite (global) daripada -lco OVERWRITE
OGR_ARGS=(
  -f "$DRIVER"
  "$OUTPUT_GDB"
  PG:"host=${DB_HOST} port=${DB_PORT} dbname=${DB_NAME} user=${DB_USER} password=${DB_PASS}"
  "${DB_SCHEMA}.${LAYER_NAME}"
  -nln "$LAYER_NAME"
  -overwrite # <--- Gunakan ini untuk menimpa dataset/tabel
  -dim 2
  -t_srs EPSG:4326
  -nlt PROMOTE_TO_MULTI
  -progress
)

ogr2ogr "${OGR_ARGS[@]}"

# === Validasi & Kompresi ===
if [ ! -d "$OUTPUT_GDB" ]; then
  echo "❌ Ekspor gagal!"
  exit 1
fi

echo "📦 Mengarsipkan ke ZIP..."
# Menggunakan -j agar tidak menyertakan struktur folder /app/data/ di dalam zip
zip -jr "$ZIP_PATH" "$OUTPUT_GDB" > /dev/null

# === Cleanup ===
rm -rf "$OUTPUT_GDB"
echo "✅ Ekspor Berhasil!"
echo "🕒 Selesai pada: $(date)"
