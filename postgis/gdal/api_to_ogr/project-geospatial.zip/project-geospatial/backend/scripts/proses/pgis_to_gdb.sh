#!/bin/bash
set -e

# === Konfigurasi Internal ===
LAYER_NAME=$1
DATA_DIR="/app/data"

# 1. Validasi Input Dasar
if [ -z "$LAYER_NAME" ]; then
    echo "❌ Error: Nama layer tidak disertakan!"
    exit 1
fi

# 2. Validasi Environment
REQUIRED_VARS=(DB_HOST DB_PORT DB_NAME DB_USER DB_PASS DB_SCHEMA)
for var in "${REQUIRED_VARS[@]}"; do
    if [ -z "${!var}" ]; then echo "❌ Error: Variabel $var belum disetel!"; exit 1; fi
done

# === Jalur File ===
OUTPUT_GDB="${DATA_DIR}/${LAYER_NAME}.gdb"
ZIP_PATH="${DATA_DIR}/${LAYER_NAME}.gdb.zip"

# === Deteksi Driver ===
DRIVER="OpenFileGDB"
if ! ogrinfo --formats | grep -q "OpenFileGDB"; then
    DRIVER="FileGDB"
fi

# === Persiapan Folder ===
mkdir -p "$DATA_DIR"
rm -rf "$OUTPUT_GDB"
rm -f "$ZIP_PATH"

echo "✅ Driver: $DRIVER | Layer: ${DB_SCHEMA}.${LAYER_NAME}"
echo "🚀 Memulai ekspor dari PostGIS..."

# === Ekspor dengan Konfigurasi Global di Awal ===
export PGPASSWORD="${DB_PASS}"



# Menjalankan ogr2ogr dengan --config di posisi awal
ogr2ogr \
    --config METHOD SKIP \
    --config PG_LIST_ALL_TABLES YES \
    -f "$DRIVER" \
    "$OUTPUT_GDB" \
    "PG:host=${DB_HOST} port=${DB_PORT} dbname=${DB_NAME} user=${DB_USER}" \
    "${DB_SCHEMA}.${LAYER_NAME}" \
    -nln "$LAYER_NAME" \
    -overwrite \
    -dim 2 \
    -t_srs EPSG:4326 \
    -nlt PROMOTE_TO_MULTI \
    -progress

unset PGPASSWORD

# === Validasi & Kompresi ===
if [ -d "$OUTPUT_GDB" ]; then
    echo "📦 Mengarsipkan ke ZIP (Level 9)..."
    zip -9jr "$ZIP_PATH" "$OUTPUT_GDB" > /dev/null
    rm -rf "$OUTPUT_GDB"
    echo "✅ Berhasil! File: $ZIP_PATH"
    echo "🕒 Selesai: $(date)"
else
    echo "❌ Error: Output GDB tidak ditemukan!"
    exit 1
fi
