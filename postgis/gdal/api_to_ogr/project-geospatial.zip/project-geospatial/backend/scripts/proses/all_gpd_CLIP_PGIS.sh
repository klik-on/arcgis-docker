#!/bin/bash
PROVINSI=("DKI Jakarta" "Jawa Timur" "Kalimantan Barat" "Jawa Barat" "Jawa Tengah")

for PROV in "${PROVINSI[@]}"
do
    python3 gpd_CLIP_KWS2.py "$PROV"
done
