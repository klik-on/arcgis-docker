#!/usr/bin/env python3
import os
import time
import sys
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# 1. LOAD KONFIGURASI
load_dotenv()

# Kredensial Database dari Environment
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')

# Skema dari Environment (Sesuai dengan JSON Task Anda)
RKP_SCHEMA = os.getenv("RKP_SCHEMA", "rekap")

def build_national_recap():
    print("="*70)
    print("📊 GEO-DATABASE CONSOLIDATOR: NATIONAL RECAP")
    print(f"🕒 Time: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"📂 Target Schema: {RKP_SCHEMA}")
    print("="*70)

    # Inisialisasi koneksi database
    db_url = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    engine = create_engine(db_url)
    
    # Query untuk membangun Materialized View Nasional secara dinamis
    # Menggunakan teknik XML unnesting untuk performa penggabungan tabel yang cepat
    sql_consolidate = text(f"""
        -- 1. Bersihkan versi lama jika ada
        DROP MATERIALIZED VIEW IF EXISTS {RKP_SCHEMA}."SUM_KWSHUTAN_NASIONAL";
        
        -- 2. Bangun View Nasional dari semua tabel ber-prefix SUM_KWS_
        CREATE MATERIALIZED VIEW {RKP_SCHEMA}."SUM_KWSHUTAN_NASIONAL" AS
        SELECT 
            -- Membersihkan nama tabel untuk kolom Provinsi (Contoh: SUM_KWS_JAWA_TIMUR -> JAWA TIMUR)
            REPLACE(REPLACE(table_name, 'SUM_KWS_', ''), '_', ' ') AS provinsi,
            (xpath('/row/kode/text()', data))[1]::text as kode,
            (xpath('/row/fungsi_hutan/text()', data))[1]::text as fungsi_hutan,
            (xpath('/row/luas_ha/text()', data))[1]::text::float8 as luas_ha,
            NOW() as tanggal_analisis
        FROM information_schema.tables t
        CROSS JOIN LATERAL (
            -- Teknik dynamic union tanpa harus menulis UNION ALL satu-satu
            SELECT unnest(xpath('/table/row', query_to_xml(format('SELECT * FROM %I.%I', table_schema, table_name), true, false, ''))) as data
        ) AS rows
        WHERE table_schema = '{RKP_SCHEMA}' 
          AND table_name LIKE 'SUM_KWS_%'
          AND table_name != 'SUM_KWSHUTAN_NASIONAL'
          AND table_name NOT LIKE 'SUM_KWS_KODE_%'; -- Filter tabel referensi

        -- 3. Optimasi Indexing agar dashboard tidak lemot
        CREATE INDEX IF NOT EXISTS idx_nas_fungsi ON {RKP_SCHEMA}."SUM_KWSHUTAN_NASIONAL"(fungsi_hutan);
        CREATE INDEX IF NOT EXISTS idx_nas_prov ON {RKP_SCHEMA}."SUM_KWSHUTAN_NASIONAL"(provinsi);
    """)

    start_time = time.time()
    try:
        with engine.begin() as conn:
            print(f"🔄 Menghimpun data dari tabel-tabel di skema '{RKP_SCHEMA}'...")
            conn.execute(sql_consolidate)
            
            # Ambil total baris sebagai validasi hasil
            count_res = conn.execute(text(f'SELECT count(*) FROM {RKP_SCHEMA}."SUM_KWSHUTAN_NASIONAL"'))
            total_rows = count_res.scalar()
            
        duration = time.time() - start_time
        print(f"✅ SUCCESS: Tabel {RKP_SCHEMA}.\"SUM_KWSHUTAN_NASIONAL\" berhasil diperbarui.")
        print(f"📈 Total entitas data terhimpun: {total_rows} baris.")
        print(f"⏱️ Waktu proses: {duration:.2f} detik.")
        
    except Exception as e:
        print(f"❌ ERROR saat konsolidasi nasional: {e}")
        sys.exit(1)
    finally:
        engine.dispose()
        print("="*70)

if __name__ == "__main__":
    build_national_recap()
