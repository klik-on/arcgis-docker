#!/usr/bin/env python3
import os
import time
import sys
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

load_dotenv()

DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
RKP_SCHEMA = os.getenv("RKP_SCHEMA", "rekap")

def build_national_recap():
    print("="*70)
    print("📊 GEO-DATABASE CONSOLIDATOR: NATIONAL RECAP (FIXED VERSION)")
    print(f"🕒 Time: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)

    db_url = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    engine = create_engine(db_url)

    # PERHATIKAN: Nama tag XML (kode, fungsikws, luas_cea_ha) harus sesuai 
    # dengan hasil query_to_xml yang biasanya mengikuti case kolom di DB.
    sql_consolidate = text(f"""
        DROP MATERIALIZED VIEW IF EXISTS {RKP_SCHEMA}."SUM_KWSHUTAN_NASIONAL";

        CREATE MATERIALIZED VIEW {RKP_SCHEMA}."SUM_KWSHUTAN_NASIONAL" AS
        SELECT
            REPLACE(REPLACE(table_name, 'SUM_KWS_', ''), '_', ' ') AS provinsi,
            -- Menggunakan nama kolom hasil standardisasi UPPERCASE sebelumnya
            (xpath('/row/KODE_KWS/text()', data))[1]::text as kode,
            (xpath('/row/FUNGSIKWS/text()', data))[1]::text as fungsi_hutan,
            (xpath('/row/TOTAL_LUAS_HA/text()', data))[1]::text::float8 as luas_ha,
            NOW() as tanggal_analisis
        FROM information_schema.tables t
        CROSS JOIN LATERAL (
            SELECT unnest(xpath('/table/row', query_to_xml(format('SELECT * FROM %I.%I', table_schema, table_name), true, false, ''))) as data
        ) AS rows
        WHERE table_schema = '{RKP_SCHEMA}'
          AND table_name LIKE 'SUM_KWS_%'
          AND table_name != 'SUM_KWSHUTAN_NASIONAL'
          AND table_name NOT LIKE 'SUM_KWS_KODE_%';

        CREATE INDEX idx_nas_fungsi ON {RKP_SCHEMA}."SUM_KWSHUTAN_NASIONAL"(fungsi_hutan);
        CREATE INDEX idx_nas_prov ON {RKP_SCHEMA}."SUM_KWSHUTAN_NASIONAL"(provinsi);
    """)

    start_time = time.time()
    try:
        with engine.begin() as conn:
            print(f"🔄 Menghimpun data dari tabel rekapitulasi provinsi...")
            conn.execute(sql_consolidate)
            
            res = conn.execute(text(f'SELECT count(*) FROM {RKP_SCHEMA}."SUM_KWSHUTAN_NASIONAL"'))
            total_rows = res.scalar()

        print(f"✅ SUCCESS: {total_rows} baris data nasional terkonsolidasi.")
        print(f"⏱️ Waktu proses: {time.time() - start_time:.2f} detik.")

    except Exception as e:
        print(f"❌ ERROR: Pastikan kolom di tabel SUM_KWS_ sesuai (KODE_KWS, FUNGSIKWS, TOTAL_LUAS_HA)")
        print(f"Detail Error: {e}")
        sys.exit(1)
    finally:
        engine.dispose()
        print("="*70)

if __name__ == "__main__":
    build_national_recap()
