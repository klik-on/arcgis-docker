#!/bin/bash
HOSTNAME=$(docker inspect --format '{{ .Config.Hostname }}' supabase-db)
# Menambahkan direktori psql ke PATH
# which psql
# export PATH=$PATH:/root/.nix-profile/bin
# \pset pager off
# \dt datagis.*

# Konfigurasi PostgreSQL
# docker exec -it supabase-db bash -c "sed -i 's/^#*shared_buffers.*/shared_buffers = 8GB/' /etc/postgresql/postgresql.conf"
# docker exec -it supabase-db bash -c "sed -i 's/^#*work_mem.*/work_mem = 256MB/' /etc/postgresql/postgresql.conf"
# docker exec -it supabase-db bash -c "sed -i 's/^#*maintenance_work_mem.*/maintenance_work_mem = 1GB/' /etc/postgresql/postgresql.conf"
# docker exec -it supabase-db bash -c "sed -i 's/^#*max_parallel_workers_per_gather.*/max_parallel_workers_per_gather = 8/' /etc/postgresql/postgresql.conf"
# docker exec -it supabase-db bash -c "sed -i 's/^#*temp_buffers.*/temp_buffers = 512MB/' /etc/postgresql/postgresql.conf"
# docker restart supabase-db

# psql -h 172.16.2.122 -U postgres.67888 -d postgres -p 5432 --pset=pager=off
# postges=>
# SHOW shared_buffers;
# SHOW work_mem;
# SHOW maintenance_work_mem;
# SHOW max_parallel_workers_per_gather;
# SHOW temp_buffers;

docker exec -it supabase-db psql -h "$HOSTNAME" -U postgres -d postgres -p 5432 --pset=pager=off

