#!/usr/bin/env python3
import os
import sys
import zipfile
import shutil
import json
import warnings
import time
import datetime
import logging
import boto3
import pyproj
import geopandas as gpd
import pyogrio
from shapely import force_2d
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
from botocore.client import Config

# Akses CLI
# docker exec -it  geo-worker python3 /app/scripts/proses/gpd_GDBtoPGIS.py "KUPS.gdb.zip"
# docker exec -it -e DB_SCHEMA=analisis geo-worker python3 /app/scripts/proses/gpd_GDBtoPGIS.py "analisis/2026-02-23/DAS_DKI_JAKARTA.gdb.zip"

# --- 1. CONFIGURATION & LOGGING ---
load_dotenv()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("GDB-Loader")

# Konfigurasi PROJ agar transformasi CRS lancar di Docker
OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)

warnings.filterwarnings("ignore", category=UserWarning)

def migrate_gdb_to_postgis(input_param):
    start_time = time.time()
    
    try:
        # Parsing input (JSON string atau File Path String)
        try:
            data = json.loads(input_param)
            s3_key_input = data.get("layer")
            bucket_name = data.get("bucket", os.getenv("S3_BUCKET"))
        except:
            s3_key_input = input_param
            bucket_name = os.getenv("S3_BUCKET")

        # Sanitasi nama file lokal (Ganti '/' jadi '_' agar download tidak error folder)
        safe_name = s3_key_input.replace("/", "_")
        base_name = safe_name.replace(".gdb.zip", "").replace(".zip", "")
        
        data_dir = "/app/data/output_gdb"
        os.makedirs(data_dir, exist_ok=True)
        local_zip = os.path.join(data_dir, f"{base_name}_temp.zip")
        extract_path = os.path.join(data_dir, f"ext_{base_name}")

        # S3 Connection (MinIO)
        s3 = boto3.client('s3', 
            endpoint_url=os.getenv("S3_ENDPOINT"),
            aws_access_key_id=os.getenv("S3_USER"),
            aws_secret_access_key=os.getenv("S3_PASS"),
            config=Config(signature_version='s3v4')
        )

        logger.info(f"📥 Downloading {s3_key_input} from S3...")
        s3.download_file(bucket_name, s3_key_input, local_zip)

        with zipfile.ZipFile(local_zip, 'r') as z:
            z.extractall(extract_path)

        # Cari folder .gdb di hasil ekstrak
        found_gdb = next((os.path.join(r, d) for r, dirs, _ in os.walk(extract_path) 
                         for d in dirs if d.lower().endswith(".gdb")), None)
        
        if not found_gdb:
            logger.error("❌ Folder .gdb tidak ditemukan.")
            return

        # Database Connection
        db_url = f"postgresql+psycopg://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}"
        engine = create_engine(db_url)
        schema = os.getenv("DB_SCHEMA", "datagis")

        layers = pyogrio.list_layers(found_gdb)
        
        for layer_name in layers[:, 0]:
            logger.info(f"⏳ Processing Layer: {layer_name} into Schema: {schema}")
            gdf = gpd.read_file(found_gdb, layer=layer_name, engine="pyogrio")
            
            if gdf.empty: continue

            # Pre-processing Data
            gdf.geometry = gdf.geometry.apply(force_2d)
            if gdf.geometry.name != 'geom':
                gdf = gdf.rename_geometry('geom')
            
            gdf.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf.columns]
            
            if gdf.crs is None:
                gdf.set_crs(epsg=4326, inplace=True)
            else:
                gdf.to_crs(epsg=4326, inplace=True)

            final_table = layer_name.upper()
            temp_table = f"{final_table.lower()}_temp"
            idx_temp = f"idx_{temp_table}_geom" # Indeks otomatis GeoPandas

            # --- PRE-CLEANUP (Solusi untuk Duplicate Relation Error) ---
            with engine.begin() as conn:
                conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}";'))
                # Hapus indeks yang mungkin tertinggal sebelum upload baru
                conn.execute(text(f'DROP INDEX IF EXISTS "{schema}"."{idx_temp}";'))
                conn.execute(text(f'DROP TABLE IF EXISTS "{schema}"."{temp_table}" CASCADE;'))

            # --- UPLOAD TO POSTGIS ---
            logger.info(f"📤 Uploading {len(gdf)} records to {temp_table}...")
            gdf.to_postgis(
                name=temp_table, 
                con=engine, 
                schema=schema, 
                if_exists='replace', 
                index=False
            )

            # --- REPAIR & SWAP ---
            with engine.begin() as conn:
                # Bypass type constraint agar fleksibel
                conn.execute(text(f'ALTER TABLE "{schema}"."{temp_table}" ALTER COLUMN geom TYPE geometry;'))

                # Deteksi Tipe (Point, Line, Poly)
                res = conn.execute(text(f'SELECT ST_GeometryType(geom) FROM "{schema}"."{temp_table}" WHERE geom IS NOT NULL LIMIT 1')).first()
                geom_type_raw = res[0] if res else "ST_MultiPolygon"

                if "Polygon" in geom_type_raw:
                    t_type, e_code = "MultiPolygon", 3
                elif "Point" in geom_type_raw:
                    t_type, e_code = "MultiPoint", 1
                else:
                    t_type, e_code = "MultiLineString", 2

                logger.info(f"🔧 Normalizing to {t_type}...")
                
                # Update geometri ke Multi, Set SRID, dan Ganti Tabel Utama
                conn.execute(text(f"""
                    UPDATE "{schema}"."{temp_table}"
                    SET geom = ST_Multi(ST_CollectionExtract(ST_MakeValid(geom), {e_code}))
                    WHERE geom IS NOT NULL;

                    ALTER TABLE "{schema}"."{temp_table}"
                    ALTER COLUMN geom TYPE geometry({t_type}, 4326) USING ST_SetSRID(geom, 4326);

                    DROP TABLE IF EXISTS "{schema}"."{final_table}" CASCADE;
                    ALTER TABLE "{schema}"."{temp_table}" RENAME TO "{final_table}";

                    CREATE INDEX "idx_{final_table.lower()}_geom" ON "{schema}"."{final_table}" USING GIST (geom);
                    GRANT SELECT ON TABLE "{schema}"."{final_table}" TO PUBLIC;
                """))

            logger.info(f"✅ Success: {schema}.{final_table} is live.")

    except Exception as e:
        logger.error(f"🚨 Migration Failed: {str(e)}")
    finally:
        if 'extract_path' in locals() and os.path.exists(extract_path): shutil.rmtree(extract_path)
        if 'local_zip' in locals() and os.path.exists(local_zip): os.remove(local_zip)
        
        duration = str(datetime.timedelta(seconds=int(time.time()-start_time)))
        logger.info(f"🏁 Finished in {duration}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        migrate_gdb_to_postgis(sys.argv[1])
