#!/usr/bin/env python3
import os
import sys
import zipfile
import shutil
import warnings
import geopandas as gpd
import pyogrio
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL
from dotenv import load_dotenv

warnings.filterwarnings("ignore", category=RuntimeWarning)

def migrate_gdb_to_postgis(layer_input):
    load_dotenv()

    db_user = os.getenv("DB_USER")
    db_pass = os.getenv("DB_PASS")
    db_host = os.getenv("DB_HOST")
    db_port = os.getenv("DB_PORT", "5432")
    db_name = os.getenv("DB_NAME")
    db_schema = os.getenv("DB_SCHEMA", "datagis")

    data_dir = "/app/data"
    clean_name = layer_input.replace(".gdb", "").replace(".zip", "")
    zip_path = os.path.join(data_dir, f"{clean_name}.gdb.zip")
    gdb_path = os.path.join(data_dir, f"{clean_name}.gdb")

    if not os.path.exists(gdb_path):
        if os.path.exists(zip_path):
            print(f"📦 Mengekstrak {zip_path}...")
            os.makedirs(gdb_path, exist_ok=True)
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(gdb_path)
            print(f"✅ Folder GDB direkonstruksi.")
        else:
            print(f"❌ Error: File sumber tidak ditemukan.")
            sys.exit(1)

    connection_url = URL.create(
        drivername="postgresql+psycopg",
        username=db_user,
        password=db_pass,
        host=db_host,
        port=db_port,
        database=db_name
    )
    engine = create_engine(connection_url, pool_pre_ping=True)

    try:
        layers = pyogrio.list_layers(gdb_path)

        for layer_name in layers[:, 0]:
            # TETAPKAN NAMA ASLI (Uppercase)
            target_table = layer_name 
            print(f"\n---------------------------------------------------")
            print(f"📥 Memproses Layer: {target_table}")

            gdf = gpd.read_file(gdb_path, layer=layer_name, engine="pyogrio")
            if gdf.empty: continue

            if gdf.geometry.name != 'geom':
                gdf = gdf.rename_geometry('geom')

            if gdf.crs is None:
                gdf.set_crs("EPSG:4326", inplace=True)
            elif gdf.crs != "EPSG:4326":
                gdf = gdf.to_crs(epsg=4326)

            # 1. Upload dengan nama tabel asli (Case Sensitive menggunakan quoted name)
            print(f"📤 Mengunggah ke: {db_schema}.\"{target_table}\"...")
            
            gdf.to_postgis(
                name=target_table,
                con=engine,
                schema=db_schema,
                if_exists='replace',
                index=False,
                chunksize=5000
            )

            # 2. Optimasi dengan penanganan GeometryCollection
            print(f"⚡ Membuat Spatial Index & Validasi Geometri...")
            with engine.begin() as conn:
                # Perbaikan ST_CollectionExtract(..., 3) untuk memastikan tetap poligon
                valid_query = f"""
                    UPDATE "{db_schema}"."{target_table}" 
                    SET geom = ST_Multi(ST_CollectionExtract(ST_MakeValid(geom), 3)) 
                    WHERE NOT ST_IsValid(geom);
                """
                conn.execute(text(valid_query))
                
                idx_name = f"idx_{target_table}_geom"
                conn.execute(text(f'DROP INDEX IF EXISTS "{db_schema}"."{idx_name}";'))
                conn.execute(text(f'CREATE INDEX "{idx_name}" ON "{db_schema}"."{target_table}" USING GIST (geom);'))
                conn.execute(text(f'GRANT SELECT ON TABLE "{db_schema}"."{target_table}" TO PUBLIC;'))

            print(f"✅ Berhasil! {len(gdf)} baris masuk ke {db_schema}.{target_table}")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")
        sys.exit(1)
    finally:
        if os.path.exists(gdb_path):
            shutil.rmtree(gdb_path)
            print(f"🧹 Cleanup selesai.")
        engine.dispose()

if __name__ == "__main__":
    target_layer = sys.argv[1] if len(sys.argv) > 1 else os.getenv("IGT")
    if target_layer:
        migrate_gdb_to_postgis(target_layer)
    else:
        sys.exit(1)
