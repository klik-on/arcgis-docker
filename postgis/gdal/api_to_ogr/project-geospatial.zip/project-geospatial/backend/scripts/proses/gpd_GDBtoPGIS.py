#!/usr/bin/env python3
import os
import sys
import time
import datetime
import shutil
import boto3
import zipfile
import subprocess
from dotenv import load_dotenv
from botocore.client import Config

# Akses CLI 
# docker exec -it geo-worker python3 scripts/proses/gpd_GDBtoPGIS.py BATAS_ADMINISTRASI.gdb.zip ADMINISTRASI_KECAMATAN_AR:ADM_KEC_2025

load_dotenv()

TEMP_DIR = "/app/data/temp_import"
os.makedirs(TEMP_DIR, exist_ok=True)

def download_from_s3(file_name, bucket_name):
    local_path = os.path.join(TEMP_DIR, file_name)
    s3 = boto3.client('s3',
                      endpoint_url=os.getenv("S3_ENDPOINT"),
                      aws_access_key_id=os.getenv("S3_USER"),
                      aws_secret_access_key=os.getenv("S3_PASS"),
                      config=Config(signature_version='s3v4'),
                      verify=False)
    try:
        print(f"☁️ Downloading {file_name} from S3...")
        s3.download_file(bucket_name, file_name, local_path)
        return local_path
    except Exception as e:
        print(f"⚠️ S3 Download Error: {e}"); return None

def get_all_layers(gdb_path):
    """Mengambil semua daftar layer dari GDB menggunakan ogrinfo."""
    cmd = ["ogrinfo", "-so", "-al", gdb_path]
    result = subprocess.run(cmd, capture_output=True, text=True)
    layers = []
    for line in result.stdout.splitlines():
        if line.startswith("Layer name: "):
            layers.append(line.replace("Layer name: ", "").strip())
    return layers

def migrate_gdb_to_postgis(zip_filename, mappings=None):
    start_time = time.time()
    zip_path = None
    extract_path = None

    try:
        bucket_name = os.getenv("S3_BUCKET", "geospatial-bucket")
        schema = os.getenv("SCHEMA_DATA", "datagis")
        
        zip_path = download_from_s3(zip_filename, bucket_name)
        if not zip_path: return

        extract_path = os.path.join(TEMP_DIR, f"extracted_{int(time.time())}")
        print(f"📦 Extracting {zip_filename}...")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)

        gdb_folder = next((os.path.join(root, d) for root, dirs, _ in os.walk(extract_path) for d in dirs if d.endswith(".gdb")), None)
        if not gdb_folder:
            print("❌ GDB not found in ZIP."); return

        # Logika Penentuan Layer
        final_mappings = []
        available_layers = get_all_layers(gdb_folder)

        if mappings and mappings[0].upper() == "ALL":
            print(f"📚 Mass Import detected. Processing all {len(available_layers)} layers...")
            final_mappings = available_layers # Menggunakan nama asli
        elif mappings:
            final_mappings = mappings
        else:
            print(f"\n📚 Layer tersedia di {zip_filename}:")
            for lyr in available_layers: print(f"   - {lyr}")
            return

        pg_conn = f"PG:host={os.getenv('DB_HOST')} port={os.getenv('DB_PORT')} dbname={os.getenv('DB_NAME')} user={os.getenv('DB_USER')} password={os.getenv('DB_PASS')}"

        for item in final_mappings:
            src_layer, dest_table = item.split(":", 1) if ":" in item else (item, item)
            
            print(f"🚀 Processing: {src_layer} ➡️  \"{dest_table}\" (EPSG:4326)...")

        # OGR2OGR Command (Clean Version - No Warnings)
            cmd = [
                "ogr2ogr",
                "-f", "PostgreSQL",
                pg_conn,
                gdb_folder,
                src_layer,
                "-nln", f"{schema}.{dest_table}",
                "-nlt", "MULTIPOLYGON", 
                "-dim", "XY",
                "-t_srs", "EPSG:4326",
                "-overwrite",
                "-lco", "GEOMETRY_NAME=geom",
                "-lco", "SPATIAL_INDEX=GIST",
                "-lco", "LAUNDER=NO",
                "-skipfailures",
                # --- HILANGKAN WARNING ---
                "--config", "PG_USE_COPY", "YES",
                "--config", "CPL_LOG", "/dev/null",  # Mematikan logging internal GDAL
                "--config", "GDAL_ERROR_THRESHOLD", "0", # Mengabaikan level warning/error di log
                "-q" # Mode Quiet: Hanya error fatal yang muncul
            ]

            try:
                subprocess.run(cmd, check=True)
                print(f"   ✅ Success: {schema}.{dest_table}")
            except subprocess.CalledProcessError:
                print(f"   ❌ Failed: {src_layer}")

    except Exception as e:
        print(f"💥 Error: {e}")
    finally:
        if zip_path and os.path.exists(zip_path): os.remove(zip_path)
        if extract_path and os.path.exists(extract_path): shutil.rmtree(extract_path)
        print(f"🏁 FINISHED! Duration: {str(datetime.timedelta(seconds=int(time.time()-start_time)))}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        migrate_gdb_to_postgis(sys.argv[1], sys.argv[2:] if len(sys.argv) > 2 else None)
    else:
        print("💡 Usage: python3 script.py <file.zip> [LayerAsal:NamaBaru | ALL]")
