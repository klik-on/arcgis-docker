#!/usr/bin/env python3
import os
import sys
import zipfile
import shutil
import json
import warnings
import time
import datetime
import boto3
import pyproj
import geopandas as gpd
import pyogrio
from shapely import force_2d
from sqlalchemy import create_engine, text, inspect, types
from dotenv import load_dotenv
from botocore.client import Config

# --- 1️⃣ INISIALISASI PROJ (Path Statis) ---
OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)
    os.environ['PROJ_LIB'] = OS_PROJ_PATH
else:
    proj_path = pyproj.datadir.get_data_dir()
    os.environ['PROJ_LIB'] = proj_path
    os.environ['PROJ_DATA'] = proj_path

warnings.filterwarnings("ignore", category=UserWarning)
load_dotenv()

# --- 2️⃣ CONFIG & LOGGING ---
LOG_DIR = "/app/data/logs/properties"
os.makedirs(LOG_DIR, exist_ok=True)

def upload_log_to_s3(file_path, bucket_name):
    """Mengunggah file log ke S3."""
    s3 = boto3.client('s3', 
                      endpoint_url=os.getenv("S3_ENDPOINT"),
                      aws_access_key_id=os.getenv("S3_USER"),
                      aws_secret_access_key=os.getenv("S3_PASS"),
                      config=Config(signature_version='s3v4'))
    file_name = os.path.basename(file_path)
    s3_key = f"logs/properties/{file_name}"
    try:
        s3.upload_file(file_path, bucket_name, s3_key)
        print(f"☁️ Log uploaded to S3: {s3_key}")
    except Exception as e:
        print(f"⚠️ S3 Upload Error: {e}")

def generate_table_properties(engine, schema, table_name):
    """Menghasilkan file .txt metadata dengan format VARCHAR dan geom kecil."""
    inspector = inspect(engine)
    columns = inspector.get_columns(table_name, schema=schema)
    prop_file_path = os.path.join(LOG_DIR, f"{table_name.upper()}_PROPERTIES.txt")
    
    with engine.connect() as conn:
        count = conn.execute(text(f'SELECT COUNT(*) FROM "{schema}"."{table_name}"')).scalar()
        res_geo = conn.execute(text(f"SELECT srid, type FROM geometry_columns WHERE f_table_schema = '{schema}' AND f_table_name = '{table_name}'")).first()
        srid, g_type = (res_geo[0], res_geo[1]) if res_geo else ("4326", "GEOMETRY")

    with open(prop_file_path, "w") as f:
        f.write(f"METADATA ATRIBUT TABEL: {schema}.{table_name.upper()}\n")
        f.write(f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Rows: {count}\n")
        f.write(f"Geometry : {g_type} (SRID: {srid})\n")
        f.write("="*90 + "\n")
        f.write(f"{'COLUMN_NAME':<30} | {'TYPE':<25} | {'INFO'}\n")
        f.write("-" * 90 + "\n")

        for col in columns:
            c_name = col['name']
            if c_name.lower() in ['geom', 'geometry']:
                f.write(f"{'geom':<30} | {'GEOMETRY':<25} | SRID:{srid}\n")
            else:
                raw_type = str(col['type']).upper()
                if hasattr(col['type'], 'length') and col['type'].length:
                    display_type = f"VARCHAR({col['type'].length})"
                    info = f"L: {col['type'].length}"
                else:
                    display_type = raw_type
                    info = "-"
                f.write(f"{c_name.upper():<30} | {display_type:<25} | {info}\n")
    return prop_file_path

# --- 3️⃣ CORE MIGRATION ---
def migrate_gdb_to_postgis(input_param):
    start_time = time.time()
    try:
        data = json.loads(input_param)
        layer_input = data.get("layer")
        bucket_name = data.get("bucket", os.getenv("S3_BUCKET", "geospatial-bucket"))
    except:
        layer_input, bucket_name = input_param, os.getenv("S3_BUCKET", "geospatial-bucket")

    clean_name = layer_input.replace(".gdb", "").replace(".zip", "")
    data_dir = "/app/data/output_gdb"
    os.makedirs(data_dir, exist_ok=True)
    local_zip, gdb_path = os.path.join(data_dir, f"{clean_name}_down.zip"), os.path.join(data_dir, f"{clean_name}.gdb")

    s3 = boto3.client('s3', endpoint_url=os.getenv("S3_ENDPOINT"), aws_access_key_id=os.getenv("S3_USER"), aws_secret_access_key=os.getenv("S3_PASS"), config=Config(signature_version='s3v4'))
    s3.download_file(bucket_name, f"{clean_name}.zip", local_zip)

    with zipfile.ZipFile(local_zip, 'r') as z:
        temp_p = os.path.join(data_dir, "temp_ext")
        z.extractall(temp_p)
        for root, dirs, _ in os.walk(temp_p):
            for d in dirs:
                if d.endswith(".gdb"):
                    if os.path.exists(gdb_path): shutil.rmtree(gdb_path)
                    shutil.move(os.path.join(root, d), gdb_path)
        shutil.rmtree(temp_p)
    os.remove(local_zip)

    db_url = f"postgresql+psycopg://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}"
    engine = create_engine(db_url)
    schema = os.getenv("SCHEMA_DATA", "datagis")

    try:
        layers = pyogrio.list_layers(gdb_path)
        for layer_name in layers[:, 0]:
            print(f"📥 Processing Layer: {layer_name}")
            gdf = gpd.read_file(gdb_path, layer=layer_name, engine="pyogrio")
            
            # 2D Conversion & Standardization
            gdf.geometry = gdf.geometry.apply(force_2d)
            if gdf.geometry.name != 'geom': gdf = gdf.rename_geometry('geom')
            gdf.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf.columns]
            gdf = gdf.to_crs(epsg=4326)

            # Dynamic VARCHAR mapping
            dtype_mapping = {}
            for col in gdf.columns:
                if col != 'geom' and gdf[col].dtype == 'object':
                    max_len = gdf[col].astype(str).str.len().max()
                    dtype_mapping[col] = types.VARCHAR(length=int(max_len + 50) if max_len > 0 else 250)

            final_table = layer_name.upper()
            temp_table = f"{final_table.lower()}_temp"

            with engine.begin() as conn:
                conn.execute(text(f'DROP TABLE IF EXISTS "{schema}"."{temp_table}" CASCADE;'))
                conn.execute(text(f"DROP INDEX IF EXISTS {schema}.idx_{temp_table}_geom;"))

            print(f"📤 Uploading to {temp_table}...")
            gdf.to_postgis(name=temp_table, con=engine, schema=schema, if_exists='replace', index=False, dtype=dtype_mapping)

            with engine.begin() as conn:
                idx_name = f"idx_{final_table.lower()}_geom"
                conn.execute(text(f'UPDATE "{schema}"."{temp_table}" SET geom = ST_Multi(ST_CollectionExtract(ST_MakeValid(geom), 3));'))
                conn.execute(text(f'DROP TABLE IF EXISTS "{schema}"."{final_table}" CASCADE;'))
                conn.execute(text(f'ALTER TABLE "{schema}"."{temp_table}" RENAME TO "{final_table}";'))
                conn.execute(text(f'CREATE INDEX "{idx_name}" ON "{schema}"."{final_table}" USING GIST (geom);'))
                conn.execute(text(f'GRANT SELECT ON TABLE "{schema}"."{final_table}" TO PUBLIC;'))

            prop_path = generate_table_properties(engine, schema, final_table)
            upload_log_to_s3(prop_path, bucket_name)
    finally:
        if os.path.exists(gdb_path): shutil.rmtree(gdb_path)
        engine.dispose()
        print(f"🏁 FINISHED! Duration: {str(datetime.timedelta(seconds=int(time.time()-start_time)))}")

if __name__ == "__main__":
    if len(sys.argv) > 1: migrate_gdb_to_postgis(sys.argv[1])
    else: print("💡 Usage: python3 script.py <layer_name>")
