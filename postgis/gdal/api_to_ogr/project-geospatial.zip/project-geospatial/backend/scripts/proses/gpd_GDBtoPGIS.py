#!/usr/bin/env python3
import os
import sys
import zipfile
import shutil
import json
import warnings
import time
import datetime
import boto3
import pyproj
import geopandas as gpd
import pyogrio
from shapely import force_2d
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
from botocore.client import Config

# --- 1. SETTINGS & PROJ ---
OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)

warnings.filterwarnings("ignore", category=UserWarning)
load_dotenv()

# --- 2. CORE FUNCTIONS ---
def migrate_gdb_to_postgis(input_param):
    start_time = time.time()
    
    try:
        data = json.loads(input_param)
        layer_input = data.get("layer")
        bucket_name = data.get("bucket", os.getenv("S3_BUCKET"))
    except:
        layer_input = input_param
        bucket_name = os.getenv("S3_BUCKET")

    base_name = layer_input.replace(".gdb.zip", "").replace(".zip", "")
    data_dir = "/app/data/output_gdb"
    os.makedirs(data_dir, exist_ok=True)
    local_zip = os.path.join(data_dir, f"{base_name}_temp.zip")
    extract_path = os.path.join(data_dir, f"ext_{base_name}")
    
    s3 = boto3.client('s3', endpoint_url=os.getenv("S3_ENDPOINT"), 
                      aws_access_key_id=os.getenv("S3_USER"), 
                      aws_secret_access_key=os.getenv("S3_PASS"), 
                      config=Config(signature_version='s3v4'))
    
    s3_key = None
    for ext in [".gdb.zip", ".zip", ""]:
        try:
            key = f"{base_name}{ext}"
            s3.head_object(Bucket=bucket_name, Key=key)
            s3_key = key
            break
        except: continue

    if not s3_key:
        print(f"❌ File {base_name} tidak ditemukan di S3.")
        return

    print(f"📥 Downloading {s3_key}...")
    s3.download_file(bucket_name, s3_key, local_zip)

    with zipfile.ZipFile(local_zip, 'r') as z:
        z.extractall(extract_path)
    
    found_gdb = next((os.path.join(r, d) for r, dirs, _ in os.walk(extract_path) for d in dirs if d.lower().endswith(".gdb")), None)
    if not found_gdb: return print("❌ GDB tidak ditemukan.")

    db_url = f"postgresql+psycopg://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}"
    engine = create_engine(db_url)
    schema = os.getenv("SCHEMA_DATA", "datagis")

    try:
        layers = pyogrio.list_layers(found_gdb)
        for layer_name in layers[:, 0]:
            print(f"\n⏳ Processing: {layer_name}")
            gdf = gpd.read_file(found_gdb, layer=layer_name, engine="pyogrio")
            if gdf.empty: continue

            gdf.geometry = gdf.geometry.apply(force_2d)
            if gdf.geometry.name != 'geom': gdf = gdf.rename_geometry('geom')
            gdf.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf.columns]
            gdf = gdf.to_crs(epsg=4326) if gdf.crs else gdf.set_crs(epsg=4326)

            final_table = layer_name.upper()
            temp_table = f"{final_table.lower()}_temp"
            idx_temp = f"idx_{temp_table}_geom"
            idx_final = f"idx_{final_table.lower()}_geom"

            # --- PRE-CLEANUP MANUAL ---
            # Hapus index yang mungkin tertinggal sebelum to_postgis mencoba membuatnya
            with engine.begin() as conn:
                conn.execute(text(f'DROP INDEX IF EXISTS "{schema}"."{idx_temp}";'))
                conn.execute(text(f'DROP INDEX IF EXISTS "{schema}"."{idx_final}";'))

            # Upload (Versi Standar tanpa keyword bermasalah)
            gdf.to_postgis(
                name=temp_table, 
                con=engine, 
                schema=schema, 
                if_exists='replace', 
                index=False
            )

            with engine.begin() as conn:
                # Bypass type constraint
                conn.execute(text(f'ALTER TABLE "{schema}"."{temp_table}" ALTER COLUMN geom TYPE geometry;'))

                # Deteksi Tipe
                res = conn.execute(text(f'SELECT ST_GeometryType(geom) FROM "{schema}"."{temp_table}" WHERE geom IS NOT NULL LIMIT 1')).first()
                geom_type_raw = res[0] if res else "ST_MultiPolygon"
                
                t_type, e_code = ("MultiPolygon", 3) if "Polygon" in geom_type_raw else (("MultiPoint", 1) if "Point" in geom_type_raw else ("MultiLineString", 2))

                conn.execute(text(f"""
                    UPDATE "{schema}"."{temp_table}" 
                    SET geom = ST_Multi(ST_CollectionExtract(ST_MakeValid(geom), {e_code}))
                    WHERE geom IS NOT NULL;

                    ALTER TABLE "{schema}"."{temp_table}" 
                    ALTER COLUMN geom TYPE geometry({t_type}, 4326) USING ST_SetSRID(geom, 4326);

                    -- Pastikan sekali lagi index bersih sebelum swap
                    DROP INDEX IF EXISTS "{schema}"."{idx_final}";
                    
                    DROP TABLE IF EXISTS "{schema}"."{final_table}" CASCADE;
                    ALTER TABLE "{schema}"."{temp_table}" RENAME TO "{final_table}";

                    -- Buat index baru secara manual pada tabel final
                    CREATE INDEX "{idx_final}" ON "{schema}"."{final_table}" USING GIST (geom);
                    GRANT SELECT ON TABLE "{schema}"."{final_table}" TO PUBLIC;
                """))

            print(f"✅ Success: {final_table} ({t_type})")

    finally:
        if os.path.exists(extract_path): shutil.rmtree(extract_path)
        if os.path.exists(local_zip): os.remove(local_zip)
        engine.dispose()
        print(f"🏁 Finished in {str(datetime.timedelta(seconds=int(time.time()-start_time)))}")

if __name__ == "__main__":
    if len(sys.argv) > 1: migrate_gdb_to_postgis(sys.argv[1])
