#!/usr/bin/env python3
import os
import sys
import zipfile
import shutil
import warnings
import geopandas as gpd
import pyogrio
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL
from dotenv import load_dotenv

# Mematikan peringatan driver yang tidak perlu agar log bersih
warnings.filterwarnings("ignore", category=RuntimeWarning)

def migrate_gdb_to_postgis(layer_input):
    load_dotenv()
    
    # 1. Konfigurasi Database dari Environment
    db_user = os.getenv("DB_USER")
    db_pass = os.getenv("DB_PASS")
    db_host = os.getenv("DB_HOST")
    db_port = os.getenv("DB_PORT", "5432")
    db_name = os.getenv("DB_NAME")
    # Mengambil skema dari env, default ke 'datagis' jika tidak ada
    db_schema = os.getenv("DB_SCHEMA", "datagis")

    # 2. Path Management
    data_dir = "/app/data" # Sesuaikan dengan path di Docker Anda
    clean_name = layer_input.replace(".gdb", "").replace(".zip", "")
    zip_path = os.path.join(data_dir, f"{clean_name}.gdb.zip")
    gdb_path = os.path.join(data_dir, f"{clean_name}.gdb")

    # 3. Ekstraksi Otomatis
    if not os.path.exists(gdb_path):
        if os.path.exists(zip_path):
            print(f"📦 Mengekstrak {zip_path}...")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(data_dir)
            print(f"✅ Ekstraksi selesai.")
        else:
            print(f"❌ Error: File sumber tidak ditemukan di {zip_path} atau {gdb_path}")
            sys.exit(1)

    # 4. Koneksi Database (Psycopg 3)
    connection_url = URL.create(
        drivername="postgresql+psycopg",
        username=db_user,
        password=db_pass,
        host=db_host,
        port=db_port,
        database=db_name
    )
    engine = create_engine(connection_url)

    try:
        print(f"🔍 Memeriksa isi GDB di: {gdb_path}")
        layers = pyogrio.list_layers(gdb_path)
        
        # layers[:, 0] berisi nama-nama layer dalam GDB
        for layer_name in layers[:, 0]:
            print(f"\n---------------------------------------------------")
            print(f"📥 Membaca Layer: {layer_name}")

            # Membaca data menggunakan engine pyogrio (High Performance)
            gdf = gpd.read_file(gdb_path, layer=layer_name, engine="pyogrio")

            if gdf.empty:
                print(f"⚠️ Layer {layer_name} kosong, melewati...")
                continue

            # 5. Transformasi CRS ke WGS84 (EPSG:4326)
            if gdf.crs is None:
                print(f"⚠️ CRS tidak terdeteksi, menetapkan ke EPSG:4326...")
                gdf.set_crs("EPSG:4326", inplace=True)
            elif gdf.crs != "EPSG:4326":
                print(f"🌍 Mengonversi CRS dari {gdf.crs} ke EPSG:4326...")
                gdf = gdf.to_crs(epsg=4326)

            # 6. Kirim ke PostGIS
            print(f"📤 Mengunggah ke tabel: {db_schema}.{layer_name}...")
            gdf.to_postgis(
                name=layer_name,
                con=engine,
                schema=db_schema,
                if_exists='replace',
                index=False,
                chunksize=5000
            )

            # 7. Pembuatan Spatial Index (GIST)
            print(f"⚡ Membuat Spatial Index pada {db_schema}.{layer_name}...")
            with engine.connect() as conn:
                # Menggunakan double quote untuk menjaga case-sensitivity nama tabel
                index_query = f'CREATE INDEX IF NOT EXISTS "{layer_name}_geom_idx" ON "{db_schema}"."{layer_name}" USING GIST (geometry)'
                conn.execute(text(index_query))
                # Berikan akses select ke publik (opsional)
                conn.execute(text(f'GRANT SELECT ON TABLE "{db_schema}"."{layer_name}" TO PUBLIC'))
                conn.commit()

            print(f"✅ Berhasil! {len(gdf)} baris masuk ke {db_schema}.{layer_name}")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")
        sys.exit(1)
    finally:
        # 8. Cleanup
        if os.path.exists(gdb_path):
            shutil.rmtree(gdb_path)
            print(f"🧹 Cleanup: Folder {gdb_path} dihapus.")
        engine.dispose()

if __name__ == "__main__":
    # Mendukung input dari Argumen Command Line atau Environment Variable (IGT)
    target_layer = None
    
    if len(sys.argv) > 1:
        target_layer = sys.argv[1]
    elif os.getenv("IGT"):
        target_layer = os.getenv("IGT")

    if target_layer:
        migrate_gdb_to_postgis(target_layer)
    else:
        print("❌ Error: Tidak ada input layer!")
        print("💡 Gunakan: python3 gpd_GDBtoPGIS.py NAMA_FILE")
        print("💡 Atau atur env variable 'IGT'")
        sys.exit(1)
