#!/usr/bin/env python3
import os
import sys
import zipfile
import shutil
import warnings
import time
import datetime
import geopandas as gpd
import pyogrio
from shapely import force_2d
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL
from dotenv import load_dotenv

warnings.filterwarnings("ignore", category=UserWarning, module="geopandas")
warnings.filterwarnings("ignore", category=RuntimeWarning)

def migrate_gdb_to_postgis(layer_input):
    load_dotenv()
    start_time = time.time()

    db_user, db_pass = os.getenv("DB_USER"), os.getenv("DB_PASS")
    db_host, db_port = os.getenv("DB_HOST", "dbgis"), os.getenv("DB_PORT", "5432")
    db_name = os.getenv("DB_NAME")
    db_schema = os.getenv("SCHEMA_DATA", "datagis")

    data_dir = "/app/data/output_gdb"
    clean_name = layer_input.replace(".gdb", "").replace(".zip", "")
    zip_path = os.path.join(data_dir, f"{clean_name}.gdb.zip")
    gdb_path = os.path.join(data_dir, f"{clean_name}.gdb")

    if not os.path.exists(gdb_path):
        if os.path.exists(zip_path):
            print(f"📦 Mengekstrak {zip_path}...")
            temp_extract = os.path.join(data_dir, f"temp_{clean_name}")
            os.makedirs(temp_extract, exist_ok=True)
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_extract)
            
            for root, dirs, _ in os.walk(temp_extract):
                for d in dirs:
                    if d.endswith(".gdb"):
                        if os.path.exists(gdb_path): shutil.rmtree(gdb_path)
                        shutil.move(os.path.join(root, d), gdb_path)
            shutil.rmtree(temp_extract)
            print(f"✅ GDB siap diakses.")
        else:
            print(f"❌ Error: File {zip_path} tidak ditemukan."); sys.exit(1)

    engine = create_engine(f"postgresql+psycopg://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}")

    try:
        layers = pyogrio.list_layers(gdb_path)
        for layer_name in layers[:, 0]:
            print(f"\n" + "-"*50 + f"\n📥 Memproses Layer: {layer_name}")
            gdf = gpd.read_file(gdb_path, layer=layer_name, engine="pyogrio")
            if gdf.empty: continue

            print("🪄  Menghilangkan dimensi Z/M (Converting to 2D)...")
            gdf.geometry = gdf.geometry.apply(force_2d)

            if gdf.geometry.name != 'geom': gdf = gdf.rename_geometry('geom')
            gdf = gdf.to_crs(epsg=4326) if gdf.crs and gdf.crs != "EPSG:4326" else gdf.set_crs("EPSG:4326", allow_override=True)

            print(f"📤 Mengunggah ke: {db_schema}.\"{layer_name}\"...")
            gdf.to_postgis(name=layer_name, con=engine, schema=db_schema, if_exists='replace', index=False)

            with engine.begin() as conn:
                conn.execute(text(f'UPDATE "{db_schema}"."{layer_name}" SET geom = ST_Multi(ST_CollectionExtract(ST_MakeValid(geom), 3));'))
                idx_name = f"idx_{layer_name.lower()}_geom"
                conn.execute(text(f'DROP INDEX IF EXISTS "{db_schema}"."{idx_name}";'))
                conn.execute(text(f'CREATE INDEX "{idx_name}" ON "{db_schema}"."{layer_name}" USING GIST (geom);'))
                conn.execute(text(f'GRANT SELECT ON TABLE "{db_schema}"."{layer_name}" TO PUBLIC;'))
            print(f"✅ Berhasil mengimpor {len(gdf)} baris ke {db_schema}.{layer_name}")

        # OUTPUT FINAL DENGAN FORMAT JAM:MENIT:DETIK
        duration = time.time() - start_time
        formatted_time = str(datetime.timedelta(seconds=int(duration)))
        print(f"\n🏁 PROSES SELESAI!")
        print(f"⏱️ Total Durasi: {formatted_time} ({duration:.2f} detik)")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}"); sys.exit(1)
    finally:
        if os.path.exists(gdb_path): 
            shutil.rmtree(gdb_path)
            print(f"🧹 Cleanup folder .gdb selesai.")
        engine.dispose()

if __name__ == "__main__":
    if len(sys.argv) > 1: migrate_gdb_to_postgis(sys.argv[1])
    else: print("💡 Gunakan: python3 gpd_GDBtoPGIS.py <nama_layer>"); sys.exit(1)
