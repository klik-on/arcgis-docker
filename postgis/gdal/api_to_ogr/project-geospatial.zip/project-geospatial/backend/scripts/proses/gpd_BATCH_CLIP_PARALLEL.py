#!/usr/bin/env python3
import os
import subprocess
import sys
import time
import multiprocessing
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# 1. LOAD KONFIGURASI DARI .ENV
load_dotenv()

DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
SCHEMA_DATA = os.getenv("SCHEMA_DATA", "datagis")

# Parameter Tabel Sumber untuk List Provinsi
TABLE_B = "ADM_KAB_KOTA"
FIELD_FILTER_B = "WADMPR"

# Jumlah Worker (Setara dengan -j 8)
NUM_WORKERS = 8 

def get_all_provinces():
    """Mengambil daftar unik provinsi dari database"""
    # Engine dibuat di dalam fungsi agar thread-safe
    engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")
    query = text(f"""
        SELECT DISTINCT "{FIELD_FILTER_B}" 
        FROM "{SCHEMA_DATA}"."{TABLE_B}" 
        WHERE "{FIELD_FILTER_B}" IS NOT NULL 
        ORDER BY "{FIELD_FILTER_B}"
    """)
    with engine.connect() as conn:
        result = conn.execute(query)
        provs = [row[0] for row in result]
    engine.dispose()
    return provs

def run_individual_clip(provinsi):
    """Fungsi worker untuk menjalankan skrip CLIP per provinsi"""
    # --- LOGIKA FIX PATH ---
    # Mendapatkan path absolut folder tempat skrip ini berada
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # Memastikan file target dicari di folder yang sama
    script_path = os.path.join(current_dir, "gpd_CLIP_IGT_ADM.py")
    
    start_time_prov = time.time()
    print(f"🚀 [START] PID {os.getpid()} memproses: {provinsi}")
    
    try:
        # Menjalankan subprocess dengan path absolut
        # capture_output=True agar log tidak tumpang tindih di STDOUT
        result = subprocess.run(
            ["python3", script_path, provinsi],
            check=True,
            capture_output=True,
            text=True
        )
        
        duration = time.time() - start_time_prov
        print(f"✅ [SUCCESS] {provinsi} selesai dalam {duration:.2f} detik.")
        return f"{provinsi}: Sukses"
        
    except subprocess.CalledProcessError as e:
        # Menangkap error dari skrip anak (stderr)
        error_msg = e.stderr.strip() if e.stderr else str(e)
        print(f"❌ [ERROR] {provinsi} Gagal! Detail: {error_msg[:200]}...")
        return f"{provinsi}: Gagal"

if __name__ == "__main__":
    # 1. Ambil daftar provinsi dari database
    try:
        provinces = get_all_provinces()
    except Exception as e:
        print(f"❌ Gagal mengambil daftar provinsi: {e}")
        sys.exit(1)
        
    total = len(provinces)
    
    print("="*70)
    print(f"🛠️  GEO-PROCESSING BATCH PARALEL (Workers: {NUM_WORKERS})")
    print(f"📋 Total Target: {total} Provinsi")
    print(f"📂 Lokasi Skrip: {os.path.dirname(os.path.abspath(__file__))}")
    print("="*70)

    start_batch = time.time()

    # 2. Inisialisasi Pool untuk Paralelisme
    # Ini akan menjalankan 8 provinsi secara simultan
    with multiprocessing.Pool(processes=NUM_WORKERS) as pool:
        results = pool.map(run_individual_clip, provinces)

    # 3. Ringkasan Akhir
    total_duration = time.time() - start_batch
    print("\n" + "="*70)
    print(f"🏁 BATCH SELESAI dalam {total_duration/60:.2f} menit")
    print("="*70)
    
    success_count = sum(1 for res in results if "Sukses" in res)
    print(f"📊 Ringkasan: {success_count} Berhasil, {total - success_count} Gagal.")
