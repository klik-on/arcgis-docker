#!/usr/bin/env python3
import os
import subprocess
import sys
import time
import multiprocessing
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# 1. LOAD KONFIGURASI
load_dotenv()

DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
SCHEMA_DATA = os.getenv("SCHEMA_DATA", "datagis")

TABLE_B = "ADM_KAB_KOTA"
FIELD_FILTER_B = "WADMPR"

# Jumlah Worker (Menyesuaikan dengan core CPU server)
NUM_WORKERS = 8

def get_all_provinces():
    """Mengambil daftar unik provinsi dari database"""
    engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")
    query = text(f'SELECT DISTINCT "{FIELD_FILTER_B}" FROM "{SCHEMA_DATA}"."{TABLE_B}" WHERE "{FIELD_FILTER_B}" IS NOT NULL ORDER BY 1')
    with engine.connect() as conn:
        result = conn.execute(query)
        provs = [row[0] for row in result]
    engine.dispose()
    return provs

def run_individual_clip(provinsi):
    """Fungsi worker untuk menjalankan skrip CLIP per provinsi dengan Timeout"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # Pastikan nama file sesuai dengan skrip yang menggunakan ST_Subdivide
    script_path = os.path.join(current_dir, "gpd_CLIP_ST_Subdivide.py")

    print(f"🚀 [START] Memproses: {provinsi}")
    start_time_prov = time.time()

    try:
        # Menjalankan skrip dengan capture_output agar log tidak bertumpuk di terminal
        result = subprocess.run(
            ["python3", script_path, provinsi],
            check=True,
            capture_output=True,
            text=True,
            timeout=1800  # Maksimal 30 menit per provinsi
        )
        
        duration = time.time() - start_time_prov
        print(f"✅ [SUCCESS] {provinsi} ({duration:.2f}s)")
        return f"{provinsi}: Sukses"

    except subprocess.TimeoutExpired:
        print(f"⏰ [TIMEOUT] {provinsi} dihentikan karena melebihi 30 menit!")
        return f"{provinsi}: Timeout"

    except subprocess.CalledProcessError as e:
        # Mengambil pesan error terakhir dari output skrip anak
        error_msg = e.stderr.strip().split('\n')[-1] if e.stderr else "Unknown Error"
        print(f"❌ [ERROR] {provinsi} Gagal! Detail: {error_msg}")
        return f"{provinsi}: Gagal"

if __name__ == "__main__":
    start_batch = time.time()

    # Validasi awal daftar provinsi
    try:
        provinces = get_all_provinces()
    except Exception as e:
        print(f"❌ Gagal koneksi database untuk mengambil daftar provinsi: {e}")
        sys.exit(1)

    total = len(provinces)
    if total == 0:
        print("⚠️ Tidak ada data provinsi ditemukan.")
        sys.exit(0)

    print("="*75)
    print(f"🛠️  GEO-PROCESSING BATCH PARALEL (ST_SUBDIVIDE MODE)")
    print(f"📋 Total Target : {total} Provinsi")
    print(f"🧵 Max Workers  : {NUM_WORKERS}")
    print(f"⏱️  Timeout      : 30 Menit per tugas")
    print("="*75)

    # Inisialisasi Pool untuk pemrosesan paralel
    with multiprocessing.Pool(processes=NUM_WORKERS) as pool:
        # Menjalankan fungsi secara paralel untuk setiap provinsi
        results = pool.map(run_individual_clip, provinces)

    # --- RINGKASAN AKHIR ---
    total_duration = time.time() - start_batch
    success_count = sum(1 for res in results if "Sukses" in res)
    timeout_count = sum(1 for res in results if "Timeout" in res)
    failed_count = total - success_count - timeout_count

    print("\n" + "="*75)
    print(f"🏁 BATCH SELESAI dalam {total_duration/60:.2f} menit")
    print(f"📊 Statistik:")
    print(f"   - Berhasil : {success_count}")
    print(f"   - Timeout  : {timeout_count}")
    print(f"   - Gagal    : {failed_count}")
    print("="*75)

    # Menampilkan daftar provinsi yang gagal jika ada
    if failed_count > 0 or timeout_count > 0:
        print("\n⚠️ Periksa kembali provinsi berikut:")
        for res in results:
            if "Sukses" not in res:
                print(f"   - {res}")
