#!/usr/bin/env python3
import os
import subprocess
import sys
import time
import multiprocessing
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# 1. LOAD KONFIGURASI
load_dotenv()

DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis') # Pastikan default ke host docker
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
SCHEMA_DATA = os.getenv("SCHEMA_DATA", "datagis")

TABLE_B = "ADM_KAB_KOTA"
FIELD_FILTER_B = "WADMPR"

# Jumlah Worker (8 proses simultan)
NUM_WORKERS = 8

def get_all_provinces():
    """Mengambil daftar unik provinsi dari database"""
    engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")
    query = text(f'SELECT DISTINCT "{FIELD_FILTER_B}" FROM "{SCHEMA_DATA}"."{TABLE_B}" WHERE "{FIELD_FILTER_B}" IS NOT NULL ORDER BY 1')
    with engine.connect() as conn:
        result = conn.execute(query)
        provs = [row[0] for row in result]
    engine.dispose()
    return provs

def run_individual_clip(provinsi):
    """Fungsi worker untuk menjalankan skrip CLIP per provinsi"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    script_path = os.path.join(current_dir, "gpd_CLIP_IGT_ADM.py")

    print(f"🚀 [START] Memproses: {provinsi}")
    start_time_prov = time.time()

    try:
        # capture_output=True sangat penting agar log 8 proses tidak berantakan di terminal
        result = subprocess.run(
            ["python3", script_path, provinsi],
            check=True,
            capture_output=True,
            text=True
        )
        duration = time.time() - start_time_prov
        print(f"✅ [SUCCESS] {provinsi} ({duration:.2f}s)")
        return f"{provinsi}: Sukses"

    except subprocess.CalledProcessError as e:
        # Jika gagal, ambil pesan error terakhir dari skrip kliping
        error_detail = e.stderr.split('\n')[-2] if e.stderr else "Unknown Error"
        print(f"❌ [ERROR] {provinsi} Gagal! Detail: {error_detail}")
        return f"{provinsi}: Gagal"

if __name__ == "__main__":
    start_batch = time.time()
    
    try:
        provinces = get_all_provinces()
    except Exception as e:
        print(f"❌ Gagal koneksi database: {e}")
        sys.exit(1)

    total = len(provinces)
    print("="*70)
    print(f"🛠️  GEO-PROCESSING BATCH PARALEL")
    print(f"📋 Total Target : {total} Provinsi")
    print(f"🧵 Max Workers  : {NUM_WORKERS}")
    print("="*70)

    # Inisialisasi Pool
    with multiprocessing.Pool(processes=NUM_WORKERS) as pool:
        results = pool.map(run_individual_clip, provinces)

    # Ringkasan Akhir
    total_duration = time.time() - start_batch
    success_count = sum(1 for res in results if "Sukses" in res)
    
    print("\n" + "="*70)
    print(f"🏁 BATCH SELESAI dalam {total_duration/60:.2f} menit")
    print(f"📊 Statistik: {success_count} Berhasil, {total - success_count} Gagal")
    print("="*70)
