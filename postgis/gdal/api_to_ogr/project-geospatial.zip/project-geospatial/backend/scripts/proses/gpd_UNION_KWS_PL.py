import sys
import os
import time
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

load_dotenv()

# =================================================================
# 1. KONFIGURASI DATABASE
# =================================================================
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
OUT_SCHEMA = os.getenv("SCHEMA_OUT", "analisis")

if not all([DB_USER, DB_PASS, DB_HOST, DB_NAME]):
    print("❌ ERROR: Konfigurasi database tidak lengkap!")
    sys.exit(1)

engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

# =================================================================
# 2. PARAMETER WILAYAH
# =================================================================
if len(sys.argv) < 2:
    print(f"\n💡 PENGGUNAAN: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = sys.argv[1]
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

TAB_KWS = f"KWS_{SAFE_NAME}"
TAB_PL = f"PL_{SAFE_NAME}"
OUT_TABLE = f"KWS_PL_{SAFE_NAME}"  # Menghapus '_FULL'
RESULT_TABLE_FULL = f'"{OUT_SCHEMA}"."{OUT_TABLE}"'
SUMMARY_TABLE_NAME = f"SUM_{OUT_TABLE}"

# =================================================================
# 3. PROSES SPASIAL UNION (IDENTITY BERBASIS KWS)
# =================================================================
print("-" * 85)
print(f"🔗 Menggabungkan KWS & PL: {PROVINSI_TARGET}")
print(f"🎯 Target: Mempertahankan 100% Luas KWS ({TAB_KWS})")
print("-" * 85)

try:
    with engine.begin() as conn:
        conn.execute(text(f'DROP TABLE IF EXISTS {RESULT_TABLE_FULL} CASCADE;'))

        query_union = text(f"""
            CREATE TABLE {RESULT_TABLE_FULL} AS
            -- BAGIAN 1: Irisan KWS dan PL
            SELECT
                k."FUNGSIKWS",
                p."PL2024_ID",
                ST_Multi(ST_CollectionExtract(ST_Intersection(k.geom, p.geom), 3)) as geom
            FROM "{OUT_SCHEMA}"."{TAB_KWS}" k
            INNER JOIN "{OUT_SCHEMA}"."{TAB_PL}" p ON ST_Intersects(k.geom, p.geom)
            
            UNION ALL
            
            -- BAGIAN 2: Area KWS yang di luar jangkauan PL (Difference)
            SELECT
                k."FUNGSIKWS",
                0 as "PL2024_ID", 
                ST_Multi(ST_CollectionExtract(
                    COALESCE(
                        ST_Difference(k.geom, (SELECT ST_Union(geom) FROM "{OUT_SCHEMA}"."{TAB_PL}")),
                        k.geom
                    ), 3
                )) as geom
            FROM "{OUT_SCHEMA}"."{TAB_KWS}" k
            WHERE NOT EXISTS (
                SELECT 1 FROM "{OUT_SCHEMA}"."{TAB_PL}" p WHERE ST_Intersects(p.geom, k.geom)
            ) OR ST_Difference(k.geom, (SELECT ST_Union(geom) FROM "{OUT_SCHEMA}"."{TAB_PL}")) IS NOT NULL;
        """)

        print(f"⏳ Menjalankan proses Spatial Overlay...")
        conn.execute(query_union)

        # Cleanup dan Hitung Luas
        conn.execute(text(f'DELETE FROM {RESULT_TABLE_FULL} WHERE ST_IsEmpty(geom);'))
        conn.execute(text(f'ALTER TABLE {RESULT_TABLE_FULL} ADD COLUMN "LUAS_UNION_HA" DOUBLE PRECISION;'))
        conn.execute(text(f'UPDATE {RESULT_TABLE_FULL} SET "LUAS_UNION_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000;'))
        conn.execute(text(f'CREATE INDEX ON {RESULT_TABLE_FULL} USING GIST(geom);'))

    # =================================================================
    # 4. RINGKASAN DATA
    # =================================================================
    query_summary = f"""
        SELECT 
            res."FUNGSIKWS",
            ref_k."FUNGSI_KWS",
            ref_k."NOURUT_KWS",
            res."PL2024_ID",
            ref_p."DESKRIPSI_PL",
            ref_p."NOURUT_PL",
            SUM(res."LUAS_UNION_HA") as total_ha
        FROM {RESULT_TABLE_FULL} res
        LEFT JOIN "kodefikasi"."KODE_KWS" ref_k ON CAST(res."FUNGSIKWS" AS TEXT) = CAST(ref_k."KD_KWS" AS TEXT)
        LEFT JOIN "kodefikasi"."KODE_PL" ref_p ON CAST(res."PL2024_ID" AS TEXT) = CAST(ref_p."KD_PL" AS TEXT)
        GROUP BY 1, 2, 3, 4, 5, 6
        ORDER BY ref_k."NOURUT_KWS" ASC NULLS LAST, ref_p."NOURUT_PL" ASC NULLS LAST
    """
    
    summary_df = pd.read_sql(query_summary, engine)
    
    if not summary_df.empty:
        # Merapikan tipe data No Urut
        for col in ['NOURUT_KWS', 'NOURUT_PL']:
            if col in summary_df.columns:
                summary_df[col] = pd.to_numeric(summary_df[col], errors='coerce').fillna(99).astype(int)

        pd.options.display.float_format = '{:,.2f}'.format
        
        print("\n" + "="*125)
        print(f"HASIL ANALISIS GABUNGAN KWS & PL: {PROVINSI_TARGET}")
        print("="*125)
        print(summary_df.to_string(index=False))
        print("-" * 125)
        
        total_ha = summary_df['total_ha'].sum()
        print(f"TOTAL LUAS GABUNGAN: {total_ha:,.2f} HA")
        
        # Simpan hasil ringkasan
        summary_df.to_sql(SUMMARY_TABLE_NAME, engine, schema=OUT_SCHEMA, if_exists='replace', index=False)
        
        # Log Final
        print(f"\n✅ BERHASIL!")
        print(f"📍 Layer Peta: \"{OUT_SCHEMA}\".\"{OUT_TABLE}\"")
        print(f"📍 Tabel Ringkasan: \"{OUT_SCHEMA}\".\"{SUMMARY_TABLE_NAME}\"")

    print(f"\n⏱️ Selesai dalam {time.time() - start_time:.2f} detik.")

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    sys.exit(1)
