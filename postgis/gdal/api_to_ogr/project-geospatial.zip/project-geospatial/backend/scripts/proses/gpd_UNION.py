#!/usr/bin/env python3
import sys
import os
import time
import pandas as pd
import geopandas as gpd
from sqlalchemy import create_engine, text, inspect
from dotenv import load_dotenv

# --- 1. KONFIGURASI ---
load_dotenv()
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
OUT_SCHEMA = os.getenv("SCHEMA_OUT", "analisis")

# Engine SQLAlchemy
DATABASE_URL = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(DATABASE_URL)

# --- 2. LOGIKA PENANGANAN ARGUMEN (ANTI-TRUNCATION) ---
if len(sys.argv) < 2:
    print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

# Menggabungkan semua argumen setelah nama skrip untuk menghindari pemotongan nama
# Contoh: ["JAWA", "BARAT"] -> "JAWA BARAT"
PROVINSI_TARGET = " ".join(sys.argv[1:]).strip()

# Bersihkan nama untuk tabel (Contoh: "JAWA BARAT" -> "JAWA_BARAT")
SAFE_NAME = "_".join(PROVINSI_TARGET.split()).replace('-', '_').upper()

start_time = time.time()

# Penamaan Tabel
TAB_KWS = f"KWS_{SAFE_NAME}"
TAB_PL = f"PL_{SAFE_NAME}"
OUT_TABLE_NAME = f"KWS_PL_{SAFE_NAME}"

print("-" * 85)
print(f"🚀 GEOPANDAS OVERLAY (IDENTITY): {PROVINSI_TARGET}")
print(f"📂 Mencari Tabel: {TAB_KWS} dan {TAB_PL} di skema '{OUT_SCHEMA}'")
print("-" * 85)

try:
    # --- 3. VALIDASI KEBERADAAN TABEL ---
    inspector = inspect(engine)
    existing_tables = inspector.get_table_names(schema=OUT_SCHEMA)
    
    if TAB_KWS not in existing_tables or TAB_PL not in existing_tables:
        print(f"❌ ERROR: Tabel tidak ditemukan!")
        print(f"   Ditemukan di database: { [t for t in existing_tables if 'KWS_' in t or 'PL_' in t][:5] } ...")
        print(f"   Pastikan Anda sudah menjalankan skrip CLIP untuk '{PROVINSI_TARGET}'.")
        sys.exit(1)

    # --- 4. LOAD DATA (ENGINE: PYOGRIO) ---
    print(f"⏳ [1/4] Memuat data dari database...")
    
    gdf_kws = gpd.read_postgis(
        f'SELECT "FUNGSIKWS", geom FROM "{OUT_SCHEMA}"."{TAB_KWS}"', 
        engine, geom_col='geom'
    )
    
    gdf_pl = gpd.read_postgis(
        f'SELECT "PL2024_ID", geom FROM "{OUT_SCHEMA}"."{TAB_PL}"', 
        engine, geom_col='geom'
    )

    # --- 5. PROSES OVERLAY (IDENTITY) ---
    print(f"⏳ [2/4] Menjalankan Overlay Identity (Shapely 2.0)...")
    
    # Validasi geometri agar overlay tidak crash
    gdf_kws['geom'] = gdf_kws.make_valid()
    gdf_pl['geom'] = gdf_pl.make_valid()

    # Operasi Spasial Identity
    
    gdf_result = gpd.overlay(gdf_kws, gdf_pl, how='identity', keep_geom_type=True)

    # Isi area KWS yang tidak tertutup PL dengan ID 0
    if 'PL2024_ID' in gdf_result.columns:
        gdf_result['PL2024_ID'] = gdf_result['PL2024_ID'].fillna(0).astype(int)

    # --- 6. KALKULASI LUAS & CLEANUP ---
    print(f"⏳ [3/4] Menghitung Luas Hektar (Cylindrical Equal Area)...")
    gdf_result['LUAS_UNION_HA'] = gdf_result.to_crs(epsg=54034).area / 10000
    
    # Hapus noise geometri yang terlalu kecil
    gdf_result = gdf_result[gdf_result['LUAS_UNION_HA'] > 0.0001].copy()

    # --- 7. SIMPAN KE DATABASE ---
    print(f"⏳ [4/4] Menyimpan ke database: {OUT_TABLE_NAME}...")
    
    with engine.begin() as conn:
        conn.execute(text(f'DROP TABLE IF EXISTS "{OUT_SCHEMA}"."{OUT_TABLE_NAME}" CASCADE;'))

    gdf_result.to_postgis(
        OUT_TABLE_NAME, 
        engine, 
        schema=OUT_SCHEMA, 
        if_exists='replace', 
        index=False,
        chunksize=10000
    )

    # Tambahkan Indeks Spasial GIST
    with engine.begin() as conn:
        conn.execute(text(f'CREATE INDEX ON "{OUT_SCHEMA}"."{OUT_TABLE_NAME}" USING GIST(geom);'))

    # --- 8. SUMMARY REPORT ---
    print("\n📊 Menghasilkan Ringkasan Luas...")
    summary_query = f"""
        SELECT 
            res."FUNGSIKWS", 
            k."FUNGSI_KWS", 
            res."PL2024_ID", 
            p."DESKRIPSI_PL", 
            SUM(res."LUAS_UNION_HA") as total_ha
        FROM "{OUT_SCHEMA}"."{OUT_TABLE_NAME}" res
        LEFT JOIN "kodefikasi"."KODE_KWS" k ON res."FUNGSIKWS"::text = k."KD_KWS"::text
        LEFT JOIN "kodefikasi"."KODE_PL" p ON res."PL2024_ID"::text = p."KD_PL"::text
        GROUP BY 1, 2, 3, 4
        ORDER BY k."NOURUT_KWS" ASC NULLS LAST, p."NOURUT_PL" ASC NULLS LAST
    """
    df_sum = pd.read_sql(summary_query, engine)
    df_sum.to_sql(f"SUM_{OUT_TABLE_NAME}", engine, schema=OUT_SCHEMA, if_exists='replace', index=False)
    
    print("-" * 85)
    print(df_sum.to_string(index=False))
    print("-" * 85)
    print(f"✅ BERHASIL! Waktu Proses: {time.time() - start_time:.2f} detik.")

except Exception as e:
    print(f"\n❌ ERROR UTAMA: {e}")
    sys.exit(1)
