#!/usr/bin/env python3
import sys
import os
import time
import math
from sqlalchemy import create_engine, text, inspect
from dotenv import load_dotenv

# --- 1. UTILITY: FORMAT WAKTU ---
def format_duration(seconds):
    minutes = int(seconds // 60)
    secs = seconds % 60
    if minutes > 0:
        return f"{minutes} Menit {secs:.2f} Detik"
    return f"{secs:.2f} Detik"

# --- 2. INISIALISASI & KONFIGURASI ---
load_dotenv()
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
OUT_SCHEMA = os.getenv("OUT_SCHEMA", "analisis")

engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

if len(sys.argv) < 2:
    print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = " ".join(sys.argv[1:]).strip()
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

layers_env = os.getenv("LAYERS_PREFIX", "KWS,PL")
LAYERS_PREFIX = [p.strip().upper() for p in layers_env.split(",")]
INPUT_TABLES = [f"{p}_{SAFE_NAME}" for p in LAYERS_PREFIX]
total_steps = len(INPUT_TABLES) + 2 # Inisialisasi + Loop Layer + Finalisasi

raw_out_name = f"{'_'.join(LAYERS_PREFIX)}_{SAFE_NAME}"
OUT_TABLE = raw_out_name[:62].rstrip('_') 

print("-" * 85)
print(f"🚀 MULTI-LAYER OVERLAY ENGINE (v3 - PROGRESS TRACKER)")
print(f"📍 Wilayah: {PROVINSI_TARGET}")
print(f"🔗 Total Layer: {len(INPUT_TABLES)}")
print("-" * 85)

try:
    inspector = inspect(engine)
    existing_tables = inspector.get_table_names(schema=OUT_SCHEMA)
    
    missing_tables = [t for t in INPUT_TABLES if t not in existing_tables]
    if missing_tables:
        print(f"❌ ERROR: Tabel tidak ditemukan: {missing_tables}")
        sys.exit(1)

    with engine.begin() as conn:
        # a. Inisialisasi
        first_table = INPUT_TABLES[0]
        print(f"⏳ [1/{total_steps}] Inisialisasi Base: {first_table}...")
        conn.execute(text("DROP TABLE IF EXISTS temp_overlay CASCADE;"))
        conn.execute(text(f"""
            CREATE TEMP TABLE temp_overlay AS 
            SELECT *, geom as geom_res FROM "{OUT_SCHEMA}"."{first_table}";
        """))

        # b. Looping Intersection
        for i in range(1, len(INPUT_TABLES)):
            next_table = INPUT_TABLES[i]
            curr_time = time.time()
            progress = ((i + 1) / total_steps) * 100
            print(f"⏳ [{i+1}/{total_steps}] Overlaying {next_table} ({progress:.0f}%)...", end=" ", flush=True)
            
            # Anti-Collision Logic
            res_cols_query = conn.execute(text("SELECT * FROM temp_overlay LIMIT 0"))
            existing_cols = [col for col in res_cols_query.keys() if col.lower() not in ['geom_res', 'geom']]
            select_a = ", ".join([f'a."{c}"' for c in existing_cols])
            
            existing_col_names_upper = [c.upper() for c in existing_cols]
            next_cols = inspector.get_columns(next_table, schema=OUT_SCHEMA)
            
            new_cols_to_add = []
            for c in next_cols:
                c_name = c['name']
                if c_name.upper() not in existing_col_names_upper and c_name.lower() not in ['geom', 'geometry', 'shape']:
                    new_cols_to_add.append(f'b."{c_name}"')
            
            select_b = ", " + ", ".join(new_cols_to_add) if new_cols_to_add else ""

            conn.execute(text(f"""
                CREATE TEMP TABLE temp_overlay_new AS
                SELECT 
                    {select_a} {select_b}, 
                    ST_Multi(ST_CollectionExtract(ST_Intersection(ST_MakeValid(a.geom_res), ST_MakeValid(b.geom)), 3)) as geom_next
                FROM temp_overlay a
                JOIN "{OUT_SCHEMA}"."{next_table}" b ON ST_Intersects(a.geom_res, b.geom)
                WHERE NOT ST_IsEmpty(ST_Intersection(ST_MakeValid(a.geom_res), ST_MakeValid(b.geom)));
                
                DROP TABLE temp_overlay;
                ALTER TABLE temp_overlay_new RENAME TO temp_overlay;
                ALTER TABLE temp_overlay RENAME COLUMN geom_next TO geom_res;
            """))
            print(f"Done! ({time.time() - curr_time:.2f}s)")

        # c. Simpan & Finalisasi
        final_step = total_steps
        print(f"⏳ [{final_step}/{total_steps}] Finalisasi & Simpan ke {OUT_TABLE}...")
        conn.execute(text(f'DROP TABLE IF EXISTS "{OUT_SCHEMA}"."{OUT_TABLE}" CASCADE;'))
        conn.execute(text(f"""
            CREATE TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" AS 
            SELECT * FROM temp_overlay WHERE ST_GeometryType(geom_res) LIKE '%Polygon%';
            
            ALTER TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" DROP COLUMN IF EXISTS geom;
            ALTER TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" RENAME COLUMN geom_res TO geom;
            
            ALTER TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" ADD COLUMN IF NOT EXISTS "LUAS_OVERLAY_HA" float;
            UPDATE "{OUT_SCHEMA}"."{OUT_TABLE}" SET "LUAS_OVERLAY_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000;
            CREATE INDEX ON "{OUT_SCHEMA}"."{OUT_TABLE}" USING GIST(geom);
        """))

    total_duration = time.time() - start_time
    print("-" * 85)
    print(f"✅ BERHASIL!")
    print(f"⏱️  Waktu Total: {format_duration(total_duration)} ({total_duration:.2f} detik)")
    print(f"📊 Tabel Hasil: {OUT_SCHEMA}.{OUT_TABLE}")
    print("-" * 85)

except Exception as e:
    print(f"\n❌ ERROR UTAMA: {e}")
    sys.exit(1)
