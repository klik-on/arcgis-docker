#!/usr/bin/env python3
import sys
import os
import time
from sqlalchemy import create_engine, text, inspect
from dotenv import load_dotenv

# --- 1. UTILITY: FORMAT WAKTU ---
def format_duration(seconds):
    minutes = int(seconds // 60)
    secs = seconds % 60
    if minutes > 0:
        return f"{minutes} Menit {secs:.2f} Detik"
    return f"{secs:.2f} Detik"

# --- 2. INISIALISASI & KONFIGURASI ---
load_dotenv()
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
OUT_SCHEMA = os.getenv("OUT_SCHEMA", "analisis")

engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

if len(sys.argv) < 2:
    print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = " ".join(sys.argv[1:]).strip()
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

layers_env = os.getenv("LAYERS_PREFIX", "KWS,PL")
LAYERS_PREFIX = [p.strip().upper() for p in layers_env.split(",")]
INPUT_TABLES = [f"{p}_{SAFE_NAME}" for p in LAYERS_PREFIX]
total_steps = len(INPUT_TABLES)

raw_out_name = f"UNION_{'_'.join(LAYERS_PREFIX)}_{SAFE_NAME}"
OUT_TABLE = raw_out_name[:62].rstrip('_') 

print("-" * 85)
print(f"🚀 TRUE GEOSPATIAL UNION ENGINE v4 (FULL OUTER JOIN LOGIC)")
print(f"📍 Wilayah: {PROVINSI_TARGET}")
print(f"🔗 Total Layer: {len(INPUT_TABLES)}")
print("-" * 85)

try:
    inspector = inspect(engine)
    with engine.begin() as conn:
        # --- a. STEP 1: PREPARASI BASE ---
        first_table = INPUT_TABLES[0]
        print(f"⏳ [1/{total_steps}] Mempersiapkan Base: {first_table}...")
        conn.execute(text("DROP TABLE IF EXISTS temp_union_result CASCADE;"))
        conn.execute(text(f"""
            CREATE TEMP TABLE temp_union_result AS 
            SELECT *, ST_MakeValid(geom) as geom_res FROM "{OUT_SCHEMA}"."{first_table}";
            CREATE INDEX idx_u_geom ON temp_union_result USING GIST(geom_res);
        """))

        # --- b. STEP 2: LOOPING FULL UNION ---
        for i in range(1, len(INPUT_TABLES)):
            next_table = INPUT_TABLES[i]
            curr_time = time.time()
            print(f"⏳ [{i+1}/{total_steps}] Unioning {next_table}...", end=" ", flush=True)
            
            # Kolom handling
            res_cols_query = conn.execute(text("SELECT * FROM temp_union_result LIMIT 0"))
            cols_a = [f'"{c}"' for c in res_cols_query.keys() if c.lower() not in ['geom_res', 'geom']]
            
            existing_col_names_upper = [c.upper() for c in res_cols_query.keys()]
            next_cols = inspector.get_columns(next_table, schema=OUT_SCHEMA)
            cols_b = [f'"{c["name"]}"' for c in next_cols if c["name"].upper() not in existing_col_names_upper and c["name"].lower() not in ['geom', 'geometry']]

            select_a = ", ".join([f'a.{c}' for c in cols_a])
            select_b = ", ".join([f'b.{c}' for c in cols_b])

            # LOGIKA TRUE UNION:
            # 1. Irisan (A INTERSECT B)
            # 2. Area A yang tidak kena B (A DIFF B)
            # 3. Area B yang tidak kena A (B DIFF A)
            conn.execute(text(f"""
                CREATE TEMP TABLE temp_union_next AS
                -- Bagian 1: Irisan (Intersection)
                SELECT {select_a}, {select_b}, ST_Multi(ST_CollectionExtract(ST_Intersection(a.geom_res, ST_MakeValid(b.geom)), 3)) as geom_res
                FROM temp_union_result a 
                JOIN "{OUT_SCHEMA}"."{next_table}" b ON ST_Intersects(a.geom_res, b.geom)
                
                UNION ALL
                
                -- Bagian 2: Area A yang tidak beririsan dengan B
                SELECT {select_a}, {", ".join(['NULL' for _ in cols_b])}, ST_Multi(ST_CollectionExtract(ST_Difference(a.geom_res, (SELECT ST_Union(ST_MakeValid(geom)) FROM "{OUT_SCHEMA}"."{next_table}" WHERE ST_Intersects(geom, a.geom_res))), 3)) as geom_res
                FROM temp_union_result a
                WHERE EXISTS (SELECT 1 FROM "{OUT_SCHEMA}"."{next_table}" b WHERE ST_Intersects(a.geom_res, b.geom))
                
                UNION ALL
                
                -- Bagian 3: Area A yang memang jauh dari B (Tidak ada irisan sama sekali)
                SELECT {select_a}, {", ".join(['NULL' for _ in cols_b])}, a.geom_res
                FROM temp_union_result a
                WHERE NOT EXISTS (SELECT 1 FROM "{OUT_SCHEMA}"."{next_table}" b WHERE ST_Intersects(a.geom_res, b.geom))

                UNION ALL

                -- Bagian 4: Area B yang tidak ada di A
                SELECT {", ".join(['NULL' for _ in cols_a])}, {select_b}, ST_Multi(ST_CollectionExtract(ST_Difference(ST_MakeValid(b.geom), (SELECT ST_Union(geom_res) FROM temp_union_result WHERE ST_Intersects(geom_res, b.geom))), 3)) as geom_res
                FROM "{OUT_SCHEMA}"."{next_table}" b
                WHERE EXISTS (SELECT 1 FROM temp_union_result a WHERE ST_Intersects(a.geom_res, b.geom))

                UNION ALL

                -- Bagian 5: Area B yang memang jauh dari A
                SELECT {", ".join(['NULL' for _ in cols_a])}, {select_b}, ST_MakeValid(b.geom) as geom_res
                FROM "{OUT_SCHEMA}"."{next_table}" b
                WHERE NOT EXISTS (SELECT 1 FROM temp_union_result a WHERE ST_Intersects(a.geom_res, b.geom));

                DROP TABLE temp_union_result;
                ALTER TABLE temp_union_next RENAME TO temp_union_result;
                CREATE INDEX idx_u_geom_{i} ON temp_union_result USING GIST(geom_res);
                -- Bersihkan poligon kosong
                DELETE FROM temp_union_result WHERE ST_IsEmpty(geom_res) OR ST_Area(geom_res) < 0.00000001;
            """))
            print(f"Selesai! ({time.time() - curr_time:.2f}s)")

        # --- c. STEP 3: FINALISASI ---
        print(f"⏳ Finalisasi Tabel Utama: {OUT_TABLE}...")
        conn.execute(text(f'DROP TABLE IF EXISTS "{OUT_SCHEMA}"."{OUT_TABLE}" CASCADE;'))
        conn.execute(text(f"""
            CREATE TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" AS 
            SELECT * FROM temp_union_result;
            
            ALTER TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" RENAME COLUMN geom_res TO geom;
            ALTER TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" ADD COLUMN "LUAS_HA" float;
            UPDATE "{OUT_SCHEMA}"."{OUT_TABLE}" SET "LUAS_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000;
            CREATE INDEX ON "{OUT_SCHEMA}"."{OUT_TABLE}" USING GIST(geom);
        """))

    print("-" * 85)
    print(f"✅ UNION BERHASIL! Total Waktu: {format_duration(time.time() - start_time)}")
    print(f"📊 Tabel Hasil: {OUT_SCHEMA}.{OUT_TABLE}")

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    sys.exit(1)
