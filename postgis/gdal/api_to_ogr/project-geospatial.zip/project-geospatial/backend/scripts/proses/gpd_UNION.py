#!/usr/bin/env python3
import sys
import os
import time
from sqlalchemy import create_engine, text, inspect
from dotenv import load_dotenv

# docker exec -it -e LAYERS_PREFIX="KWS,PL" geo-worker python3 scripts/proses/gpd_UNION.py "Bali"

# --- 1. UTILITY: FORMAT WAKTU ---
def format_duration(seconds):
    minutes = int(seconds // 60)
    secs = seconds % 60
    if minutes > 0:
        return f"{minutes} Menit {secs:.2f} Detik"
    return f"{secs:.2f} Detik"

# --- 2. INISIALISASI & KONFIGURASI ---
load_dotenv()
DB_USER = os.getenv('DB_USER')
DB_PASS = os.getenv('DB_PASS')
DB_HOST = os.getenv('DB_HOST', 'dbgis')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME')
OUT_SCHEMA = os.getenv("OUT_SCHEMA", "analisis")

engine = create_engine(f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

if len(sys.argv) < 2:
    print(f"💡 Gunakan: python3 {os.path.basename(__file__)} \"Nama Wilayah\"")
    sys.exit(1)

PROVINSI_TARGET = " ".join(sys.argv[1:]).strip()
SAFE_NAME = PROVINSI_TARGET.replace(' ', '_').replace('-', '_').upper()
start_time = time.time()

layers_env = os.getenv("LAYERS_PREFIX", "KWS,PL")
LAYERS_PREFIX = [p.strip().upper() for p in layers_env.split(",")]
INPUT_TABLES = [f"{p}_{SAFE_NAME}" for p in LAYERS_PREFIX]
total_steps = len(INPUT_TABLES)

raw_out_name = f"UNION_{'_'.join(LAYERS_PREFIX)}_{SAFE_NAME}"
OUT_TABLE = raw_out_name[:62].rstrip('_')

print("-" * 85)
print(f"🚀 TRUE GEOSPATIAL UNION ENGINE v4.1 (AUTO-COL FIX)")
print(f"📍 Wilayah: {PROVINSI_TARGET}")
print(f"🔗 Total Layer: {len(INPUT_TABLES)}")
print("-" * 85)

try:
    inspector = inspect(engine)
    with engine.begin() as conn:
        # --- a. STEP 1: PREPARASI BASE ---
        first_table = INPUT_TABLES[0]
        print(f"⏳ [1/{total_steps}] Mempersiapkan Base: {first_table}...")
        conn.execute(text("DROP TABLE IF EXISTS temp_union_result CASCADE;"))
        conn.execute(text(f"""
            CREATE TEMP TABLE temp_union_result AS
            SELECT *, ST_MakeValid(geom) as geom_res FROM "{OUT_SCHEMA}"."{first_table}";
            CREATE INDEX idx_u_geom ON temp_union_result USING GIST(geom_res);
        """))

        # --- b. STEP 2: LOOPING FULL UNION ---
        for i in range(1, len(INPUT_TABLES)):
            next_table = INPUT_TABLES[i]
            curr_time = time.time()
            print(f"⏳ [{i+1}/{total_steps}] Unioning {next_table}...", end=" ", flush=True)

            # Ambil kolom yang sudah ada di temp_union_result
            res_cols_query = conn.execute(text("SELECT * FROM temp_union_result LIMIT 0"))
            existing_cols = [c.upper() for c in res_cols_query.keys()]
            
            # Kolom dari tabel A (temp_result)
            cols_a = [f'a."{c}"' for c in res_cols_query.keys() if c.lower() not in ['geom_res', 'geom']]

            # Kolom dari tabel B (next_table) - Hanya ambil yang belum ada di A
            next_cols_info = inspector.get_columns(next_table, schema=OUT_SCHEMA)
            cols_b_names = [c["name"] for c in next_cols_info 
                            if c["name"].upper() not in existing_cols 
                            and c["name"].lower() not in ['geom', 'geometry']]
            
            cols_b = [f'b."{c}"' for c in cols_b_names]
            null_b = ", ".join(['NULL' for _ in cols_b_names])
            null_a = ", ".join(['NULL' for _ in cols_a])

            select_a = ", ".join(cols_a)
            select_b = ", ".join(cols_b) if cols_b else ""
            
            # Tambahkan koma jika ada kolom B
            comma = ", " if select_b else ""

            conn.execute(text(f"""
                CREATE TEMP TABLE temp_union_next AS
                -- 1. Intersection
                SELECT {select_a}{comma}{select_b}, 
                       ST_Multi(ST_CollectionExtract(ST_Intersection(a.geom_res, ST_MakeValid(b.geom)), 3)) as geom_res
                FROM temp_union_result a
                JOIN "{OUT_SCHEMA}"."{next_table}" b ON ST_Intersects(a.geom_res, b.geom)

                UNION ALL

                -- 2. Difference A - B
                SELECT {select_a}{comma}{null_b}, 
                       ST_Multi(ST_CollectionExtract(ST_Difference(a.geom_res, (
                           SELECT ST_Union(ST_MakeValid(geom)) FROM "{OUT_SCHEMA}"."{next_table}" 
                           WHERE ST_Intersects(geom, a.geom_res)
                       )), 3)) as geom_res
                FROM temp_union_result a
                WHERE EXISTS (SELECT 1 FROM "{OUT_SCHEMA}"."{next_table}" b WHERE ST_Intersects(a.geom_res, b.geom))

                UNION ALL

                -- 3. Only A
                SELECT {select_a}{comma}{null_b}, a.geom_res
                FROM temp_union_result a
                WHERE NOT EXISTS (SELECT 1 FROM "{OUT_SCHEMA}"."{next_table}" b WHERE ST_Intersects(a.geom_res, b.geom))

                UNION ALL

                -- 4. Difference B - A
                SELECT {null_a}{comma}{select_b}, 
                       ST_Multi(ST_CollectionExtract(ST_Difference(ST_MakeValid(b.geom), (
                           SELECT ST_Union(geom_res) FROM temp_union_result 
                           WHERE ST_Intersects(geom_res, b.geom)
                       )), 3)) as geom_res
                FROM "{OUT_SCHEMA}"."{next_table}" b
                WHERE EXISTS (SELECT 1 FROM temp_union_result a WHERE ST_Intersects(a.geom_res, b.geom))

                UNION ALL

                -- 5. Only B
                SELECT {null_a}{comma}{select_b}, ST_MakeValid(b.geom) as geom_res
                FROM "{OUT_SCHEMA}"."{next_table}" b
                WHERE NOT EXISTS (SELECT 1 FROM temp_union_result a WHERE ST_Intersects(a.geom_res, b.geom));

                DROP TABLE temp_union_result;
                ALTER TABLE temp_union_next RENAME TO temp_union_result;
                CREATE INDEX idx_u_geom_{i} ON temp_union_result USING GIST(geom_res);
                
                DELETE FROM temp_union_result WHERE ST_IsEmpty(geom_res) OR ST_Area(geom_res) < 0.00000001;
            """))
            print(f"Selesai! ({time.time() - curr_time:.2f}s)")

        # --- c. STEP 3: FINALISASI ---
        print(f"⏳ Finalisasi Tabel Utama: {OUT_TABLE}...")
        conn.execute(text(f'DROP TABLE IF EXISTS "{OUT_SCHEMA}"."{OUT_TABLE}" CASCADE;'))
        
        # Cek keberadaan kolom LUAS_HA agar tidak DuplicateColumn error
        check_luas = conn.execute(text("SELECT * FROM temp_union_result LIMIT 0"))
        has_luas = "LUAS_HA" in [k.upper() for k in check_luas.keys()]

        sql_final = f"""
            CREATE TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" AS SELECT * FROM temp_union_result;
            ALTER TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" RENAME COLUMN geom_res TO geom;
        """
        
        if not has_luas:
            sql_final += f'\n            ALTER TABLE "{OUT_SCHEMA}"."{OUT_TABLE}" ADD COLUMN "LUAS_HA" float;'
        
        sql_final += f"""
            UPDATE "{OUT_SCHEMA}"."{OUT_TABLE}" SET "LUAS_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000;
            CREATE INDEX ON "{OUT_SCHEMA}"."{OUT_TABLE}" USING GIST(geom);
            DROP TABLE IF EXISTS temp_union_result;
        """
        
        conn.execute(text(sql_final))

    print("-" * 85)
    print(f"✅ UNION BERHASIL! Total Waktu: {format_duration(time.time() - start_time)}")
    print(f"📊 Tabel Hasil: {OUT_SCHEMA}.{OUT_TABLE}")

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    sys.exit(1)
