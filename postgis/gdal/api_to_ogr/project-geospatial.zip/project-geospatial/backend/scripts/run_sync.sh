#!/bin/bash

# =================================================================
# 🚀 GEOSPATIAL TASK WRAPPER (Enterprise & Docker Optimized)
# =================================================================
# Versi: 1.1.2
# Deskripsi: Menjalankan skrip spasial dengan rotasi log otomatis,
#            real-time piping, dan manajemen proses untuk Celery.
# =================================================================

# --- 1. KONFIGURASI PATH & LOGGING ---
LOG_FILE="/app/data/sync.log"
MAX_LOG_SIZE_KB=5120  # Rotasi setelah 5MB agar performa baca tetap cepat
CURRENT_PID=$$
TIMESTAMP_START=$(date "+%Y-%m-%d %H:%M:%S")

# Pastikan direktori data tersedia
mkdir -p /app/data

# Fungsi untuk mencatat info sistem ke log
log_sys() {
    local MSG=$1
    echo "[$TIMESTAMP_START] [SYSTEM:$CURRENT_PID] $MSG" >> "$LOG_FILE"
}

# --- 2. MANAJEMEN SINYAL (CLEANUP) ---
cleanup() {
    log_sys "⚠️ Sinyal Terminasi Diterima. Menghentikan sub-proses..."
    if [ -n "$CHILD_PID" ]; then
        # Kirim sinyal TERM ke child process (Python/GIS)
        kill -TERM "$CHILD_PID" 2>/dev/null
    fi
    exit 143
}

# Tangkap sinyal TERM dan INT (Docker Stop / Celery Revoke)
trap cleanup SIGTERM SIGINT

# --- 3. LOAD ENVIRONMENT ---
# Mendukung loading manual .env jika tidak dijalankan via Docker Compose
if [ -f "/app/.env" ]; then
    if [ -z "$DATABASE_URL" ]; then
        set -a
        source /app/.env
        set +a
        log_sys "💡 Env: Loaded from /app/.env"
    fi
fi

# Tangkap Argumen
SCRIPT_PATH=$1
shift
ARGS=$@

# --- 4. ATOMIC LOG ROTATION ---
# Mencegah file sync.log menjadi terlalu besar (Raw Data GIS seringkali berisik)
if [ -f "$LOG_FILE" ]; then
    FILE_SIZE=$(du -k "$LOG_FILE" | cut -f1)
    if [ "$FILE_SIZE" -gt "$MAX_LOG_SIZE_KB" ]; then
        ROTATED_FILE="$LOG_FILE.$(date +%Y%m%d_%H%M%S).old"
        mv "$LOG_FILE" "$ROTATED_FILE"
        touch "$LOG_FILE"
        log_sys "🔄 Log Rotated: Size > 5MB. Archived to $(basename $ROTATED_FILE)"
    fi
fi

# --- 5. EXECUTION LOGIC ---
echo "----------------------------------------------------------" >> "$LOG_FILE"
log_sys "🚀 STARTING TASK: $(basename "$SCRIPT_PATH")"
[ -n "$ARGS" ] && log_sys "📂 ARGS: $ARGS"

# Validasi File
if [ ! -f "$SCRIPT_PATH" ]; then
    log_sys "❌ Error: File skrip tidak ditemukan."
    exit 1
fi

EXTENSION="${SCRIPT_PATH##*.}"

# Fungsi eksekusi utama dengan piping real-time
execute_with_log() {
    local INTERPRETER=$1
    
    # Menjalankan skrip dan menyalurkan output ke file log & stdout (untuk Celery)
    # PIPESTATUS digunakan untuk menangkap exit code dari interpreter, bukan dari tee
    if [ -n "$INTERPRETER" ]; then
        $INTERPRETER "$SCRIPT_PATH" $ARGS 2>&1 | tee -a "$LOG_FILE"
    else
        bash "$SCRIPT_PATH" $ARGS 2>&1 | tee -a "$LOG_FILE"
    fi

    RESULT=${PIPESTATUS[0]}
}

# Pilih Interpreter berdasarkan ekstensi
case $EXTENSION in
    py)
        log_sys "🐍 Mode: Python 3 (Unbuffered)"
        execute_with_log "python3 -u" # -u penting agar log tidak tertahan di buffer
        ;;
    sh)
        log_sys "🐚 Mode: Bash Shell"
        chmod +x "$SCRIPT_PATH"
        execute_with_log "bash"
        ;;
    *)
        log_sys "❓ Mode: Direct Execution"
        chmod +x "$SCRIPT_PATH"
        execute_with_log ""
        ;;
esac

# --- 6. FINALIZING ---
TIMESTAMP_END=$(date "+%Y-%m-%d %H:%M:%S")

if [ $RESULT -eq 0 ]; then
    echo "[$TIMESTAMP_END] [SYSTEM:$CURRENT_PID] ✅ TASK SUCCESS" >> "$LOG_FILE"
else
    echo "[$TIMESTAMP_END] [SYSTEM:$CURRENT_PID] 💥 TASK FAILED (Exit Code: $RESULT)" >> "$LOG_FILE"
fi
echo "----------------------------------------------------------" >> "$LOG_FILE"

exit $RESULT
