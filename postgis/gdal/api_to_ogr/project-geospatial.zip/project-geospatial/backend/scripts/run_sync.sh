#!/bin/bash

# =================================================================
# 🚀 GEOSPATIAL TASK WRAPPER (Enterprise & Docker Optimized)
# =================================================================

# --- 1. KONFIGURASI PATH & LOGGING ---
LOG_FILE="/app/data/sync.log"
TIMESTAMP_START=$(date "+%Y-%m-%d %H:%M:%S")
# Set ke 2048 KB (2MB) agar selaras dengan kebijakan Docker Compose Anda
MAX_LOG_SIZE_KB=2048  
CURRENT_PID=$$        # ID proses untuk melacak log jika paralel (Celery Concurrency)

# Pastikan direktori data tersedia
mkdir -p /app/data

# Fungsi pembantu untuk menulis log ke file
log_info() {
    local MSG=$1
    echo "[$TIMESTAMP_START] [PID: $CURRENT_PID] $MSG" >> "$LOG_FILE"
}

# --- 2. LOAD ENVIRONMENT VARIABLES (Safe Loading) ---
if [ -f "/app/.env" ]; then
    if [ -z "$DB_NAME" ]; then
        set -a
        source /app/.env
        set +a
        log_info "💡 Env: Loaded from /app/.env"
    fi
else
    if [ -n "$DB_NAME" ]; then
        log_info "☁️ Env: Using Docker system variables."
    fi
fi

# Menangkap Argumen dari Celery/Caller
SCRIPT_PATH=$1
shift
ARGS=$@

# --- 3. LOG ROTATION (Atomic Strategy) ---
if [ -f "$LOG_FILE" ]; then
    FILE_SIZE=$(du -k "$LOG_FILE" | cut -f1)
    if [ "$FILE_SIZE" -gt "$MAX_LOG_SIZE_KB" ]; then
        # Menggunakan timestamp agar file .old tidak saling timpa jika task berjalan simultan
        ROTATED_FILE="$LOG_FILE.$(date +%Y%m%d_%H%M%S).old"
        mv "$LOG_FILE" "$ROTATED_FILE"
        touch "$LOG_FILE"
        log_info "🔄 Log rotated: Size reached 2MB. Archived to $(basename $ROTATED_FILE)"
    fi
fi

# --- 4. EXECUTION LOGIC ---
echo "----------------------------------------------------------" >> "$LOG_FILE"
log_info "🚀 STARTING TASK: $SCRIPT_PATH"
[ -n "$ARGS" ] && log_info "📂 ARGUMENTS: $ARGS"

# Validasi Keberadaan Skrip
if [ ! -f "$SCRIPT_PATH" ]; then
    log_info "❌ Error: Script $SCRIPT_PATH not found."
    echo "----------------------------------------------------------" >> "$LOG_FILE"
    exit 1
fi

# Identifikasi Ekstensi File
EXTENSION="${SCRIPT_PATH##*.}"

# Fungsi eksekusi untuk menangkap stdout & stderr secara real-time
execute_with_log() {
    local INTERPRETER=$1
    # python3 -u (unbuffered) sangat penting agar log muncul saat proses berjalan (tidak tertahan)
    $INTERPRETER "$SCRIPT_PATH" $ARGS 2>&1 | while IFS= read -r line; do
        echo "[$CURRENT_PID] $line" >> "$LOG_FILE"
    done
    return ${PIPESTATUS[0]} # Ambil exit code dari interpreter, bukan dari pipe (while)
}

case $EXTENSION in
    py)
        log_info "🐍 Interpreter: Python 3 (Unbuffered)"
        execute_with_log "python3 -u"
        RESULT=$?
        ;;
    sh)
        log_info "🐚 Interpreter: Bash Shell"
        chmod +x "$SCRIPT_PATH"
        execute_with_log "bash"
        RESULT=$?
        ;;
    *)
        log_info "❓ Unknown type. Attempting direct execution..."
        chmod +x "$SCRIPT_PATH"
        execute_with_log ""
        RESULT=$?
        ;;
esac

# --- 5. FINALIZING ---
TIMESTAMP_END=$(date "+%Y-%m-%d %H:%M:%S")

if [ $RESULT -eq 0 ]; then
    echo "[$TIMESTAMP_END] [PID: $CURRENT_PID] ✅ TASK COMPLETED SUCCESSFULLY" >> "$LOG_FILE"
else
    echo "[$TIMESTAMP_END] [PID: $CURRENT_PID] 💥 TASK FAILED (Exit Code: $RESULT)" >> "$LOG_FILE"
fi
echo "----------------------------------------------------------" >> "$LOG_FILE"

exit $RESULT
