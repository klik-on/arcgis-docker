#!/bin/bash

# =================================================================
# 🚀 GEOSPATIAL TASK WRAPPER (Docker Optimized)
# =================================================================

# --- 1. KONFIGURASI PATH & LOGGING ---
LOG_FILE="/app/data/sync.log"
TIMESTAMP_START=$(date "+%Y-%m-%d %H:%M:%S")
MAX_LOG_SIZE_KB=5120  # 5MB Rotation
CURRENT_PID=$$        # ID proses untuk membedakan log antar task

# Pastikan direktori data tersedia
mkdir -p /app/data

# Fungsi pembantu untuk menulis log ke file
log_info() {
    echo "[$TIMESTAMP_START] [PID: $CURRENT_PID] $1" >> "$LOG_FILE"
}

# --- 2. LOAD ENVIRONMENT VARIABLES (Silent Loading) ---
# Jika berjalan di Docker, variabel biasanya sudah ada di system env.
# Jika ada file .env, kita muat hanya jika variabel kunci belum ada.
if [ -f "/app/.env" ]; then
    if [ -z "$DB_NAME" ]; then
        set -a
        source /app/.env
        set +a
        log_info "💡 Env: Loaded from /app/.env"
    fi
else
    if [ -n "$DB_NAME" ]; then
        log_info "☁️ Env: Using Docker system variables."
    fi
fi

# Argumen dari Celery (Script & Args)
SCRIPT_PATH=$1
shift
ARGS=$@

# --- 3. LOG ROTATION ---
if [ -f "$LOG_FILE" ]; then
    FILE_SIZE=$(du -k "$LOG_FILE" | cut -f1)
    if [ "$FILE_SIZE" -gt "$MAX_LOG_SIZE_KB" ]; then
        mv "$LOG_FILE" "$LOG_FILE.old"
        touch "$LOG_FILE"
        log_info "🔄 Log rotated: Previous log moved to sync.log.old"
    fi
fi

# --- 4. EXECUTION LOGIC ---
echo "----------------------------------------------------------" >> "$LOG_FILE"
log_info "🚀 STARTING TASK: $SCRIPT_PATH"
[ -n "$ARGS" ] && log_info "📂 ARGUMENTS: $ARGS"

# Validasi Keberadaan Skrip
if [ ! -f "$SCRIPT_PATH" ]; then
    log_info "❌ Error: Script $SCRIPT_PATH not found."
    echo "----------------------------------------------------------" >> "$LOG_FILE"
    exit 1
fi

EXTENSION="${SCRIPT_PATH##*.}"

# Fungsi eksekusi untuk menangkap stdout & stderr ke dalam log
execute_with_log() {
    # $1 adalah interpreter (python3 atau bash)
    $1 "$SCRIPT_PATH" $ARGS 2>&1 | while IFS= read -r line; do
        echo "[$CURRENT_PID] $line" >> "$LOG_FILE"
    done
    return ${PIPESTATUS[0]}
}

case $EXTENSION in
    py)
        log_info "🐍 Interpreter: Python 3.12"
        execute_with_log "python3 -u"
        RESULT=$?
        ;;
    sh)
        log_info "🐚 Interpreter: Bash Shell"
        chmod +x "$SCRIPT_PATH"
        execute_with_log "bash"
        RESULT=$?
        ;;
    *)
        log_info "❓ Unknown type. Direct execution..."
        chmod +x "$SCRIPT_PATH"
        execute_with_log ""
        RESULT=$?
        ;;
esac

# --- 5. FINALIZING ---
TIMESTAMP_END=$(date "+%Y-%m-%d %H:%M:%S")

if [ $RESULT -eq 0 ]; then
    echo "[$TIMESTAMP_END] [PID: $CURRENT_PID] ✅ TASK COMPLETED SUCCESSFULLY" >> "$LOG_FILE"
else
    echo "[$TIMESTAMP_END] [PID: $CURRENT_PID] 💥 TASK FAILED (Exit Code: $RESULT)" >> "$LOG_FILE"
fi
echo "----------------------------------------------------------" >> "$LOG_FILE"

exit $RESULT
