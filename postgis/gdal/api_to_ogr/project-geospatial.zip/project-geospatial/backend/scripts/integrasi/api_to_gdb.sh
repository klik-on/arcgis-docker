#!/bin/bash
set -e

IGT_BASE="ADM_KAB_KOTA"
DATA_DIR="/app/data"

echo "🕒 Mulai proses: $(date)"

# === Gabungkan semua argumen menjadi 1 filter string ===
FILTER="${*}"

# === Jalankan Python API ke GeoJSON ===
if [ -n "$FILTER" ]; then
  echo "🚀 Menjalankan api_to_geojson.py dengan filter: \"$FILTER\""
  python3 api_to_geojson.py "$FILTER"
else
  echo "🚀 Menjalankan api_to_geojson.py dengan filter default (Kalimantan Barat)"
  python3 api_to_geojson.py
  FILTER="WADMPR=eq.Kalimantan Barat"
fi

# === Ekstrak nama wilayah dari filter ===
if [[ "$FILTER" =~ WADMPR=eq[.\ ]*([^[:space:]]+.*) ]]; then
  RAW_WILAYAH=$(echo "${BASH_REMATCH[1]}" | tr -d "'\"")
else
  RAW_WILAYAH="Kalimantan_Barat"
fi

# Format nama wilayah (hapus spasi & karakter spesial)
ALIAS=$(echo "$RAW_WILAYAH" | tr ' ' '_' | tr -cd '[:alnum:]_')
IGT="${IGT_BASE}_${ALIAS}"

# === Lokasi file ===
GEOJSON_PATH="${DATA_DIR}/${IGT}.geojson"
GDB_PATH="${DATA_DIR}/${IGT}.gdb"
ZIP_PATH="${DATA_DIR}/${IGT}.gdb.zip"

# === Cek file GeoJSON (lebih fleksibel) ===
GEOJSON_SRC=$(ls ${DATA_DIR}/${IGT_BASE}*.geojson 2>/dev/null | head -n 1)
if [ -z "$GEOJSON_SRC" ]; then
  echo "❌ File GeoJSON tidak ditemukan di ${DATA_DIR}"
  exit 1
fi

# Rename file sesuai wilayah
mv "$GEOJSON_SRC" "$GEOJSON_PATH"

# === Validasi dependencies ===
for cmd in ogr2ogr zip; do
  if ! command -v "$cmd" &> /dev/null; then
    echo "❌ Perintah '$cmd' tidak ditemukan. Pastikan sudah terinstal."
    exit 1
  fi
done

# === Atur LD_LIBRARY_PATH untuk FileGDB resmi (jika ada) ===
if [ -f "/usr/local/FileGDB_API/lib/libFileGDBAPI.so" ]; then
  export LD_LIBRARY_PATH="/usr/local/FileGDB_API/lib:${LD_LIBRARY_PATH:-}"
fi

# === Tentukan driver GDB (lebih robust) ===
if ogrinfo --formats | grep -qE "FileGDB.*\(rw\+\)"; then
  DRIVER="FileGDB"
  echo "✅ Menggunakan driver GDAL resmi FileGDB"
elif ogrinfo --formats | grep -q "OpenFileGDB"; then
  DRIVER="OpenFileGDB"
  echo "⚠️ Driver FileGDB resmi tidak ditemukan. Fallback ke OpenFileGDB (read/write terbatas)"
else
  echo "❌ Tidak ada driver GDB yang tersedia di GDAL"
  exit 1
fi

# === Konversi GeoJSON → GDB (tanpa eval, pakai array) ===
echo "🚀 Mengkonversi GeoJSON ke GDB dengan driver $DRIVER..."

# Matikan warning HTTPS di GDAL (opsional)
export CPL_LOG=OFF

# Siapkan argumen aman dalam array
OGR_ARGS=(
  -f "$DRIVER"
  "$GDB_PATH"
  "$GEOJSON_PATH"
  -dim 2
  -nln "$IGT"
  -nlt PROMOTE_TO_MULTI
  -t_srs EPSG:4326
  --config OGR_ENABLE_CURVE_REDUCTION YES
  --config OGR_ORGANIZE_POLYGONS SKIP
)

# Tambahkan overwrite bila pakai FileGDB resmi
if [ "$DRIVER" = "FileGDB" ]; then
  OGR_ARGS+=(-lco OVERWRITE=YES)
fi

ogr2ogr "${OGR_ARGS[@]}"

echo "✅ Konversi selesai. Hasil tersimpan di: $GDB_PATH"

# === Compress hasil ===
echo "📦 Membuat archive ZIP dari $GDB_PATH ..."
pushd "$DATA_DIR" > /dev/null
zip -r "$(basename "$ZIP_PATH")" "$(basename "$GDB_PATH")"
popd > /dev/null

# === Tambahkan info ukuran file ===
echo "📦 Ukuran ZIP: $(du -h "$ZIP_PATH" | cut -f1)"

# === Cleanup sementara ===
echo "🧹 Menghapus folder $GDB_PATH dan file $GEOJSON_PATH ..."
rm -rf "$GDB_PATH"
rm -f "$GEOJSON_PATH"

echo "✅ Proses selesai! File ZIP tersimpan di: $ZIP_PATH"
echo "🕒 Selesai: $(date)"
