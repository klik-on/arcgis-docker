#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import random
import pandas as pd
import geopandas as gpd
import requests
import urllib3
from datetime import datetime
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# --- 0. KONFIGURASI ENVIRONMENT & SSL ---
# Memastikan library projs/geospasial terbaca dengan benar di Docker/Linux
# os.environ['PROJ_LIB'] = '/usr/local/lib/python3.12/site-packages/pyproj/proj_dir/share/proj'
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- 1. INISIALISASI & KONFIGURASI ---
start_proc = time.time()
start_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

load_dotenv()

# Parameter Database & API dari .env
DB_URL = os.getenv("DATABASE_URL")
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
TABLE_NAME = os.getenv("KUPS_TABLE", "KUPS")
API_URL = os.getenv("KUPS_API_URL")

# Path Folder Data
FOLDER_PATH = "/app/data"
ZIP_PATH = os.path.join(FOLDER_PATH, f"{TABLE_NAME}.gdb.zip")
PROCESS_LOG = os.path.join(FOLDER_PATH, "kups_process.log")
INVALID_LOG = os.path.join(FOLDER_PATH, "invalid_kups_records.txt")

os.makedirs(FOLDER_PATH, exist_ok=True)

# Konfigurasi Logging (Terminal + File)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(PROCESS_LOG, encoding="utf-8")
    ]
)
logger = logging.getLogger("KUPS-Sync")

# --- 2. FUNGSI FETCH DATA (SMART RETRY) ---
def get_all_api_data(url):
    all_data = []
    page = 1
    session = requests.Session()
    per_page = 100

    while True:
        try:
            full_url = f"{url}?page={page}&per_page={per_page}"
            res = session.get(full_url, verify=False, timeout=60)

            if res.status_code == 429:
                wait = random.uniform(15, 30)
                logger.warning(f"⚠️ Limit 429. Menunggu {wait:.1f} detik...")
                time.sleep(wait); continue

            res.raise_for_status()
            data = res.json()
            items = data.get("data", [])

            if not items: break
            all_data.extend(items)
            logger.info(f"📄 Halaman {page} sukses. Total data sementara: {len(all_data)}")

            if not data.get("next_page_url"): break
            page += 1
            time.sleep(0.3) # Jedah halus agar tidak kena ban

        except Exception as e:
            logger.error(f"❌ Error permanen di halaman {page}: {e}")
            break
    return all_data

# --- 3. EKSEKUSI PROSES ---
logger.info(f"🚀 Memulai sinkronisasi Layer: {TABLE_NAME}")

raw_json = get_all_api_data(API_URL)
if not raw_json:
    logger.error("❌ Data API kosong. Proses dibatalkan.")
    sys.exit(1)

# Konversi ke DataFrame
df_raw = pd.DataFrame(raw_json)
total_downloaded = len(df_raw)

# Transformasi Koordinat ke Numerik
df_raw['nujur'] = pd.to_numeric(df_raw['nujur'], errors='coerce')
df_raw['lintang'] = pd.to_numeric(df_raw['lintang'], errors='coerce')

# Filter Data Valid vs Invalid
df_valid_coord = df_raw.dropna(subset=['nujur', 'lintang']).copy()
df_no_coord = df_raw[df_raw['nujur'].isna() | df_raw['lintang'].isna()].copy()

# Konversi ke GeoDataFrame (CRS WGS84)
gdf = gpd.GeoDataFrame(
    df_valid_coord,
    geometry=gpd.points_from_xy(df_valid_coord['nujur'], df_valid_coord['lintang']),
    crs="EPSG:4326"
)

# Audit Spasial (Hanya wilayah Indonesia)
mask_ri = (gdf.geometry.x >= 95.0) & (gdf.geometry.x <= 141.0) & \
          (gdf.geometry.y >= -11.0) & (gdf.geometry.y <= 6.0)

gdf_final = gdf[mask_ri].copy()
gdf_outside = gdf[~mask_ri].copy()

# Standarisasi Nama Kolom Geometri
gdf_final = gdf_final.rename_geometry('geom')

# --- 4. EXPORT DATA (POSTGIS & FILEGDB) ---
if not gdf_final.empty:
    # Uppercase untuk Atribut, lowercase untuk geom (Standar GIS)
    gdf_final.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf_final.columns]
    gdf_final = gdf_final.drop(columns=['NUJUR', 'LINTANG'], errors='ignore')

    engine = create_engine(DB_URL)

    try:
        # 4a. Persiapan Schema
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))

        # 4b. Upload ke PostGIS
        logger.info(f"🐘 Mengirim data ke PostGIS ({SCHEMA}.{TABLE_NAME})...")
        gdf_final.to_postgis(
            name=TABLE_NAME,
            con=engine,
            schema=SCHEMA,
            if_exists='replace',
            index=False
        )

        # 4c. Optimasi: Spatial Index & Vacuum
        with engine.begin() as conn:
            idx_name = f"idx_{TABLE_NAME.lower()}_geom"
            conn.execute(text(f'CREATE INDEX IF NOT EXISTS "{idx_name}" ON "{SCHEMA}"."{TABLE_NAME}" USING GIST (geom);'))
        
        with engine.connect() as conn:
            conn.execution_options(isolation_level="AUTOCOMMIT")
            conn.execute(text(f'VACUUM ANALYZE "{SCHEMA}"."{TABLE_NAME}";'))
        
        logger.info("⚡ Optimasi database selesai.")

        # 4d. Export ke FileGDB (ZIP)
        gdb_temp = os.path.join(FOLDER_PATH, f"{TABLE_NAME}_TEMP.gdb")
        if os.path.exists(gdb_temp): shutil.rmtree(gdb_temp)

        logger.info("📦 Membuat FileGDB lokal...")
        gdf_final.to_file(gdb_temp, driver="OpenFileGDB", layer=TABLE_NAME, engine='pyogrio')

        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(gdb_temp):
                for file in files:
                    arcname = os.path.join(f"{TABLE_NAME}.gdb", file)
                    z.write(os.path.join(root, file), arcname)

        shutil.rmtree(gdb_temp)
        
    except Exception as e:
        logger.error(f"❌ Kesalahan saat export: {e}")
        sys.exit(1)

# --- 5. RINGKASAN AKHIR (PENTING UNTUK FLOWER) ---
end_proc = time.time()
duration = end_proc - start_proc
minutes, seconds = divmod(duration, 60)

# Output ini yang akan muncul di kolom Result Flower
print("\n" + "="*50)
print(f"SINKRONISASI SELESAI")
print("-" * 50)
print(f"NAMA LAYER   : {TABLE_NAME}")
print(f"TOTAL API    : {total_downloaded}")
print(f"VALID (RI)   : {len(gdf_final)}")
print(f"LUAR RI      : {len(gdf_outside)}")
print(f"TANPA KOORD  : {len(df_no_coord)}")
print(f"DURASI       : {int(minutes)}m {int(seconds)}s")
print(f"DATABASE     : {SCHEMA}.{TABLE_NAME}")
print(f"FILE ZIP     : {ZIP_PATH}")
print("="*50 + "\n")
