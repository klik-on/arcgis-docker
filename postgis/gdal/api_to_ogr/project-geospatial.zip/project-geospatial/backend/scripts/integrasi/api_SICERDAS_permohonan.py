#!/usr/bin/env python3
import os
import sys
import time
import datetime
import requests
import geopandas as gpd
import pandas as pd
import urllib3
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
from shapely.geometry import Polygon, MultiPolygon

# --- 1️⃣ INISIALISASI & KONFIGURASI ---
load_dotenv()
sys.stdout.reconfigure(line_buffering=True)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE_URL = "http://172.16.2.175:8180"
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
DB_SCHEMA = os.getenv("DB_SCHEMA", "datagis")
TABLE_NAME = "PERMOHONAN_SICERDAS"

def get_bearer_token():
    auth_url = f"{BASE_URL}/api/authenticate"
    payload = {
        "username": "pdasrh_jagarimba", 
        "password": "pdasrhJagarimba123!@#", 
        "rememberMe": True
    }
    try:
        r = requests.post(auth_url, json=payload, timeout=20, verify=False)
        r.raise_for_status()
        return r.json().get("id_token")
    except Exception as e:
        print(f"❌ Auth Gagal: {e}")
        return None

def to_multi(geom):
    if geom is None:
        return None
    if isinstance(geom, Polygon):
        return MultiPolygon([geom])
    return geom

def process_layer():
    start_time = time.time()
    xlsx_path = os.path.join(DATA_DIR, f"{TABLE_NAME}_Full.xlsx")
    
    print(f"\n{'='*60}")
    print(f"🚀 PROCESSING LAYER: {TABLE_NAME}")
    print(f"{'='*60}")

    # A. Fetch Data
    token = get_bearer_token()
    if not token: return

    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
    api_url = f"{BASE_URL}/services/sipdasrh-proxy/sicerdas/permohonan"

    try:
        print(f"🔗 Calling API: {api_url}")
        r = requests.get(api_url, headers=headers, timeout=300, verify=False)
        r.raise_for_status()
        data_json = r.json()
    except Exception as e:
        print(f"❌ API Error: {e}"); return

    # B. GeoDataFrame Parsing
    print(f"📊 Parsing {len(data_json.get('features', []))} features...")
    try:
        gdf = gpd.GeoDataFrame.from_features(data_json["features"])
        if gdf.empty:
            print("⚠️ Data kosong dari API."); return
        gdf.crs = "EPSG:4326"
    except Exception as e:
        print(f"❌ Gagal membuat GeoDataFrame: {e}"); return

    # C. Normalisasi & Fix Active Geometry
    # Gunakan Upper untuk semua kolom agar konsisten
    gdf.columns = [c.replace('.', '_').upper() for c in gdf.columns]
    
    if 'GEOMETRY' in gdf.columns:
        gdf = gdf.set_geometry('GEOMETRY')
    
    geom_col = gdf.geometry.name 
    print(f"🛠️ Validasi Geometri pada kolom aktif: {geom_col}")

    gdf[geom_col] = gdf.geometry.make_valid()
    gdf[geom_col] = gdf.geometry.apply(to_multi)
    gdf = gdf[gdf[geom_col].notnull()].copy()

    # Handle tipe data object/list agar aman di DB
    for col in gdf.select_dtypes(include=['object', 'string']).columns:
        if col != geom_col:
            gdf[col] = gdf[col].apply(lambda x: str(x) if isinstance(x, (list, dict)) else x)

    # D. Database Processing
    db_url = os.getenv("DATABASE_URL")
    if db_url and "postgresql://" in db_url and "+psycopg" not in db_url:
        db_url = db_url.replace("postgresql://", "postgresql+psycopg://", 1)
    
    engine = create_engine(db_url)

    try:
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{DB_SCHEMA}"'))
            tmp_table = f"tmp_{TABLE_NAME.lower()}"
            
            print(f"💾 Menulis ke tabel temporary {DB_SCHEMA}.{tmp_table}...")
            gdf.to_postgis(tmp_table, conn, schema=DB_SCHEMA, if_exists='replace', index=False)

            # E. Finalisasi di PostGIS (Fix ID Column & GeometryCollection)
            print(f"⚙️ Memproses pembersihan Geometri & Struktur ke {TABLE_NAME}...")
            
            # Cek apakah kolom ID ada, jika tidak pakai ROW_NUMBER
            id_col_exists = "ID" in gdf.columns
            id_logic = '"ID"' if id_col_exists else 'ROW_NUMBER() OVER () as "ID"'

            sql_logic = f"""
                DROP TABLE IF EXISTS "{DB_SCHEMA}"."{TABLE_NAME}" CASCADE;
                CREATE TABLE "{DB_SCHEMA}"."{TABLE_NAME}" AS
                SELECT 
                    ST_Multi(ST_CollectionExtract("{geom_col}", 3))::geometry(MultiPolygon, 4326) as geom,
                    {id_logic if not id_col_exists else '*'}
                    {', *' if not id_col_exists else ''}
                FROM "{DB_SCHEMA}"."{tmp_table}";

                -- Jika tadi pakai *, hapus kolom geometri lama
                ALTER TABLE "{DB_SCHEMA}"."{TABLE_NAME}" DROP COLUMN IF EXISTS "{geom_col}";
                
                -- Jika kolom ID ganda karena *, hapus salah satu atau pastikan bersih
                -- Kita asumsikan ID dari API unik, jika tidak ada kita buat baru.
                ALTER TABLE "{DB_SCHEMA}"."{TABLE_NAME}" ADD PRIMARY KEY ("ID");
                
                CREATE INDEX "idx_{TABLE_NAME.lower()}_geom" ON "{DB_SCHEMA}"."{TABLE_NAME}" USING GIST (geom);
                GRANT SELECT ON TABLE "{DB_SCHEMA}"."{TABLE_NAME}" TO PUBLIC;
                DROP TABLE IF EXISTS "{DB_SCHEMA}"."{tmp_table}";
            """
            conn.execute(text(sql_logic))

        # F. Export Excel Backup
        gdf.to_excel(xlsx_path, index=False)
        
        # Summary
        duration = str(datetime.timedelta(seconds=round(time.time() - start_time)))
        print("\n" + "="*60)
        print(f"✅ INTEGRASI BERHASIL")
        print(f"📍 Tabel     : {DB_SCHEMA}.{TABLE_NAME}")
        print(f"👥 Records   : {len(gdf)}")
        print(f"⏱️  Durasi    : {duration}")
        print("="*60 + "\n")

    except Exception as e:
        print(f"❌ Database Error: {e}")

if __name__ == "__main__":
    process_layer()
