import os
import sys
import time
import zipfile
import shutil
import tempfile
import boto3
from lxml import etree
from osgeo import ogr
from sqlalchemy import create_engine, text
from botocore.client import Config
from dotenv import load_dotenv

# --- 1️⃣ INISIALISASI & ENV ---
load_dotenv()
DB_URL = os.getenv("DATABASE_URL")
DB_SCHEMA = os.getenv("DB_SCHEMA", "datagis")
S3_USER = os.getenv("S3_USER", "geobackup")
S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")
XSLT_PATH = os.getenv("XSLT_PATH", "/app/resources/metadata/Export/ISO19139_Full_Stack.xslt")

# --- 2️⃣ UTILITY S3 ---
def upload_file_to_s3(file_path, object_name):
    s3 = boto3.client('s3', endpoint_url=S3_ENDPOINT,
                      aws_access_key_id=S3_USER, aws_secret_access_key=S3_PASS,
                      config=Config(signature_version='s3v4'))
    try:
        s3.upload_file(file_path, S3_BUCKET, object_name)
        print(f"✅ S3 UPLOAD SUCCESS: {object_name}")
        return True
    except Exception as e:
        print(f"❌ S3 ERROR: {e}"); return False

# --- 3️⃣ PROSES UTAMA ---
def process_metadata(zip_input, layer_name):
    temp_dir = tempfile.mkdtemp()
    engine = create_engine(DB_URL)
    
    try:
        print(f"📦 Memproses Metadata dari: {zip_input}")
        
        # A. Ekstrak ZIP
        with zipfile.ZipFile(zip_input, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
        
        # Cari folder .gdb
        gdb_folder = next((os.path.join(root, d) for root, dirs, _ in os.walk(temp_dir) 
                          for d in dirs if d.lower().endswith(".gdb")), None)
        
        if not gdb_folder:
            raise Exception("Folder .gdb tidak ditemukan di dalam ZIP")

        # B. Ekstrak ESRI Metadata via OGR
        driver = ogr.GetDriverByName("OpenFileGDB")
        ds = driver.Open(gdb_folder, 0)
        sql = f"SELECT Documentation FROM GDB_Items WHERE Name = '{layer_name}'"
        res = ds.ExecuteSQL(sql)
        feature = res.GetNextFeature()
        
        if not feature or not feature.GetField("Documentation"):
            raise Exception(f"Metadata untuk layer '{layer_name}' tidak ditemukan di GDB_Items")
        
        esri_xml_raw = feature.GetField("Documentation")

        # C. Transformasi XSLT ke ISO 19139
        parser = etree.XMLParser(remove_blank_text=True, resolve_entities=True)
        xslt_doc = etree.parse(XSLT_PATH, parser)
        transform = etree.XSLT(xslt_doc)
        source_xml = etree.fromstring(esri_xml_raw.encode('utf-8'))
        result_xml = transform(source_xml)
        
        xml_string = etree.tostring(result_xml, encoding='unicode', pretty_print=True)
        
        # D. Simpan ke PostGIS (Tabel layer_metadata)
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{DB_SCHEMA}"'))
            conn.execute(text(f"""
                CREATE TABLE IF NOT EXISTS "{DB_SCHEMA}"."layer_metadata" (
                    layer_name VARCHAR(255) PRIMARY KEY,
                    metadata_iso XML,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """))
            
            conn.execute(text(f"""
                INSERT INTO "{DB_SCHEMA}"."layer_metadata" (layer_name, metadata_iso)
                VALUES (:name, :xml)
                ON CONFLICT (layer_name) DO UPDATE 
                SET metadata_iso = EXCLUDED.metadata_iso, updated_at = CURRENT_TIMESTAMP;
            """), {"name": layer_name, "xml": xml_string})
            print(f"🗄️ Metadata '{layer_name}' berhasil disimpan di PostGIS.")

        # E. Simpan XML lokal & Upload ke Minio S3
        xml_filename = f"{layer_name}_metadata_iso.xml"
        xml_temp_path = os.path.join(temp_dir, xml_filename)
        with open(xml_temp_path, "w") as f:
            f.write(xml_string)
            
        upload_file_to_s3(xml_temp_path, f"metadata/{xml_filename}")

    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
    finally:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
            print("🧹 Cleanup temporary files.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path ke file .gdb.zip")
    parser.add_argument("--layer", required=True, help="Nama layer dalam GDB")
    
    args = parser.parse_args()
    process_metadata(args.input, args.layer)
