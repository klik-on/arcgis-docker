import requests
import os
import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# 1. Load Konfigurasi .env
load_dotenv()

# Konfigurasi API dari .env
BASE_URL = os.getenv("SIGAP_URL")
USERNAME = os.getenv("SIGAP_USER")
PASSWORD = os.getenv("SIGAP_PASS")

# Konfigurasi Database dari .env
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
SCHEMA  = os.getenv("OUT_SCHEMA", "analisis")
TABLE_NAME = "list_TK_data_produsen"

def get_data():
    """Mengambil data dari API SIGAP"""
    print(f"🔑 Melakukan login ke {BASE_URL}...")
    login_url = f"{BASE_URL}/api/auth/signin"
    payload = {"username": USERNAME, "password": PASSWORD}
    
    res = requests.post(login_url, json=payload)
    res.raise_for_status()
    token = res.json().get("accessToken")

    print("📡 Menarik data produsen...")
    data_url = f"{BASE_URL}/api/data-produsen/"
    headers = {"x-access-token": token}
    res_data = requests.get(data_url, headers=headers)
    res_data.raise_for_status()
    return res_data.json()

def flatten_dict(d, parent_key="", sep="_"):
    """Meratakan struktur JSON nested"""
    flat = {}
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            flat.update(flatten_dict(v, new_key, sep=sep))
        elif isinstance(v, list):
            flat[new_key] = ", ".join(str(i) for i in v)
        else:
            flat[new_key] = v
    return flat

if __name__ == "__main__":
    try:
        # Step 1: Ambil dan Olah Data
        raw_data = get_data()
        flat_list = [flatten_dict(item) for item in raw_data]
        df = pd.DataFrame(flat_list)
        
        print(f"📊 Total record yang didapat: {len(df)}")

        # Step 2: Koneksi Database menggunakan Driver Psycopg 3 (sesuai sys info Anda)
        # Format: postgresql+psycopg://user:pass@host:port/dbname
        connection_uri = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        engine = create_engine(connection_uri)

        # Step 3: Pastikan Schema Tersedia
        with engine.connect() as conn:
            print(f"🛠️ Memastikan skema '{SCHEMA}' tersedia...")
            conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA};"))
            conn.commit()

        # Step 4: Simpan ke PostGIS
        print(f"🚀 Menulis ke tabel {SCHEMA}.{TABLE_NAME}...")
        # 'replace' akan menghapus tabel lama dan membuat baru dengan struktur terbaru dari API
        df.to_sql(
            TABLE_NAME, 
            engine, 
            schema=SCHEMA, 
            if_exists='replace', 
            index=False,
            chunksize=500
        )

        print(f"✅ Selesai! Data berhasil diperbarui di database {DB_HOST}.")

    except Exception as e:
        print(f"❌ Terjadi kesalahan: {e}")
