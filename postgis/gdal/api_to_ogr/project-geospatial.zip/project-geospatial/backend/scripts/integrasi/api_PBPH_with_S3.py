import os
import sys
import time
import datetime
import shutil
import requests
import pyproj
import boto3
import pandas as pd
import geopandas as gpd
import warnings
import shapely
from sqlalchemy import create_engine, text
from botocore.client import Config
from shapely.geometry import MultiPolygon, Polygon

# docker exec -it geo-api python3 scripts/integrasi/api_PBPH_with_S3.py

# --- 1️⃣ INISIALISASI ---
warnings.filterwarnings("ignore", category=RuntimeWarning, module="pyogrio")

OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)

# --- 2️⃣ KONFIGURASI ---
IGT = os.getenv("IGT", "PERSETUJUAN_KOMITMEN_PBPH")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
DB_URL = os.getenv("DATABASE_URL")
DB_SCHEMA = os.getenv("DB_SCHEMA", "datagis")

S3_USER = os.getenv("S3_USER", "geobackup")
S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")

# --- 3️⃣ UTILITY ---
def upload_to_s3(file_path, object_name):
    s3 = boto3.client('s3', endpoint_url=S3_ENDPOINT,
                      aws_access_key_id=S3_USER, aws_secret_access_key=S3_PASS,
                      config=Config(signature_version='s3v4'))
    try:
        s3.upload_file(file_path, S3_BUCKET, object_name)
        return True
    except Exception as e:
        print(f"❌ S3 ERROR: {e}"); return False

def force_multipolygon(geom):
    if geom is None or geom.is_empty: return None
    if isinstance(geom, Polygon):
        return MultiPolygon([geom])
    elif isinstance(geom, MultiPolygon):
        return geom
    return None

# --- 4️⃣ PROSES UTAMA ---
def run_process():
    start_time = time.time()
    TABLE_NAME = IGT.upper()
    print(f"🚀 Integrasi PBPH v2.1 (Dissolve Mode & Auto-CRS)")

    # A. Fetch API & Auto-Detect CRS
    try:
        auth = (os.getenv("PBPH_USER"), os.getenv("PBPH_PASS"))
        api_url = f"https://phl.kehutanan.go.id/api/v1/{IGT}?select=*"
        with requests.get(api_url, auth=auth, timeout=120) as r:
            r.raise_for_status()
            data = r.json().get("data", [])

        if not data:
            print("⚠️ API Kosong. Menghentikan proses."); return

        df = pd.DataFrame(data)
        geom_series = gpd.GeoSeries.from_wkb(df.pop('geom').apply(lambda x: bytes.fromhex(x)))
        gdf = gpd.GeoDataFrame(df, geometry=geom_series)

        # LOGIKA AUTO-DETEKSI CRS
        sample_x = gdf.geometry.iloc[0].centroid.x
        if abs(sample_x) <= 180:
            print(f"🛰️ DETEKSI: Koordinat DERAJAT ({sample_x:.4f}). Set EPSG:4326")
            gdf.crs = "EPSG:4326"
        else:
            print(f"📏 DETEKSI: Koordinat METER ({sample_x:.2f}). Set EPSG:3857 -> Transform to 4326")
            gdf.crs = "EPSG:3857"
            gdf = gdf.to_crs("EPSG:4326")

    except Exception as e:
        print(f"❌ Fetch/Detection Error: {e}"); sys.exit(1)

    # B. Pre-processing Geometri & Dissolve
    print("🛠️ Membersihkan geometri & standarisasi kolom...")
    gdf['geometry'] = shapely.force_2d(shapely.make_valid(gdf['geometry']))
    gdf.columns = [c.upper() if c.lower() != 'geometry' else 'geometry' for c in gdf.columns]

    # --- LOGIKA DISSOLVE BERDASARKAN SEMUA FIELD ---
    print("🧩 Menjalankan Dissolve berdasarkan semua field atribut...")
    dissolve_fields = [col for col in gdf.columns if col != 'geometry']
    gdf = gdf.dissolve(by=dissolve_fields, as_index=False)

    # C. Database Processing (PostGIS)
    engine = create_engine(DB_URL)
    try:
        with engine.begin() as conn:
            # --- CEK & BUAT SCHEMA JIKA BELUM ADA ---
            print(f"🛠️ Memastikan schema '{DB_SCHEMA}' tersedia...")
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{DB_SCHEMA}"'))

            print(f"🗑️ Menghapus tabel lama jika ada...")
            conn.execute(text(f'DROP TABLE IF EXISTS "{DB_SCHEMA}"."{TABLE_NAME}" CASCADE'))

            # Load data ke PostGIS (EPSG:4326)
            print(f"📤 Menulis data ke tabel {DB_SCHEMA}.{TABLE_NAME}...")
            gdf.to_postgis(TABLE_NAME, conn, schema=DB_SCHEMA, index=False, chunksize=1000)

            # Post-Processing di SQL: Paksa MultiPolygon & Hitung Luas
            print("📐 Post-processing di Database (SRID 54034)...")
            sql_logic = f"""
                UPDATE "{DB_SCHEMA}"."{TABLE_NAME}"
                SET geometry = ST_Multi(ST_CollectionExtract(ST_MakeValid(geometry), 3));

                ALTER TABLE "{DB_SCHEMA}"."{TABLE_NAME}" ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;

                UPDATE "{DB_SCHEMA}"."{TABLE_NAME}"
                SET "LUAS_CEA_HA" = ST_Area(ST_Transform(geometry, 54034)) / 10000;
            """
            conn.execute(text(sql_logic))

            conn.execute(text(f"SELECT UpdateGeometrySRID('{DB_SCHEMA}', '{TABLE_NAME}', 'geometry', 4326)"))
            conn.execute(text(f'CREATE INDEX IF NOT EXISTS "idx_{TABLE_NAME.lower()}_geom" ON "{DB_SCHEMA}"."{TABLE_NAME}" USING GIST (geometry)'))
            conn.execute(text(f'ANALYZE "{DB_SCHEMA}"."{TABLE_NAME}"'))

        # Tarik data final untuk GDB
        gdf_final = gpd.read_postgis(f'SELECT * FROM "{DB_SCHEMA}"."{TABLE_NAME}"', engine, geom_col='geometry')
    except Exception as e:
        print(f"❌ Database Error: {e}"); sys.exit(1)

    # D. Export FileGeodatabase
    gdb_folder = f"{TABLE_NAME}.gdb"
    full_gdb_path = os.path.join(DATA_DIR, gdb_folder)
    zip_base = os.path.join(DATA_DIR, TABLE_NAME)

    print(f"📦 Menulis GDB (EPSG:4326)...")
    if os.path.exists(full_gdb_path): shutil.rmtree(full_gdb_path)

    # Standarisasi tipe geometri untuk driver OpenFileGDB
    gdf_final = gdf_final.explode(index_parts=False)
    gdf_final['geometry'] = gdf_final['geometry'].apply(force_multipolygon)
    gdf_final = gdf_final[gdf_final.geometry.notnull()].copy()

    try:
        gdf_final.to_file(
            full_gdb_path,
            driver="OpenFileGDB",
            engine="pyogrio",
            layer_options={
                "TARGET_ARCGIS_VERSION": "ARCGIS_PRO_3_2_OR_LATER",
                "COLUMN_TYPES": "INT64"
            }
        )
    except Exception as e:
        print(f"❌ GDB Write Error: {e}"); sys.exit(1)

    # Zipping
    shutil.make_archive(zip_base, 'zip', DATA_DIR, gdb_folder)
    final_zip = f"{zip_base}.zip"

    # E. S3 Upload & Reporting
    report_path = os.path.join(DATA_DIR, f"SUMMARY_{TABLE_NAME}.txt")
    with open(report_path, "w") as f:
        f.write(f"SUMMARY INTEGRASI: {TABLE_NAME}\n" + "="*40 + "\n")
        f.write(f"Waktu Selesai  : {datetime.datetime.now()}\n")
        f.write(f"Total Fitur    : {len(gdf_final)}\n")
        f.write(f"Total Luas (Ha): {gdf_final['LUAS_CEA_HA'].sum():,.2f}\n")
        f.write(f"CRS Output     : EPSG:4326\n")

    upload_to_s3(final_zip, f"{TABLE_NAME}.gdb.zip")
    upload_to_s3(report_path, f"reports/{datetime.date.today()}/SUMMARY_{TABLE_NAME}.txt")

    # F. Cleanup
    for p in [full_gdb_path, final_zip, report_path]:
        if os.path.isdir(p): shutil.rmtree(p)
        elif os.path.exists(p): os.remove(p)

    print(f"✅ INTEGRASI BERHASIL | Durasi: {time.time() - start_time:.2f} detik.")

if __name__ == "__main__":
    run_process()
