#!/usr/bin/env python3
import os
import sys
import time
import datetime
import shutil
import requests
import pyproj
import boto3
import pandas as pd
import geopandas as gpd
import warnings
import shapely
import urllib3
import random
from sqlalchemy import create_engine, text
from botocore.client import Config
from shapely.geometry import MultiPolygon, Polygon
from dotenv import load_dotenv
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- 1️⃣ INISIALISASI & TUNING STREAMING ---
# Memaksa log agar langsung muncul di Dashboard API tanpa delay
sys.stdout.reconfigure(line_buffering=True)
os.environ['OGR_ORGANIZE_POLYGONS'] = 'SKIP'
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning, module="pyogrio")
load_dotenv()

OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)

# --- 2️⃣ KONFIGURASI ---
PBPH_API_URL = os.getenv("PBPH_API_URL", "https://phl.kehutanan.go.id/api/v1/")
IGT = os.getenv("IGT", "PERSETUJUAN_KOMITMEN_PBPH")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
DB_URL = os.getenv("DATABASE_URL")
DB_SCHEMA = os.getenv("DB_SCHEMA", "datagis")

S3_USER = os.getenv("S3_USER", "geobackup")
S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")

# --- 3️⃣ UTILITY ---
def upload_to_s3(file_path, object_name):
    s3 = boto3.client('s3', endpoint_url=S3_ENDPOINT,
                      aws_access_key_id=S3_USER, aws_secret_access_key=S3_PASS,
                      config=Config(signature_version='s3v4'))
    try:
        s3.upload_file(file_path, S3_BUCKET, object_name)
        print(f"✅ S3 UPLOAD SUCCESS: {object_name}")
        return True
    except Exception as e:
        print(f"❌ S3 ERROR: {e}"); return False

def force_multipolygon(geom):
    if geom is None or geom.is_empty: return None
    if isinstance(geom, Polygon):
        return MultiPolygon([geom])
    elif isinstance(geom, MultiPolygon):
        return geom
    return None

# --- 4️⃣ PROSES UTAMA ---
def run_process():
    start_time = time.time()
    TABLE_NAME = IGT.upper()
    TS_SUFFIX = int(time.time())
    UNIQUE_TEMP = f"tmp_{TABLE_NAME.lower()}_{TS_SUFFIX}"

    print(f"🚀 Integrasi PBPH v2.8 (Robust & Streaming Mode)")

    # A. Fetch API dengan Retry Logic (FIX DNS/TIMEOUT ISSUE)
    data = []
    auth = (os.getenv("PBPH_USER"), os.getenv("PBPH_PASS"))
    api_url = f"{PBPH_API_URL.rstrip('/')}/{IGT}?select=*"

    session = requests.Session()
    # Strategi Retry: 5 kali percobaan jika gagal koneksi/DNS
    retries = Retry(total=5, backoff_factor=3, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))

    try:
        print(f"🔗 Calling API: {api_url}")
        # Tambahkan timeout agar tidak menggantung selamanya
        with session.get(api_url, auth=auth, timeout=300, verify=False) as r:
            r.raise_for_status()
            data = r.json().get("data", [])
    except Exception as e:
        print(f"❌ API Fatal Error: {e}")
        sys.exit(1)

    if not data:
        print("⚠️ API Kosong. Proses dihentikan."); return

    # B. Processing GeoDataFrame
    print(f"📊 Mengolah {len(data)} record...")
    df = pd.DataFrame(data)
    
    # Konversi WKB ke Geometry
    geom_series = gpd.GeoSeries.from_wkb(df.pop('geom').apply(lambda x: bytes.fromhex(x)))
    gdf = gpd.GeoDataFrame(df, geometry=geom_series)

    # Auto-detection CRS
    sample_geom = gdf.geometry.iloc[0]
    sample_x = sample_geom.centroid.x if not sample_geom.is_empty else 110
    gdf.crs = "EPSG:4326" if abs(sample_x) <= 180 else "EPSG:3857"
    if gdf.crs == "EPSG:3857": 
        print("🌍 Proyeksi terdeteksi 3857, re-projecting ke 4326...")
        gdf = gdf.to_crs("EPSG:4326")

    print("🛠️ Validasi Geometri & Transformasi...")
    gdf['geometry'] = shapely.force_2d(shapely.make_valid(gdf['geometry']))
    gdf.columns = [c.upper() if c.lower() != 'geometry' else 'geometry' for c in gdf.columns]

    print("🧩 Dissolving features...")
    dissolve_fields = [col for col in gdf.columns if col != 'geometry']
    gdf = gdf.dissolve(by=dissolve_fields, as_index=False)

    # C. Database Processing (PostGIS)
    engine = create_engine(DB_URL)
    try:
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{DB_SCHEMA}"'))

            print(f"📤 Menulis ke tabel unik: {UNIQUE_TEMP}...")
            gdf.to_postgis(UNIQUE_TEMP, conn, schema=DB_SCHEMA, if_exists='replace', index=False)

            print("📐 Post-processing & Atomic Swap...")
            sql_logic = f"""
                -- 1. Pastikan Geometri Valid & MultiPolygon
                UPDATE "{DB_SCHEMA}"."{UNIQUE_TEMP}"
                SET geometry = ST_Multi(ST_CollectionExtract(ST_MakeValid(geometry), 3));

                -- 2. Kalkulasi Luas (Cylindrical Equal Area)
                ALTER TABLE "{DB_SCHEMA}"."{UNIQUE_TEMP}" ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;
                UPDATE "{DB_SCHEMA}"."{UNIQUE_TEMP}"
                SET "LUAS_CEA_HA" = ST_Area(ST_Transform(geometry, 54034)) / 10000;

                -- 3. SWAP TABLE (Atomic)
                DROP TABLE IF EXISTS "{DB_SCHEMA}"."{TABLE_NAME}" CASCADE;
                ALTER TABLE "{DB_SCHEMA}"."{UNIQUE_TEMP}" RENAME TO "{TABLE_NAME}";

                -- 4. Re-Index
                DROP INDEX IF EXISTS "{DB_SCHEMA}"."idx_{TABLE_NAME.lower()}_geom";
                
                DO $$
                DECLARE auto_idx_name TEXT;
                BEGIN
                    SELECT indexname INTO auto_idx_name FROM pg_indexes 
                    WHERE schemaname = '{DB_SCHEMA}' AND tablename = '{TABLE_NAME}';
                    IF auto_idx_name IS NOT NULL THEN
                        EXECUTE 'ALTER INDEX "{DB_SCHEMA}"."' || auto_idx_name || '" RENAME TO "idx_{TABLE_NAME.lower()}_geom"';
                    END IF;
                END $$;

                GRANT SELECT ON TABLE "{DB_SCHEMA}"."{TABLE_NAME}" TO PUBLIC;
            """
            conn.execute(text(sql_logic))

        print("🔄 Membaca kembali data untuk export...")
        gdf_final = gpd.read_postgis(f'SELECT * FROM "{DB_SCHEMA}"."{TABLE_NAME}"', engine, geom_col='geometry')
    except Exception as e:
        print(f"❌ Database Error: {e}"); sys.exit(1)

    # D. Export & S3
    gdb_folder = f"{TABLE_NAME}.gdb"
    full_gdb_path = os.path.join(DATA_DIR, gdb_folder)
    zip_base = os.path.join(DATA_DIR, TABLE_NAME)

    if os.path.exists(full_gdb_path): shutil.rmtree(full_gdb_path)
    gdf_final = gdf_final.explode(index_parts=False)
    gdf_final['geometry'] = gdf_final['geometry'].apply(force_multipolygon)

    try:
        print(f"📦 Exporting ke FileGDB...")
        gdf_final.to_file(full_gdb_path, driver="OpenFileGDB", engine="pyogrio")
        shutil.make_archive(zip_base, 'zip', DATA_DIR, gdb_folder)
        upload_to_s3(f"{zip_base}.zip", f"{TABLE_NAME}.gdb.zip")
    except Exception as e:
        print(f"❌ Export/S3 Error: {e}"); sys.exit(1)

    # F. Cleanup
    for p in [full_gdb_path, f"{zip_base}.zip"]:
        if os.path.isdir(p): shutil.rmtree(p)
        elif os.path.exists(p): os.remove(p)

    duration = time.time() - start_time
    print(f"\n{'='*55}\n✅ PBPH SINKRONISASI SELESAI | Durasi: {duration:.2f}s\n{'='*55}\n")

if __name__ == "__main__":
    run_process()
