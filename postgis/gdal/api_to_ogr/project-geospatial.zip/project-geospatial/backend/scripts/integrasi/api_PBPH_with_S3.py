#!/usr/bin/env python3
import os
import sys
import time
import shutil
import requests
import pyproj
import boto3
import pandas as pd
import geopandas as gpd
import warnings
import shapely
import urllib3
import zipfile
from sqlalchemy import create_engine, text, Integer
from botocore.client import Config
from shapely.geometry import MultiPolygon, Polygon
from dotenv import load_dotenv
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- 1️⃣ INISIALISASI ---
sys.stdout.reconfigure(line_buffering=True)
os.environ['OGR_ORGANIZE_POLYGONS'] = 'SKIP'
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning, module="pyogrio")
load_dotenv()

OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)

# --- 2️⃣ KONFIGURASI ---
PBPH_API_URL = os.getenv("PBPH_API_URL", "https://phl.kehutanan.go.id/api/v1/")
IGT = os.getenv("IGT", "PERSETUJUAN_KOMITMEN_PBPH")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
DB_URL = os.getenv("DATABASE_URL")
DB_SCHEMA = os.getenv("DB_SCHEMA", "datagis")

S3_USER = os.getenv("S3_USER", "geobackup")
S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")

# --- 3️⃣ UTILITY ---
def upload_to_s3(file_path, object_name):
    s3 = boto3.client('s3', endpoint_url=S3_ENDPOINT,
                      aws_access_key_id=S3_USER, aws_secret_access_key=S3_PASS,
                      config=Config(signature_version='s3v4'))
    try:
        s3.upload_file(file_path, S3_BUCKET, object_name)
        print(f"✅ S3 UPLOAD SUCCESS: {object_name}")
        return True
    except Exception as e:
        print(f"❌ S3 ERROR: {e}"); return False

# --- 4️⃣ PROSES UTAMA ---
def run_process():
    start_time = time.time()
    TABLE_NAME = IGT.upper()
    TS_SUFFIX = int(time.time())
    UNIQUE_TEMP = f"tmp_{TABLE_NAME.lower()}_{TS_SUFFIX}"

    print(f"🚀 Integrasi PBPH v3.6 (Smart CRS Auto-Detection)")

    # A. Fetch API
    data = []
    auth = (os.getenv("PBPH_USER"), os.getenv("PBPH_PASS"))
    api_url = f"{PBPH_API_URL.rstrip('/')}/{IGT}?select=*"

    session = requests.Session()
    retries = Retry(total=5, backoff_factor=3, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))

    try:
        print(f"🔗 Calling API: {api_url}")
        with session.get(api_url, auth=auth, timeout=300, verify=False) as r:
            r.raise_for_status()
            res_json = r.json()
            data = res_json.get("data", []) if isinstance(res_json, dict) else res_json
    except Exception as e:
        print(f"❌ API Fatal Error: {e}"); sys.exit(1)

    if not data:
        print("⚠️ API Kosong. Proses dihentikan."); return

    # B. Processing GeoDataFrame
    print(f"📊 Mengolah {len(data)} record...")
    df = pd.DataFrame(data)
    geom_series = gpd.GeoSeries.from_wkb(df.pop('geom').apply(lambda x: bytes.fromhex(x)))
    gdf = gpd.GeoDataFrame(df, geometry=geom_series)
    
    # --- SMART CRS DETECTION ---
    max_val = gdf.geometry.bounds.maxx.max()
    if max_val > 200: # Jika lebih dari 200, hampir pasti ini Meter (Web Mercator)
        print("🌍 Detected: PROJECTED CRS (EPSG:3857). Normalizing to WGS84...")
        gdf.crs = "EPSG:3857"
        gdf = gdf.to_crs("EPSG:4326")
    else:
        print("📍 Detected: GEOGRAPHIC CRS (EPSG:4326).")
        gdf.crs = "EPSG:4326"

    print("🛠️ Validasi Geometri & Standarisasi...")
    gdf['geometry'] = shapely.force_2d(shapely.make_valid(gdf['geometry']))
    gdf = gdf.reset_index(drop=True)
    gdf.insert(0, 'id_gid', gdf.index + 1)
    gdf.columns = [c.upper() for c in gdf.columns]
    gdf = gdf.set_geometry('GEOMETRY')
    gdf = gdf.rename_geometry('geom')

    # C. Database Processing
    engine = create_engine(DB_URL)
    try:
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{DB_SCHEMA}"'))
            print(f"📤 Menulis ke tabel unik: {UNIQUE_TEMP}...")
            gdf.to_postgis(UNIQUE_TEMP, conn, schema=DB_SCHEMA, if_exists='replace', index=False, dtype={"ID_GID": Integer()})

            print("📐 Post-processing (CEA Calculation) & Atomic Swap...")
            sql_logic = f"""
                UPDATE "{DB_SCHEMA}"."{UNIQUE_TEMP}"
                SET geom = ST_Multi(ST_CollectionExtract(ST_MakeValid(geom), 3))
                WHERE geom IS NOT NULL;

                ALTER TABLE "{DB_SCHEMA}"."{UNIQUE_TEMP}" ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;
                UPDATE "{DB_SCHEMA}"."{UNIQUE_TEMP}"
                SET "LUAS_CEA_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000
                WHERE geom IS NOT NULL AND ST_IsValid(geom) AND NOT ST_IsEmpty(geom)
                  AND ST_XMin(geom) >= -180 AND ST_XMax(geom) <= 180;

                DROP TABLE IF EXISTS "{DB_SCHEMA}"."{TABLE_NAME}" CASCADE;
                ALTER TABLE "{DB_SCHEMA}"."{UNIQUE_TEMP}" RENAME TO "{TABLE_NAME}";
                ALTER TABLE "{DB_SCHEMA}"."{TABLE_NAME}" ADD PRIMARY KEY ("ID_GID");
                CREATE INDEX "idx_{TABLE_NAME.lower()}_geom" ON "{DB_SCHEMA}"."{TABLE_NAME}" USING GIST (geom);
                GRANT SELECT ON TABLE "{DB_SCHEMA}"."{TABLE_NAME}" TO PUBLIC;
            """
            conn.execute(text(sql_logic))

        print("🔄 Membaca kembali data untuk export...")
        gdf_final = gpd.read_postgis(f'SELECT * FROM "{DB_SCHEMA}"."{TABLE_NAME}"', engine, geom_col='geom')
    except Exception as e:
        print(f"❌ Database Error: {e}"); sys.exit(1)

    # D. Export FileGDB & S3
    gdb_name = f"{TABLE_NAME}.gdb"
    gdb_path = os.path.join(DATA_DIR, gdb_name)
    zip_path = os.path.join(DATA_DIR, f"{gdb_name}.zip")

    if os.path.exists(gdb_path): shutil.rmtree(gdb_path)

    try:
        # Sanitasi Akhir
        gdf_final = gdf_final[gdf_final.geom.is_valid & ~gdf_final.geom.is_empty].copy()
        
        print(f"📦 Exporting {len(gdf_final)} record ke FileGDB...")
        gdf_final.to_file(
            gdb_path,
            driver="OpenFileGDB",
            layer=TABLE_NAME,
            engine='pyogrio',
            layer_options={'TARGET_ARCGIS_VERSION': 'ARCGIS_PRO_3_2_OR_LATER'}
        )

        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(gdb_path):
                for file in files:
                    z.write(os.path.join(root, file), os.path.join(gdb_name, file))

        upload_to_s3(zip_path, f"{gdb_name}.zip")
    except Exception as e:
        print(f"❌ Export/S3 Error: {e}"); sys.exit(1)

    # F. Cleanup
    if os.path.exists(gdb_path): shutil.rmtree(gdb_path)
    if os.path.exists(zip_path): os.remove(zip_path)

    duration = time.time() - start_time
    print(f"\n{'='*55}\n✅ PBPH SINKRONISASI SELESAI | Layer: {TABLE_NAME} | Durasi: {duration:.2f}s\n{'='*55}\n")

if __name__ == "__main__":
    run_process()
