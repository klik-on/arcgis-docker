#!/usr/bin/env python3
import os
import sys
import time
import datetime
import shutil
import requests
import pyproj
import boto3
import pandas as pd
import geopandas as gpd
import warnings
import shapely
import urllib3
import zipfile
from sqlalchemy import create_engine, text, URL
from botocore.client import Config
from shapely.geometry import MultiPolygon, Polygon, GeometryCollection
from dotenv import load_dotenv
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- 1️⃣ INISIALISASI & GLOBAL CONFIG ---
load_dotenv()
sys.stdout.reconfigure(line_buffering=True)
os.environ['OGR_ORGANIZE_POLYGONS'] = 'SKIP'
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning, module="pyogrio")
warnings.filterwarnings("ignore", category=UserWarning, module="pyogrio")

# Bounding Box Indonesia (Strict Filter)
INDONESIA_BOUNDS = {"xmin": 94.0, "ymin": -12.0, "xmax": 142.0, "ymax": 8.0}

OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)

# Config dari ENV
PBPH_API_URL = os.getenv("PBPH_API_URL", "https://phl.kehutanan.go.id/api/v1/")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
DB_SCHEMA = os.getenv("DB_SCHEMA", "datagis")
S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

# --- 2️⃣ UTILITY ---
def get_s3_client():
    return boto3.client('s3', endpoint_url=S3_ENDPOINT,
                        aws_access_key_id=S3_USER, aws_secret_access_key=S3_PASS,
                        config=Config(signature_version='s3v4'), verify=False)

def force_to_multipolygon(geom):
    """Shield untuk FileGDB: Memastikan output hanya MultiPolygon."""
    if geom is None or geom.is_empty: return None
    if isinstance(geom, GeometryCollection):
        polys = [g for g in geom.geoms if isinstance(g, (Polygon, MultiPolygon))]
        if not polys: return None
        from shapely.ops import unary_union
        geom = unary_union(polys)
    if isinstance(geom, Polygon): return MultiPolygon([geom])
    if isinstance(geom, MultiPolygon): return geom
    return None

# --- 3️⃣ LOGIKA PER LAYER ---
def process_layer(igt_name):
    start_time = time.time()
    TABLE_NAME = igt_name.upper().strip()
    
    # Init Paths
    xlsx_path = os.path.join(DATA_DIR, f"{TABLE_NAME}_Full.xlsx")
    gdb_path = os.path.join(DATA_DIR, f"{TABLE_NAME}.gdb")
    zip_path = f"{gdb_path}.zip"

    print(f"\n{'='*60}\n🚀 PROCESSING LAYER: {TABLE_NAME}\n{'='*60}")

    # A. Fetch API
    auth = (os.getenv("PBPH_USER"), os.getenv("PBPH_PASS"))
    api_url = f"{PBPH_API_URL.rstrip('/')}/{igt_name}?select=*"
    
    session = requests.Session()
    retries = Retry(total=5, backoff_factor=3, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))

    try:
        print(f"🔗 Calling API: {api_url}")
        with session.get(api_url, auth=auth, timeout=300, verify=False) as r:
            r.raise_for_status()
            data_raw = r.json().get("data", []) if isinstance(r.json(), dict) else r.json()
    except Exception as e:
        print(f"❌ API Fatal Error for {TABLE_NAME}: {e}"); return

    if not data_raw:
        print(f"⚠️ API {TABLE_NAME} Kosong. Skip..."); return

    # B. GeoDataFrame Processing
    print(f"📊 Mengolah {len(data_raw)} record...")
    df = pd.DataFrame(data_raw)
    geom_series = gpd.GeoSeries.from_wkb(df.pop('geom').apply(lambda x: bytes.fromhex(x)))
    gdf = gpd.GeoDataFrame(df, geometry=geom_series)

    # CRS Normalization
    if gdf.geometry.bounds.maxx.max() > 200:
        gdf.crs = "EPSG:3857"
        gdf = gdf.to_crs("EPSG:4326")
    else:
        gdf.crs = "EPSG:4326"

    # Strict BBOX Filter Indonesia
    gdf = gdf.cx[INDONESIA_BOUNDS['xmin']:INDONESIA_BOUNDS['xmax'], 
                 INDONESIA_BOUNDS['ymin']:INDONESIA_BOUNDS['ymax']].copy()

    print("🛠️ Validasi Geometri & Homogenasi MultiPolygon...")
    gdf['geometry'] = shapely.force_2d(shapely.make_valid(gdf['geometry']))
    gdf['geometry'] = gdf['geometry'].apply(force_to_multipolygon)
    gdf = gdf.dropna(subset=['geometry']).copy()

    # Standardize
    gdf = gdf.reset_index(drop=True)
    gdf.insert(0, 'id_gid', gdf.index + 1)
    gdf.columns = [c.upper() for c in gdf.columns]
    gdf = gdf.set_geometry('GEOMETRY')
    gdf = gdf.rename_geometry('geom')

    # C. Database Processing
    db_url = os.getenv("DATABASE_URL")
    if db_url and "postgresql://" in db_url and "+psycopg" not in db_url:
        db_url = db_url.replace("postgresql://", "postgresql+psycopg://", 1)
    engine = create_engine(db_url)

    try:
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{DB_SCHEMA}"'))
            tmp_table = f"tmp_{TABLE_NAME.lower()}"
            gdf.to_postgis(tmp_table, conn, schema=DB_SCHEMA, if_exists='replace', index=False)

            # Fix Duplicate 'geom' columns by explicit selection
            col_query = f"SELECT column_name FROM information_schema.columns WHERE table_schema = '{DB_SCHEMA}' AND table_name = '{tmp_table}' AND column_name != 'geom'"
            cols = [f'"{row[0]}"' for row in conn.execute(text(col_query))]
            cols_str = ", ".join(cols)

            sql_logic = f"""
                DROP TABLE IF EXISTS "{DB_SCHEMA}"."{TABLE_NAME}" CASCADE;
                CREATE TABLE "{DB_SCHEMA}"."{TABLE_NAME}" AS
                SELECT ST_Multi(ST_CollectionExtract(geom, 3))::geometry(MultiPolygon, 4326) as geom, {cols_str}
                FROM "{DB_SCHEMA}"."{tmp_table}"
                WHERE ST_Intersects(geom, ST_MakeEnvelope({INDONESIA_BOUNDS['xmin']}, {INDONESIA_BOUNDS['ymin']}, {INDONESIA_BOUNDS['xmax']}, {INDONESIA_BOUNDS['ymax']}, 4326));

                ALTER TABLE "{DB_SCHEMA}"."{TABLE_NAME}" ADD COLUMN IF NOT EXISTS "LUAS_CEA_HA" DOUBLE PRECISION;
                UPDATE "{DB_SCHEMA}"."{TABLE_NAME}" SET "LUAS_CEA_HA" = ST_Area(ST_Transform(geom, 54034)) / 10000;
                ALTER TABLE "{DB_SCHEMA}"."{TABLE_NAME}" ADD PRIMARY KEY ("ID_GID");
                CREATE INDEX "idx_{TABLE_NAME.lower()}_geom" ON "{DB_SCHEMA}"."{TABLE_NAME}" USING GIST (geom);
                GRANT SELECT ON TABLE "{DB_SCHEMA}"."{TABLE_NAME}" TO PUBLIC;
                DROP TABLE IF EXISTS "{DB_SCHEMA}"."{tmp_table}";
            """
            conn.execute(text(sql_logic))

        print("🔄 Exporting & Uploading S3...")
        gdf_final = gpd.read_postgis(f'SELECT * FROM "{DB_SCHEMA}"."{TABLE_NAME}"', engine, geom_col='geom')
        
        # Files Export
        gdf_final.drop(columns='geom').to_excel(xlsx_path, index=False)
        if os.path.exists(gdb_path): shutil.rmtree(gdb_path)
        gdf_final.to_file(gdb_path, driver="OpenFileGDB", layer=TABLE_NAME, engine='pyogrio',
                         layer_options={'TARGET_ARCGIS_VERSION': 'ARCGIS_PRO_3_2_OR_LATER'})

        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(gdb_path):
                for file in files:
                    z.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), os.path.dirname(gdb_path)))

        # S3 Versioning
        s3 = get_s3_client()
        s3_prefix = f"integrasi/PBPH/{datetime.date.today().isoformat()}"
        s3.upload_file(xlsx_path, S3_BUCKET, f"{s3_prefix}/{TABLE_NAME}_Full.xlsx")
        s3.upload_file(zip_path, S3_BUCKET, f"{s3_prefix}/{TABLE_NAME}.gdb.zip")

        # --- 🏁 SUMMARY REPORT ---
        duration_val = time.time() - start_time
        duration_str = str(datetime.timedelta(seconds=round(duration_val)))
        
        print("\n" + "="*60)
        print(f"📊 SUMMARY REPORT - {TABLE_NAME}")
        print("="*60)
        print(f"✅ Total API Records     : {len(data_raw)}")
        print(f"🌍 Berhasil Masuk DB    : {len(gdf_final)}")
        print(f"💾 Status Database       : Sukses (Schema: {DB_SCHEMA})")
        print(f"☁️  S3 Version Path       : {s3_prefix}")
        print(f"⏱️  Total Durasi          : {duration_str}")
        print("="*60 + "\n")

    except Exception as e:
        print(f"❌ Error in {TABLE_NAME}: {e}")
    finally:
        # Cleanup
        for p in [gdb_path, zip_path, xlsx_path]:
            if os.path.exists(p):
                if os.path.isdir(p): shutil.rmtree(p)
                else: os.remove(p)

if __name__ == "__main__":
    igt_raw = os.getenv("IGT", "PERSETUJUAN_KOMITMEN_PBPH")
    igt_list = [item.strip() for item in igt_raw.split(",") if item.strip()]

    print(f"🚀 Integrasi PBPH v4.4 (Unified Standard)")
    for target_igt in igt_list:
        process_layer(target_igt)
