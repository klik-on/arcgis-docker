#!/bin/bash
# Daftar IGT yang ingin ditarik
LAYERS=("KUPS")

for layer in "${LAYERS[@]}"
do
    echo "Processing layer: $layer"
    IGT=$layer python3 /app/scripts/integrasi/api_KUPS_with_S3.py
done
