#!/bin/bash

docker exec -it geo-api python3 scripts/integrasi/api_KUPS_with_S3.py
