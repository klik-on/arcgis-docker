#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import requests
import pyproj
import boto3
import geopandas as gpd
import pandas as pd
import urllib3
from sqlalchemy import create_engine, text, URL
from dotenv import load_dotenv
from botocore.client import Config
from shapely.wkb import loads, dumps
from shapely.geometry import MultiPolygon, Polygon

# --- 1️⃣ INISIALISASI & KONFIGURASI ---
load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
sys.stdout.reconfigure(line_buffering=True)

# Path Proj untuk Geopandas
proj_path = pyproj.datadir.get_data_dir()
os.environ['PROJ_LIB'] = proj_path

# Logging
LOG_FILE = "/app/data/akps_sync.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(LOG_FILE)]
)
logger = logging.getLogger("AKPS-SYNC")

# Koneksi Database
connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", "password00"),
    host=os.getenv("DB_HOST", "dbgis"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "gisdb")
)

SCHEMA = os.getenv("DB_SCHEMA", "datagis")
TABLE_NAME = "AKPS"
API_URL = "https://pkps.hutsos.kehutanan.go.id/api-sitroom/api/Jagarimba/akps_penomoran"
TEMP_DIR = "/app/data/temp_akps"
FOLDER_DATA = "/app/data"

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

# --- 2️⃣ UTILITY FUNCTIONS ---

def force_2d(geometry):
    """Membuang dimensi Z agar konsisten 2D"""
    if geometry is None: return None
    if geometry.has_z:
        geometry = loads(dumps(geometry, output_dimension=2))
    return geometry

def ensure_multipolygon(geometry):
    """Memaksa Polygon tunggal menjadi MultiPolygon agar skema GDB konsisten"""
    if geometry is None: return None
    if isinstance(geometry, Polygon):
        return MultiPolygon([geometry])
    return geometry

def upload_to_s3(file_path):
    if not os.path.exists(file_path): return
    file_name = os.path.basename(file_path)
    try:
        s3_client = boto3.client(
            's3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER,
            aws_secret_access_key=S3_PASS, config=Config(signature_version='s3v4'), verify=False
        )
        s3_client.upload_file(file_path, S3_BUCKET, file_name)
        logger.info(f"✅ S3 UPLOAD SUCCESS: {file_name}")
    except Exception as e:
        logger.error(f"❌ S3 ERROR: {e}")

def zip_directory(folder_path, zip_path):
    """Membungkus folder .gdb menjadi file .zip"""
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                rel_path = os.path.relpath(os.path.join(root, file), os.path.dirname(folder_path))
                zipf.write(os.path.join(root, file), rel_path)

def download_and_read_shp(url, record_id):
    target_zip = os.path.join(TEMP_DIR, f"{record_id}.zip")
    extract_folder = os.path.join(TEMP_DIR, str(record_id))
    try:
        res = requests.get(url, verify=False, timeout=60)
        res.raise_for_status()
        with open(target_zip, 'wb') as f:
            f.write(res.content)
        with zipfile.ZipFile(target_zip, 'r') as z:
            z.extractall(extract_folder)
        for root, dirs, files in os.walk(extract_folder):
            for file in files:
                if file.endswith(".shp"):
                    shp_path = os.path.join(root, file)
                    gdf = gpd.read_file(shp_path, engine="pyogrio")
                    if gdf.crs is None:
                        gdf.set_crs("EPSG:4326", inplace=True)
                    else:
                        gdf = gdf.to_crs("EPSG:4326")
                    return gdf
    except Exception as e:
        logger.warning(f"⚠️ Skip ID {record_id}: {e}")
    return None

# --- 3️⃣ MAIN PROCESS ---

def run_sync():
    start_time = time.time()
    if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR, exist_ok=True)

    try:
        logger.info(f"🔍 Mengambil data dari API AKPS...")
        response = requests.get(API_URL, verify=False, timeout=30)
        response.raise_for_status()
        data_list = response.json().get("data", [])
        
        if not data_list:
            logger.error("❌ API kosong."); return

        # --- EXPORT ATRIBUT KE EXCEL ---
        XLSX_FILE = f"{TABLE_NAME}_Attribute.xlsx"
        XLSX_PATH = os.path.join(FOLDER_DATA, XLSX_FILE)
        logger.info(f"📊 Menyimpan atribut API ke Excel...")
        pd.DataFrame(data_list).to_excel(XLSX_PATH, index=False)
        upload_to_s3(XLSX_PATH)

        all_gdfs = []
        total = len(data_list)

        for idx, item in enumerate(data_list, 1):
            record_id = item.get("id")
            shp_url = item.get("shapefile")
            if not shp_url: continue

            logger.info(f"[{idx}/{total}] Memproses ID: {record_id}")
            gdf_shp = download_and_read_shp(shp_url, record_id)

            if gdf_shp is not None:
                for key, value in item.items():
                    if key != 'shapefile':
                        gdf_shp[key.upper()] = str(value) if value is not None else None
                all_gdfs.append(gdf_shp)

        if not all_gdfs:
            logger.error("❌ Tidak ada data spasial."); return

        logger.info("📦 Menggabungkan layer spasial...")
        gdf_final = pd.concat(all_gdfs, ignore_index=True)
        
        logger.info("🔧 Menormalisasi Geometri...")
        gdf_final['geometry'] = gdf_final['geometry'].apply(force_2d)
        gdf_final['geometry'] = gdf_final.make_valid()
        gdf_final['geometry'] = gdf_final['geometry'].apply(ensure_multipolygon)
        
        gdf_final = gdf_final.rename_geometry('geom')
        gdf_final.set_crs("EPSG:4326", allow_override=True, inplace=True)

        # --- POSTGIS LOAD ---
        engine = create_engine(connection_url)
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TABLE_NAME}" CASCADE;'))
            logger.info(f"🐘 Mengirim {len(gdf_final)} row ke PostGIS...")
        
        gdf_final.to_postgis(name=TABLE_NAME, con=engine, schema=SCHEMA, if_exists='replace', index=False)

        # --- GDB EXPORT ---
        GDB_NAME = f"{TABLE_NAME}.gdb"
        GDB_PATH = os.path.join(FOLDER_DATA, GDB_NAME)
        ZIP_GDB_OUT = os.path.join(FOLDER_DATA, f"{GDB_NAME}.zip")

        if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
        if os.path.exists(ZIP_GDB_OUT): os.remove(ZIP_GDB_OUT)

        try:
            logger.info(f"📦 Exporting to FileGeodatabase...")
            
            # 1. Gunakan copy agar data asli PostGIS tidak berubah
            gdf_export = gdf_final.copy()
            
            # 2. Hapus kolom ID/FID bawaan agar tidak konflik dengan primary key GDB
            cols_to_drop = [c for c in gdf_export.columns if c.upper() in ['ID', 'FID', 'OBJECTID']]
            if cols_to_drop:
                logger.info(f"🗑️ Menghapus kolom sensitif GDB: {cols_to_drop}")
                gdf_export = gdf_export.drop(columns=cols_to_drop)

            # 3. Reset Index (Penting untuk 32-bit FID)
            gdf_export = gdf_export.reset_index(drop=True)
            
            # 4. Standarisasi Nama Kolom (Uppercase & No Duplicate)
            gdf_export.columns = [c.upper() for c in gdf_export.columns]
            gdf_export = gdf_export.loc[:, ~gdf_export.columns.duplicated()]
            
            # 5. Handle NULL values & Tipe Data
            for col in gdf_export.columns:
                if col != 'GEOM':
                    if gdf_export[col].dtype == 'object':
                        gdf_export[col] = gdf_export[col].fillna('')
                    elif 'float' in str(gdf_export[col].dtype):
                        gdf_export[col] = gdf_export[col].fillna(0.0)
                    elif 'int' in str(gdf_export[col].dtype):
                        gdf_export[col] = gdf_export[col].fillna(0)

            # 6. Tulis ke GDB
            gdf_export.to_file(
                GDB_PATH, 
                driver="OpenFileGDB", 
                layer=TABLE_NAME, 
                engine="pyogrio",
                index=False
            )
            
            logger.info(f"🤐 Zipping GDB...")
            zip_directory(GDB_PATH, ZIP_GDB_OUT)
            upload_to_s3(ZIP_GDB_OUT)
            
            if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
            
        except Exception as export_err:
            logger.error(f"⚠️ Export GDB failed: {export_err}")

    except Exception as e:
        logger.error(f"❌ FATAL ERROR: {e}")
    finally:
        if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
        duration = time.time() - start_time
        logger.info(f"🏁 SELESAI | Durasi: {int(duration//60)}m {int(duration%60)}s")

if __name__ == "__main__":
    run_sync()
