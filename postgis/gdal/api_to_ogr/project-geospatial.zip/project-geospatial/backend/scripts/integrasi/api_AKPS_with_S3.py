#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import requests
import pyproj
import boto3
import geopandas as gpd
import pandas as pd
import urllib3
from sqlalchemy import create_engine, text, URL
from dotenv import load_dotenv
from botocore.client import Config
from shapely.wkb import loads, dumps
from shapely.geometry import MultiPolygon, Polygon
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- 1️⃣ INISIALISASI & KONFIGURASI ---
load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
sys.stdout.reconfigure(line_buffering=True)

proj_path = pyproj.datadir.get_data_dir()
os.environ['PROJ_LIB'] = proj_path

LOG_FILE = "/app/data/akps_sync.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(LOG_FILE)]
)
logger = logging.getLogger("AKPS-SYNC")

connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", "password00"),
    host=os.getenv("DB_HOST", "dbgis"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "gisdb")
)

SCHEMA = os.getenv("DB_SCHEMA", "datagis")
TABLE_NAME = "AKPS"
# Tabel pembantu untuk atribut
TABLE_ATTR = f"{TABLE_NAME}_attr" 

API_URL = os.getenv("AKPS_API_URL", "https://pkps.hutsos.kehutanan.go.id/api-sitroom/api/Jagarimba/akps_penomoran")
TEMP_DIR = "/app/data/temp_akps"
FOLDER_DATA = "/app/data"

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

# --- 2️⃣ UTILITY FUNCTIONS ---

def get_session():
    session = requests.Session()
    retry_strategy = Retry(total=5, backoff_factor=2, status_forcelist=[429, 500, 502, 503, 504])
    session.mount("https://", HTTPAdapter(max_retries=retry_strategy))
    return session

def force_2d(geometry):
    if geometry is None: return None
    if geometry.has_z: geometry = loads(dumps(geometry, output_dimension=2))
    return geometry

def ensure_multipolygon(geometry):
    if geometry is None: return None
    if isinstance(geometry, Polygon): return MultiPolygon([geometry])
    return geometry

def upload_to_s3(file_path):
    if not os.path.exists(file_path): return
    file_name = os.path.basename(file_path)
    try:
        s3_client = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER,
                                 aws_secret_access_key=S3_PASS, config=Config(signature_version='s3v4'), verify=False)
        s3_client.upload_file(file_path, S3_BUCKET, file_name)
        logger.info(f"✅ S3 UPLOAD SUCCESS: {file_name}")
    except Exception as e: logger.error(f"❌ S3 ERROR: {e}")

def zip_directory(folder_path, zip_path):
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                rel_path = os.path.relpath(os.path.join(root, file), os.path.dirname(folder_path))
                zipf.write(os.path.join(root, file), rel_path)

def download_and_read_shp(session, url, record_id):
    target_zip = os.path.join(TEMP_DIR, f"{record_id}.zip")
    extract_folder = os.path.join(TEMP_DIR, str(record_id))
    try:
        res = session.get(url, verify=False, timeout=90)
        res.raise_for_status()
        with open(target_zip, 'wb') as f: f.write(res.content)
        with zipfile.ZipFile(target_zip, 'r') as z: z.extractall(extract_folder)
        for root, dirs, files in os.walk(extract_folder):
            for file in files:
                if file.endswith(".shp"):
                    shp_path = os.path.join(root, file)
                    gdf = gpd.read_file(shp_path, engine="pyogrio")
                    gdf = gdf[gdf.geometry.type.isin(['Polygon', 'MultiPolygon'])]
                    if gdf.empty: return None
                    gdf['API_KODE'] = str(record_id)
                    gdf = gdf.to_crs("EPSG:4326") if gdf.crs else gdf.set_crs("EPSG:4326")
                    return gdf[['API_KODE', 'geometry']]
    except Exception as e: logger.warning(f"⚠️ Skip ID {record_id}: {e}")
    return None

# --- 3️⃣ MAIN PROCESS ---

def run_sync():
    start_time = time.time()
    session = get_session()
    if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR, exist_ok=True)

    try:
        logger.info(f"🔍 Mengambil data dari API AKPS...")
        response = session.get(API_URL, verify=False, timeout=120)
        response.raise_for_status()
        data_list = response.json().get("data", [])
        if not data_list: logger.error("❌ API kosong."); return

        # --- A. PROSES ATRIBUT (DF) ---
        df_api = pd.DataFrame(data_list)
        df_api['API_KODE'] = df_api['id'].astype(str)
        
        # Simpan Excel untuk S3
        XLSX_PATH = os.path.join(FOLDER_DATA, f"{TABLE_NAME}_Full.xlsx")
        df_api.to_excel(XLSX_PATH, index=False)
        upload_to_s3(XLSX_PATH)

        # --- B. PROSES SPASIAL (GDF) ---
        all_gdfs = []
        for idx, item in enumerate(data_list, 1):
            if not item.get("shapefile"): continue
            logger.info(f"[{idx}/{len(data_list)}] Mendownload Polygon ID: {item.get('id')}")
            gdf_shp = download_and_read_shp(session, item.get("shapefile"), item.get("id"))
            if gdf_shp is not None: all_gdfs.append(gdf_shp)

        if not all_gdfs: logger.error("❌ Tidak ada data spasial."); return
        
        gdf_final = pd.concat(all_gdfs, ignore_index=True)
        gdf_final['geometry'] = gdf_final['geometry'].apply(force_2d)
        gdf_final['geometry'] = gdf_final.make_valid()
        gdf_final['geometry'] = gdf_final['geometry'].apply(ensure_multipolygon)
        gdf_final = gdf_final.rename_geometry('geom')
        gdf_final.set_crs("EPSG:4326", allow_override=True, inplace=True)

        # --- C. POSTGIS LOAD & JOIN ---
        engine = create_engine(connection_url)
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
            
            # 1. Simpan Tabel Atribut Murni
            logger.info("🐘 Mengirim tabel atribut ke PostGIS...")
            df_api.to_sql(name=TABLE_ATTR, con=conn, schema=SCHEMA, if_exists='replace', index=False)
            
            # 2. Simpan Tabel Spasial (Hanya Geometri + API_KODE)
            logger.info("🐘 Mengirim tabel spasial ke PostGIS...")
            gdf_final.to_postgis(name=f"{TABLE_NAME}_geom", con=conn, schema=SCHEMA, if_exists='replace', index=False)

            # 3. BUAT TABEL FINAL HASIL JOIN
            logger.info("🔗 Melakukan Join Spasial & Atribut...")
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TABLE_NAME}" CASCADE;'))
            join_query = f"""
                CREATE TABLE "{SCHEMA}"."{TABLE_NAME}" AS
                SELECT 
                    g.geom,
                    a.*
                FROM "{SCHEMA}"."{TABLE_NAME}_geom" g
                LEFT JOIN "{SCHEMA}"."{TABLE_ATTR}" a ON g."API_KODE" = a."API_KODE";
            """
            conn.execute(text(join_query))
            
            # 4. Tambahkan Index Spasial agar cepat dibuka di QGIS
            conn.execute(text(f'CREATE INDEX idx_akps_geom ON "{SCHEMA}"."{TABLE_NAME}" USING GIST(geom);'))
            logger.info(f"✅ Tabel '{SCHEMA}.{TABLE_NAME}' berhasil dibuat dengan hasil join.")

        # --- D. GDB EXPORT (Dari Hasil Join) ---
        # Kita ambil data yang sudah di-join untuk di-export ke GDB agar user ArcGIS senang
        GDB_PATH = os.path.join(FOLDER_DATA, f"{TABLE_NAME}.gdb")
        ZIP_GDB_OUT = f"{GDB_PATH}.zip"
        
        # Baca kembali hasil join dari database untuk di-export ke GDB
        gdf_joined = gpd.read_postgis(f'SELECT * FROM "{SCHEMA}"."{TABLE_NAME}"', con=engine, geom_col='geom')
        
        if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
        gdf_joined.columns = [c.upper() for c in gdf_joined.columns]
        gdf_joined.to_file(GDB_PATH, driver="OpenFileGDB", layer=TABLE_NAME, engine="pyogrio")
        zip_directory(GDB_PATH, ZIP_GDB_OUT)
        upload_to_s3(ZIP_GDB_OUT)

    except Exception as e: logger.error(f"❌ FATAL ERROR: {e}")
    finally:
        if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
        logger.info(f"🏁 SELESAI | Durasi: {int((time.time() - start_time)//60)}m")

if __name__ == "__main__":
    run_sync()
