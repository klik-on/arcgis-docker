#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import datetime
import requests
import pyproj
import boto3
import geopandas as gpd
import pandas as pd
import urllib3
import warnings
from sqlalchemy import create_engine, text, URL
from dotenv import load_dotenv
from botocore.client import Config
from shapely.wkb import loads, dumps
from shapely.geometry import MultiPolygon, GeometryCollection
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from concurrent.futures import ThreadPoolExecutor, as_completed

# --- 1️⃣ INISIALISASI & KONFIGURASI ---
load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning, module="pyogrio")
warnings.filterwarnings("ignore", category=UserWarning, module="pyogrio")
from sqlalchemy import exc as sa_exc
warnings.filterwarnings("ignore", category=sa_exc.SAWarning)

sys.stdout.reconfigure(line_buffering=True)

# Path PROJ untuk transformasi koordinat
proj_path = pyproj.datadir.get_data_dir()
os.environ['PROJ_LIB'] = proj_path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("AKPS-INTEGRATION-FINAL")

# Bounding Box Indonesia (Filter Spasial)
INDONESIA_BOUNDS = {"xmin": 94.0, "ymin": -12.0, "xmax": 142.0, "ymax": 8.0}

# Config API, DB & S3
SCHEMA = os.getenv("DB_SCHEMA", "datagis")
TABLE_NAME = "AKPS"
API_URL = os.getenv("AKPS_API_URL", "https://pkps.hutsos.kehutanan.go.id/api-sitroom/api/Jagarimba/akps_penomoran")
TEMP_DIR = "/app/data/temp_akps"
FOLDER_DATA = "/app/data"
MAX_WORKERS = 10

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", "password00"),
    host=os.getenv("DB_HOST", "dbgis"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "gisdb")
)

# --- 2️⃣ UTILITY FUNCTIONS ---

def get_session():
    session = requests.Session()
    retry_strategy = Retry(total=5, backoff_factor=2, status_forcelist=[429, 500, 502, 503, 504])
    session.mount("https://", HTTPAdapter(max_retries=retry_strategy))
    return session

def clean_and_force_multi(geom):
    """Membersihkan geometri dan memaksa menjadi MultiPolygon 2D."""
    if geom is None or geom.is_empty: return None
    try:
        geom = loads(dumps(geom, output_dimension=2))
        if not geom.is_valid: geom = geom.make_valid()

        if isinstance(geom, GeometryCollection):
            polys = [g for g in geom.geoms if g.geom_type in ['Polygon', 'MultiPolygon']]
            if not polys: return None
            from shapely.ops import unary_union
            geom = unary_union(polys)

        if geom.geom_type == 'Polygon':
            return MultiPolygon([geom])
        elif geom.geom_type == 'MultiPolygon':
            return geom
        return None
    except: return None

def download_worker(record_data, session):
    """Worker paralel untuk download dan re-proyeksi ke EPSG:4326."""
    record_id = record_data.get('id')
    url = record_data.get("shapefile")
    if not url: return None

    target_zip = os.path.join(TEMP_DIR, f"{record_id}.zip")
    extract_folder = os.path.join(TEMP_DIR, str(record_id))

    try:
        res = session.get(url, verify=False, timeout=90)
        res.raise_for_status()
        with open(target_zip, 'wb') as f: f.write(res.content)
        with zipfile.ZipFile(target_zip, 'r') as z: z.extractall(extract_folder)

        for root, dirs, files in os.walk(extract_folder):
            for file in files:
                if file.endswith(".shp"):
                    shp_path = os.path.join(root, file)
                    gdf = gpd.read_file(shp_path, engine="pyogrio")
                    gdf = gdf[gdf.geometry.type.isin(['Polygon', 'MultiPolygon'])]
                    if gdf.empty: continue

                    if gdf.crs is None:
                        gdf.set_crs("EPSG:4326", inplace=True)
                    elif gdf.crs != "EPSG:4326":
                        gdf = gdf.to_crs("EPSG:4326")

                    gdf['API_KODE'] = str(record_id)
                    return gdf[['API_KODE', 'geometry']]
    except Exception: return None

# --- 3️⃣ MAIN PROCESS ---

def run_sync():
    start_time = time.time()
    session = get_session()
    summary = {"total_api": 0, "berhasil_spasial": 0, "status_db": "Gagal", "s3_path": "N/A"}

    if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR, exist_ok=True)

    try:
        logger.info(f"🔍 Mengambil data dari API {TABLE_NAME}...")
        response = session.get(API_URL, verify=False, timeout=120)
        response.raise_for_status()
        data_list = response.json().get("data", [])
        summary["total_api"] = len(data_list)

        # --- A. PROSES ATRIBUT ---
        df_api = pd.DataFrame(data_list)
        df_api['id'] = df_api['id'].astype(str)
        df_api = df_api.drop_duplicates(subset=['id'], keep='first')
        df_api.columns = [c.upper() for c in df_api.columns]
        df_api['API_KODE'] = df_api['ID']

        XLSX_NAME = f"{TABLE_NAME}_Full.xlsx"
        XLSX_PATH = os.path.join(FOLDER_DATA, XLSX_NAME)
        df_api.to_excel(XLSX_PATH, index=False)

        # --- B. PROSES SPASIAL (Parallel) ---
        logger.info(f"🚀 Memulai download paralel {MAX_WORKERS} threads...")
        all_gdfs = []
        valid_shp_list = [item for item in data_list if item.get("shapefile") and str(item.get("id")) in df_api['ID'].values]

        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = [executor.submit(download_worker, item, session) for item in valid_shp_list]
            for future in as_completed(futures):
                res_gdf = future.result()
                if res_gdf is not None: all_gdfs.append(res_gdf)

        if not all_gdfs:
            logger.error("❌ Tidak ada data spasial valid."); return

        gdf_final = pd.concat(all_gdfs, ignore_index=True)
        gdf_final['geometry'] = gdf_final['geometry'].apply(clean_and_force_multi)
        gdf_final = gdf_final.dropna(subset=['geometry']).copy()
        gdf_final = gdf_final.rename(columns={'geometry': 'geom'}).set_geometry('geom')

        # --- C. DATABASE LOAD (Optimized + BBOX + DISTINCT ON) ---
        logger.info("💾 Loading data ke PostGIS (Fix Duplicate & BBOX)...")
        engine = create_engine(connection_url)
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
            
            df_api.to_sql("tmp_attr_akps", conn, schema=SCHEMA, if_exists='replace', index=False, method='multi')
            gdf_final.to_postgis("tmp_geom_akps", conn, schema=SCHEMA, if_exists='replace', index=False, chunksize=1000)

            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TABLE_NAME}" CASCADE;'))
            
            # DISTINCT ON (a."ID") mencegah error UniqueViolation jika 1 ID punya >1 SHP
            join_query = f"""
                CREATE TABLE "{SCHEMA}"."{TABLE_NAME}" AS
                SELECT DISTINCT ON (a."ID")
                    g.geom, a.* FROM "{SCHEMA}"."tmp_geom_akps" g
                LEFT JOIN "{SCHEMA}"."tmp_attr_akps" a ON g."API_KODE" = a."API_KODE"
                WHERE ST_Intersects(g.geom, ST_MakeEnvelope({INDONESIA_BOUNDS['xmin']}, {INDONESIA_BOUNDS['ymin']}, {INDONESIA_BOUNDS['xmax']}, {INDONESIA_BOUNDS['ymax']}, 4326))
                ORDER BY a."ID", g.ctid;
            """
            conn.execute(text(join_query))
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."tmp_attr_akps";'))
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."tmp_geom_akps";'))
            conn.execute(text(f'CREATE INDEX idx_{TABLE_NAME.lower()}_geom ON "{SCHEMA}"."{TABLE_NAME}" USING GIST(geom);'))
            conn.execute(text(f'CREATE UNIQUE INDEX idx_{TABLE_NAME.lower()}_id ON "{SCHEMA}"."{TABLE_NAME}" ("ID");'))
            
            summary["status_db"] = "Sukses"
            summary["berhasil_spasial"] = conn.execute(text(f'SELECT COUNT(*) FROM "{SCHEMA}"."{TABLE_NAME}"')).scalar()

        # --- D. S3 & GDB EXPORT (Versioning) ---
        s3_client = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER,
                                 aws_secret_access_key=S3_PASS, config=Config(signature_version='s3v4'), verify=False)
        
        date_folder = datetime.date.today().isoformat()
        s3_path = f"integrasi/AKPS/{date_folder}"
        summary["s3_path"] = s3_path

        # Upload XLSX
        s3_client.upload_file(XLSX_PATH, S3_BUCKET, f"{s3_path}/{XLSX_NAME}")

        GDB_PATH = os.path.join(FOLDER_DATA, f"{TABLE_NAME}.gdb")
        ZIP_NAME = f"{TABLE_NAME}.gdb.zip"
        ZIP_PATH = os.path.join(FOLDER_DATA, ZIP_NAME)
        
        if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
        gdf_export = gpd.read_postgis(f'SELECT * FROM "{SCHEMA}"."{TABLE_NAME}"', engine, geom_col='geom')
        gdf_export.columns = [c.upper() if c != 'geom' else 'geom' for c in gdf_export.columns]
        gdf_export.to_file(GDB_PATH, driver="OpenFileGDB", layer=TABLE_NAME, engine="pyogrio")

        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(GDB_PATH):
                for file in files:
                    zf.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), os.path.dirname(GDB_PATH)))
        
        # Upload ZIP GDB
        s3_client.upload_file(ZIP_PATH, S3_BUCKET, f"{s3_path}/{ZIP_NAME}")

        # --- 🏁 FINAL REPORT ---
        duration = str(datetime.timedelta(seconds=round(time.time() - start_time)))
        print("\n" + "="*60 + f"\n📊 SUMMARY REPORT - AKPS INTEGRATION (v6.9)\n" + "="*60)
        print(f"✅ Total API Records     : {summary['total_api']}")
        print(f"🌍 Berhasil Spasial      : {summary['berhasil_spasial']}")
        print(f"💾 Status Database       : {summary['status_db']}")
        print(f"☁️  S3 Version Path       : {summary['s3_path']}")
        print(f"⏱️  Total Durasi          : {duration}\n" + "="*60)

    except Exception as e:
        logger.error(f"❌ FATAL ERROR: {e}", exc_info=True)
    finally:
        # --- 🧹 SAFE CLEANUP (Zero Residue) ---
        logger.info("🧹 Membersihkan file temporary lokal...")
        if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
        
        vars_to_clean = []
        if 'GDB_PATH' in locals(): vars_to_clean.append(GDB_PATH)
        if 'XLSX_PATH' in locals(): vars_to_clean.append(XLSX_PATH)
        if 'ZIP_PATH' in locals(): vars_to_clean.append(ZIP_PATH)
        
        for p in vars_to_clean:
            if os.path.exists(p):
                if os.path.isdir(p): shutil.rmtree(p)
                else: os.remove(p)

if __name__ == "__main__":
    run_sync()
