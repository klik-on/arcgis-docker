#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import datetime
import requests
import pyproj
import boto3
import geopandas as gpd
import pandas as pd
import urllib3
import warnings
from sqlalchemy import create_engine, text, URL
from dotenv import load_dotenv
from botocore.client import Config
from shapely.wkb import loads, dumps
from shapely.geometry import MultiPolygon, GeometryCollection
from shapely.ops import unary_union
from concurrent.futures import ThreadPoolExecutor, as_completed

# --- 1️⃣ INISIALISASI & KONFIGURASI ---
load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning, module="pyogrio")
warnings.filterwarnings("ignore", category=UserWarning, module="pyogrio")
from sqlalchemy import exc as sa_exc
warnings.filterwarnings("ignore", category=sa_exc.SAWarning)

sys.stdout.reconfigure(line_buffering=True)

# Path PROJ untuk transformasi koordinat
proj_path = pyproj.datadir.get_data_dir()
os.environ['PROJ_LIB'] = proj_path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("SINERGY-INTEGRATION")

# Bounding Box Indonesia (Filter Spasial)
INDONESIA_BOUNDS = {"xmin": 94.0, "ymin": -12.0, "xmax": 142.0, "ymax": 8.0}

# Config API & S3
API_URL = os.getenv("SINERGY_API_URL", "https://sinergy.planologi.kehutanan.go.id/main-api/data_srtprmn")
BASE_DOMAIN = "https://sinergy.planologi.kehutanan.go.id"
ASA_TOKEN = os.getenv("SINERGY_ASA_TOKEN", "Asa-Token 0beb25bddf59.7.1716190054609")

# Config DB & Path
SCHEMA = os.getenv("DB_SCHEMA", "datagis")
TABLE_NAME = "SINERGY_SRTPRM"
TEMP_DIR = "/app/data/temp_sinergy"
FOLDER_DATA = "/app/data"
MAX_WORKERS = 10

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", "password00"),
    host=os.getenv("DB_HOST", "dbgis"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "gisdb")
)

# --- 2️⃣ UTILITY FUNCTIONS ---

def clean_geometry_strict(geom):
    """Memastikan geometri valid, 2D, dan berupa MultiPolygon."""
    if geom is None or geom.is_empty: return None
    try:
        geom = loads(dumps(geom, output_dimension=2))
        if not geom.is_valid: geom = geom.make_valid()

        if isinstance(geom, GeometryCollection):
            polys = [g for g in geom.geoms if g.geom_type in ['Polygon', 'MultiPolygon']]
            if not polys: return None
            geom = unary_union(polys)

        if geom.geom_type == 'Polygon':
            return MultiPolygon([geom])
        elif geom.geom_type == 'MultiPolygon':
            return geom
        return None
    except Exception: return None

def download_worker(record_data, headers):
    """Download, Filter Geometry Type, dan Force EPSG:4326."""
    record_id = record_data.get('id')
    titik_list = record_data.get("PermohonanTitik", [])
    if not titik_list or not titik_list[0].get("UpldShpl"): return None

    url = titik_list[0].get("UpldShpl")
    if not url.startswith('http'): url = f"{BASE_DOMAIN}{url}"

    target_zip = os.path.join(TEMP_DIR, f"{record_id}.zip")
    extract_folder = os.path.join(TEMP_DIR, str(record_id))

    try:
        res = requests.get(url, headers=headers, verify=False, timeout=60)
        res.raise_for_status()
        with open(target_zip, 'wb') as f: f.write(res.content)
        with zipfile.ZipFile(target_zip, 'r') as z: z.extractall(extract_folder)

        for root, dirs, files in os.walk(extract_folder):
            for file in files:
                if file.endswith(".shp"):
                    shp_path = os.path.join(root, file)
                    gdf = gpd.read_file(shp_path, engine="pyogrio")
                    gdf = gdf[gdf.geometry.type.isin(['Polygon', 'MultiPolygon'])]
                    if gdf.empty: continue

                    if gdf.crs is None:
                        gdf.set_crs("EPSG:4326", inplace=True)
                    elif gdf.crs != "EPSG:4326":
                        gdf = gdf.to_crs("EPSG:4326")

                    gdf['API_KODE'] = str(record_id)
                    return gdf.dissolve(by='API_KODE').reset_index()[['API_KODE', 'geometry']]
    except Exception: return None

# --- 3️⃣ MAIN PROCESS ---

def main():
    start_time = time.time()
    headers = {'Authorization': ASA_TOKEN, 'User-Agent': 'Mozilla/5.0'}
    summary = {"total_api": 0, "berhasil_spasial": 0, "status_db": "Gagal"}

    if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR, exist_ok=True)

    try:
        logger.info("📡 Mengambil data dari API SINERGY...")
        res = requests.get(API_URL, headers=headers, params={'page': 1, 'limit': 2000}, verify=False)
        res.raise_for_status()
        raw_data = res.json().get('data', {}).get('data', [])
        summary["total_api"] = len(raw_data)

        # --- A. PROSES ATRIBUT ---
        df_attr = pd.json_normalize(
            raw_data, record_path=['PermohonanTitik'],
            meta=['id', 'nmpmhn', 'kdlmbg', 'nomor', 'tanggal', 'perihal', 'status', 'user_id'],
            record_prefix='PT_', errors='ignore'
        )

        status_allowed = ['Proses Permohonan Selesai', 'Verifikasi Berkas Lengkap', 'Selesai Telaah Spasial']
        df_attr = df_attr[df_attr['status'].isin(status_allowed)]
        df_attr['id'] = df_attr['id'].astype(str)
        df_attr = df_attr.drop_duplicates(subset=['id'], keep='first')

        df_attr.columns = [c.upper() for c in df_attr.columns]
        df_attr['API_KODE_JOIN'] = df_attr['ID']
        
        XLSX_NAME = f"{TABLE_NAME}_Full.xlsx"
        XLSX_PATH = os.path.join(FOLDER_DATA, XLSX_NAME)
        df_attr.to_excel(XLSX_PATH, index=False)

        # --- B. PROSES SPASIAL (Parallel) ---
        logger.info(f"🚀 Memulai download paralel {MAX_WORKERS} threads...")
        all_gdfs = []
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = [executor.submit(download_worker, item, headers) for item in raw_data]
            for future in as_completed(futures):
                res_gdf = future.result()
                if res_gdf is not None: all_gdfs.append(res_gdf)

        if not all_gdfs:
            logger.error("❌ Tidak ada data spasial valid."); return

        gdf_final = pd.concat(all_gdfs, ignore_index=True)
        gdf_final['geometry'] = gdf_final['geometry'].apply(clean_geometry_strict)
        gdf_final = gdf_final.dropna(subset=['geometry']).copy()
        gdf_final = gdf_final.rename(columns={'geometry': 'geom'}).set_geometry('geom')

        # --- C. DATABASE LOAD (Optimized) ---
        logger.info("💾 Loading data ke PostGIS (Optimized Multi-Insert)...")
        engine = create_engine(connection_url)
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
            
            df_attr.to_sql("tmp_attr_sinergy", conn, schema=SCHEMA, if_exists='replace', index=False, method='multi')
            gdf_final.to_postgis("tmp_geom_sinergy", conn, schema=SCHEMA, if_exists='replace', index=False, chunksize=1000)

            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TABLE_NAME}" CASCADE;'))
            join_sql = f"""
                CREATE TABLE "{SCHEMA}"."{TABLE_NAME}" AS
                SELECT g.geom, a.* FROM "{SCHEMA}"."tmp_geom_sinergy" g
                LEFT JOIN "{SCHEMA}"."tmp_attr_sinergy" a ON g."API_KODE" = a."API_KODE_JOIN"
                WHERE ST_Intersects(g.geom, ST_MakeEnvelope({INDONESIA_BOUNDS['xmin']}, {INDONESIA_BOUNDS['ymin']}, {INDONESIA_BOUNDS['xmax']}, {INDONESIA_BOUNDS['ymax']}, 4326));
            """
            conn.execute(text(join_sql))
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."tmp_attr_sinergy";'))
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."tmp_geom_sinergy";'))
            conn.execute(text(f'CREATE INDEX idx_{TABLE_NAME.lower()}_geom ON "{SCHEMA}"."{TABLE_NAME}" USING GIST(geom);'))
            summary["status_db"] = "Sukses"
            summary["berhasil_spasial"] = conn.execute(text(f'SELECT COUNT(*) FROM "{SCHEMA}"."{TABLE_NAME}"')).scalar()

        # --- D. S3 & GDB EXPORT (Versioning) ---
        s3_client = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER,
                                 aws_secret_access_key=S3_PASS, config=Config(signature_version='s3v4'), verify=False)
        
        date_folder = datetime.date.today().isoformat()
        s3_path = f"integrasi/SINERGY/{date_folder}"

        s3_client.upload_file(XLSX_PATH, S3_BUCKET, f"{s3_path}/{XLSX_NAME}")

        GDB_PATH = os.path.join(FOLDER_DATA, f"{TABLE_NAME}.gdb")
        ZIP_NAME = f"{TABLE_NAME}.gdb.zip"
        ZIP_PATH = os.path.join(FOLDER_DATA, ZIP_NAME)
        
        if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
        gdf_export = gpd.read_postgis(f'SELECT * FROM "{SCHEMA}"."{TABLE_NAME}"', engine, geom_col='geom')
        gdf_export.columns = [c.upper() if c != 'geom' else 'geom' for c in gdf_export.columns]
        gdf_export.to_file(GDB_PATH, driver="OpenFileGDB", layer=TABLE_NAME, engine="pyogrio")

        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(GDB_PATH):
                for file in files:
                    zf.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), os.path.dirname(GDB_PATH)))
        
        s3_client.upload_file(ZIP_PATH, S3_BUCKET, f"{s3_path}/{ZIP_NAME}")

        # --- 🏁 REPORT ---
        duration = str(datetime.timedelta(seconds=round(time.time() - start_time)))
        print("\n" + "="*60 + f"\n📊 SUMMARY REPORT - SINERGY INTEGRATION\n" + "="*60)
        print(f"✅ Total API Records     : {summary['total_api']}\n🌍 Berhasil Spasial      : {summary['berhasil_spasial']}")
        print(f"💾 Status Database       : {summary['status_db']}\n☁️  S3 Path               : {s3_path}\n⏱️  Durasi                : {duration}\n" + "="*60)

    except Exception as e:
        logger.error(f"❌ FATAL ERROR: {e}", exc_info=True)
    finally:
        # CLEANUP
        if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
        if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
        for f in [XLSX_PATH, ZIP_PATH]:
            if os.path.exists(f): os.remove(f)

if __name__ == "__main__":
    main()
