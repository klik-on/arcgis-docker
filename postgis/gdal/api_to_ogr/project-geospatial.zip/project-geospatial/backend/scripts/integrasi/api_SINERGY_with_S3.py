#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import requests
import boto3
import geopandas as gpd
import pandas as pd
import urllib3
from io import BytesIO
from sqlalchemy import create_engine, text, URL
from dotenv import load_dotenv
from botocore.client import Config
from shapely.wkb import loads, dumps
from shapely.geometry import MultiPolygon, GeometryCollection

# --- 1️⃣ INISIALISASI & KONFIGURASI ---
load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
sys.stdout.reconfigure(line_buffering=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("Sinergy-Sync-Final-GIS")

# API & S3 CONFIG
API_URL = os.getenv("SINERGY_API_URL", "https://sinergy.planologi.kehutanan.go.id/main-api/data_srtprmn")
BASE_DOMAIN = "https://sinergy.planologi.kehutanan.go.id"
ASA_TOKEN = os.getenv("SINERGY_ASA_TOKEN", "Asa-Token 0beb25bddf59.7.1716190054609")

# DB & File Config
SCHEMA = os.getenv("DB_SCHEMA", "datagis")
TABLE_NAME = "SINERGY_SRTPRM"
TEMP_DIR = "/app/data/temp_sinergy"
FOLDER_DATA = "/app/data"
MIN_AREA_M2 = 1.0  # Filter poligon di bawah 1 m2

# MENGGUNAKAN EPSG:6933 (EASE-Grid 2.0 Global) untuk hitung luas yang akurat (Equal Area)
# Ini adalah pengganti EPSG:54034 yang lebih universal dan kompatibel.
CALC_CRS = "EPSG:6933" 

# Global Paths
gdb_path = os.path.join(FOLDER_DATA, f"{TABLE_NAME}.gdb")
zip_path = f"{gdb_path}.zip"

# S3 Config
S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", "password00"),
    host=os.getenv("DB_HOST", "dbgis"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "gisdb")
)

# --- 2️⃣ UTILITY FUNCTIONS ---

def clean_geometry_strict(geom):
    """Force 2D, Remove M, Fix Topology, and Ensure Polygon Type"""
    if geom is None or geom.is_empty:
        return None
    try:
        # Step 1: Force 2D & Remove M-values
        geom = loads(dumps(geom, output_dimension=2))
        
        # Step 2: Topology Fix
        if not geom.is_valid:
            geom = geom.buffer(0)
        
        # Step 3: Extract Polygons from Collections
        if isinstance(geom, GeometryCollection):
            polys = [g for g in geom.geoms if g.geom_type in ['Polygon', 'MultiPolygon']]
            if not polys: return None
            geom = MultiPolygon(polys) if len(polys) > 1 else polys[0]
        
        # Step 4: Final Type Filtering
        if geom.geom_type not in ['Polygon', 'MultiPolygon']:
            return None
            
        # Step 5: Wrap in MultiPolygon for consistency
        if geom.geom_type == 'Polygon':
            return MultiPolygon([geom])
        return geom
    except:
        return None

def download_and_read_shp(url, record_id, headers):
    if not url.startswith('http'): url = f"{BASE_DOMAIN}{url}"
    target_zip = os.path.join(TEMP_DIR, f"{record_id}.zip")
    extract_folder = os.path.join(TEMP_DIR, str(record_id))
    
    try:
        res = requests.get(url, headers=headers, verify=False, timeout=90)
        res.raise_for_status()
        with open(target_zip, 'wb') as f: f.write(res.content)
        
        with zipfile.ZipFile(target_zip, 'r') as z: z.extractall(extract_folder)
        
        for root, dirs, files in os.walk(extract_folder):
            for file in files:
                if file.endswith(".shp"):
                    shp_path = os.path.join(root, file)
                    gdf = gpd.read_file(shp_path, engine="pyogrio")
                    
                    if gdf.empty: return None

                    orig_crs = gdf.crs if gdf.crs else "UNDEFINED"
                    # Selalu transform ke 4326 sebelum digabung
                    if str(orig_crs).upper() != "EPSG:4326":
                        gdf = gdf.to_crs("EPSG:4326") if gdf.crs else gdf.set_crs("EPSG:4326")
                    
                    gdf['ORIG_CRS'] = str(orig_crs)
                    gdf['API_KODE'] = str(record_id)
                    return gdf[['API_KODE', 'ORIG_CRS', 'geometry']]
    except Exception as e:
        logger.warning(f"⚠️ ID {record_id} skipped: {e}")
    return None

# --- 3️⃣ MAIN PROCESS ---

def main():
    start_time = time.time()
    headers = {'Authorization': ASA_TOKEN, 'User-Agent': 'Mozilla/5.0'}
    
    if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR, exist_ok=True)

    try:
        # A. ATRIBUT DATA
        logger.info("📡 Requesting API Sinergy...")
        res = requests.get(API_URL, headers=headers, params={'page': 1, 'limit': 2000}, verify=False)
        res.raise_for_status()
        raw_items = res.json().get('data', {}).get('data', [])

        df_attr = pd.json_normalize(raw_items, record_path=['PermohonanTitik'], 
                                   meta=['id', 'nmpmhn', 'nomor', 'tanggal', 'status'], errors='ignore')
        df_attr.columns = [c.upper() for c in df_attr.columns]
        df_attr = df_attr.loc[:, ~df_attr.columns.duplicated()].copy()
        df_attr['API_KODE_JOIN'] = df_attr['ID'].astype(str)
        df_attr = df_attr.drop_duplicates(subset=['ID'])

        # B. SPASIAL DATA
        all_gdfs = []
        for idx, item in enumerate(raw_items, 1):
            titik = item.get("PermohonanTitik", [])
            if titik and titik[0].get("UpldShpl"):
                gdf_res = download_and_read_shp(titik[0].get("UpldShpl"), item.get('id'), headers)
                if gdf_res is not None:
                    all_gdfs.append(gdf_res)

        if not all_gdfs: logger.error("❌ No spatial data found."); return
        
        # C. CLEANING & AREA FILTER
        logger.info(f"📦 Filtering area with {CALC_CRS} (Min: {MIN_AREA_M2} m2)...")
        gdf_final = pd.concat(all_gdfs, ignore_index=True)
        
        gdf_final['geometry'] = gdf_final['geometry'].apply(clean_geometry_strict)
        gdf_final = gdf_final.dropna(subset=['geometry']).copy()
        
        # Step filter luas: 4326 -> 6933 (m2) -> Filter -> Back to 4326
        gdf_final = gdf_final.to_crs(CALC_CRS) 
        gdf_final = gdf_final[gdf_final.geometry.area >= MIN_AREA_M2].copy()
        gdf_final = gdf_final.to_crs("EPSG:4326") 
        
        if gdf_final.empty: logger.error("❌ Data empty after area filter."); return

        gdf_final = gdf_final.rename(columns={'geometry': 'geom'}).set_geometry('geom')
        gdf_final.set_crs("EPSG:4326", allow_override=True, inplace=True)

        # D. POSTGIS LOAD
        engine = create_engine(connection_url)
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
            df_attr.to_sql("tmp_attr_sinergy", conn, schema=SCHEMA, if_exists='replace', index=False)
            gdf_final.to_postgis("tmp_geom_sinergy", conn, schema=SCHEMA, if_exists='replace', index=False)

            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TABLE_NAME}" CASCADE;'))
            conn.execute(text(f"""
                CREATE TABLE "{SCHEMA}"."{TABLE_NAME}" AS
                SELECT g.geom, g."ORIG_CRS", a.* FROM "{SCHEMA}"."tmp_geom_sinergy" g
                LEFT JOIN "{SCHEMA}"."tmp_attr_sinergy" a ON g."API_KODE" = a."API_KODE_JOIN";
            """))
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."tmp_attr_sinergy";'))
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."tmp_geom_sinergy";'))

        # E. EXPORT S3
        s3_client = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER, aws_secret_access_key=S3_PASS, verify=False)
        
        # Excel
        out_ex = BytesIO()
        with pd.ExcelWriter(out_ex, engine='openpyxl') as writer:
            df_attr.to_excel(writer, index=False)
        s3_client.put_object(Bucket=S3_BUCKET, Key=f"master_sinergy_{int(time.time())}.xlsx", Body=out_ex.getvalue())
        
        # GDB
        if os.path.exists(gdb_path): shutil.rmtree(gdb_path)
        gdf_joined = gpd.read_postgis(f'SELECT * FROM "{SCHEMA}"."{TABLE_NAME}"', engine, geom_col='geom')
        gdf_joined.columns = [c.upper() for c in gdf_joined.columns]
        gdf_joined.to_file(gdb_path, driver="OpenFileGDB", layer=TABLE_NAME, engine="pyogrio")
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
            for f in os.listdir(gdb_path): z.write(os.path.join(gdb_path, f), f)
        s3_client.upload_file(zip_path, S3_BUCKET, os.path.basename(zip_path))

        logger.info(f"✨ SUCCESS | Polygons: {len(gdf_final)} | Time: {int(time.time() - start_time)}s")

    except Exception as e: 
        logger.error(f"❌ ERROR: {e}", exc_info=True)
    finally:
        if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
        if os.path.exists(gdb_path): shutil.rmtree(gdb_path)

if __name__ == "__main__":
    main()
