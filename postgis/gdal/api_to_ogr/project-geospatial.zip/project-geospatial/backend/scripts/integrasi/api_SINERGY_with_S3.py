#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import requests
import pyproj
import boto3
import geopandas as gpd
import pandas as pd
import urllib3
from io import BytesIO
from sqlalchemy import create_engine, text, URL
from dotenv import load_dotenv
from botocore.client import Config
from shapely.wkb import loads, dumps
from shapely.geometry import MultiPolygon, Polygon

# --- 1️⃣ INISIALISASI & KONFIGURASI ---
load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
sys.stdout.reconfigure(line_buffering=True)

# Path Proj
os.environ['PROJ_LIB'] = pyproj.datadir.get_data_dir()

# Logging
LOG_FILE = "/app/data/srtprmn_sync.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(LOG_FILE)]
)
logger = logging.getLogger("SRTPRMN-SYNC")

# API & S3 CONFIG
API_BASE_URL = "https://sinergy.planologi.kehutanan.go.id/main-api/data_srtprmn"
BASE_DOMAIN = "https://sinergy.planologi.kehutanan.go.id"
ASA_TOKEN = "Asa-Token 0beb25bddf59.7.1716190054609"
HEADERS = {
    'Authorization': ASA_TOKEN,
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
}

S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")
S3_USER = os.getenv("S3_USER", "geobackup")
S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_XLSX_KEY = "metadata_sinergy/master_data_sinergy.xlsx"

# DB CONFIG
connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", "password00"),
    host=os.getenv("DB_HOST", "dbgis"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "gisdb")
)
SCHEMA = os.getenv("DB_SCHEMA", "datagis")
TABLE_NAME = "SRTPRMN"
TEMP_DIR = "/app/data/temp_srtprmn"
FOLDER_DATA = "/app/data"

# --- 2️⃣ UTILITY FUNCTIONS ---

def force_2d(geometry):
    if geometry is None: return None
    return loads(dumps(geometry, output_dimension=2)) if geometry.has_z else geometry

def ensure_multipolygon(geometry):
    if geometry is None: return None
    return MultiPolygon([geometry]) if isinstance(geometry, Polygon) else geometry

def upload_to_s3(file_path, s3_key=None):
    if not os.path.exists(file_path): return
    key = s3_key if s3_key else os.path.basename(file_path)
    try:
        s3 = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER,
                          aws_secret_access_key=S3_PASS, config=Config(signature_version='s3v4'), verify=False)
        s3.upload_file(file_path, S3_BUCKET, key)
        logger.info(f"✅ S3 UPLOAD SUCCESS: {key}")
    except Exception as e: logger.error(f"❌ S3 ERROR: {e}")

def download_and_read_shp(url, record_id):
    target_zip = os.path.join(TEMP_DIR, f"{record_id}.zip")
    extract_folder = os.path.join(TEMP_DIR, str(record_id))
    try:
        res = requests.get(url, headers=HEADERS, verify=False, timeout=60)
        res.raise_for_status()
        with open(target_zip, 'wb') as f: f.write(res.content)
        with zipfile.ZipFile(target_zip, 'r') as z: z.extractall(extract_folder)
        for root, _, files in os.walk(extract_folder):
            for file in files:
                if file.endswith(".shp"):
                    gdf = gpd.read_file(os.path.join(root, file), engine="pyogrio")
                    gdf = gdf.to_crs("EPSG:4326") if gdf.crs else gdf.set_crs("EPSG:4326")
                    return gdf
    except Exception as e: logger.warning(f"⚠️ Skip ID {record_id}: {e}")
    return None

# --- 3️⃣ MAIN PROCESS ---

def run_sync():
    start_time = time.time()
    if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR, exist_ok=True)

    try:
        # 1. PULL DATA (Limit 2000 untuk One-Shot)
        logger.info(f"📡 Requesting API Sinergy (Limit 2000)...")
        params = {'page': 1, 'limit': 2000}
        response = requests.get(API_BASE_URL, headers=HEADERS, params=params, verify=False, timeout=60)
        response.raise_for_status()
        
        json_res = response.json()
        raw_data = json_res.get('data', {}).get('data', [])
        if not raw_data: logger.error("⚠️ Data API Kosong."); return

        # 2. EXCEL NORMALIZATION (Sesuai Master Sinergy)
        logger.info(f"📊 Normalizing {len(raw_data)} records for Excel...")
        df_excel = pd.json_normalize(
            raw_data,
            record_path=['PermohonanTitik'],
            meta=['id', 'nmpmhn', 'nomor', 'tanggal', 'status'],
            errors='ignore'
        ).drop_duplicates(subset=['id'], keep='first')

        XLSX_PATH = os.path.join(FOLDER_DATA, "master_data_sinergy.xlsx")
        df_excel.to_excel(XLSX_PATH, index=False)
        upload_to_s3(XLSX_PATH, S3_XLSX_KEY)

        # 3. SPATIAL PROCESSING (Download & Extract)
        all_gdfs = []
        for idx, item in enumerate(raw_data, 1):
            record_id = item.get("id")
            titik = item.get("PermohonanTitik", [])
            if not titik or not titik[0].get("UpldShpl"): continue
            
            full_shp_url = f"{BASE_DOMAIN}{titik[0].get('UpldShpl')}"
            logger.info(f"[{idx}/{len(raw_data)}] Memproses Spasial ID: {record_id}")
            
            gdf_shp = download_and_read_shp(full_shp_url, record_id)
            if gdf_shp is not None:
                # Masukkan atribut API (Hanya tipe data dasar)
                for k, v in item.items():
                    if not isinstance(v, (list, dict)):
                        gdf_shp[k.upper()] = str(v) if v is not None else ""
                
                # Masukkan atribut khusus dari PermohonanTitik
                gdf_shp['LS_PRMN'] = titik[0].get('LsPrmn', 0)
                gdf_shp['KABUPATEN_API'] = str(titik[0].get('Kabupaten', ""))
                all_gdfs.append(gdf_shp)

        if not all_gdfs: logger.error("❌ Geometri tidak ditemukan."); return

        # 4. MERGE & CLEANUP (Fix Reindexing Error)
        logger.info("📦 Menggabungkan layer spasial...")
        # ignore_index=True menghapus duplikasi index dari file-file asal
        gdf_final = pd.concat(all_gdfs, ignore_index=True)
        
        # Hapus kolom duplikat nama (case-insensitive check)
        gdf_final.columns = [c.upper() for c in gdf_final.columns]
        gdf_final = gdf_final.loc[:, ~gdf_final.columns.duplicated()].copy()

        logger.info("🔧 Menormalisasi Geometri...")
        # Reset index secara eksplisit untuk menjamin keunikan objek index
        gdf_final = gdf_final.reset_index(drop=True)
        
        gdf_final['GEOMETRY'] = gdf_final['GEOMETRY'].apply(force_2d)
        gdf_final['GEOMETRY'] = gdf_final.geometry.make_valid()
        gdf_final['GEOMETRY'] = gdf_final['GEOMETRY'].apply(ensure_multipolygon)
        
        gdf_final = gdf_final.rename_geometry('geom').set_crs("EPSG:4326")

        # 5. POSTGIS LOAD
        engine = create_engine(connection_url)
        with engine.begin() as conn:
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TABLE_NAME}" CASCADE;'))
            logger.info(f"🐘 Mengirim {len(gdf_final)} row ke PostGIS...")
        
        gdf_final.to_postgis(name=TABLE_NAME, con=engine, schema=SCHEMA, if_exists='replace', index=False)

        # 6. GDB EXPORT
        GDB_NAME = f"{TABLE_NAME}.gdb"
        GDB_PATH = os.path.join(FOLDER_DATA, GDB_NAME)
        ZIP_GDB = f"{GDB_PATH}.zip"
        
        if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
        if os.path.exists(ZIP_GDB): os.remove(ZIP_GDB)

        try:
            logger.info(f"📦 Exporting to FileGeodatabase...")
            gdf_export = gdf_final.copy()
            
            # Drop kolom ID/FID/OBJECTID bawaan agar driver OpenFileGDB membuat FID baru (32-bit)
            cols_to_drop = [c for c in gdf_export.columns if c.upper() in ['ID', 'FID', 'OBJECTID']]
            gdf_export = gdf_export.drop(columns=cols_to_drop).reset_index(drop=True)

            # Final check nulls & types
            for col in gdf_export.columns:
                if col != 'geom':
                    if gdf_export[col].dtype == 'object':
                        gdf_export[col] = gdf_export[col].fillna('')
                    else:
                        gdf_export[col] = gdf_export[col].fillna(0)

            gdf_export.to_file(GDB_PATH, driver="OpenFileGDB", layer=TABLE_NAME, engine="pyogrio", index=False)
            
            # Zipping GDB Folder
            with zipfile.ZipFile(ZIP_GDB, 'w', zipfile.ZIP_DEFLATED) as z:
                for r, _, fs in os.walk(GDB_PATH):
                    for f in fs:
                        z.write(os.path.join(r, f), os.path.relpath(os.path.join(r, f), os.path.dirname(GDB_PATH)))
            
            upload_to_s3(ZIP_GDB)
            if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
            
        except Exception as export_err:
            logger.error(f"⚠️ Export GDB failed: {export_err}")

    except Exception as e:
        logger.error(f"❌ FATAL ERROR: {e}")
    finally:
        if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
        duration = time.time() - start_time
        logger.info(f"🏁 SELESAI | Durasi: {int(duration//60)}m {int(duration%60)}s")

if __name__ == "__main__":
    run_sync()
