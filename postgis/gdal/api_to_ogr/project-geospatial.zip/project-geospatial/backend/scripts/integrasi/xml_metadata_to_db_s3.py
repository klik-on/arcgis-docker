import os
import argparse
import boto3
from lxml import etree
from sqlalchemy import create_engine, text
from botocore.client import Config
from dotenv import load_dotenv

# --- 1️⃣ INISIALISASI ---
load_dotenv()
DB_URL = os.getenv("DATABASE_URL")
DB_SCHEMA = os.getenv("DB_SCHEMA", "datagis")
XSLT_PATH = os.getenv("XSLT_PATH", "/app/resources/metadata/Export/ISO19139_Full_Stack.xslt")

# --- 2️⃣ PROSES KONVERSI & SIMPAN ---
def process_xml(input_path):
    if not os.path.exists(input_path):
        print(f"❌ File tidak ditemukan: {input_path}"); return

    engine = create_engine(DB_URL)
    layer_name = os.path.basename(input_path).replace(".xml", "").replace("_metadata", "")

    try:
        print(f"📄 Membaca & Mengonversi: {input_path}")
        
        # A. Baca XML Mentah
        with open(input_path, 'rb') as f:
            xml_data = f.read()

        # B. Transformasi ke ISO Standard (PENTING)
        parser = etree.XMLParser(remove_blank_text=True, resolve_entities=True)
        xslt_doc = etree.parse(XSLT_PATH, parser)
        transform = etree.XSLT(xslt_doc)
        
        source_xml = etree.fromstring(xml_data)
        result_xml = transform(source_xml) # Transformasi terjadi di sini
        
        # C. Hasil Akhir (String XML ISO)
        xml_iso_str = etree.tostring(result_xml, encoding='unicode', pretty_print=True)

        # D. Simpan ke PostGIS
        with engine.begin() as conn:
            conn.execute(text(f"""
                INSERT INTO "{DB_SCHEMA}"."layer_metadata" (layer_name, metadata_iso)
                VALUES (:name, :xml)
                ON CONFLICT (layer_name) DO UPDATE SET 
                    metadata_iso = EXCLUDED.metadata_iso, 
                    updated_at = CURRENT_TIMESTAMP;
            """), {"name": layer_name, "xml": xml_iso_str})
        
        print(f"✅ SUKSES: Metadata '{layer_name}' telah dikonversi ke ISO & disimpan di DB.")

    except Exception as e:
        print(f"❌ ERROR: {e}")

# --- 3️⃣ ARGUMENT PARSER ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Convert XML to ISO and store in PostGIS")
    parser.add_argument("--input", required=True, help="Path ke file XML")
    
    args = parser.parse_args()
    process_xml(args.input)
