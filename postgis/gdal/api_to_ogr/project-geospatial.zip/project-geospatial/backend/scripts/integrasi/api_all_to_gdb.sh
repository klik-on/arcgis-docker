#!/bin/bash
set -e

IGT="${1:-ADM_KAB_KOTA}"   # Default IGT jika tidak diberikan parameter
DATA_DIR="/app/data"
CERT_FILE="$DATA_DIR/ssl/Chain_RootCA_Bundle.crt"

echo "🕒 Mulai proses: $(date)"
echo "🚀 Menjalankan api_all_to_geojson.py dengan IGT: $IGT"

if [ -f "$CERT_FILE" ]; then
  python3 api_all_to_geojson.py "$IGT" "$CERT_FILE"
else
  python3 api_all_to_geojson.py "$IGT"
fi

GEOJSON_PATH="$DATA_DIR/${IGT}.geojson"
GDB_PATH="$DATA_DIR/${IGT}.gdb"
ZIP_PATH="$DATA_DIR/${IGT}.gdb.zip"

# === Cek file GeoJSON ===
if [ ! -f "$GEOJSON_PATH" ]; then
  echo "❌ File GeoJSON tidak ditemukan di ${DATA_DIR}"
  exit 1
fi

# === Validasi dependencies ===
for cmd in ogr2ogr zip; do
  if ! command -v "$cmd" &> /dev/null; then
    echo "❌ Perintah '$cmd' tidak ditemukan. Pastikan sudah terinstal."
    exit 1
  fi
done

# === Atur LD_LIBRARY_PATH untuk FileGDB resmi ===
if [ -f "/usr/local/FileGDB_API/lib/libFileGDBAPI.so" ]; then
  export LD_LIBRARY_PATH="/usr/local/FileGDB_API/lib:${LD_LIBRARY_PATH:-}"
fi

# === Tentukan driver GDB ===
if ogrinfo --formats | grep -qE "FileGDB.*\(rw\+\)"; then
  DRIVER="FileGDB"
  echo "✅ Menggunakan driver GDAL resmi FileGDB"
elif ogrinfo --formats | grep -q "OpenFileGDB"; then
  DRIVER="OpenFileGDB"
  echo "⚠️ Driver FileGDB resmi tidak ditemukan. Fallback ke OpenFileGDB (read/write terbatas)"
else
  echo "❌ Tidak ada driver GDB yang tersedia di GDAL"
  exit 1
fi

# === Konversi GeoJSON → GDB ===
echo "🚀 Mengkonversi GeoJSON ke GDB dengan driver $DRIVER..."
export CPL_LOG=OFF

OGR_ARGS=(
  -f "$DRIVER"
  "$GDB_PATH"
  "$GEOJSON_PATH"
  -dim 2
  -nln "$IGT"
  -nlt PROMOTE_TO_MULTI
  -t_srs EPSG:4326
  --config OGR_ENABLE_CURVE_REDUCTION YES
  --config OGR_ORGANIZE_POLYGONS SKIP
)

if [ "$DRIVER" = "FileGDB" ]; then
  OGR_ARGS+=(-lco OVERWRITE=YES)
fi

ogr2ogr "${OGR_ARGS[@]}"

echo "✅ Konversi selesai. Hasil tersimpan di: $GDB_PATH"

# === Compress hasil ===
echo "📦 Membuat archive ZIP dari $GDB_PATH ..."
pushd "$DATA_DIR" > /dev/null
zip -r "$(basename "$ZIP_PATH")" "$(basename "$GDB_PATH")"
popd > /dev/null

echo "📦 Ukuran ZIP: $(du -h "$ZIP_PATH" | cut -f1)"

# === Cleanup sementara ===
echo "🧹 Menghapus folder $GDB_PATH dan file $GEOJSON_PATH ..."
rm -rf "$GDB_PATH"
rm -f "$GEOJSON_PATH"

echo "✅ Proses selesai! File ZIP tersedia di: $ZIP_PATH"
