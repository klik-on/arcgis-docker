import os
import sys
import pandas as pd
import geopandas as gpd
from sqlalchemy import create_engine, text
from shapely.geometry import Point
from dotenv import load_dotenv

# 1. Load Environment Variables
load_dotenv()

def check_connectivity():
    db_url = os.getenv("DATABASE_URL")
    schema = os.getenv("DB_SCHEMA", "datagis")
    
    print("--- 🔍 MEMULAI DIAGNOSA SISTEM API & DB ---")
    print(f"Target Host: {os.getenv('DB_HOST')}")
    print(f"Target Schema: {schema}")

    try:
        # 2. Inisialisasi Engine SQLAlchemy (Psycopg 3)
        engine = create_engine(db_url)
        
        # 3. Tes Koneksi Database & PostGIS
        with engine.connect() as conn:
            result = conn.execute(text("SELECT postgis_full_version();")).fetchone()
            print(f"✅ Database Terhubung!")
            print(f"✅ PostGIS Versi: {result[0][:50]}...")

            # Pastikan Schema Ada
            conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {schema};"))
            conn.commit()
            print(f"✅ Schema '{schema}' siap.")

        # 4. Simulasi Tarik Data API (Dummy Geodataframe)
        print("--- 🌐 SIMULASI TARIK DATA API ---")
        data = {
            'id': [1, 2],
            'nama_lokasi': ['Titik Pantau A', 'Titik Pantau B'],
            'latitude': [-6.1751, -6.2088],
            'longitude': [106.8272, 106.8456]
        }
        df = pd.DataFrame(data)
        
        # Konversi ke GeoDataFrame (CRS 4326 - WGS84)
        gdf = gpd.GeoDataFrame(
            df, 
            geometry=gpd.points_from_xy(df.longitude, df.latitude),
            crs="EPSG:4326"
        )
        print(f"✅ Berhasil membuat GeoDataFrame dengan {len(gdf)} baris.")

        # 5. Uji Coba Write ke Database
        print("--- 💾 UJI COBA PENULISAN DATA ---")
        # Kita gunakan skema dari .env
        table_name = "test_api_connection"
        
        gdf.to_postgis(
            table_name, 
            engine, 
            schema=schema, 
            if_exists='replace', 
            index=False
        )
        print(f"✅ Data berhasil ditulis ke tabel: {schema}.{table_name}")

        print("\n--- 🏁 DIAGNOSA SELESAI: SISTEM OPTIMAL ---")

    except Exception as e:
        print(f"\n❌ TERJADI ERROR: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    check_connectivity()
