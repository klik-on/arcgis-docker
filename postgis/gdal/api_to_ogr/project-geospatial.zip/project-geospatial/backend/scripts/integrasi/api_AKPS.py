#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import requests
import pyproj
import boto3
import geopandas as gpd
import pandas as pd
import urllib3
from sqlalchemy import create_engine, text, URL
from dotenv import load_dotenv
from botocore.client import Config
from shapely.wkb import loads, dumps

# --- 1️⃣ INISIALISASI & KONFIGURASI ---
load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
sys.stdout.reconfigure(line_buffering=True)

# Path Proj untuk Geopandas
proj_path = pyproj.datadir.get_data_dir()
os.environ['PROJ_LIB'] = proj_path

# Logging
LOG_FILE = "/app/data/akps_sync.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(LOG_FILE)]
)
logger = logging.getLogger("AKPS-SYNC")

# Koneksi Database
connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", "password00"),
    host=os.getenv("DB_HOST", "dbgis"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "gisdb")
)

SCHEMA = os.getenv("DB_SCHEMA", "datagis")
TABLE_NAME = "AKPS"
API_URL = "https://pkps.hutsos.kehutanan.go.id/api-sitroom/api/Jagarimba/akps_penomoran"
TEMP_DIR = "/app/data/temp_akps"
FOLDER_DATA = "/app/data"

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

# --- 2️⃣ UTILITY FUNCTIONS ---

def force_2d(geometry):
    """Membuang dimensi Z (altitude) agar konsisten 2D di PostGIS"""
    if geometry is None: return None
    if geometry.has_z:
        return loads(dumps(geometry, output_dimension=2))
    return geometry

def upload_to_s3(file_path):
    if not os.path.exists(file_path): return
    file_name = os.path.basename(file_path)
    try:
        s3_client = boto3.client(
            's3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER,
            aws_secret_access_key=S3_PASS, config=Config(signature_version='s3v4'), verify=False
        )
        s3_client.upload_file(file_path, S3_BUCKET, file_name)
        logger.info(f"✅ S3 UPLOAD SUCCESS: {file_name}")
    except Exception as e:
        logger.error(f"❌ S3 ERROR: {e}")

def download_and_read_shp(url, record_id):
    target_zip = os.path.join(TEMP_DIR, f"{record_id}.zip")
    extract_folder = os.path.join(TEMP_DIR, str(record_id))
    try:
        res = requests.get(url, verify=False, timeout=60)
        res.raise_for_status()
        with open(target_zip, 'wb') as f:
            f.write(res.content)
        with zipfile.ZipFile(target_zip, 'r') as z:
            z.extractall(extract_folder)
        for root, dirs, files in os.walk(extract_folder):
            for file in files:
                if file.endswith(".shp"):
                    shp_path = os.path.join(root, file)
                    gdf = gpd.read_file(shp_path)
                    if gdf.crs is None:
                        gdf.set_crs("EPSG:4326", inplace=True)
                    else:
                        gdf = gdf.to_crs("EPSG:4326")
                    return gdf
    except Exception as e:
        logger.warning(f"⚠️ Skip ID {record_id}: {e}")
    return None

# --- 3️⃣ MAIN PROCESS ---

def run_sync():
    start_time = time.time()
    if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR, exist_ok=True)

    try:
        logger.info(f"🔍 Mengambil data dari API AKPS...")
        response = requests.get(API_URL, verify=False, timeout=30)
        response.raise_for_status()
        data_list = response.json().get("data", [])
        
        if not data_list:
            logger.error("❌ API kosong."); return

        all_gdfs = []
        total = len(data_list)

        for idx, item in enumerate(data_list, 1):
            record_id = item.get("id")
            shp_url = item.get("shapefile")
            if not shp_url: continue

            logger.info(f"[{idx}/{total}] Memproses ID: {record_id}")
            gdf_shp = download_and_read_shp(shp_url, record_id)

            if gdf_shp is not None:
                # Inject semua field API ke GeoDataFrame
                for key, value in item.items():
                    if key != 'shapefile':
                        gdf_shp[key.upper()] = str(value) if value is not None else None
                all_gdfs.append(gdf_shp)

        if not all_gdfs:
            logger.error("❌ Tidak ada data spasial yang berhasil diproses."); return

        # MERGE DATA
        logger.info("📦 Menggabungkan layer spasial...")
        gdf_final = pd.concat(all_gdfs, ignore_index=True)
        
        # FIX KOORDINAT & DIMENSI
        logger.info("🔧 Menormalkan geometri ke 2D...")
        gdf_final['geometry'] = gdf_final['geometry'].apply(force_2d)
        gdf_final = gdf_final.rename_geometry('geom')
        gdf_final.set_crs("EPSG:4326", allow_override=True, inplace=True)

        # DATABASE LOAD
        engine = create_engine(connection_url)
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TABLE_NAME}" CASCADE;'))
            logger.info(f"🐘 Mengirim {len(gdf_final)} row ke PostGIS...")
            # Using engine directly to handle the GeoDataFrame
        
        gdf_final.to_postgis(name=TABLE_NAME, con=engine, schema=SCHEMA, if_exists='replace', index=False)

        # POST-LOAD OPTIMIZATION
        with engine.begin() as conn:
            conn.execute(text(f'CREATE INDEX idx_akps_geom ON "{SCHEMA}"."{TABLE_NAME}" USING GIST (geom);'))
            conn.execute(text(f'GRANT SELECT ON TABLE "{SCHEMA}"."{TABLE_NAME}" TO PUBLIC;'))

        # EXPORT TO GEOPACKAGE & S3
        GPKG_FILE = f"{TABLE_NAME}.gpkg"
        GPKG_PATH = os.path.join(FOLDER_DATA, GPKG_FILE)
        ZIP_OUT = os.path.join(FOLDER_DATA, f"{GPKG_FILE}.zip")

        if os.path.exists(GPKG_PATH): os.remove(GPKG_PATH)
        if os.path.exists(ZIP_OUT): os.remove(ZIP_OUT)

        try:
            logger.info(f"📦 Exporting to GeoPackage: {GPKG_FILE}")
            gdf_final.to_file(GPKG_PATH, driver="GPKG", layer=TABLE_NAME)
            
            with zipfile.ZipFile(ZIP_OUT, 'w', zipfile.ZIP_DEFLATED) as z:
                z.write(GPKG_PATH, GPKG_FILE)
            
            upload_to_s3(ZIP_OUT)
            if os.path.exists(GPKG_PATH): os.remove(GPKG_PATH) # Cleanup raw gpkg
            
        except Exception as export_err:
            logger.error(f"⚠️ Export to S3 failed, but PostGIS is updated: {export_err}")

    except Exception as e:
        logger.error(f"❌ FATAL ERROR: {e}")
    finally:
        if os.path.exists(TEMP_DIR): shutil.rmtree(TEMP_DIR)
        duration = time.time() - start_time
        logger.info(f"🏁 SELESAI | Durasi: {int(duration//60)}m {int(duration%60)}s")

if __name__ == "__main__":
    run_sync()
