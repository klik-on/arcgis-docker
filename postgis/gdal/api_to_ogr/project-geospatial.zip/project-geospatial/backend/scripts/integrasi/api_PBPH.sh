#!/bin/bash
# Daftar IGT yang ingin ditarik
LAYERS=("PERSETUJUAN_KOMITMEN_PBPH"  "PBPH_DEFINITIF")

for layer in "${LAYERS[@]}"
do
    echo "Processing layer: $layer"
    IGT=$layer python3 /app/scripts/integrasi/api_PBPH_with_S3.py
done
