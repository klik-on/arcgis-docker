#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import datetime
import random
import pyproj
import boto3
import pandas as pd
import geopandas as gpd
import requests
import urllib3
import warnings
from sqlalchemy import create_engine, text, URL
from dotenv import load_dotenv
from botocore.client import Config
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- 1️⃣ INISIALISASI LINGKUNGAN ---
load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning, module="pyogrio")
warnings.filterwarnings("ignore", category=UserWarning, module="pyogrio")

proj_path = pyproj.datadir.get_data_dir()
os.environ['PROJ_LIB'] = proj_path
sys.stdout.reconfigure(line_buffering=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("KUPS-POINT-INTEGRATION")

# Bounding Box Indonesia (Strict Filter)
INDONESIA_BOUNDS = {"xmin": 94.0, "ymin": -12.0, "xmax": 142.0, "ymax": 8.0}

# --- 2️⃣ KONFIGURASI DATABASE & S3 ---
connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", "password00"),
    host=os.getenv("DB_HOST", "dbgis"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "gisdb")
)

SCHEMA = os.getenv("DB_SCHEMA", "datagis")
TABLE_NAME = "KUPS"
API_URL = os.getenv("KUPS_API_URL", "https://gokups.hutsos.kehutanan.go.id/api/v1/kups")

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

FOLDER_DATA = "/app/data"
os.makedirs(FOLDER_DATA, exist_ok=True)

# --- 3️⃣ UTILITY: FETCH DATA API (PAGINATION) ---
def get_all_api_data(url):
    all_data = []
    page = 1
    session = requests.Session()
    retries = Retry(total=5, backoff_factor=2, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))

    while True:
        try:
            logger.info(f"🔍 Mengambil data halaman {page}...")
            res = session.get(f"{url}?page={page}&per_page=100", verify=False, timeout=60)
            if res.status_code == 429:
                logger.warning("⚠️ Rate limit 429. Cooling down...")
                time.sleep(random.uniform(30, 60)); continue
            res.raise_for_status()
            data = res.json()
            items = data.get("data", [])
            if not items: break
            all_data.extend(items)
            if not data.get("next_page_url"): break
            page += 1
            time.sleep(0.1) # Small delay to be polite to API
        except Exception as e:
            logger.error(f"❌ API Error: {e}"); break
    return all_data

# --- 4️⃣ MAIN PROCESS ---
def run_sync():
    start_proc = time.time()
    summary = {"total_api": 0, "berhasil": 0, "status_db": "Gagal"}
    
    # S3 Client Setup
    s3_client = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER,
                             aws_secret_access_key=S3_PASS, config=Config(signature_version='s3v4'), verify=False)
    date_folder = datetime.date.today().isoformat()
    s3_base_path = f"integrasi/KUPS/{date_folder}"

    try:
        raw_json = get_all_api_data(API_URL)
        if not raw_json:
            logger.error("❌ Data API kosong."); return

        summary["total_api"] = len(raw_json)

        # --- A. TRANSFORMATION (Point Data Handling) ---
        df_raw = pd.DataFrame(raw_json)
        df_raw = df_raw.drop_duplicates(subset=['id'], keep='first')
        
        # Konversi koordinat ke numerik
        df_raw['nujur'] = pd.to_numeric(df_raw['nujur'], errors='coerce')
        df_raw['lintang'] = pd.to_numeric(df_raw['lintang'], errors='coerce')
        df_raw = df_raw.dropna(subset=['nujur', 'lintang'])

        # Create GeoDataFrame
        gdf = gpd.GeoDataFrame(df_raw, geometry=gpd.points_from_xy(df_raw.nujur, df_raw.lintang), crs="EPSG:4326")
        
        # Filter Spasial (BBOX Indonesia)
        mask = (gdf.geometry.x >= INDONESIA_BOUNDS['xmin']) & (gdf.geometry.x <= INDONESIA_BOUNDS['xmax']) & \
               (gdf.geometry.y >= INDONESIA_BOUNDS['ymin']) & (gdf.geometry.y <= INDONESIA_BOUNDS['ymax'])
        gdf_final = gdf[mask].copy()

        # Standarisasi Kolom (Handle Case Sensitivity)
        gdf_final.columns = [c.upper() for c in gdf_final.columns]
        
        # FIX ERROR: Set geometry explicitly after column rename
        gdf_final = gdf_final.set_geometry('GEOMETRY')
        gdf_final = gdf_final.rename_geometry('geom')
        gdf_final = gdf_final.drop(columns=['NUJUR', 'LINTANG'], errors='ignore')
        
        # Simpan XLSX sebagai backup di S3
        XLSX_NAME = f"{TABLE_NAME}_Full.xlsx"
        XLSX_PATH = os.path.join(FOLDER_DATA, XLSX_NAME)
        gdf_final.drop(columns='geom').to_excel(XLSX_PATH, index=False)

        # --- B. DATABASE LOAD (PostGIS) ---
        engine = create_engine(connection_url)
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
            logger.info(f"💾 Mengirim {len(gdf_final)} data titik ke PostGIS...")
            
            # Load Temporary Table
            gdf_final.to_postgis("tmp_kups", conn, schema=SCHEMA, if_exists='replace', index=False)
            
            # Final Table Setup
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TABLE_NAME}" CASCADE;'))
            conn.execute(text(f'CREATE TABLE "{SCHEMA}"."{TABLE_NAME}" AS SELECT * FROM "{SCHEMA}"."tmp_kups";'))
            conn.execute(text(f'ALTER TABLE "{SCHEMA}"."{TABLE_NAME}" ADD PRIMARY KEY ("ID");'))
            conn.execute(text(f'CREATE INDEX idx_{TABLE_NAME.lower()}_geom ON "{SCHEMA}"."{TABLE_NAME}" USING GIST (geom);'))
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."tmp_kups";'))
            
            summary["status_db"] = "Sukses"
            summary["berhasil"] = len(gdf_final)

        # --- C. EXPORT & S3 UPLOAD ---
        GDB_PATH = os.path.join(FOLDER_DATA, f"{TABLE_NAME}.gdb")
        ZIP_NAME = f"{TABLE_NAME}.gdb.zip"
        ZIP_PATH = os.path.join(FOLDER_DATA, ZIP_NAME)

        if os.path.exists(GDB_PATH): shutil.rmtree(GDB_PATH)
        gdf_final.to_file(GDB_PATH, driver="OpenFileGDB", layer=TABLE_NAME, engine='pyogrio')

        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, _, files in os.walk(GDB_PATH):
                for file in files:
                    zf.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), os.path.dirname(GDB_PATH)))

        # S3 Versioning Upload
        s3_client.upload_file(XLSX_PATH, S3_BUCKET, f"{s3_base_path}/{XLSX_NAME}")
        s3_client.upload_file(ZIP_PATH, S3_BUCKET, f"{s3_base_path}/{ZIP_NAME}")

        # --- 🏁 REPORT ---
        duration = str(datetime.timedelta(seconds=round(time.time() - start_proc)))
        print("\n" + "="*60 + f"\n📊 SUMMARY REPORT - KUPS POINT INTEGRATION\n" + "="*60)
        print(f"✅ Total API Records     : {summary['total_api']}")
        print(f"🌍 Berhasil Masuk DB    : {summary['berhasil']}")
        print(f"💾 Status Database       : {summary['status_db']}")
        print(f"☁️  S3 Version Path       : {s3_base_path}")
        print(f"⏱️  Total Durasi          : {duration}\n" + "="*60)

    except Exception as e:
        logger.error(f"❌ FATAL ERROR: {e}", exc_info=True)
    finally:
        # --- 🧹 CLEANUP ---
        logger.info("🧹 Membersihkan residu lokal...")
        paths_to_clean = []
        if 'GDB_PATH' in locals(): paths_to_clean.append(GDB_PATH)
        if 'XLSX_PATH' in locals(): paths_to_clean.append(XLSX_PATH)
        if 'ZIP_PATH' in locals(): paths_to_clean.append(ZIP_PATH)
        
        for p in paths_to_clean:
            if os.path.exists(p):
                if os.path.isdir(p): shutil.rmtree(p)
                else: os.remove(p)

if __name__ == "__main__":
    run_sync()
