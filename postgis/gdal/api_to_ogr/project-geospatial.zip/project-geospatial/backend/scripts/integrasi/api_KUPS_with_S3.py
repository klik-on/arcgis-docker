#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import random
import pyproj
import boto3
import pandas as pd
import geopandas as gpd
import requests
import urllib3
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
from botocore.exceptions import ClientError
from botocore.client import Config

# --- 1️⃣ INISIALISASI PROJ (Path Statis) ---
OS_PROJ_PATH = '/usr/local/share/proj'
if os.path.exists(OS_PROJ_PATH):
    os.environ['PROJ_DATA'] = OS_PROJ_PATH
    pyproj.datadir.set_data_dir(OS_PROJ_PATH)
    os.environ['PROJ_LIB'] = OS_PROJ_PATH 
else:
    proj_path = pyproj.datadir.get_data_dir()
    os.environ['PROJ_LIB'] = proj_path
    os.environ['PROJ_DATA'] = proj_path

# --- 2️⃣ KONFIGURASI ENVIRONMENT & SSL ---
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
load_dotenv()

DB_URL = os.getenv("DATABASE_URL")
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
TABLE_NAME = os.getenv("KUPS_TABLE", "KUPS")
API_URL = os.getenv("KUPS_API_URL", "https://gokups.hutsos.kehutanan.go.id/api/v1/kups")

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")

FOLDER_PATH = "/app/data"
ZIP_PATH = os.path.join(FOLDER_PATH, f"{TABLE_NAME}.gdb.zip")
PROCESS_LOG = os.path.join(FOLDER_PATH, "kups_process.log")

os.makedirs(FOLDER_PATH, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(PROCESS_LOG, encoding="utf-8")
    ]
)
logger = logging.getLogger("KUPS-Sync")

# --- 3️⃣ UTILITY: S3 UPLOAD ---
def upload_to_s3(file_path):
    if not os.path.exists(file_path):
        logger.warning(f"⚠️ File {file_path} tidak ditemukan.")
        return

    logger.info(f"☁️ Memulai upload ke S3: {S3_BUCKET}/{TABLE_NAME}.gdb.zip...")
    s3_client = boto3.client(
        's3',
        endpoint_url=S3_ENDPOINT,
        aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS,
        config=Config(signature_version='s3v4'),
        region_name='us-east-1',
        verify=False
    )
    try:
        object_name = f"{TABLE_NAME}.gdb.zip"
        s3_client.upload_file(file_path, S3_BUCKET, object_name)
        logger.info(f"✅ S3 BACKUP SUCCESS")
    except Exception as e:
        logger.error(f"❌ S3 ERROR: {e}")

# --- 4️⃣ UTILITY: FETCH DATA ---
def get_all_api_data(url):
    all_data = []
    page = 1
    session = requests.Session()
    per_page = 100
    while True:
        try:
            full_url = f"{url}?page={page}&per_page={per_page}"
            res = session.get(full_url, verify=False, timeout=60)
            if res.status_code == 429:
                wait = random.uniform(20, 35)
                time.sleep(wait); continue
            res.raise_for_status()
            data = res.json()
            items = data.get("data", [])
            if not items: break
            all_data.extend(items)
            logger.info(f"📄 Halaman {page} sukses. Total data: {len(all_data)}")
            if not data.get("next_page_url"): break
            page += 1
            time.sleep(0.5)
        except Exception as e:
            logger.error(f"❌ Error API: {e}"); break
    return all_data

# --- 5️⃣ EKSEKUSI PROSES ---
start_proc = time.time()
logger.info(f"🚀 Memulai sinkronisasi Layer: {TABLE_NAME}")

raw_json = get_all_api_data(API_URL)
if not raw_json:
    logger.error("❌ Data API kosong."); sys.exit(1)

df_raw = pd.DataFrame(raw_json)
total_downloaded = len(df_raw)

# Transformasi Koordinat
df_raw['nujur'] = pd.to_numeric(df_raw['nujur'], errors='coerce')
df_raw['lintang'] = pd.to_numeric(df_raw['lintang'], errors='coerce')

# Simpan data tanpa koordinat untuk laporan
df_no_coord = df_raw[df_raw['nujur'].isna() | df_raw['lintang'].isna()].copy()
df_valid_coord = df_raw.dropna(subset=['nujur', 'lintang']).copy()

gdf = gpd.GeoDataFrame(
    df_valid_coord,
    geometry=gpd.points_from_xy(df_valid_coord['nujur'], df_valid_coord['lintang']),
    crs="EPSG:4326"
)

# Filter Batas RI (Bbox Indonesia)
mask_ri = (gdf.geometry.x >= 94.0) & (gdf.geometry.x <= 142.0) & \
          (gdf.geometry.y >= -12.0) & (gdf.geometry.y <= 7.0)

gdf_final = gdf[mask_ri].copy()
gdf_outside = gdf[~mask_ri].copy() # Data yang secara koordinat di luar RI
gdf_final = gdf_final.rename_geometry('geom')

# --- 6️⃣ EXPORT DATA ---
if not gdf_final.empty:
    gdf_final.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf_final.columns]
    gdf_final = gdf_final.drop(columns=['NUJUR', 'LINTANG'], errors='ignore')

    engine = create_engine(DB_URL)
    TEMP_TABLE = f"{TABLE_NAME.lower()}_temp"

    try:
        # PEMBERSIHAN AWAL
        logger.info(f"🧹 Membersihkan tabel temporary {TEMP_TABLE}...")
        with engine.begin() as conn:
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TEMP_TABLE}" CASCADE;'))
            conn.execute(text(f'DROP INDEX IF EXISTS "{SCHEMA}"."idx_{TEMP_TABLE}_geom";'))

        # 6a. Kirim data ke PostGIS
        logger.info(f"🐘 Mengirim {len(gdf_final)} data ke PostGIS...")
        gdf_final.to_postgis(
            name=TEMP_TABLE, 
            con=engine, 
            schema=SCHEMA, 
            if_exists='replace', 
            index=False,
            chunksize=1000
        )

        # 6b. Transaksi Atomic: Swap Table & Indexing Manual
        with engine.begin() as conn:
            idx_name = f"idx_{TABLE_NAME.lower()}_geom"
            conn.execute(text(f'DROP INDEX IF EXISTS "{SCHEMA}"."idx_{TEMP_TABLE}_geom";'))
            conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TABLE_NAME}" CASCADE;'))
            conn.execute(text(f'ALTER TABLE "{SCHEMA}"."{TEMP_TABLE}" RENAME TO "{TABLE_NAME}";'))

            logger.info(f"🏗️ Membuat index spasial {idx_name}...")
            conn.execute(text(f'CREATE INDEX "{idx_name}" ON "{SCHEMA}"."{TABLE_NAME}" USING GIST (geom);'))

        logger.info("⚡ Database PostGIS berhasil diperbarui.")

        # 6c. Pembuatan FileGDB & ZIP
        gdb_temp = os.path.join(FOLDER_PATH, f"{TABLE_NAME}_TEMP.gdb")
        if os.path.exists(gdb_temp): shutil.rmtree(gdb_temp)
        
        gdf_final.to_file(gdb_temp, driver="OpenFileGDB", layer=TABLE_NAME, engine='pyogrio')

        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(gdb_temp):
                for file in files:
                    z.write(os.path.join(root, file), os.path.join(f"{TABLE_NAME}.gdb", file))

        shutil.rmtree(gdb_temp)
        upload_to_s3(ZIP_PATH)

    except Exception as e:
        logger.error(f"❌ Proses Gagal: {e}"); sys.exit(1)

# --- 7️⃣ RINGKASAN AKHIR ---
duration = time.time() - start_proc
minutes, seconds = divmod(duration, 60)

print("\n" + "="*50)
print(f"SINKRONISASI KUPS SELESAI")
print("-" * 50)
print(f"TOTAL DATA API       : {total_downloaded}")
print(f"BERHASIL IMPORT      : {len(gdf_final)}")
print(f"KOORDINAT KOSONG     : {len(df_no_coord)}")
print(f"DI LUAR WILAYAH RI   : {len(gdf_outside)}")
print(f"TOTAL DURASI         : {int(minutes)}m {int(seconds)}s")
print(f"PROJ PATH            : {OS_PROJ_PATH}")
print("="*50 + "\n")
