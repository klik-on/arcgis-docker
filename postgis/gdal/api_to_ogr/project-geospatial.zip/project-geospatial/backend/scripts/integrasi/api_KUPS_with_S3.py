#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import random
import pyproj
import boto3
import pandas as pd
import geopandas as gpd
import requests
import urllib3
from sqlalchemy import create_engine, text, URL
from dotenv import load_dotenv
from botocore.client import Config
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- 1️⃣ INISIALISASI PROFIL PROJ ---
proj_path = pyproj.datadir.get_data_dir()
os.environ['PROJ_LIB'] = proj_path
os.environ['PROJ_DATA'] = proj_path

sys.stdout.reconfigure(line_buffering=True)

# --- 2️⃣ KONFIGURASI ENVIRONMENT ---
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
load_dotenv()

connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", ""),
    host=os.getenv("DB_HOST", "172.16.2.122"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "geodb")
)

SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
TABLE_NAME = os.getenv("KUPS_TABLE", "KUPS")
API_URL = os.getenv("KUPS_API_URL", "https://gokups.hutsos.kehutanan.go.id/api/v1/kups")

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")

FOLDER_PATH = "/app/data"
ZIP_PATH = os.path.join(FOLDER_PATH, f"{TABLE_NAME}.gdb.zip")
FAILED_DATA_CSV = os.path.join(FOLDER_PATH, f"{TABLE_NAME}_failed_rows.csv")
PROCESS_LOG = os.path.join(FOLDER_PATH, "kups_process.log")

os.makedirs(FOLDER_PATH, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(PROCESS_LOG, encoding="utf-8")]
)
logger = logging.getLogger("KUPS-Sync")

# --- 3️⃣ UTILITY: S3 UPLOAD ---
def upload_to_s3(file_path):
    if not os.path.exists(file_path): return
    file_name = os.path.basename(file_path)
    s3_config = Config(signature_version='s3v4', max_pool_connections=20, retries={'max_attempts': 5})
    s3_client = boto3.client(
        's3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS, config=s3_config, verify=False
    )
    try:
        s3_client.upload_file(file_path, S3_BUCKET, file_name)
        logger.info(f"✅ S3 UPLOAD SUCCESS: {file_name}")
    except Exception as e:
        logger.error(f"❌ S3 ERROR for {file_name}: {e}")

# --- 4️⃣ UTILITY: FETCH DATA API ---
def get_all_api_data(url):
    all_data = []
    page = 1
    session = requests.Session()
    retries = Retry(total=5, backoff_factor=2, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))

    while True:
        try:
            logger.info(f"🔍 Mengambil data halaman {page}...")
            res = session.get(f"{url}?page={page}&per_page=100", verify=False, timeout=45)

            if res.status_code == 429:
                logger.warning("⚠️ Rate limited (429). Menunggu jeda...")
                time.sleep(random.uniform(30, 60))
                continue

            res.raise_for_status()
            data = res.json()
            items = data.get("data", [])

            if not items: break

            all_data.extend(items)
            logger.info(f"📄 Halaman {page} terunduh. Akumulasi: {len(all_data)} record.")

            if not data.get("next_page_url"): break
            page += 1
            time.sleep(0.3)
        except Exception as e:
            logger.error(f"❌ API Fatal Error: {e}")
            break
    return all_data

# --- 5️⃣ TRANSFORMATION & AUDIT ---
start_proc = time.time()
raw_json = get_all_api_data(API_URL)

if not raw_json:
    logger.error("❌ Data API kosong. Proses berhenti.")
    sys.exit(1)

df_raw = pd.DataFrame(raw_json)
df_raw['nujur'] = pd.to_numeric(df_raw['nujur'], errors='coerce')
df_raw['lintang'] = pd.to_numeric(df_raw['lintang'], errors='coerce')

df_valid = df_raw.dropna(subset=['nujur', 'lintang']).copy()
gdf = gpd.GeoDataFrame(df_valid, geometry=gpd.points_from_xy(df_valid.nujur, df_valid.lintang), crs="EPSG:4326")

# Audit Spasial (Wilayah RI)
mask = (gdf.geometry.x >= 94.0) & (gdf.geometry.x <= 142.0) & (gdf.geometry.y >= -12.0) & (gdf.geometry.y <= 7.0)
gdf_final = gdf[mask].copy()
gdf_final = gdf_final.rename_geometry('geom')

# --- 6️⃣ DATABASE & EXPORT (DIRECT REPLACE) ---
if not gdf_final.empty:
    gdf_final.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf_final.columns]
    gdf_final = gdf_final.drop(columns=['NUJUR', 'LINTANG'], errors='ignore')

    engine = create_engine(connection_url, pool_size=10, max_overflow=20)
    
    try:
        # 6a. CREATE SCHEMA & CLEANUP INDEX
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
            logger.info(f"🐘 Mengirim {len(gdf_final)} data ke tabel {SCHEMA}.{TABLE_NAME} (REPLACE)...")

        # 6b. LOAD TO POSTGIS (DIRECT REPLACE)
        # Parameter if_exists='replace' akan men-drop tabel lama dan membuat yang baru
        gdf_final.to_postgis(name=TABLE_NAME, con=engine, schema=SCHEMA, if_exists='replace', index=False)

        # 6c. POST-LOAD: REBUILD INDEX & LOGGING
        with engine.begin() as conn:
            IDX_NAME = f"idx_{TABLE_NAME.lower()}_geom"
            logger.info(f"🏗️ Membangun index GIST: {IDX_NAME}...")
            conn.execute(text(f'DROP INDEX IF EXISTS "{SCHEMA}"."{IDX_NAME}";'))
            conn.execute(text(f'CREATE INDEX "{IDX_NAME}" ON "{SCHEMA}"."{TABLE_NAME}" USING GIST (geom);'))

            # Logging hasil sinkronisasi
            conn.execute(text(f'''
                CREATE TABLE IF NOT EXISTS "{SCHEMA}"."sync_logs" (
                    id SERIAL PRIMARY KEY,
                    task_name VARCHAR(100),
                    last_sync TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                    status VARCHAR(20),
                    total_data INTEGER,
                    duration VARCHAR(50)
                );
            '''))
            dur = time.time() - start_proc
            conn.execute(text(f'INSERT INTO "{SCHEMA}"."sync_logs" (task_name, last_sync, status, total_data, duration) VALUES (:n, NOW(), :s, :t, :d);'),
                         {"n": f"{TABLE_NAME}_SYNC", "s": "SUCCESS", "t": len(gdf_final), "d": f"{int(dur//60)}m {int(dur%60)}s"})

        # 6d. FILEGDB & ZIP
        gdb_path = os.path.join(FOLDER_PATH, f"{TABLE_NAME}.gdb")
        if os.path.exists(gdb_path): shutil.rmtree(gdb_path)

        logger.info("📦 Mengemas data ke dalam FileGDB & S3...")
        gdf_final.to_file(gdb_path, driver="OpenFileGDB", layer=TABLE_NAME, engine='pyogrio')

        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(gdb_path):
                for file in files:
                    z.write(os.path.join(root, file), os.path.join(f"{TABLE_NAME}.gdb", file))

        shutil.rmtree(gdb_path)
        upload_to_s3(ZIP_PATH)

    except Exception as e:
        logger.error(f"❌ Gagal pada proses Database/Export: {e}")
        sys.exit(1)

# --- 7️⃣ FINAL SUMMARY ---
duration = time.time() - start_proc
print(f"\n{'='*55}\n✅ SINKRONISASI SELESAI | Durasi: {int(duration//60)}m {int(duration%60)}s\n{'='*55}\n")
