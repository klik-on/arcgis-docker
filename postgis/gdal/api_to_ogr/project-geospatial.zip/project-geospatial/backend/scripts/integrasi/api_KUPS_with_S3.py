#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import random
import subprocess  # Tambahan untuk rclone
import pyproj

# 1️⃣ INISIALISASI PROJ (Wajib sebelum geopandas)
proj_path = pyproj.datadir.get_data_dir()
os.environ['PROJ_LIB'] = proj_path
os.environ['PROJ_DATA'] = proj_path

import pandas as pd
import geopandas as gpd
import requests
import urllib3
from datetime import datetime
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# --- 0. KONFIGURASI ENVIRONMENT & SSL ---
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- 1. INISIALISASI & KONFIGURASI ---
start_proc = time.time()
load_dotenv()

# Konfigurasi Database & API
DB_URL = os.getenv("DATABASE_URL")
SCHEMA = os.getenv("SCHEMA_DATA", "datagis")
TABLE_NAME = os.getenv("KUPS_TABLE", "KUPS")
API_URL = os.getenv("KUPS_API_URL", "https://gokups.hutsos.kehutanan.go.id/api/v1/kups")

# Kredensial S3 (MinIO)
S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")

# Path Folder Data
FOLDER_PATH = "/app/data"
ZIP_PATH = os.path.join(FOLDER_PATH, f"{TABLE_NAME}.gdb.zip")
PROCESS_LOG = os.path.join(FOLDER_PATH, "kups_process.log")

os.makedirs(FOLDER_PATH, exist_ok=True)

# Konfigurasi Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(PROCESS_LOG, encoding="utf-8")
    ]
)
logger = logging.getLogger("KUPS-Sync")

# --- 2. FUNGSI S3 BACKUP ---
def upload_to_s3(file_path):
    """Mengunggah file ke MinIO menggunakan Rclone bawaan container"""
    if not os.path.exists(file_path):
        logger.warning(f"⚠️ File {file_path} tidak ditemukan, membatalkan upload.")
        return

    logger.info(f"☁️ Memulai upload ke S3: {S3_BUCKET}/{TABLE_NAME}.gdb.zip...")
    
    cmd = [
        "rclone", "copyto", file_path, f":s3:{S3_BUCKET}/{TABLE_NAME}.gdb.zip",
        "--s3-provider=Minio",
        f"--s3-endpoint={S3_ENDPOINT}",
        f"--s3-access-key-id={S3_USER}",
        f"--s3-secret-access-key={S3_PASS}",
        "--s3-env-auth=false",
        "--s3-region=us-east-1"
    ]

    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        logger.info(f"✅ S3 BACKUP SUCCESS: Tersedia di bucket {S3_BUCKET}")
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ S3 BACKUP FAILED: {e.stderr}")

# --- 3. FUNGSI FETCH DATA (SMART RETRY) ---
def get_all_api_data(url):
    all_data = []
    page = 1
    session = requests.Session()
    per_page = 100

    while True:
        try:
            full_url = f"{url}?page={page}&per_page={per_page}"
            res = session.get(full_url, verify=False, timeout=60)

            if res.status_code == 429:
                wait = random.uniform(20, 35)
                logger.warning(f"⚠️ Limit 429 Terdeteksi. Menunggu {wait:.1f} detik...")
                time.sleep(wait); continue

            res.raise_for_status()
            data = res.json()
            items = data.get("data", [])

            if not items: break
            all_data.extend(items)
            logger.info(f"📄 Halaman {page} sukses. Total data: {len(all_data)}")

            if not data.get("next_page_url"): break
            page += 1
            time.sleep(0.5)

        except Exception as e:
            logger.error(f"❌ Error di halaman {page}: {e}")
            break
    return all_data

# --- 4. EKSEKUSI PROSES ---
logger.info(f"🚀 Memulai sinkronisasi Layer: {TABLE_NAME}")

raw_json = get_all_api_data(API_URL)
if not raw_json:
    logger.error("❌ Data API kosong. Proses dibatalkan.")
    sys.exit(1)

df_raw = pd.DataFrame(raw_json)
total_downloaded = len(df_raw)

# Transformasi & Filter
df_raw['nujur'] = pd.to_numeric(df_raw['nujur'], errors='coerce')
df_raw['lintang'] = pd.to_numeric(df_raw['lintang'], errors='coerce')
df_valid_coord = df_raw.dropna(subset=['nujur', 'lintang']).copy()
df_no_coord = df_raw[df_raw['nujur'].isna() | df_raw['lintang'].isna()].copy()

# Konversi ke GeoDataFrame
gdf = gpd.GeoDataFrame(
    df_valid_coord,
    geometry=gpd.points_from_xy(df_valid_coord['nujur'], df_valid_coord['lintang']),
    crs="EPSG:4326"
)

# Audit Spasial Batas RI
mask_ri = (gdf.geometry.x >= 94.0) & (gdf.geometry.x <= 142.0) & \
          (gdf.geometry.y >= -12.0) & (gdf.geometry.y <= 7.0)
gdf_final = gdf[mask_ri].copy()
gdf_outside = gdf[~mask_ri].copy()
gdf_final = gdf_final.rename_geometry('geom')

# --- 5. EXPORT DATA ---
if not gdf_final.empty:
    gdf_final.columns = [c.upper() if c.lower() != 'geom' else 'geom' for c in gdf_final.columns]
    gdf_final = gdf_final.drop(columns=['NUJUR', 'LINTANG'], errors='ignore')

    engine = create_engine(DB_URL)

    try:
        with engine.begin() as conn:
            conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))

        logger.info(f"🐘 Mengirim {len(gdf_final)} data valid ke PostGIS...")
        gdf_final.to_postgis(name=TABLE_NAME, con=engine, schema=SCHEMA, if_exists='replace', index=False)

        # Indeks Spasial
        with engine.begin() as conn:
            idx_name = f"idx_{TABLE_NAME.lower()}_geom"
            conn.execute(text(f'DROP INDEX IF EXISTS "{SCHEMA}"."{idx_name}";'))
            conn.execute(text(f'CREATE INDEX "{idx_name}" ON "{SCHEMA}"."{TABLE_NAME}" USING GIST (geom);'))

        logger.info("⚡ Database diperbarui.")

        # FileGDB & ZIP
        gdb_temp = os.path.join(FOLDER_PATH, f"{TABLE_NAME}_TEMP.gdb")
        if os.path.exists(gdb_temp): shutil.rmtree(gdb_temp)
        gdf_final.to_file(gdb_temp, driver="OpenFileGDB", layer=TABLE_NAME, engine='pyogrio')

        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(gdb_temp):
                for file in files:
                    arcname = os.path.join(f"{TABLE_NAME}.gdb", file)
                    z.write(os.path.join(root, file), arcname)

        shutil.rmtree(gdb_temp)
        logger.info(f"✅ ZIP Repository Created: {ZIP_PATH}")

        # --- TRIGGER S3 BACKUP ---
        upload_to_s3(ZIP_PATH)

    except Exception as e:
        logger.error(f"❌ Export Gagal: {e}")
        sys.exit(1)

# --- 6. RINGKASAN AKHIR ---
duration = time.time() - start_proc
minutes, seconds = divmod(duration, 60)

print("\n" + "="*50)
print(f"SINKRONISASI SELESAI")
print("-" * 50)
print(f"TOTAL API    : {total_downloaded}")
print(f"VALID        : {len(gdf_final)}")
print(f"INVALID/NaN  : {len(df_no_coord)}")
print(f"OUTSIDE      : {len(gdf_outside)}")
print(f"DURASI       : {int(minutes)}m {int(seconds)}s")
print("="*50 + "\n")
