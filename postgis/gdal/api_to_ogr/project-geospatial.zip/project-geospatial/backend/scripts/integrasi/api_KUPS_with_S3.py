#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile
import logging
import time
import random
import pyproj
import boto3
import pandas as pd
import geopandas as gpd
import requests
import urllib3
from sqlalchemy import create_engine, text, URL, Integer
from dotenv import load_dotenv
from botocore.client import Config
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Akses CLI
# docker exec -it geo-worker python3 /app/scripts/integrasi/api_KUPS_with_S3.py

# --- 1️⃣ INISIALISASI LINGKUNGAN ---
proj_path = pyproj.datadir.get_data_dir()
os.environ['PROJ_LIB'] = proj_path
os.environ['PROJ_DATA'] = proj_path

sys.stdout.reconfigure(line_buffering=True)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
load_dotenv()

# --- 2️⃣ KONFIGURASI DATABASE & S3 ---
connection_url = URL.create(
    drivername="postgresql+psycopg",
    username=os.getenv("DB_USER", "dbgis"),
    password=os.getenv("DB_PASS", "password00"),
    host=os.getenv("DB_HOST", "dbgis"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "gisdb")
)

SCHEMA = os.getenv("DB_SCHEMA", "datagis")
TABLE_NAME = os.getenv("KUPS_TABLE", "KUPS")
API_URL = os.getenv("KUPS_API_URL", "https://gokups.hutsos.kehutanan.go.id/api/v1/kups")

S3_USER = os.getenv("S3_USER")
S3_PASS = os.getenv("S3_PASS")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://geo-s3:9000")

FOLDER_PATH = "/app/data"
ZIP_PATH = os.path.join(FOLDER_PATH, f"{TABLE_NAME}.gdb.zip")
PROCESS_LOG = os.path.join(FOLDER_PATH, "kups_process.log")

os.makedirs(FOLDER_PATH, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(PROCESS_LOG, encoding="utf-8")]
)
logger = logging.getLogger("KUPS-Sync")

# --- 3️⃣ UTILITY: S3 UPLOAD ---
def upload_to_s3(file_path):
    if not os.path.exists(file_path): return
    file_name = os.path.basename(file_path)
    s3_config = Config(signature_version='s3v4', max_pool_connections=20, retries={'max_attempts': 5})
    s3_client = boto3.client(
        's3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER,
        aws_secret_access_key=S3_PASS, config=s3_config, verify=False
    )
    try:
        s3_client.upload_file(file_path, S3_BUCKET, file_name)
        logger.info(f"✅ S3 UPLOAD SUCCESS: {file_name}")
    except Exception as e:
        logger.error(f"❌ S3 ERROR for {file_name}: {e}")

# --- 4️⃣ UTILITY: FETCH DATA API ---
def get_all_api_data(url):
    all_data = []
    page = 1
    session = requests.Session()
    retries = Retry(total=5, backoff_factor=2, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))

    while True:
        try:
            logger.info(f"🔍 Mengambil data halaman {page}...")
            res = session.get(f"{url}?page={page}&per_page=100", verify=False, timeout=60)
            if res.status_code == 429:
                logger.warning("⚠️ Rate limited (429). Menunggu jeda...")
                time.sleep(random.uniform(30, 60)); continue
            res.raise_for_status()
            data = res.json()
            items = data.get("data", [])
            if not items: break
            all_data.extend(items)
            logger.info(f"📄 Halaman {page} terunduh. Akumulasi: {len(all_data)} record.")
            if not data.get("next_page_url"): break
            page += 1
            time.sleep(0.3)
        except Exception as e:
            logger.error(f"❌ API Fatal Error: {e}"); break
    return all_data

# --- 5️⃣ MAIN PROCESS ---
def run_sync():
    start_proc = time.time()
    raw_json = get_all_api_data(API_URL)
    if not raw_json:
        logger.error("❌ Data API kosong. Proses berhenti."); sys.exit(1)

    # A. Transformasi Data
    df_raw = pd.DataFrame(raw_json)
    if 'id' in df_raw.columns:
        df_raw = df_raw.drop_duplicates(subset=['id'], keep='first')

    df_raw['nujur'] = pd.to_numeric(df_raw['nujur'], errors='coerce')
    df_raw['lintang'] = pd.to_numeric(df_raw['lintang'], errors='coerce')

    df_valid = df_raw.dropna(subset=['nujur', 'lintang']).copy()
    gdf = gpd.GeoDataFrame(df_valid, geometry=gpd.points_from_xy(df_valid.nujur, df_valid.lintang), crs="EPSG:4326")

    # Filter wilayah RI
    mask = (gdf.geometry.x >= 90.0) & (gdf.geometry.x <= 142.0) & (gdf.geometry.y >= -12.0) & (gdf.geometry.y <= 9.0)
    gdf_final = gdf[mask].copy()

    # Standarisasi Kolom & Geometry
    gdf_final = gdf_final.reset_index(drop=True)
    gdf_final.insert(0, 'id_gid', gdf_final.index + 1)
    gdf_final.columns = [c.upper() for c in gdf_final.columns]
    gdf_final = gdf_final.set_geometry('GEOMETRY')
    gdf_final = gdf_final.rename_geometry('geom')
    gdf_final = gdf_final.drop(columns=['NUJUR', 'LINTANG'], errors='ignore')

    # B. Database Processing
    if not gdf_final.empty:
        engine = create_engine(connection_url, pool_size=10, max_overflow=20)
        try:
            # 1. Atomic Reset Schema
            with engine.begin() as conn:
                conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}";'))
                logger.info(f"🧹 Clean up: DROP TABLE {SCHEMA}.{TABLE_NAME} CASCADE")
                conn.execute(text(f'DROP TABLE IF EXISTS "{SCHEMA}"."{TABLE_NAME}" CASCADE;'))

            # 2. Bulk Load
            logger.info(f"🐘 Mengirim {len(gdf_final)} record ke PostGIS...")
            with engine.connect() as conn:
                gdf_final.to_postgis(name=TABLE_NAME, con=conn, schema=SCHEMA, if_exists='append', index=False, dtype={"ID_GID": Integer()})
                conn.commit()

            # 3. Post-Processing (Fix: Separate Commands for Psycopg 3)
            with engine.begin() as conn:
                logger.info("🏗️ Finalizing Database: PK, SRID, & GIST Index...")
                conn.execute(text(f'ALTER TABLE "{SCHEMA}"."{TABLE_NAME}" ADD PRIMARY KEY ("ID_GID");'))
                conn.execute(text(f"SELECT UpdateGeometrySRID('{SCHEMA}', '{TABLE_NAME}', 'geom', 4326);"))
                
                idx_name = f"idx_{TABLE_NAME.lower()}_geom"
                conn.execute(text(f'CREATE INDEX "{idx_name}" ON "{SCHEMA}"."{TABLE_NAME}" USING GIST (geom);'))
                conn.execute(text(f'GRANT SELECT ON TABLE "{SCHEMA}"."{TABLE_NAME}" TO PUBLIC;'))

                # --- HANDLING LOG TABLE SEPARATELY ---
                conn.execute(text(f'''
                    CREATE TABLE IF NOT EXISTS "{SCHEMA}"."sync_logs" (
                        id SERIAL PRIMARY KEY, 
                        task_name TEXT, 
                        last_sync TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                        status TEXT, 
                        total_data INTEGER, 
                        duration TEXT
                    );
                '''))

                dur_val = time.time() - start_proc
                conn.execute(text(f'''
                    INSERT INTO "{SCHEMA}"."sync_logs" (task_name, status, total_data, duration)
                    VALUES (:n, :s, :t, :d);
                '''), {
                    "n": f"{TABLE_NAME}_SYNC", 
                    "s": "SUCCESS", 
                    "t": len(gdf_final), 
                    "d": f"{int(dur_val//60)}m {int(dur_val%60)}s"
                })

            # C. Export FileGDB & S3
            gdb_path = os.path.join(FOLDER_PATH, f"{TABLE_NAME}.gdb")
            if os.path.exists(gdb_path): shutil.rmtree(gdb_path)

            logger.info("📦 Generating FileGDB & Zipping...")
            gdf_final.to_file(gdb_path, driver="OpenFileGDB", layer=TABLE_NAME, engine='pyogrio',
                              layer_options={'TARGET_ARCGIS_VERSION': 'ARCGIS_PRO_3_2_OR_LATER'})

            with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as z:
                for root, _, files in os.walk(gdb_path):
                    for file in files:
                        z.write(os.path.join(root, file), os.path.join(f"{TABLE_NAME}.gdb", file))

            shutil.rmtree(gdb_path)
            upload_to_s3(ZIP_PATH)

        except Exception as e:
            logger.error(f"❌ DATABASE/S3 ERROR: {e}"); sys.exit(1)

    duration = time.time() - start_proc
    logger.info(f"✅ SINKRONISASI SELESAI | Total: {len(gdf_final)} | Durasi: {int(duration//60)}m {int(duration%60)}s")

if __name__ == "__main__":
    run_sync()
