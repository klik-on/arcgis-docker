<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:import href="ArcGIS_2ISO19139gml32.xslt"/>
    
    <xsl:import href="../Stylesheets/ArcGIS_Imports/ArcGISmetadataPro.xslt"/>
    <xsl:import href="../Stylesheets/ArcGIS_Imports/generalPro.xslt"/>
    <xsl:import href="../Stylesheets/ArcGIS_Imports/codelistsPro.xslt"/>
    <xsl:import href="../Stylesheets/ArcGIS_Imports/auxLangCountryPro.xslt"/>
    
    <xsl:template match="/">
        <xsl:apply-imports/>
    </xsl:template>
</xsl:stylesheet>
