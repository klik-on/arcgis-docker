#!/usr/bin/env python3
import os
import subprocess
import logging
import signal
import pytz
from datetime import datetime
from celery import Celery
from celery.schedules import crontab
from celery.exceptions import SoftTimeLimitExceeded

# --- 1. KONFIGURASI LOGGING TERPUSAT ---
# Log utama worker diarahkan ke file yang sama agar bisa dipantau via API Dashboard
LOG_FILE = os.getenv("LOG_FILE_PATH", "/app/data/sync.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s [%(module)s]: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("geo-worker")

# --- 2. INISIALISASI CELERY ---
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)

app.conf.update(
    timezone='Asia/Jakarta',
    enable_utc=False,
    task_track_started=True,
    result_extended=True,
    # Keamanan Eksekusi (Hard limit 1 jam)
    task_time_limit=3600,          
    task_soft_time_limit=3550,     
    # Optimasi Resource GIS (Penting untuk mencegah Out-of-Memory)
    worker_prefetch_multiplier=1,  
    worker_max_tasks_per_child=10, # Restart worker process setiap 10 task untuk flush RAM
    broker_connection_retry_on_startup=True,
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json'
)

# --- 3. UTILS ---
def get_now():
    return datetime.now(pytz.timezone('Asia/Jakarta')).strftime('%Y-%m-%d %H:%M:%S')

# --- 4. TASK DEFINITIONS ---

@app.task(name="execute_geo_script", bind=True)
def execute_geo_script(self, script_name: str, args: list = None, env_vars: dict = None):
    """
    Worker task utama yang memanggil run_sync.sh untuk mengeksekusi .py atau .sh
    """
    scripts_dir = os.getenv("SCRIPTS_DIR", "/app/scripts")
    wrapper_path = os.path.join(scripts_dir, "run_sync.sh")
    target_script = os.path.join(scripts_dir, script_name.lstrip("/"))

    logger.info(f"--- CELERY TASK START: {self.request.id} ---")

    # 1. Validasi Keberadaan Wrapper & Skrip Target
    if not os.path.exists(wrapper_path):
        error_msg = f"Wrapper run_sync.sh tidak ditemukan di {wrapper_path}"
        logger.error(f"❌ {error_msg}")
        return {"status": "error", "message": error_msg}

    if not os.path.exists(target_script):
        error_msg = f"Skrip target tidak ditemukan: {target_script}"
        logger.error(f"❌ {error_msg}")
        return {"status": "error", "message": error_msg}

    # 2. Siapkan Command (Menggunakan Wrapper sebagai eksekutor utama)
    cmd = ["bash", wrapper_path, target_script]
    if args:
        cmd.extend([str(a) for a in args])

    # 3. Gabungkan Environment Variables
    full_env = os.environ.copy()
    if env_vars:
        full_env.update({k: str(v) for k, v in env_vars.items()})

    # Inject Task ID untuk tracking di dalam skrip
    full_env["CELERY_TASK_ID"] = self.request.id

    try:
        # 4. Eksekusi Subproses
        # os.setsid memastikan seluruh group proses (termasuk gdal/ogr child)
        # bisa dimatikan sekaligus jika task dibatalkan (Revoked).
        process = subprocess.run(
            cmd,
            env=full_env,
            capture_output=True,
            text=True,
            check=True,
            timeout=3500,
            preexec_fn=os.setsid
        )

        logger.info(f"✅ TASK COMPLETED: {script_name} ({self.request.id})")

        return {
            "status": "success",
            "executed_at": get_now(),
            "script": script_name,
            "stdout_summary": process.stdout[-1500:] if process.stdout else "Success with no output"
        }

    except SoftTimeLimitExceeded:
        logger.warning(f"⚠️ TIMEOUT: Task {self.request.id} melewati soft limit.")
        return {"status": "timeout", "message": "Eksekusi dihentikan karena batas waktu (1 jam)."}

    except subprocess.CalledProcessError as e:
        # Menangkap error dari run_sync.sh atau skrip di dalamnya
        err_out = e.stderr if e.stderr else e.stdout
        logger.error(f"❌ FAILED: Task {self.request.id} gagal dengan exit code {e.returncode}")
        return {
            "status": "failed",
            "exit_code": e.returncode,
            "error_detail": err_out[-1000:] if err_out else "Unknown error during execution"
        }

    except Exception as e:
        logger.critical(f"🚨 SYSTEM ERROR: {str(e)}")
        return {"status": "system_error", "message": str(e)}

    finally:
        logger.info(f"--- CELERY TASK END: {self.request.id} ---")

# --- 5. BEAT SCHEDULE (OTOMATISASI) ---
app.conf.beat_schedule = {
    'sync-kups-malam-hari': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0, hour=0), # 00:00 WIB
        'args': ('integrasi/api_KUPS_with_S3.py',),
    },
    'health-check-system-setiap-jam': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0), # Awal setiap jam
        'args': ('utils/health_check_gis.py',),
    },
    'rotasi-log-maintenance-minggu': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0, hour=3, day_of_week='sun'), # Minggu jam 03:00 pagi
        'args': ('utils/cleanup_old_logs.sh',), # Contoh file .sh baru
    }
}

# --- 6. SIGNAL HANDLING ---
def terminate_worker(signum, frame):
    logger.info("Worker shutting down... Cleaning up processes.")
    exit(0)

signal.signal(signal.SIGTERM, terminate_worker)
signal.signal(signal.SIGINT, terminate_worker)

if __name__ == "__main__":
    app.start()
