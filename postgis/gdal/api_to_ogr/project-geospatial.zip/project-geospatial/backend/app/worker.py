#!/usr/bin/env python3
import os
import subprocess
import logging
import signal
import pytz
from datetime import datetime
from celery import Celery
from celery.schedules import crontab
from celery.exceptions import SoftTimeLimitExceeded
from sqlalchemy import create_engine, text

# --- 1. KONFIGURASI LOGGING TERPUSAT ---
LOG_FILE = os.getenv("LOG_FILE_PATH", "/app/data/sync.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s [%(module)s]: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("geo-worker")

# --- 2. INISIALISASI CELERY & DATABASE ---
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
DATABASE_URL = os.getenv("DATABASE_URL")
app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)

engine = create_engine(DATABASE_URL, pool_pre_ping=True)

app.conf.update(
    timezone='Asia/Jakarta',
    enable_utc=False,
    task_track_started=True,
    result_extended=True,
    task_time_limit=3600,
    task_soft_time_limit=3550,
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=10,
    broker_connection_retry_on_startup=True,
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json'
)

# --- 3. UTILS ---
def get_now():
    return datetime.now(pytz.timezone('Asia/Jakarta')).strftime('%Y-%m-%d %H:%M:%S')

def log_to_file(msg):
    timestamp = datetime.now(pytz.timezone('Asia/Jakarta')).strftime('%Y-%m-%d %H:%M:%S')
    with open(LOG_FILE, "a") as f:
        f.write(f"[{timestamp}] [OPTIMIZER] {msg}\n")

# --- 4. TASK DEFINITIONS ---

@app.task(name="execute_geo_script", bind=True)
def execute_geo_script(self, script_name: str, args: list = None, env_vars: dict = None):
    scripts_dir = os.getenv("SCRIPTS_DIR", "/app/scripts")
    wrapper_path = os.path.join(scripts_dir, "run_sync.sh")
    target_script = os.path.join(scripts_dir, script_name.lstrip("/"))

    logger.info(f"--- CELERY TASK START: {self.request.id} ---")

    if not os.path.exists(wrapper_path):
        error_msg = f"Wrapper run_sync.sh tidak ditemukan di {wrapper_path}"
        logger.error(f"❌ {error_msg}")
        return {"status": "error", "message": error_msg}

    if not os.path.exists(target_script):
        error_msg = f"Skrip target tidak ditemukan: {target_script}"
        logger.error(f"❌ {error_msg}")
        return {"status": "error", "message": error_msg}

    cmd = ["bash", wrapper_path, target_script]
    if args:
        cmd.extend([str(a) for a in args])

    full_env = os.environ.copy()
    if env_vars:
        full_env.update({k: str(v) for k, v in env_vars.items()})

    full_env["CELERY_TASK_ID"] = self.request.id

    try:
        process = subprocess.run(
            cmd,
            env=full_env,
            capture_output=True,
            text=True,
            check=True,
            timeout=3500,
            preexec_fn=os.setsid
        )

        logger.info(f"✅ TASK COMPLETED: {script_name} ({self.request.id})")

        return {
            "status": "success",
            "executed_at": get_now(),
            "script": script_name,
            "stdout_summary": process.stdout[-1500:] if process.stdout else "Success"
        }

    except SoftTimeLimitExceeded:
        logger.warning(f"⚠️ TIMEOUT: Task {self.request.id} melewati soft limit.")
        return {"status": "timeout", "message": "Eksekusi dihentikan karena batas waktu."}

    except subprocess.CalledProcessError as e:
        err_out = e.stderr if e.stderr else e.stdout
        logger.error(f"❌ FAILED: Task {self.request.id} gagal dengan exit code {e.returncode}")
        return {
            "status": "failed",
            "exit_code": e.returncode,
            "error_detail": err_out[-1000:] if err_out else "Execution error"
        }
    except Exception as e:
        logger.critical(f"🚨 SYSTEM ERROR: {str(e)}")
        return {"status": "system_error", "message": str(e)}
    finally:
        logger.info(f"--- CELERY TASK END: {self.request.id} ---")

@app.task(name="optimize_geometry_task")
def optimize_geometry_task(source_schema, layer):
    """
    MODIFIED: Refresh jika sudah ada, Create jika belum ada. Tanpa DROP jika sudah eksis.
    """
    target_schema = f"{source_schema}_3857"
    view_full_name = f'"{target_schema}"."{layer}"'
    
    log_to_file(f"Checking status for {view_full_name}")
    
    try:
        with engine.begin() as conn: # Menggunakan transaction block
            # 1. Cek apakah MV sudah ada
            check_sql = text("""
                SELECT 1 FROM pg_matviews 
                WHERE schemaname = :s AND matviewname = :l
            """)
            exists = conn.execute(check_sql, {"s": target_schema, "l": layer}).fetchone()

            if exists:
                # AKSI A: REFRESH (Tanpa menghapus view yang ada)
                log_to_file(f"View exists. Refreshing data for {view_full_name}...")
                conn.execute(text(f"REFRESH MATERIALIZED VIEW {view_full_name};"))
                log_to_file(f"SUCCESS: Data in {view_full_name} refreshed.")
                return {"status": "refreshed", "layer": layer}

            else:
                # AKSI B: CREATE (Jika benar-benar baru)
                log_to_file(f"View not found. Creating new view {view_full_name}...")
                conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {target_schema};"))
                
                # Deteksi Primary Key Tabel Asal
                pk_query = text("""
                    SELECT a.column_name
                    FROM information_schema.key_column_usage a
                    JOIN information_schema.table_constraints b ON a.constraint_name = b.constraint_name
                    WHERE a.table_schema = :s AND a.table_name = :t AND b.constraint_type = 'PRIMARY KEY'
                    LIMIT 1
                """)
                pk_res = conn.execute(pk_query, {"s": source_schema, "t": layer}).fetchone()
                pk_col = pk_res[0] if pk_res else None

                # Ambil daftar kolom dinamis
                col_res = conn.execute(text(f"""
                    SELECT column_name FROM information_schema.columns 
                    WHERE table_schema = :s AND table_name = :t AND column_name != 'geom'
                """), {"s": source_schema, "t": layer})
                
                cols = [f'"{r[0]}"' for r in col_res]
                if not cols:
                    raise Exception(f"Source table {source_schema}.{layer} not found.")

                sql_create = f"""
                    CREATE MATERIALIZED VIEW {view_full_name} AS 
                    SELECT {", ".join(cols)}, ST_Transform(ST_MakeValid(geom), 3857)::geometry(Geometry, 3857) as geom 
                    FROM "{source_schema}"."{layer}";
                """
                conn.execute(text(sql_create))

                # Buat Unique Index untuk Identify Tool
                unique_col = pk_col
                if not unique_col:
                    potential_ids = [c.strip('"') for c in cols if c.lower().strip('"') in ['id', 'gid', 'objectid', 'ogc_fid']]
                    if potential_ids: unique_col = potential_ids[0]

                if unique_col:
                    idx_u_name = f"ux_{source_schema}_{layer.lower()}_id"
                    conn.execute(text(f'CREATE UNIQUE INDEX "{idx_u_name}" ON {view_full_name} ("{unique_col}");'))

                # Buat GIST Spatial Index
                idx_gist_name = f"idx_{source_schema}_{layer.lower()}_3857"
                conn.execute(text(f'CREATE INDEX "{idx_gist_name}" ON {view_full_name} USING GIST (geom);'))
                
                log_to_file(f"SUCCESS: {view_full_name} created and indexed.")
                return {"status": "created", "layer": layer}
        
    except Exception as e:
        log_to_file(f"ERROR: {str(e)}")
        logger.error(f"Optimization Task Failed: {str(e)}")
        return {"status": "error", "message": str(e)}

# --- 5. BEAT SCHEDULE ---
app.conf.beat_schedule = {
    'sync-kups-malam-hari': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0, hour=12),
        'args': ('integrasi/api_KUPS_with_S3.py',),
    },
    'health-check-system-setiap-jam': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0),
        'args': ('utils/health_check_gis.py',),
    }
}

# --- 6. SIGNAL HANDLING ---
def terminate_worker(signum, frame):
    logger.info("Worker shutting down...")
    exit(0)

signal.signal(signal.SIGTERM, terminate_worker)
signal.signal(signal.SIGINT, terminate_worker)

if __name__ == "__main__":
    app.start()
