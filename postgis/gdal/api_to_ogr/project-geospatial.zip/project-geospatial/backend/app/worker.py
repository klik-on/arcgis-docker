#!/usr/bin/env python3
import os
import subprocess
import logging
import signal
import pytz
import sys
import time
from datetime import datetime
from celery import Celery
from celery.schedules import crontab
from celery.exceptions import SoftTimeLimitExceeded
from sqlalchemy import create_engine

# 1. PATH CONFIGURATION
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'scripts')))
from utils.MVTOptimizeLayer import optimize_layer_logic

# 2. LOGGING TERPUSAT
LOG_FILE = os.getenv("LOG_FILE_PATH", "/app/data/sync.log")
log_dir = os.path.dirname(LOG_FILE)
os.makedirs(log_dir, exist_ok=True)

logger = logging.getLogger("geo-worker")
logger.setLevel(logging.INFO)

stream_handler = logging.StreamHandler()
stream_handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s: %(message)s"))
logger.addHandler(stream_handler)

if os.access(log_dir, os.W_OK):
    file_handler = logging.FileHandler(LOG_FILE)
    file_handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s [%(module)s]: %(message)s"))
    logger.addHandler(file_handler)

# 3. INISIALISASI CELERY & DATABASE
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
DATABASE_URL = os.getenv("DATABASE_URL")

if DATABASE_URL and DATABASE_URL.startswith("postgresql://") and "+psycopg" not in DATABASE_URL:
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)

app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)

engine = create_engine(DATABASE_URL, pool_size=5, max_overflow=10, pool_pre_ping=True)

app.conf.update(
    timezone='Asia/Jakarta',
    enable_utc=False,
    task_track_started=True,
    result_extended=True,
    task_time_limit=3600,
    worker_prefetch_multiplier=1,
    broker_connection_retry_on_startup=True
)

# 4. HELPER FUNCTIONS
def get_now():
    return datetime.now(pytz.timezone('Asia/Jakarta')).strftime('%Y-%m-%d %H:%M:%S')

def log_to_sync_file(msg):
    timestamp = get_now()
    try:
        with open(LOG_FILE, "a") as f:
            f.write(f"[{timestamp}] [WORKER_SYSTEM] {msg}\n")
    except: pass

# 5. TASK DEFINITIONS
@app.task(name="execute_geo_script", bind=True)
def execute_geo_script(self, script_name: str, args: list = None):
    scripts_dir = os.getenv("SCRIPTS_DIR", "/app/scripts")
    target_script = os.path.join(scripts_dir, script_name.lstrip("/"))

    if not os.path.exists(target_script):
        return {"status": "error", "message": f"Script {target_script} not found."}

    cmd = ["python3", "-u", target_script]
    if args: cmd.extend([str(a) for a in args])

    log_to_sync_file(f"🚀 Memulai: {script_name}")
    try:
        with open(LOG_FILE, "a") as log_out:
            process = subprocess.Popen(
                cmd, stdout=log_out, stderr=log_out,
                env={**os.environ, "PYTHONUNBUFFERED": "1"},
                text=True, bufsize=1
            )
            process.wait(timeout=3500)

        if process.returncode == 0:
            log_to_sync_file(f"✅ Selesai: {script_name}")
            return {"status": "success"}
        return {"status": "failed", "exit_code": process.returncode}
    except Exception as e:
        log_to_sync_file(f"🚨 Error {script_name}: {str(e)}")
        return {"status": "error", "message": str(e)}

@app.task(name="optimize_geometry_task")
def optimize_geometry_task(source_schema: str, layer: str):
    log_to_sync_file(f"🔄 Optimasi Layer: {source_schema}.{layer}")
    try:
        return optimize_layer_logic(engine, source_schema, layer, log_to_sync_file)
    except Exception as e:
        return {"status": "error", "message": str(e)}

# 6. BEAT SCHEDULE (LENGKAP: KUPS + PBPH + HEALTH)
app.conf.beat_schedule = {
    # --- KUPS FLOW ---
    'sync-kups-tengah-malam': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0, hour=0),
        'args': ('integrasi/api_KUPS_with_S3.py',),
    },
    'optimize-kups-after-sync': {
        'task': 'optimize_geometry_task',
        'schedule': crontab(minute=45, hour=0),
        'args': ('datagis', 'kups'),
    },

    # --- PBPH FLOW (DIPERTAHANKAN) ---
    'sync-pbph-dini-hari': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0, hour=1),
        'args': ('integrasi/api_PBPH_with_S3.py',),
    },
    'optimize-pbph-after-sync': {
        'task': 'optimize_geometry_task',
        'schedule': crontab(minute=45, hour=1),
        'args': ('datagis', 'pbph'),
    },

    # --- MAINTENANCE ---
    'health-check-hourly': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=30),
        'args': ('utils/health_check_gis.py',),
    }
}

if __name__ == "__main__":
    app.start()
