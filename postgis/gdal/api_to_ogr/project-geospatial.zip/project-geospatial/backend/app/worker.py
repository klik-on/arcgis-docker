import os
import subprocess
import logging
from celery import Celery
from celery.schedules import crontab
from celery.exceptions import SoftTimeLimitExceeded

# --- 1. Konfigurasi Logging ---
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s in %(module)s: %(message)s"
)
logger = logging.getLogger("geo-worker")

# --- 2. Inisialisasi Celery ---
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)

app.conf.update(
    timezone='Asia/Jakarta',
    enable_utc=False,
    task_track_started=True,
    result_extended=True,
    task_time_limit=3600,
    task_soft_time_limit=3550,
    worker_prefetch_multiplier=1,
    broker_connection_retry_on_startup=True
)

# --- 3. Penjadwalan Otomatis (Beat Schedule) ---
app.conf.beat_schedule = {
    'sync-kups-setiap-malam': {
        'task': 'execute_kups_sync',
        'schedule': crontab(minute=0, hour=0),  # Setiap jam 00:00 WIB
    },
}

# --- 4. Task Definitions ---

@app.task(name="execute_kups_sync")
def execute_kups_sync():
    """Task khusus untuk jadwal otomatis KUPS"""
    script_path = "/app/scripts/integrasi/api_KUPS_with_S3.py"
    logger.info("⏰ Memulai tugas rutin: Sinkronisasi KUPS Otomatis")
    try:
        # Menggunakan python3 langsung karena ini skrip spesifik
        result = subprocess.run(["python3", script_path], capture_output=True, text=True, timeout=3500)
        logger.info("✅ Tugas rutin KUPS selesai.")
        return result.stdout[-1000:] # Kirim summary ke Redis
    except Exception as e:
        logger.error(f"❌ Gagal dalam tugas rutin KUPS: {str(e)}")
        return str(e)

@app.task(name="execute_geo_script", bind=True)
def execute_geo_script(self, script_name: str, args: list = None, env_vars: dict = None):
    """Worker task fleksibel untuk menjalankan skrip apa pun via API/Frontend"""
    scripts_dir = os.getenv("SCRIPTS_DIR", "/app/scripts")
    wrapper_path = os.path.join(scripts_dir, "run_sync.sh")
    target_script = os.path.join(scripts_dir, script_name.lstrip("/"))

    if not os.path.exists(wrapper_path) or not os.path.exists(target_script):
        return {"status": "error", "message": "File skrip atau wrapper tidak ditemukan"}

    cmd = ["bash", wrapper_path, target_script]
    if args: cmd.extend([str(a) for a in args])

    full_env = os.environ.copy()
    if env_vars: full_env.update(env_vars)

    logger.info(f"🔄 Menjalankan Task ID {self.request.id}: {script_name}")

    try:
        process = subprocess.run(
            cmd, env=full_env, capture_output=True, text=True, check=True, timeout=3500
        )
        return {
            "status": "success",
            "task_id": self.request.id,
            "stdout_summary": process.stdout[-1000:] if process.stdout else "Success"
        }
    except SoftTimeLimitExceeded:
        return {"status": "timeout", "message": "Soft Limit tercapai"}
    except subprocess.CalledProcessError as e:
        return {"status": "failed", "stderr": e.stderr[-1000:] if e.stderr else "Error"}
    except Exception as e:
        return {"status": "system_error", "message": str(e)}
