#!/usr/bin/env python3
import os
import subprocess
import logging
import signal
import pytz
import sys
from datetime import datetime
from celery import Celery
from celery.schedules import crontab
from celery.exceptions import SoftTimeLimitExceeded
from sqlalchemy import create_engine, text

# Pastikan path ke folder scripts terdaftar
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'scripts')))
from utils.MVTOptimizeLayer import optimize_layer_logic

# --- 1. KONFIGURASI LOGGING TERPUSAT ---
LOG_FILE = os.getenv("LOG_FILE_PATH", "/app/data/sync.log")
log_dir = os.path.dirname(LOG_FILE)

try:
    os.makedirs(log_dir, exist_ok=True)
    can_write_log = os.access(log_dir, os.W_OK)
except Exception:
    can_write_log = False

# Handler Konfigurasi
file_handler = logging.FileHandler(LOG_FILE) if can_write_log else logging.NullHandler()
file_handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s [%(module)s]: %(message)s"))

stream_handler = logging.StreamHandler()
stream_handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s: %(message)s"))

logging.basicConfig(
    level=logging.INFO,
    handlers=[file_handler, stream_handler]
)
logger = logging.getLogger("geo-worker")

# Setup Logging untuk Celery Signals
from celery.signals import setup_logging
@setup_logging.connect
def config_loggers(*args, **kw):
    from logging import getLogger
    l = getLogger()
    if can_write_log:
        l.addHandler(file_handler)
    l.addHandler(stream_handler)

# --- 2. INISIALISASI CELERY & DATABASE ---
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
DATABASE_URL = os.getenv("DATABASE_URL")

if DATABASE_URL and DATABASE_URL.startswith("postgresql://") and "+psycopg" not in DATABASE_URL:
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)

app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)

engine = create_engine(
    DATABASE_URL,
    pool_size=10,
    max_overflow=20,
    pool_timeout=30,
    pool_recycle=1800,
    pool_pre_ping=True
)

app.conf.update(
    timezone='Asia/Jakarta',
    enable_utc=False,
    task_track_started=True,
    result_extended=True,
    task_time_limit=3600,
    task_soft_time_limit=3550,
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=10,
    broker_connection_retry_on_startup=True,
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json'
)

# --- 3. UTILS ---
def get_now():
    return datetime.now(pytz.timezone('Asia/Jakarta')).strftime('%Y-%m-%d %H:%M:%S')

def log_to_file(msg):
    timestamp = get_now()
    if can_write_log:
        try:
            with open(LOG_FILE, "a") as f:
                f.write(f"[{timestamp}] [OPTIMIZER] {msg}\n")
        except Exception as e:
            logger.error(f"Gagal menulis ke log file: {e}")
    else:
        logger.info(f"[OPTIMIZER - STDOUT ONLY] {msg}")

# --- 4. TASK DEFINITIONS ---

@app.task(name="execute_geo_script", bind=True)
def execute_geo_script(self, script_name: str, args: list = None, env_vars: dict = None):
    """
    Task untuk menjalankan script Python dengan streaming log real-time ke file.
    """
    scripts_dir = os.getenv("SCRIPTS_DIR", "/app/scripts")
    target_script = os.path.join(scripts_dir, script_name.lstrip("/"))

    logger.info(f"--- CELERY TASK START: {script_name} ({self.request.id}) ---")

    if not os.path.exists(target_script):
        error_msg = f"Skrip target tidak ditemukan: {target_script}"
        logger.error(f"❌ {error_msg}")
        return {"status": "error", "message": error_msg}

    # Gunakan python3 -u untuk unbuffered output
    cmd = ["python3", "-u", target_script]
    if args:
        cmd.extend([str(a) for a in args])

    # Injeksi Environment Variables untuk Real-time logging
    full_env = os.environ.copy()
    full_env["PYTHONUNBUFFERED"] = "1"
    if env_vars:
        full_env.update({k: str(v) for k, v in env_vars.items()})
    full_env["CELERY_TASK_ID"] = self.request.id

    try:
        # Buka file log dalam mode append untuk streaming langsung
        with open(LOG_FILE, "a") as log_out:
            log_out.write(f"\n[{get_now()}] [SYSTEM] Executing Script: {script_name}\n")
            log_out.flush()

            # Menggunakan Popen agar stdout/stderr langsung mengalir ke file
            process = subprocess.Popen(
                cmd,
                env=full_env,
                stdout=log_out,
                stderr=log_out,
                text=True,
                bufsize=1  # Line buffering
            )
            
            # Menunggu hingga proses selesai (dengan batas waktu timeout)
            process.wait(timeout=3500)

        if process.returncode == 0:
            logger.info(f"✅ TASK COMPLETED: {script_name}")
            return {
                "status": "success",
                "executed_at": get_now(),
                "script": script_name,
                "detail": "Proses selesai dengan sukses (Log tersimpan di sync.log)"
            }
        else:
            logger.error(f"❌ FAILED: {script_name} exit code {process.returncode}")
            return {"status": "failed", "exit_code": process.returncode}

    except subprocess.TimeoutExpired:
        process.kill()
        logger.warning(f"⚠️ TIMEOUT: Task {self.request.id} dihentikan paksa.")
        return {"status": "timeout", "message": "Eksekusi melewati batas waktu 1 jam."}
    except SoftTimeLimitExceeded:
        logger.warning(f"⚠️ SOFT TIMEOUT: Task {self.request.id}")
        return {"status": "timeout", "message": "Soft time limit reached."}
    except Exception as e:
        logger.critical(f"🚨 SYSTEM ERROR: {str(e)}")
        return {"status": "system_error", "message": str(e)}

@app.task(name="optimize_geometry_task")
def optimize_geometry_task(source_schema, layer):
    try:
        result = optimize_layer_logic(
            engine=engine,
            source_schema=source_schema,
            layer=layer,
            log_to_file_func=log_to_file
        )
        return result
    except Exception as e:
        logger.error(f"Optimization Task Failed: {str(e)}")
        log_to_file(f"TASK SYSTEM ERROR: {str(e)}")
        return {"status": "error", "message": str(e)}

# --- 5. BEAT SCHEDULE ---
app.conf.beat_schedule = {
    # --- KUPS FLOW ---
    'sync-kups-tengah-malam': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0, hour=0),
        'args': ('integrasi/api_KUPS_with_S3.py',),
    },
    'optimize-kups-after-sync': {
        'task': 'optimize_geometry_task',
        'schedule': crontab(minute=45, hour=0),
        'args': ('datagis', 'kups'),
    },

    # --- PBPH FLOW (DIPERTAHANKAN) ---
    'sync-pbph-dini-hari': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0, hour=1),
        'args': ('integrasi/api_PBPH_with_S3.py',),
    },
    'optimize-pbph-after-sync': {
        'task': 'optimize_geometry_task',
        'schedule': crontab(minute=45, hour=1),
        'args': ('datagis', 'pbph'),
    },

    # --- MAINTENANCE ---
    'health-check-hourly': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=30),
        'args': ('utils/health_check_gis.py',),
    }
}
# --- 6. SIGNAL HANDLING ---
def terminate_worker(signum, frame):
    logger.info("Worker shutting down...")
    engine.dispose()
    exit(0)

signal.signal(signal.SIGTERM, terminate_worker)
signal.signal(signal.SIGINT, terminate_worker)

if __name__ == "__main__":
    app.start()
