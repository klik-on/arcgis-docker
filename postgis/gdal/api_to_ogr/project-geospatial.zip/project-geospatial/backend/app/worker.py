#!/usr/bin/env python3
import os
import subprocess
import logging
import signal
import pytz
from datetime import datetime
from celery import Celery
from celery.schedules import crontab
from celery.exceptions import SoftTimeLimitExceeded
from sqlalchemy import create_engine, text

# --- 1. KONFIGURASI LOGGING TERPUSAT ---
LOG_FILE = os.getenv("LOG_FILE_PATH", "/app/data/sync.log")

# Pastikan folder log ada
log_dir = os.path.dirname(LOG_FILE)
try:
    os.makedirs(log_dir, exist_ok=True)
except Exception:
    pass

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s [%(module)s]: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE) if os.access(log_dir, os.W_OK) else logging.NullHandler(),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("geo-worker")

# --- 2. INISIALISASI CELERY & DATABASE ---
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
DATABASE_URL = os.getenv("DATABASE_URL")

# FIX: Injeksi Driver Psycopg 3 untuk kompatibilitas Python 3.13
if DATABASE_URL and DATABASE_URL.startswith("postgresql://") and "+psycopg" not in DATABASE_URL:
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)

app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)

# Gunakan pool yang optimal untuk pengolahan data spasial besar
engine = create_engine(
    DATABASE_URL,
    pool_size=10,
    max_overflow=20,
    pool_timeout=30,
    pool_recycle=1800,
    pool_pre_ping=True
)

app.conf.update(
    timezone='Asia/Jakarta',
    enable_utc=False,
    task_track_started=True,
    result_extended=True,
    task_time_limit=3600,        # Maksimal 1 jam per task
    task_soft_time_limit=3550,
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=10,
    broker_connection_retry_on_startup=True,
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json'
)

# --- 3. UTILS ---
def get_now():
    return datetime.now(pytz.timezone('Asia/Jakarta')).strftime('%Y-%m-%d %H:%M:%S')

def log_to_file(msg):
    timestamp = get_now()
    try:
        with open(LOG_FILE, "a") as f:
            f.write(f"[{timestamp}] [OPTIMIZER] {msg}\n")
    except Exception:
        logger.error(f"Gagal menulis ke log file: {msg}")

# --- 4. TASK DEFINITIONS ---

@app.task(name="execute_geo_script", bind=True)
def execute_geo_script(self, script_name: str, args: list = None, env_vars: dict = None):
    """
    Task general untuk menjalankan script Python geospasial.
    """
    scripts_dir = os.getenv("SCRIPTS_DIR", "/app/scripts")
    # Mencari skrip langsung jika wrapper tidak digunakan, atau sesuaikan path
    target_script = os.path.join(scripts_dir, script_name.lstrip("/"))

    logger.info(f"--- CELERY TASK START: {script_name} ({self.request.id}) ---")

    if not os.path.exists(target_script):
        error_msg = f"Skrip target tidak ditemukan: {target_script}"
        logger.error(f"❌ {error_msg}")
        return {"status": "error", "message": error_msg}

    # Menjalankan langsung dengan python3 untuk kompatibilitas lingkungan venv/docker
    cmd = ["python3", target_script]
    if args:
        cmd.extend([str(a) for a in args])

    full_env = os.environ.copy()
    if env_vars:
        full_env.update({k: str(v) for k, v in env_vars.items()})
    full_env["CELERY_TASK_ID"] = self.request.id

    try:
        process = subprocess.run(
            cmd,
            env=full_env,
            capture_output=True,
            text=True,
            check=True,
            timeout=3500
        )
        logger.info(f"✅ TASK COMPLETED: {script_name}")
        return {
            "status": "success",
            "executed_at": get_now(),
            "script": script_name,
            "stdout_summary": process.stdout[-1000:] if process.stdout else "Success"
        }
    except SoftTimeLimitExceeded:
        logger.warning(f"⚠️ TIMEOUT: Task {self.request.id} melewati soft limit.")
        return {"status": "timeout", "message": "Eksekusi dihentikan karena batas waktu."}
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ FAILED: {script_name} gagal dengan exit code {e.returncode}")
        return {"status": "failed", "error": e.stderr[-1000:] if e.stderr else "Error"}
    except Exception as e:
        logger.critical(f"🚨 SYSTEM ERROR: {str(e)}")
        return {"status": "system_error", "message": str(e)}

@app.task(name="optimize_geometry_task")
def optimize_geometry_task(source_schema, layer):
    """
    Task untuk me-refresh atau membuat Materialized View ST_Transform (EPSG:3857).
    """
    target_schema = f"{source_schema}_3857"
    view_full_name = f'"{target_schema}"."{layer}"'
    
    try:
        with engine.begin() as conn:
            # Refresh jika sudah ada, buat jika belum
            conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {target_schema};"))
            # Logic refresh/create simplified untuk brevity
            conn.execute(text(f"REFRESH MATERIALIZED VIEW CONCURRENTLY {view_full_name};"))
            return {"status": "refreshed", "layer": layer}
    except Exception as e:
        logger.error(f"Optimization Task Failed: {str(e)}")
        return {"status": "error", "message": str(e)}

# --- 5. BEAT SCHEDULE (JADWAL OTOMATIS) ---
app.conf.beat_schedule = {
    # 1. Sinkronisasi KUPS - Setiap Jam 00:00 Malam
    'sync-kups-tengah-malam': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0, hour=0),
        'args': ('integrasi/api_KUPS_with_S3.py',),
    },
    # 2. Sinkronisasi PBPH - Setiap Jam 01:00 Malam
    'sync-pbph-dini-hari': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=0, hour=1),
        'args': ('integrasi/api_PBPH_with_S3.py',),
    },
    # 3. Health Check GIS - Setiap Jam (Menit 30)
    'health-check-setiap-jam': {
        'task': 'execute_geo_script',
        'schedule': crontab(minute=30),
        'args': ('utils/health_check_gis.py',),
    }
}

# --- 6. SIGNAL HANDLING ---
def terminate_worker(signum, frame):
    logger.info("Worker shutting down...")
    exit(0)

signal.signal(signal.SIGTERM, terminate_worker)
signal.signal(signal.SIGINT, terminate_worker)

if __name__ == "__main__":
    app.start()
