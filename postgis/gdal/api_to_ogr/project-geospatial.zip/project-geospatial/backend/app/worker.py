import os
import subprocess
import logging
from celery import Celery
from celery.exceptions import SoftTimeLimitExceeded

# --- 1. Konfigurasi Logging Worker ---
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s in %(module)s: %(message)s"
)
logger = logging.getLogger("geo-worker")

# --- 2. Inisialisasi Celery ---
# Menggunakan hostname 'geo-redis' sesuai docker-compose
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")

app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)

app.conf.update(
    timezone='Asia/Jakarta',
    enable_utc=False,
    task_track_started=True,
    result_extended=True,
    task_time_limit=3600,             # Hard limit (1 jam)
    task_soft_time_limit=3550,        # Soft limit untuk cleanup internal
    worker_prefetch_multiplier=1,     # GIS Optimization: 1 task per worker process
    task_ignore_result=False,
    broker_connection_retry_on_startup=True
)

# --- 3. Task Definition ---

@app.task(name="execute_geo_script", bind=True)
def execute_geo_script(self, script_name: str, args: list = None, env_vars: dict = None):
    """
    Worker task untuk menjalankan script geospasial melalui wrapper run_sync.sh
    """
    scripts_dir = os.getenv("SCRIPTS_DIR", "/app/scripts")
    wrapper_path = os.path.join(scripts_dir, "run_sync.sh")
    target_script = os.path.join(scripts_dir, script_name.lstrip("/"))

    # 1. Validasi Keberadaan File Wrapper dan Target
    if not os.path.exists(wrapper_path):
        error_msg = f"Wrapper run_sync.sh tidak ditemukan di: {wrapper_path}"
        logger.error(error_msg)
        return {"status": "error", "message": error_msg}

    if not os.path.exists(target_script):
        error_msg = f"File skrip tidak ditemukan: {target_script}"
        logger.error(error_msg)
        return {"status": "error", "message": error_msg}

    # 2. Persiapkan Command
    cmd = ["bash", wrapper_path, target_script]
    if args:
        cmd.extend([str(a) for a in args])

    # 3. Gabungkan Environment Variables
    full_env = os.environ.copy()
    if env_vars:
        full_env.update(env_vars)

    logger.info(f"🔄 Executing Task ID {self.request.id}: {script_name}")

    try:
        # 4. Menjalankan Subprocess
        # capture_output=True menangkap hasil agar bisa disimpan di backend Celery (Redis)
        process = subprocess.run(
            cmd,
            env=full_env,
            capture_output=True,
            text=True,
            check=True,
            timeout=3500  # Sedikit di bawah soft limit Celery
        )

        logger.info(f"✅ Success: {script_name}")
        return {
            "status": "success",
            "task_id": self.request.id,
            "script": script_name,
            # Mengirim potongan output terakhir ke Redis untuk dipantau Dashboard
            "stdout_summary": process.stdout[-1000:] if process.stdout else "Success"
        }

    except SoftTimeLimitExceeded:
        logger.warning(f"⚠️ Soft Timeout exceeded for Task {self.request.id}")
        return {"status": "timeout", "message": "Task dihentikan karena batas waktu (Soft Limit)."}

    except subprocess.TimeoutExpired as e:
        logger.error(f"⌛ Task {self.request.id} HARD TIMEOUT")
        return {
            "status": "timeout",
            "task_id": self.request.id,
            "message": "Skrip melebihi batas waktu (Hard Timeout).",
            "stdout_partial": e.stdout[-500:] if e.stdout else ""
        }

    except subprocess.CalledProcessError as e:
        logger.error(f"💥 Failed {script_name} with exit code {e.returncode}")
        return {
            "status": "failed",
            "task_id": self.request.id,
            "exit_code": e.returncode,
            "stderr": e.stderr[-1000:] if e.stderr else "Error tanpa pesan detail."
        }

    except Exception as e:
        logger.error(f"⚠️ System Error: {str(e)}")
        return {
            "status": "system_error",
            "task_id": self.request.id,
            "message": str(e)
        }
