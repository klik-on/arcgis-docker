#!/usr/bin/env python3
import os
import logging
import json
import time
import pytz
from datetime import datetime
from typing import List, Optional, Dict

from fastapi import FastAPI, Depends, HTTPException, Security, Query
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, HTMLResponse
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from celery import Celery
from celery.result import AsyncResult

# --- 1. CONFIGURATION ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("geo-api")

DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("API_KEY", os.getenv("PGIS_API_TOKEN", "pgis-pass-2026"))
DATA_DIR = os.getenv("DATA_DIR", "/app/data/output_gdb")
SCRIPTS_DIR = os.getenv("SCRIPTS_DIR", "/app/scripts")
ROOT_PATH = os.getenv("ROOT_PATH", "/datagis")
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")

# Celery & Timezone
celery_app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)
jakarta_tz = pytz.timezone('Asia/Jakarta')

# --- 2. SCHEMAS ---
class ScriptRequest(BaseModel):
    script_name: str
    args: Optional[List[str]] = []
    env: Optional[Dict[str, str]] = {}

# --- 3. APP METADATA ---
tags_metadata = [
    {"name": "Status Sistem", "description": "Indeks API dan Pemeriksaan Kesehatan Infrastruktur."},
    {"name": "API Data Kehutanan", "description": "Eksplorasi Struktur Data, GeoJSON Spasial, & Tabel Atribut."},
    {"name": "Sinkronisasi Data Analisis", "description": "Geoprocessing Skrip & Kontrol Task ETL via Celery."},
    {"name": "Sistem", "description": "Portal Monitoring, Log Server, & Cleanup."},
]

app = FastAPI(
    title="Analisis Spasial berbasis API",
    description="### Enterprise Middleware v1.0.1\nIntegrasi PostGIS, Celery Worker, dan Monitoring Cloud Storage.",
    version="1.0.1",
    root_path=ROOT_PATH,
    openapi_tags=tags_metadata
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# --- 4. SECURITY ---
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)

async def get_api_key(
    header_key: Optional[str] = Security(api_key_header),
    query_key: Optional[str] = Query(None, alias="api_key")
):
    final_key = header_key or query_key
    if final_key == API_KEY:
        return final_key
    raise HTTPException(status_code=403, detail="Akses Ditolak: API Key tidak valid.")

# --- 5. DATABASE ENGINE ---
engine = create_engine(DATABASE_URL, pool_size=10, max_overflow=20, pool_pre_ping=True)

# --- 6. MODUL 0: INDEKS & STATUS SISTEM ---

@app.get("/api/v1", tags=["Status Sistem"])
async def api_v1_root():
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            db_status = "Connected (PostGIS Ready)"
    except Exception:
        db_status = "Disconnected"

    return {
        "status": "online",
        "service": "Analisis Spasial berbasis API",
        "version": "1.0.1",
        "server_time": datetime.now(jakarta_tz).isoformat(),
        "infrastructure": {
            "database": db_status,
            "broker": "Redis (Celery Active)",
            "storage_policy": "Cloud-First (Minio/Nextcloud)"
        }
    }

# --- 7. MODUL 1: API DATA KEHUTANAN ---

@app.get("/api/v1/layers/tree", tags=["API Data Kehutanan"])
async def get_layer_tree(_=Depends(get_api_key)):
    query = text("""
        SELECT table_schema, table_name FROM information_schema.tables
        WHERE table_schema NOT IN ('information_schema', 'pg_catalog', 'topology')
        AND table_type = 'BASE TABLE' ORDER BY table_schema, table_name;
    """)
    try:
        with engine.connect() as conn:
            result = conn.execute(query)
            tree = {}
            for row in result:
                schema, table = row[0], row[1]
                if schema not in tree: tree[schema] = []
                tree[schema].append(table)
            return {"status": "success", "repository": tree}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/layers/{schema_name}/{table_name}", tags=["API Data Kehutanan"])
async def get_spatial_layer(schema_name: str, table_name: str, limit: int = Query(1000), _=Depends(get_api_key)):
    def generate_geojson():
        yield '{"type": "FeatureCollection", "features": ['
        try:
            with engine.connect() as conn:
                geom_query = text("""
                    SELECT column_name FROM information_schema.columns
                    WHERE table_schema = :s AND table_name = :t
                    AND udt_name = 'geometry' LIMIT 1
                """)
                geom_col = conn.execute(geom_query, {"s": schema_name, "t": table_name}).scalar()

                if not geom_col:
                    yield f'], "error": "Geom not found"}}'
                    return

                query = text(f"""
                    SELECT jsonb_build_object(
                        'type', 'Feature',
                        'geometry', ST_AsGeoJSON("{geom_col}")::jsonb,
                        'properties', to_jsonb(t.*) - '{geom_col}'
                    ) FROM "{schema_name}"."{table_name}" AS t LIMIT :l
                """)
                result = conn.execution_options(stream_results=True).execute(query, {"l": limit})
                first = True
                for row in result:
                    if not first: yield ","
                    yield json.dumps(row[0])
                    first = False
        except Exception as e:
            yield f', "error": "{str(e)}"'
        yield ']}'
    return StreamingResponse(generate_geojson(), media_type="application/json")

# --- 8. MODUL 2: SINKRONISASI DATA (REDIS/CELERY) ---

@app.get("/api/v1/sync/scripts-tree", tags=["Sinkronisasi Data Analisis"])
async def get_scripts_tree(_=Depends(get_api_key)):
    if not os.path.exists(SCRIPTS_DIR): raise HTTPException(status_code=404, detail="Scripts folder missing.")
    tree = {}
    for root, _, files in os.walk(SCRIPTS_DIR):
        rel = os.path.relpath(root, SCRIPTS_DIR)
        curr = tree
        if rel != ".":
            for p in rel.split(os.sep): curr = curr.setdefault(p, {})
        valid = [f for f in files if f.endswith(('.py', '.sh'))]
        if valid: curr["_files"] = sorted(valid)
    return {"status": "success", "tree": tree}

@app.post("/api/v1/sync/run-script", tags=["Sinkronisasi Data Analisis"])
async def trigger_sync(req: ScriptRequest, _=Depends(get_api_key)):
    task = celery_app.send_task("execute_geo_script", args=[req.script_name, req.args, req.env])
    return {"status": "success", "task_id": task.id, "queued_at": datetime.now(jakarta_tz).isoformat()}

@app.get("/api/v1/sync/status/{task_id}", tags=["Sinkronisasi Data Analisis"])
async def get_task_status(task_id: str, _=Depends(get_api_key)):
    res = AsyncResult(task_id, app=celery_app)
    return {"task_id": task_id, "status": res.status, "ready": res.ready(), "result": res.result}

# --- 9. MODUL 3: SISTEM & MONITORING (UI ONLY) ---

@app.get("/api/v1/sync/files", response_class=HTMLResponse, tags=["Sistem"])
async def list_files_ui(api_key: str = Depends(get_api_key)):
    """UI Monitoring untuk melihat status file yang sudah diproses ke Cloud."""
    if not os.path.exists(DATA_DIR):
        return "<body style='font-family:sans-serif;padding:50px;text-align:center;'><h3>⚠️ Folder Output GDB Tidak Ditemukan</h3></body>"

    files = [f for f in os.listdir(DATA_DIR) if f.endswith(".zip")]
    files.sort(key=lambda x: os.path.getmtime(os.path.join(DATA_DIR, x)), reverse=True)

    rows = ""
    for f in files:
        f_path = os.path.join(DATA_DIR, f)
        f_size = f"{os.path.getsize(f_path) / (1024*1024):.2f} MB"
        f_time = datetime.fromtimestamp(os.path.getmtime(f_path), jakarta_tz).strftime('%d %b %Y, %H:%M')
        rows += f"""
        <tr>
            <td>
                <div style='display:flex; align-items:center;'>
                    <div style='font-size:24px; margin-right:15px;'>📦</div>
                    <div><div style='font-weight:600; color:#2d3748;'>{f}</div><div style='font-size:12px; color:#718096;'>Selesai: {f_time} WIB</div></div>
                </div>
            </td>
            <td><span style='background:#ebf8ff; color:#3182ce; padding:4px 8px; border-radius:4px; font-size:11px; font-weight:bold;'>{f_size}</span></td>
            <td style='text-align:right;'><span style='color:#38a169; font-size:12px; font-weight:600;'>✓ Synced to Cloud ☁️</span></td>
        </tr>"""

    return f"""
    <html><head><title>Geo-Monitor</title><style>
        body {{ font-family: 'Segoe UI', sans-serif; background: #f8fafc; margin: 0; padding: 40px; }}
        .container {{ max-width: 900px; margin: auto; background: white; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); overflow: hidden; }}
        .header {{ background: #1a202c; color: white; padding: 25px; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th {{ text-align: left; padding: 15px; border-bottom: 2px solid #edf2f7; color: #a0aec0; font-size: 11px; text-transform: uppercase; }}
        td {{ padding: 15px; border-bottom: 1px solid #f7fafc; }}
    </style></head>
    <body><div class='container'>
        <div class='header'><h2>🛰️ Geoprocessing Monitor</h2><p style='margin:0;opacity:0.8;'>Daftar task selesai yang telah dikirim ke Minio & Nextcloud</p></div>
        <div style='padding:20px;'><table><thead><tr><th>Output Layer</th><th>Ukuran</th><th style='text-align:right;'>Status Storage</th></tr></thead>
        <tbody>{rows if rows else '<tr><td colspan="3" style="text-align:center;padding:40px;color:#a0aec0;">Belum ada data tersedia.</td></tr>'}</tbody></table></div>
    </div></body></html>"""

@app.get("/api/v1/sync/logs", tags=["Sistem"])
async def get_logs(lines: int = 50, _=Depends(get_api_key)):
    log_file = "/app/data/sync.log"
    if not os.path.exists(log_file): return {"content": ["Log not found."]}
    with open(log_file, "r") as f: return {"content": [l.strip() for l in f.readlines()[-lines:]]}

@app.delete("/api/v1/sync/cleanup", tags=["Sistem"])
async def cleanup_old_files(days: int = 7, _=Depends(get_api_key)):
    now = time.time(); cutoff = now - (days * 86400)
    files = [f for f in os.listdir(DATA_DIR) if f.endswith(".zip") and os.path.getmtime(os.path.join(DATA_DIR, f)) < cutoff]
    for f in files: os.remove(os.path.join(DATA_DIR, f))
    return {"status": "success", "deleted": files}

@app.get("/health", tags=["Sistem"])
def health(): return {"status": "healthy", "version": "1.0.1"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
