#!/usr/bin/env python3
import os
import logging
import json
import time
import pytz
import subprocess
from datetime import datetime
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, Depends, HTTPException, Security, Query
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, PlainTextResponse, HTMLResponse
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from celery import Celery
from celery.result import AsyncResult

# --- 1. CONFIGURATION ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("geo-api")

# Environment Variables
DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("API_KEY", os.getenv("PGIS_API_TOKEN", "pgis-pass-2026"))
DATA_DIR = os.getenv("DATA_DIR", "/app/data/output_gdb")
SCRIPTS_DIR = os.getenv("SCRIPTS_DIR", "/app/scripts")
ROOT_PATH = os.getenv("ROOT_PATH", "/datagis")
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")

# Celery & Timezone
celery_app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)
jakarta_tz = pytz.timezone('Asia/Jakarta')

# --- 2. SCHEMAS ---
class ScriptRequest(BaseModel):
    script_name: str
    args: List[str] = []
    env: Dict[str, Any] = {}

# --- 3. SECURITY ---
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)

async def get_api_key(
    header_key: Optional[str] = Security(api_key_header),
    api_key: Optional[str] = Query(None)
):
    final_key = header_key or api_key
    if final_key == API_KEY:
        return final_key
    raise HTTPException(status_code=403, detail="Akses Ditolak: API Key tidak valid.")

# --- 4. APP METADATA ---
tags_metadata = [
    {"name": "Status Sistem", "description": "Pemeriksaan kesehatan infrastruktur dasar."},
    {"name": "API Data Kehutanan", "description": "Eksplorasi PostGIS & GeoJSON."},
    {"name": "Sinkronisasi Data Analisis", "description": "Orkestrasi geoprocessing via Celery."},
    {"name": "Sistem", "description": "Monitoring Stack GIS & Logs."},
]

app = FastAPI(
    title="Analisis Spasial berbasis API",
    description="### Enterprise Middleware v1.0.1\nIntegrasi PostGIS, Celery, S3/Minio, & Dashboard Mobile.",
    version="1.0.1",
    root_path=ROOT_PATH,
    openapi_tags=tags_metadata
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# --- 5. DATABASE ENGINE ---
engine = create_engine(DATABASE_URL, pool_size=10, max_overflow=20, pool_pre_ping=True)

# --- 6. ENDPOINTS ---

@app.get("/", response_class=HTMLResponse, tags=["Sistem"])
async def mobile_dashboard(api_key: Optional[str] = Query(None)):
    """Dashboard khusus tampilan HP untuk monitoring cepat"""
    now = datetime.now(jakarta_tz).strftime('%Y-%m-%d %H:%M:%S')
    return f"""
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>GeoAPI Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <style>
            .btn-card {{ transition: transform 0.2s; }}
            .btn-card:active {{ transform: scale(0.95); }}
        </style>
    </head>
    <body class="bg-slate-950 text-slate-200 font-sans min-h-screen">
        <div class="max-w-md mx-auto p-6">
            <header class="flex justify-between items-center mb-8">
                <div>
                    <h1 class="text-2xl font-extrabold text-emerald-400 tracking-tight">GeoAPI <span class="text-white">Ops</span></h1>
                    <p class="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Infrastruktur Spasial 2026</p>
                </div>
                <div class="h-2 w-2 bg-emerald-500 rounded-full animate-ping"></div>
            </header>

            <div class="grid grid-cols-2 gap-3 mb-8">
                <div class="bg-slate-900 p-4 rounded-2xl border border-slate-800 shadow-xl">
                    <p class="text-slate-500 text-[10px] uppercase font-bold mb-1">PostGIS</p>
                    <div class="flex items-center gap-2">
                        <span class="text-emerald-400 font-bold">Online</span>
                    </div>
                </div>
                <div class="bg-slate-900 p-4 rounded-2xl border border-slate-800 shadow-xl">
                    <p class="text-slate-500 text-[10px] uppercase font-bold mb-1">Redis/Celery</p>
                    <div class="flex items-center gap-2">
                        <span class="text-sky-400 font-bold">Active</span>
                    </div>
                </div>
            </div>

            <div class="space-y-4">
                <h2 class="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Quick Access</h2>
                
                <a href="{ROOT_PATH}/docs?api_key={api_key or ''}" class="btn-card flex items-center justify-between w-full bg-slate-900 p-4 rounded-xl border border-slate-800 hover:border-emerald-500/50">
                    <span class="font-medium text-slate-200">📑 API Documentation</span>
                    <span class="text-slate-500">→</span>
                </a>

                <a href="{ROOT_PATH}/api/v1/sync/logs?api_key={api_key or ''}&lines=50" class="btn-card flex items-center justify-between w-full bg-slate-900 p-4 rounded-xl border border-slate-800 hover:border-sky-500/50">
                    <span class="font-medium text-slate-200">📜 View System Logs</span>
                    <span class="text-slate-500">→</span>
                </a>

                <a href="{ROOT_PATH}/api/v1/sync/files?api_key={api_key or ''}" class="btn-card flex items-center justify-between w-full bg-slate-900 p-4 rounded-xl border border-slate-800 hover:border-amber-500/50">
                    <span class="font-medium text-slate-200">🛠️ Health Check GIS</span>
                    <span class="text-slate-500">→</span>
                </a>
            </div>

            <div class="mt-12 p-4 bg-emerald-500/5 rounded-2xl border border-emerald-500/10">
                <p class="text-[10px] text-center text-slate-500 font-mono">
                    Last Sync Check: {now}<br>
                    Root Path: {ROOT_PATH}
                </p>
            </div>
        </div>
    </body>
    </html>
    """

@app.get("/api/v1", tags=["Status Sistem"])
async def api_v1_root():
    return {
        "status": "online",
        "server_time": datetime.now(jakarta_tz).isoformat(),
        "infrastructure": {"database": "Connected", "broker": "Redis Active"}
    }

@app.get("/api/v1/layers/tree", tags=["API Data Kehutanan"])
async def get_layer_tree(_=Depends(get_api_key)):
    query = text("""
        SELECT table_schema, table_name FROM information_schema.tables
        WHERE table_schema NOT IN ('information_schema', 'pg_catalog', 'topology')
        AND table_type = 'BASE TABLE' ORDER BY table_schema, table_name;
    """)
    with engine.connect() as conn:
        result = conn.execute(query)
        tree = {}
        for row in result:
            if row[0] not in tree: tree[row[0]] = []
            tree[row[0]].append(row[1])
        return {"status": "success", "repository": tree}

@app.post("/api/v1/sync/run-script", tags=["Sinkronisasi Data Analisis"])
async def trigger_sync(req: ScriptRequest, _=Depends(get_api_key)):
    task = celery_app.send_task("execute_geo_script", args=[req.script_name, req.args, req.env])
    return {"status": "success", "task_id": task.id, "queued_at": datetime.now(jakarta_tz).isoformat()}

@app.get("/api/v1/sync/status/{task_id}", tags=["Sinkronisasi Data Analisis"])
async def get_task_status(task_id: str, _=Depends(get_api_key)):
    res = AsyncResult(task_id, app=celery_app)
    return {"task_id": task_id, "status": res.status, "ready": res.ready(), "result": res.result}

@app.get("/api/v1/sync/files", response_class=PlainTextResponse, tags=["Sistem"])
async def list_stack_gis(_=Depends(get_api_key)):
    script_path = os.path.join(SCRIPTS_DIR, "utils/health_check_gis.py")
    try:
        result = subprocess.run(["python3", script_path], capture_output=True, text=True, timeout=25)
        return result.stdout.strip() if result.returncode == 0 else result.stderr.strip()
    except Exception as e:
        return f"System Error: {str(e)}"

@app.get("/api/v1/sync/logs", tags=["Sistem"])
async def get_logs(lines: int = 50, _=Depends(get_api_key)):
    log_file = "/app/data/sync.log"
    if not os.path.exists(log_file): return {"content": ["Log not found."]}
    with open(log_file, "r") as f: 
        return {"content": [l.strip() for l in f.readlines()[-lines:]]}

@app.get("/health", tags=["Sistem"])
def health(): return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
