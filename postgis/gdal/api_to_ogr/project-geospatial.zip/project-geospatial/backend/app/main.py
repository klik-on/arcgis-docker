#!/usr/bin/env python3
import os
import logging
import json
import time
import pytz
import subprocess
from datetime import datetime
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, Depends, HTTPException, Security, Query
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, PlainTextResponse
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from celery import Celery
from celery.result import AsyncResult

# --- 1. CONFIGURATION ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("geo-api")

# Environment Variables
DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("API_KEY", os.getenv("PGIS_API_TOKEN", "pgis-pass-2026"))
DATA_DIR = os.getenv("DATA_DIR", "/app/data/output_gdb")
SCRIPTS_DIR = os.getenv("SCRIPTS_DIR", "/app/scripts")
ROOT_PATH = os.getenv("ROOT_PATH", "/datagis")
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")

# Celery & Timezone
celery_app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)
jakarta_tz = pytz.timezone('Asia/Jakarta')

# --- 2. SCHEMAS (Fix 422: Gunakan Any agar fleksibel) ---
class ScriptRequest(BaseModel):
    script_name: str
    args: List[str] = []
    env: Dict[str, Any] = {}

# --- 3. SECURITY (Fix 422: Sinkronisasi Header & Query) ---
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)

async def get_api_key(
    header_key: Optional[str] = Security(api_key_header),
    api_key: Optional[str] = Query(None)
):
    final_key = header_key or api_key
    if final_key == API_KEY:
        return final_key
    raise HTTPException(status_code=403, detail="Akses Ditolak: API Key tidak valid.")

# --- 4. APP METADATA ---
tags_metadata = [
    {"name": "Status Sistem", "description": "Pemeriksaan kesehatan infrastruktur dasar."},
    {"name": "API Data Kehutanan", "description": "Eksplorasi PostGIS & GeoJSON."},
    {"name": "Sinkronisasi Data Analisis", "description": "Orkestrasi geoprocessing via Celery."},
    {"name": "Sistem", "description": "Monitoring Stack GIS & Logs."},
]

app = FastAPI(
    title="Analisis Spasial berbasis API",
    description="### Enterprise Middleware v1.0.1\nIntegrasi PostGIS, Celery, S3/Minio, & Stack Monitoring.",
    version="1.0.1",
    root_path=ROOT_PATH,
    openapi_tags=tags_metadata
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# --- 5. DATABASE ENGINE ---
engine = create_engine(DATABASE_URL, pool_size=10, max_overflow=20, pool_pre_ping=True)

# --- 6. ENDPOINTS ---

@app.get("/api/v1", tags=["Status Sistem"])
async def api_v1_root():
    return {
        "status": "online",
        "server_time": datetime.now(jakarta_tz).isoformat(),
        "infrastructure": {"database": "Connected", "broker": "Redis Active"}
    }

@app.get("/api/v1/layers/tree", tags=["API Data Kehutanan"])
async def get_layer_tree(_=Depends(get_api_key)):
    query = text("""
        SELECT table_schema, table_name FROM information_schema.tables
        WHERE table_schema NOT IN ('information_schema', 'pg_catalog', 'topology')
        AND table_type = 'BASE TABLE' ORDER BY table_schema, table_name;
    """)
    with engine.connect() as conn:
        result = conn.execute(query)
        tree = {}
        for row in result:
            if row[0] not in tree: tree[row[0]] = []
            tree[row[0]].append(row[1])
        return {"status": "success", "repository": tree}

@app.post("/api/v1/sync/run-script", tags=["Sinkronisasi Data Analisis"])
async def trigger_sync(req: ScriptRequest, _=Depends(get_api_key)):
    # Task diserahkan ke Celery Worker
    task = celery_app.send_task("execute_geo_script", args=[req.script_name, req.args, req.env])
    return {"status": "success", "task_id": task.id, "queued_at": datetime.now(jakarta_tz).isoformat()}

@app.get("/api/v1/sync/status/{task_id}", tags=["Sinkronisasi Data Analisis"])
async def get_task_status(task_id: str, _=Depends(get_api_key)):
    res = AsyncResult(task_id, app=celery_app)
    return {"task_id": task_id, "status": res.status, "ready": res.ready(), "result": res.result}

@app.get("/api/v1/sync/files", response_class=PlainTextResponse, tags=["Sistem"])
async def list_stack_gis(_=Depends(get_api_key)):
    """Menampilkan output murni dari health_check_gis.py"""
    script_path = os.path.join(SCRIPTS_DIR, "utils/health_check_gis.py")
    try:
        result = subprocess.run(["python3", script_path], capture_output=True, text=True, timeout=25)
        return result.stdout.strip() if result.returncode == 0 else result.stderr.strip()
    except Exception as e:
        return f"System Error: {str(e)}"

@app.get("/api/v1/sync/logs", tags=["Sistem"])
async def get_logs(lines: int = 50, _=Depends(get_api_key)):
    log_file = "/app/data/sync.log"
    if not os.path.exists(log_file): return {"content": ["Log not found."]}
    with open(log_file, "r") as f: return {"content": [l.strip() for l in f.readlines()[-lines:]]}

@app.get("/health", tags=["Sistem"])
def health(): return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
