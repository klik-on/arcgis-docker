#!/usr/bin/env python3
import os
import logging
import pytz
import json
import subprocess
from datetime import datetime
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, Depends, HTTPException, Security, Query
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import HTMLResponse, ORJSONResponse, StreamingResponse, PlainTextResponse
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from celery import Celery
from celery.result import AsyncResult

# --- 1. CONFIGURATION ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("geo-api")

DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("API_KEY", "pgis-pass-2026")
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
ROOT_PATH = os.getenv("ROOT_PATH", "/datagis")
SCRIPTS_DIR = os.getenv("SCRIPTS_DIR", "/app/scripts")
# Tambahkan di sini agar semua konfigurasi path terkumpul jadi satu
LOG_FILE_PATH = os.getenv("LOG_FILE_PATH", "/app/data/sync.log")

# Celery & Timezone
celery_app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)
jakarta_tz = pytz.timezone('Asia/Jakarta')

# --- 2. SCHEMAS ---
class ScriptRequest(BaseModel):
    script_name: str
    args: List[str] = []
    env: Dict[str, Any] = {}

# --- 3. SECURITY ---
api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)

async def get_api_key(
    header_key: Optional[str] = Security(api_key_header),
    api_key: Optional[str] = Query(None)
):
    final_key = header_key or api_key
    if final_key == API_KEY:
        return final_key
    raise HTTPException(status_code=403, detail="Akses Ditolak: API Key tidak valid.")

# --- 4. APP INITIALIZATION ---
app = FastAPI(
    title="Analisis Spasial berbasis API",
    description="### Dashboard Monitoring IGT\nSpasial Analisis berbasis API .",
    version="1.0.1",
    root_path=ROOT_PATH,
    default_response_class=ORJSONResponse
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# Mengaktifkan Kompresi GZip untuk Data Spasial
app.add_middleware(GZipMiddleware, minimum_size=1000)

# --- 5. DATABASE ENGINE ---
engine = create_engine(DATABASE_URL, pool_size=15, max_overflow=25, pool_pre_ping=True)

# --- 6. UTILS & STREAMING LOGIC ---
def run_health_check():
    """Helper function to run the external GIS health check script."""
    script_path = os.path.join(SCRIPTS_DIR, "utils/health_check_gis.py")
    try:
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True,
            timeout=15
        )
        is_healthy = result.returncode == 0
        return is_healthy, result.stdout if is_healthy else result.stderr
    except Exception as e:
        return False, f"Kesalahan Eksekusi: {str(e)}"

def generate_igt_json(result, layer_name, offset):
    yield '{"status": "success", "layer": "' + layer_name + '", "results": ['
    first = True
    for row in result:
        row_dict = dict(row._mapping)
        for col in ["geom", "geometry"]:
            if col in row_dict: del row_dict[col]

        if "geometry_json" in row_dict and isinstance(row_dict["geometry_json"], str):
            row_dict["geometry_json"] = json.loads(row_dict["geometry_json"])

        chunk = ("" if first else ",") + json.dumps(row_dict)
        yield chunk
        first = False
    yield '], "offset": ' + str(offset) + '}'

# --- 7. ENDPOINTS ---

@app.get("/", response_class=HTMLResponse, tags=["Sistem"])
async def dashboard_info(api_key: Optional[str] = Query(None)):
    """
    Endpoint Root: Menampilkan Dashboard UI berbasis hasil health check.
    """
    is_healthy, status_output = run_health_check()
    status_color = "#10b981" if is_healthy else "#ef4444"
    status_label = "HEALTHY" if is_healthy else "UNHEALTHY / ERROR"

    return f"""
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>GeoAPI Ops Center</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-slate-950 text-slate-200 font-sans min-h-screen flex items-center justify-center p-4">
        <div class="max-w-2xl w-full bg-slate-900 border border-slate-800 rounded-[2.5rem] p-8 shadow-2xl transition-all hover:border-slate-700">
            <header class="flex justify-between items-start mb-8">
                <div>
                    <h1 class="text-2xl font-black text-white tracking-tighter uppercase leading-none">GeoAPI <span class="text-emerald-500">Ops</span></h1>
                    <p class="text-[9px] text-slate-500 uppercase tracking-[0.2em] font-bold mt-1">Real-time System Audit</p>
                </div>
                <div class="px-3 py-1 rounded-full text-[9px] font-black uppercase border" style="background-color: {status_color}10; color: {status_color}; border-color: {status_color}40">
                    ● {status_label}
                </div>
            </header>

            <div class="bg-black/40 rounded-3xl p-5 border border-slate-800/50 mb-8">
                <div class="flex items-center gap-2 mb-3 text-slate-500">
                    <div class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span class="text-[10px] font-bold uppercase tracking-widest">Health Check Logs (v2026)</span>
                </div>
                <pre class="font-mono text-[11px] text-emerald-400/90 whitespace-pre-wrap leading-relaxed">{status_output or "No output generated."}</pre>
            </div>

            <div class="grid grid-cols-2 gap-3">
                <a href="{ROOT_PATH}/docs?api_key={api_key or ''}" class="bg-blue-600 hover:bg-blue-500 text-white text-center py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all">
                    Open API Specs
                </a>
                <button onclick="window.location.reload()" class="bg-slate-800 hover:bg-slate-700 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all border border-slate-700">
                    Refresh System
                </button>
            </div>
        </div>
    </body>
    </html>
    """

@app.get("/health", tags=["Sistem"], summary="Arsitektur Sistem")
def health():
    """
    Endpoint Health Check: Menjalankan audit Geospatial Stack dan mengembalikan detail JSON.
    """
    is_healthy, status_output = run_health_check()
    
    return {
        "status": "healthy" if is_healthy else "unhealthy",
        "engine": "streaming",
        "compression": "gzip",
        "timestamp": datetime.now(jakarta_tz).isoformat(),
        "audit_logs": status_output.strip().split('\n')
    }

@app.get("/api/v1/IGT", tags=["Layanan Data IGT"], summary="Ambil Data Geospasial")
async def ambil_data_igt(
    layer: str = Query(..., description="Contoh: KUPS, ADM_KAB_KOTA"),
    schema: str = Query("datagis"),
    limit: int = Query(5, ge=1, le=100000),
    offset: int = Query(0, ge=0),
    _=Depends(get_api_key)
):
    """
    Keterangan: Mengambil data atribut dan geometri dari database.
    """
    layer_name = layer.upper()
    try:
        conn = engine.connect()
        detect_query = text(f"""
            SELECT column_name FROM information_schema.columns
            WHERE table_schema = :s AND table_name = :l
            AND column_name IN ('geom', 'geometry') LIMIT 1;
        """)
        geom_res = conn.execute(detect_query, {"s": schema, "l": layer_name}).fetchone()
        geom_col = geom_res[0] if geom_res else None

        if geom_col:
            sql = f'SELECT *, ST_AsGeoJSON("{geom_col}")::json as geometry_json FROM {schema}."{layer_name}" LIMIT :limit OFFSET :offset'
        else:
            sql = f'SELECT * FROM {schema}."{layer_name}" LIMIT :limit OFFSET :offset'

        result = conn.execution_options(stream_results=True).execute(text(sql), {"limit": limit, "offset": offset})

        return StreamingResponse(
            generate_igt_json(result, layer_name, offset),
            media_type="application/json"
        )
    except Exception as e:
        logger.error(f"IGT Error: {str(e)}")
        raise HTTPException(status_code=404, detail=f"Layer '{layer_name}' tidak dapat diakses.")

@app.get("/api/v1/layers/tree", tags=["Layanan Data IGT"], summary="Struktur Dataset IGT")
async def list_layer_tree(_=Depends(get_api_key)):
    """
    Mendapatkan struktur pohon (tree) dari semua tabel di database.
    """
    query = text("""
        SELECT table_schema, table_name FROM information_schema.tables
        WHERE table_schema NOT IN ('information_schema', 'pg_catalog', 'topology')
        AND table_type = 'BASE TABLE' ORDER BY table_schema, table_name;
    """)
    with engine.connect() as conn:
        result = conn.execute(query)
        tree = {}
        for row in result:
            if row[0] not in tree: tree[row[0]] = []
            tree[row[0]].append(row[1])
        return {"status": "success", "repository": tree}

@app.post("/api/v1/sync/run-script", tags=["Sinkronisasi Data Analisis"], summary="Contoh Skrip: integrasi/api_PBPH_with_S3.py")
async def trigger_sync(req: ScriptRequest, _=Depends(get_api_key)):
    task = celery_app.send_task("execute_geo_script", args=[req.script_name, req.args, req.env])
    return {"status": "success", "task_id": task.id, "queued_at": datetime.now(jakarta_tz).isoformat()}

@app.get("/api/v1/sync/status/{task_id}", tags=["Sinkronisasi Data Analisis"])
async def get_task_status(task_id: str, _=Depends(get_api_key)):
    res = AsyncResult(task_id, app=celery_app)
    return {"task_id": task_id, "status": res.status, "ready": res.ready(), "result": res.result}

@app.get("/api/v1/sync/logs", tags=["Sinkronisasi Data Analisis"], summary="Logs Aktivitas Proses")
async def get_logs(lines: int = 50, _=Depends(get_api_key)):
    # Menggunakan variabel LOG_FILE_PATH yang sudah didefinisikan di konfigurasi
    if not os.path.exists(LOG_FILE_PATH): 
        return {"content": [f"Log not found at {LOG_FILE_PATH}"]}
        
    try:
        with open(LOG_FILE_PATH, "r") as f:
            # Mengambil baris terakhir agar lebih efisien
            content = f.readlines()
            return {"content": [l.strip() for l in content[-lines:]]}
    except Exception as e:
        return {"content": [f"Error reading log: {str(e)}"]}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
