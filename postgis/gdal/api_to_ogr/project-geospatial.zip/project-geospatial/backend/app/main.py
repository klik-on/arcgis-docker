#!/usr/bin/env python3
import os
import sys
import logging
import pytz
import subprocess
import redis
import json
from datetime import datetime
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, Depends, HTTPException, Security, Query, Response
from fastapi.security import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import HTMLResponse, ORJSONResponse
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from celery import Celery
from celery.result import AsyncResult

# --- 1. CONFIGURATION & LOGGING ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("geo-api")

DATABASE_URL = os.getenv("DATABASE_URL")
if DATABASE_URL and DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)

API_KEY = os.getenv("API_KEY", "pgis-pass-2026")
REDIS_URL = os.getenv("REDIS_URL", "redis://geo-redis:6379/0")
ROOT_PATH = os.getenv("ROOT_PATH", "/datagis")
SCRIPTS_DIR = os.getenv("SCRIPTS_DIR", "/app/scripts")
LOG_FILE_PATH = os.getenv("LOG_FILE_PATH", "/app/data/sync.log")

jakarta_tz = pytz.timezone('Asia/Jakarta')

# --- 2. CACHE & TASK QUEUE ---
try:
    cache = redis.from_url(REDIS_URL, socket_timeout=5, decode_responses=False)
    logger.info("📡 Redis connected for MVT Caching")
except Exception as e:
    logger.error(f"❌ Redis connection failed: {e}")
    cache = None

celery_app = Celery("geo_tasks", broker=REDIS_URL, backend=REDIS_URL)

# --- 3. MODELS & SECURITY ---
class ScriptRequest(BaseModel):
    script_name: str
    args: List[str] = []
    env: Dict[str, Any] = {}

api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)

async def get_api_key(
    header_key: Optional[str] = Security(api_key_header),
    api_key: Optional[str] = Query(None)
):
    final_key = header_key or api_key
    if final_key == API_KEY:
        return final_key
    raise HTTPException(status_code=403, detail="Akses Ditolak: API Key tidak valid.")

# --- 4. APP INITIALIZATION ---
app = FastAPI(
    title="Analisis Spasial berbasis API",
    description="### Dashboard Monitoring IGT\nSpasial Analisis berbasis API.",
    version="1.9.0",
    root_path=ROOT_PATH,
    default_response_class=ORJSONResponse
)

app.add_middleware(
   CORSMiddleware,
   allow_origins=["*"],
   allow_methods=["*"],
   allow_headers=["*"]
)
app.add_middleware(GZipMiddleware, minimum_size=500)

engine = create_engine(
  DATABASE_URL,
  pool_size=30,
  max_overflow=60,
  pool_pre_ping=True)

# --- 5. UTILS ---
def run_health_check():
    script_path = os.path.join(SCRIPTS_DIR, "utils/health_check_gis.py")
    try:
        result = subprocess.run(["python3", script_path], capture_output=True, text=True, timeout=25, env=os.environ.copy())
        return (result.returncode == 0), result.stdout + result.stderr
    except Exception as e:
        return False, str(e)

def read_last_lines(file_path: str, count: int = 50) -> List[str]:
    """
    Membaca n baris terakhir dari file secara efisien tanpa memuat seluruh file ke memori.
    """
    if not os.path.exists(file_path):
        return ["Log file belum tersedia."]
    
    lines = []
    try:
        with open(file_path, 'rb') as f:
            # Pindah ke akhir file
            f.seek(0, os.SEEK_END)
            buffer = bytearray()
            pointer = f.tell()
            
            # Mundur ke belakang untuk mencari karakter newline
            while pointer > 0 and len(lines) < count:
                pointer -= 1
                f.seek(pointer)
                char = f.read(1)
                
                if char == b'\n' and buffer:
                    lines.append(buffer[::-1].decode('utf-8', errors='replace'))
                    buffer = bytearray()
                elif char != b'\n':
                    buffer.extend(char)
            
            # Tambahkan baris terakhir jika ada
            if buffer:
                lines.append(buffer[::-1].decode('utf-8', errors='replace'))
                
    except Exception as e:
        return [f"Error membaca log: {str(e)}"]
    
    return lines[::-1] # Kembalikan urutan agar kronologis (lama ke baru)

# --- 6. ENDPOINTS: SISTEM ---

@app.get("/", response_class=HTMLResponse, tags=["Sistem"])
async def dashboard_info(api_key: Optional[str] = Query(None)):
    is_healthy, status_output = run_health_check()
    status_color = "#10b981" if is_healthy else "#ef4444"
    return f"""
    <html><head><script src="https://cdn.tailwindcss.com"></script></head>
    <body class="bg-slate-950 text-slate-200 flex items-center justify-center min-h-screen p-4">
        <div class="max-w-3xl w-full bg-slate-900 border border-slate-800 rounded-[2rem] p-8 shadow-2xl">
            <h1 class="text-2xl font-black text-white mb-4 italic">GEOAPI <span class="text-emerald-500 underline">OPS CENTER</span></h1>
            <div class="mb-6 p-4 bg-black/40 rounded-xl border border-slate-800">
                <div class="flex items-center gap-2 mb-3">
                    <span class="relative flex h-3 w-3"><span class="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style="background-color: {status_color}"></span>
                    <span class="relative inline-flex rounded-full h-3 w-3" style="background-color: {status_color}"></span></span>
                    <span class="text-xs font-bold uppercase tracking-widest" style="color: {status_color}">SYSTEM STATUS</span>
                </div>
                <pre class="text-[11px] text-emerald-400 font-mono whitespace-pre-wrap leading-tight">{status_output}</pre>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <a href="{ROOT_PATH}/docs?api_key={api_key or ''}" class="bg-blue-600 hover:bg-blue-500 text-white text-center py-4 rounded-xl font-bold text-sm">Open API Docs</a>
                <a href="/flower" target="_blank" class="bg-slate-800 hover:bg-slate-700 text-emerald-500 text-center py-4 rounded-xl font-bold text-sm">Worker Monitor</a>
            </div>
        </div>
    </body></html>
    """

@app.get("/health", tags=["Sistem"], summary="Arsitektur Sistem")
def health():
    is_healthy, status_output = run_health_check()
    return {"status": "healthy" if is_healthy else "unhealthy", "details": {"audit_report": status_output.strip().split('\n')}}

# --- 7. LAYANAN DATA IGT ---

@app.get("/api/v1/layers/tree/igt", tags=["Layanan Data IGT"], summary="Struktur Dataset/Skema IGT")
async def list_layer_tree_igt(_=Depends(get_api_key)):
    query = text("SELECT schemaname, tablename FROM pg_tables WHERE schemaname NOT LIKE '%_3857' AND schemaname NOT IN ('information_schema', 'pg_catalog', 'topology') ORDER BY schemaname, tablename;")
    with engine.connect() as conn:
        result = conn.execute(query)
        tree = {}
        for row in result:
            s, t = row[0], row[1]
            if s not in tree: tree[s] = []
            tree[s].append(t)
        return {"status": "success", "repository": tree}

@app.get("/api/v1/IGT", tags=["Layanan Data IGT"])
async def ambil_data_igt(layer: str = Query(...), schema: str = Query("datagis"), limit: int = 100, offset: int = 0, _=Depends(get_api_key)):
    with engine.connect() as conn:
        sql = text(f'SELECT *, ST_AsGeoJSON(ST_Transform(geom, 4326), 6)::json as geometry_json FROM "{schema}"."{layer}" LIMIT :limit OFFSET :offset')
        result = conn.execute(sql, {"limit": limit, "offset": offset})
        return [dict(row._mapping) for row in result]


# --- 8. LAYANAN DATA MVT ---

@app.post("/api/v1/sync/optimize-layer", tags=["Layanan Data MVT"])
async def optimize_layer(layer: str = Query(...), source_schema: str = Query("datagis"), _=Depends(get_api_key)):
    # Menggunakan celery_app.send_task adalah cara paling aman 
    # untuk memicu task dari main app ke worker
    task = celery_app.send_task("optimize_geometry_task", args=[source_schema, layer])
    return {
        "task_id": task.id, 
        "status": "Optimization Queued",
        "detail": f"Proses optimasi {source_schema}.{layer} sedang berjalan di background."
    }

@app.get("/api/v1/mvt/{z}/{x}/{y}", tags=["Layanan Data MVT"])
async def get_mvt(z: int, x: int, y: int, layer: str = Query(...), schema: str = Query("datagis"), _=Depends(get_api_key)):
    # OTOMATISASI: Jika schema asal diminta, cek apakah ada versi optimasi (_3857)
    # Ini membuat frontend lebih mudah, cukup panggil layer, API cari yang tercepat
    target_schema = f"{schema.lower()}_3857" if "_3857" not in schema else schema
    
    cache_key = f"mvt:{target_schema}:{layer}:{z}:{x}:{y}"
    if cache:
        val = cache.get(cache_key)
        if val: return Response(content=val, media_type="application/x-protobuf", headers={"X-Cache": "HIT"})

    with engine.connect() as conn:
        # Cek apakah target_schema (versi 3857) ada, jika tidak balik ke schema asli
        check_opt = conn.execute(text("SELECT 1 FROM pg_namespace WHERE nspname = :s"), {"s": target_schema}).fetchone()
        active_schema = target_schema if check_opt else schema
        is_3857 = "_3857" in active_schema

        if is_3857:
            # Query Super Cepat (Data sudah 3857 dan punya GIST Index)
            sql = text(f"""
                WITH bounds AS (SELECT ST_TileEnvelope(:z, :x, :y) AS geom),
                mvtgeom AS (
                    SELECT ST_AsMVTGeom(t.geom, bounds.geom, 4096, 256, true) AS geom, t.* FROM "{active_schema}"."{layer}" t, bounds 
                    WHERE t.geom && bounds.geom
                ) 
                SELECT ST_AsMVT(mvtgeom, :layer) FROM mvtgeom;
            """)
        else:
            # Query Lambat (On-the-fly transform)
            sql = text(f"""
                WITH bounds AS (SELECT ST_TileEnvelope(:z, :x, :y) AS geom),
                mvtgeom AS (
                    SELECT ST_AsMVTGeom(ST_Transform(ST_MakeValid(t.geom), 3857), bounds.geom, 4096, 256, true) AS geom, t.* FROM "{active_schema}"."{layer}" t, bounds 
                    WHERE t.geom && ST_Transform(bounds.geom, 4326)
                ) 
                SELECT ST_AsMVT(mvtgeom, :layer) FROM mvtgeom;
            """)

        res = conn.execute(sql, {"z": z, "x": x, "y": y, "layer": layer}).fetchone()
        if not res or not res[0]: return Response(status_code=204)
        
        if cache: cache.setex(cache_key, 86400, res[0]) # Cache 24 jam
        return Response(content=bytes(res[0]), media_type="application/x-protobuf", headers={"X-Cache": "MISS"})

@app.get("/api/v1/layers/tree/mvt", tags=["Layanan Data MVT"])
async def list_layer_tree_mvt(_=Depends(get_api_key)):
    """
    Mengambil daftar semua Materialized View dan Tabel dari semua skema 
    yang berakhiran _3857 (datagis_3857, analisis_3857, dll).
    """
    # Gunakan escaping backslash '\' untuk underscore (_) agar akurat
    query = text("""
        SELECT schemaname, matviewname as tablename 
        FROM pg_matviews 
        WHERE schemaname LIKE '%\_3857'
        UNION ALL 
        SELECT schemaname, tablename 
        FROM pg_tables 
        WHERE schemaname LIKE '%\_3857'
        ORDER BY schemaname, tablename;
    """)
    
    try:
        with engine.connect() as conn:
            result = conn.execute(query)
            tree = {}
            for row in result:
                s, t = row[0], row[1]
                if s not in tree:
                    tree[s] = []
                tree[s].append(t)
            
            logger.info(f"MVT Tree discovered schemas: {list(tree.keys())}")
            return {
                "status": "success", 
                "repository": tree
            }
    except Exception as e:
        logger.error(f"Error building MVT tree: {e}")
        raise HTTPException(status_code=500, detail="Gagal mengambil struktur layer.")

@app.get("/api/v1/layers/bounds", tags=["Layanan Data MVT"])
async def get_layer_bounds(layer: str = Query(...), schema: str = Query("datagis"), _=Depends(get_api_key)):
    try:
        with engine.connect() as conn:
            # Query untuk mendapatkan bounding box layer dalam format GeoJSON / Array
            sql = text(f'SELECT ST_Extent(ST_Transform(geom, 4326)) as bbox FROM "{schema}"."{layer}"')
            res = conn.execute(sql).fetchone()
            return {"layer": layer, "bounds": res[0] if res else None}
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))


# --- 9. SINKRONISASI DATA ---
@app.get("/api/v1/sync/scripts-tree-text", tags=["Sinkronisasi Data"], summary="Struktur Skrip (Format Teks Tree)")
async def get_scripts_tree_text(_=Depends(get_api_key)):
    """
    Menampilkan struktur direktori folder scripts dalam format visual teks (seperti perintah tree).
    """
    allowed_extensions = {'.py', '.sh'}

    def generate_tree_text(path, prefix=""):
        items = sorted(os.listdir(path))
        # Filter item yang valid (file skrip atau direktori yang tidak kosong/relevan)
        entries = []
        for item in items:
            full_path = os.path.join(path, item)
            if os.path.isdir(full_path):
                # Cek apakah di dalam folder ada file relevan (opsional, agar folder kosong tidak tampil)
                entries.append(item)
            elif any(item.endswith(ext) for ext in allowed_extensions):
                entries.append(item)

        tree_str = ""
        for i, entry in enumerate(entries):
            is_last = (i == len(entries) - 1)
            connector = "└── " if is_last else "├── "
            
            tree_str += f"{prefix}{connector}{entry}\n"
            
            full_path = os.path.join(path, entry)
            if os.path.isdir(full_path):
                extension_prefix = "    " if is_last else "│   "
                tree_str += generate_tree_text(full_path, prefix + extension_prefix)
        
        return tree_str

    if not os.path.exists(SCRIPTS_DIR):
        return Response(content="Directory not found", media_type="text/plain")

    # Header nama root folder
    output = f". ({SCRIPTS_DIR})\n"
    output += generate_tree_text(SCRIPTS_DIR)
    
    return Response(content=output, media_type="text/plain")

@app.post("/api/v1/sync/run-script", tags=["Sinkronisasi Data"], summary="Jalankan Skrip Sinkronisasi")
async def trigger_sync(req: ScriptRequest, _=Depends(get_api_key)):
    task = celery_app.send_task("execute_geo_script", args=[req.script_name, req.args, req.env])
    return {"task_id": task.id, "status": "queued", "queued_at": datetime.now(jakarta_tz).isoformat()}

@app.get("/api/v1/sync/status/{task_id}", tags=["Sinkronisasi Data"], summary="Cek Status Antrean Task")
async def get_task_status(task_id: str, _=Depends(get_api_key)):
    res = AsyncResult(task_id, app=celery_app)
    return {"task_id": task_id, "status": res.status, "ready": res.ready(), "result": res.result}

@app.get("/api/v1/sync/logs", tags=["Sinkronisasi Data"], summary="Logs Aktivitas Proses (Real-time)")
async def get_logs(lines: int = Query(50, ge=1, le=500), _=Depends(get_api_key)):
    """
    Endpoint ini bisa dipanggil secara berkala (polling) oleh frontend 
    untuk menampilkan log saat skrip sinkronisasi sedang berjalan.
    """
    content = read_last_lines(LOG_FILE_PATH, lines)
    return {
        "content": content,
        "timestamp": datetime.now(jakarta_tz).isoformat(),
        "file_path": LOG_FILE_PATH
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
