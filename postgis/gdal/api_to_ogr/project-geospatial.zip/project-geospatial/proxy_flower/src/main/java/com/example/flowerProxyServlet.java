package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.net.*;
import java.util.*;

@WebServlet("/*")
public class flowerProxyServlet extends HttpServlet {

    private static String FLOWER_TARGET;

    @Override
    public void init() throws ServletException {
        super.init();
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            Properties prop = new Properties();
            if (input == null) throw new FileNotFoundException("config.properties not found");
            prop.load(input);

            String hostIp = prop.getProperty("flower.backend.ip", "172.16.2.122");
            FLOWER_TARGET = "http://" + hostIp + ":5555";
        } catch (IOException e) {
            throw new ServletException("Failed to load config", e);
        }
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pathInfo = request.getPathInfo();
        if (pathInfo == null) pathInfo = "/";

        // Pastikan URL target akurat
        String queryString = request.getQueryString();
        String targetUrlStr = FLOWER_TARGET + pathInfo + (queryString != null ? "?" + queryString : "");

        HttpURLConnection connection = null;
        try {
            URL url = new URL(targetUrlStr);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(request.getMethod());
            
            // Forward Headers
            Enumeration<String> hs = request.getHeaderNames();
            while (hs.hasMoreElements()) {
                String h = hs.nextElement();
                if (!h.equalsIgnoreCase("Host")) {
                    connection.setRequestProperty(h, request.getHeader(h));
                }
            }

            int code = connection.getResponseCode();
            response.setStatus(code);
            String contentType = connection.getContentType();
            if (contentType != null) response.setContentType(contentType);

            try (InputStream is = (code >= 400) ? connection.getErrorStream() : connection.getInputStream()) {
                if (is != null) {
                    if (contentType != null && contentType.contains("text/html")) {
                        // BACA HTML SEBAGAI STRING UNTUK PERBAIKAN PATH
                        String body = new String(is.readAllBytes(), "UTF-8");

                        // --- LOGIKA PERBAIKAN TAMPILAN (REWRITING) ---
                        
                        // 1. Tambahkan BASE TAG agar CSS/JS relatif ketemu
                        body = body.replace("<head>", "<head><base href=\"/flower/\">");

                        // 2. Perbaiki link statis yang pecah (menghindari double /flower)
                        body = body.replaceAll("href=\"/static", "href=\"/flower/static")
                                   .replaceAll("src=\"/static", "src=\"/flower/static")
                                   .replaceAll("href=\"/(?!flower)", "href=\"/flower/")
                                   .replaceAll("src=\"/(?!flower)", "src=\"/flower/");

                        // 3. Perbaiki variabel JavaScript internal Flower
                        body = body.replace("url_prefix = ''", "url_prefix = '/flower'")
                                   .replace("var url_prefix = \"\"", "var url_prefix = \"/flower\"");

                        response.getWriter().write(body);
                    } else {
                        // Kirim file CSS, JS, Image secara langsung tanpa modifikasi
                        is.transferTo(response.getOutputStream());
                    }
                }
            }
        } catch (Exception e) {
            response.sendError(502, "Flower Gateway Error: " + e.getMessage());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
