docker cp target/flower.war WEBADAPTOR:/usr/local/tomcat/webapps
docker exec WEBADAPTOR chown root:root /usr/local/tomcat/webapps/flower.war

docker exec WEBADAPTOR chown -R 1000:1000 /usr/local/tomcat/webapps/flower
docker exec WEBADAPTOR chmod -R 755 /usr/local/tomcat/webapps/flower
