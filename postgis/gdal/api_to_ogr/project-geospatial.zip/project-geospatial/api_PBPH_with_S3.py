import os
import sys
import time
import datetime
import zipfile
import requests
import pyproj
import boto3
import pandas as pd
import geopandas as gpd
from sqlalchemy import create_engine, text
from shapely.validation import make_valid
from shapely.geometry import MultiPolygon, Polygon, GeometryCollection
from botocore.client import Config
from botocore.exceptions import ClientError

# 1️⃣ INISIALISASI PROJ
os.environ['PROJ_LIB'] = pyproj.datadir.get_data_dir()

# =================================================================
# 2️⃣ KONFIGURASI
# =================================================================
IGT = os.getenv("IGT", "PERSETUJUAN_KOMITMEN_PBPH")
DATA_DIR = os.getenv("DATA_DIR", "/app/data")
DB_URL = os.getenv("DATABASE_URL")
DB_SCHEMA = os.getenv("DB_SCHEMA", "datagis")

S3_USER = os.getenv("S3_USER", "geobackup")
S3_PASS = os.getenv("S3_PASS", "minio-pass-2026")
S3_BUCKET = os.getenv("S3_BUCKET", "geospatial-bucket")
S3_ENDPOINT = os.getenv("S3_ENDPOINT", "http://s3-storage:9000")

ZIP_NAME = f"{IGT}.gdb.zip"
ZIP_PATH = os.path.join(DATA_DIR, ZIP_NAME)
REPORT_NAME = f"SUMMARY_{IGT}.txt"
REPORT_PATH = os.path.join(DATA_DIR, REPORT_NAME)
ENDPOINT = f"https://phl.kehutanan.go.id/api/v1/{IGT}?select=*"

# =================================================================
# 3️⃣ FUNGSI UTILITY
# =================================================================

def ensure_multipolygon(geom):
    if geom is None or geom.is_empty:
        return None
    if isinstance(geom, GeometryCollection):
        polys = [p for p in geom.geoms if isinstance(p, (Polygon, MultiPolygon))]
        if not polys: return None
        final_polys = []
        for p in polys:
            if isinstance(p, Polygon): final_polys.append(p)
            else: final_polys.extend(p.geoms)
        return MultiPolygon(final_polys)
    elif isinstance(geom, Polygon):
        return MultiPolygon([geom])
    elif isinstance(geom, MultiPolygon):
        return geom
    return None

def upload_to_s3_boto3(file_path, object_name):
    s3_client = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_USER,
                             aws_secret_access_key=S3_PASS, config=Config(signature_version='s3v4'))
    try:
        try:
            s3_client.head_bucket(Bucket=S3_BUCKET)
        except ClientError:
            s3_client.create_bucket(Bucket=S3_BUCKET)
        s3_client.upload_file(file_path, S3_BUCKET, object_name)
        return True
    except Exception as e:
        print(f"❌ S3 ERROR ({object_name}): {str(e)}")
        return False

# =================================================================
# 4️⃣ PROSES UTAMA
# =================================================================

def run_process():
    start_time = time.time()
    print(f"🚀 Memulai Integrasi API ke S3: {IGT}")

    try:
        auth = (os.getenv("PBPH_USER"), os.getenv("PBPH_PASS"))
        resp = requests.get(ENDPOINT, auth=auth, timeout=300)
        resp.raise_for_status()
        data = resp.json().get("data", [])
        if not data: 
            print("⚠️ API tidak mengembalikan data."); return

        df = pd.DataFrame(data)
        raw_count = len(df)
        geom_bytes = df.pop('geom').apply(lambda x: bytes.fromhex(x))
        geometry = gpd.GeoSeries.from_wkb(geom_bytes)
        gdf = gpd.GeoDataFrame(df, geometry=geometry, crs="EPSG:3857")
    except Exception as e:
        print(f"❌ API Error: {e}"); sys.exit(1)

    print(f"🧹 Validasi {len(gdf)} fitur...")
    gdf['geometry'] = gdf['geometry'].apply(lambda x: make_valid(x) if not x.is_valid else x)
    gdf['geometry'] = gdf['geometry'].apply(ensure_multipolygon)
    gdf = gdf[gdf.geometry.notnull()].copy()
    
    if gdf.crs != "EPSG:4326":
        gdf = gdf.to_crs("EPSG:4326")

    # --- 📐 HITUNG LUAS (Fixed Projection) ---
    # Menggunakan Proj4 String Cylindrical Equal Area untuk akurasi maksimal & kompatibilitas
    cea_proj4 = "+proj=cea +lat_ts=0 +lon_0=0 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs"
    gdf['LUAS_CEA_HA'] = gdf.to_crs(cea_proj4).area / 10000
    total_luas = gdf['LUAS_CEA_HA'].sum()
    valid_count = len(gdf)

    if not gdf.empty:
        print(f"🐘 Update PostGIS: {DB_SCHEMA}.{IGT}...")
        engine = create_engine(DB_URL)
        gdf.to_postgis(IGT, engine, schema=DB_SCHEMA, if_exists='replace', index=False, chunksize=1000)
        with engine.begin() as conn:
            conn.execute(text(f'CREATE INDEX IF NOT EXISTS "idx_{IGT.lower()}_geom" ON "{DB_SCHEMA}"."{IGT}" USING GIST (geometry)'))

    if not gdf.empty:
        # A. Create Summary Report
        print(f"📊 Generate Summary Report...")
        with open(REPORT_PATH, "w") as f:
            f.write(f"SUMMARY INTEGRASI IGT: {IGT}\n")
            f.write("="*60 + "\n")
            f.write(f"Tanggal Proses : {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Fitur dari API : {raw_count}\n")
            f.write(f"Fitur Valid    : {valid_count}\n")
            f.write(f"Total Luas (HA): {total_luas:,.2f} HA\n")
            f.write(f"Status Database: SUCCESS ({DB_SCHEMA}.{IGT})\n")
            f.write("-"*60 + "\n")
            cols_to_show = [c for c in gdf.columns if c != 'geometry']
            f.write(gdf[cols_to_show].head().to_string(index=False))

        # B. Export FileGDB
        print(f"💾 Export ke FileGDB...")
        gdb_dir = os.path.join(DATA_DIR, f"{IGT}.gdb")
        if os.path.exists(gdb_dir): shutil.rmtree(gdb_dir)
        gdf.to_file(gdb_dir, driver="OpenFileGDB", engine="pyogrio")

        with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(gdb_dir):
                for f in files:
                    z.write(os.path.join(root, f), os.path.join(f"{IGT}.gdb", f))
        
        shutil.rmtree(gdb_dir)

        # C. Upload ke S3
        s3_report_key = f"reports/{datetime.date.today()}/{REPORT_NAME}"
        upload_to_s3_boto3(ZIP_PATH, ZIP_NAME)
        upload_to_s3_boto3(REPORT_PATH, s3_report_key)

        for p in [ZIP_PATH, REPORT_PATH]:
            if os.path.exists(p): os.remove(p)
        print(f"✅ S3 Upload & Cleanup Selesai.")
    else:
        print("⚠️ No valid features.")

    print(f"🏁 SELESAI dalam {time.time() - start_time:.2f} detik.")

if __name__ == "__main__":
    import shutil
    run_process()
