#!/bin/bash

# ============================================================
# 1. KONFIGURASI
# ============================================================
ROOT_DIR="gateway-server"
APP_SERVER_IP="172.16.2.122"   # Server Backend (Target)
GATEWAY_IP="172.16.2.130"      # Server Gateway (Host ini)

# Kredensial Admin untuk Nginx Basic Auth
ADMIN_USER="flower"
ADMIN_PASS="flower-pass-2026"

echo "🚀 [$(date)] Updating Gateway with X-Forwarded-Prefix for MinIO..."

# Buat direktori kerja
mkdir -p $ROOT_DIR/nginx/conf.d

# --- GENERATE HT PASSWD (MD5 Method) ---
echo "🔑 Menggenerate file .htpasswd..."
ENCRYPTED_PASS=$(docker run --rm alpine sh -c "apk add --no-cache openssl > /dev/null && openssl passwd -apr1 '$ADMIN_PASS'")

if [ -z "$ENCRYPTED_PASS" ]; then
    echo "❌ Error: Gagal menggenerate password!"
    exit 1
fi

echo "$ADMIN_USER:$ENCRYPTED_PASS" > $ROOT_DIR/nginx/.htpasswd

# ============================================================
# 2. DOCKER COMPOSE GATEWAY
# ============================================================
cat <<EOF > $ROOT_DIR/docker-compose.yml
version: "3.9"
services:
  gateway:
    image: nginx:stable-alpine
    container_name: geo-gateway
    restart: unless-stopped
    ports:
      - "80:80"
    volumes:
      - ./nginx/conf.d/default.conf:/etc/nginx/conf.d/default.conf:ro
      - ./nginx/.htpasswd:/etc/nginx/.htpasswd:ro
    networks:
      geo-net:
        ipv4_address: 192.168.70.60

networks:
  geo-net:
    driver: bridge
    ipam:
      config:
        - subnet: 192.168.70.0/24
EOF

# ============================================================
# 3. NGINX CONFIGURATION (FIXED SUB-PATH ROUTING)
# ============================================================
cat <<EOF > $ROOT_DIR/nginx/conf.d/default.conf
server {
    listen 80;
    server_name $GATEWAY_IP;

    client_max_body_size 100M;
    proxy_buffering off;
    proxy_request_buffering off;

    # --- 1. FRONTEND (React) ---
    location / {
        proxy_pass http://$APP_SERVER_IP:3000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # --- 2. BACKEND API (FastAPI) ---
    location /api/v1 {
        proxy_pass http://$APP_SERVER_IP:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }

    # --- 3. DOKUMENTASI API (Swagger) ---
    location /datagis {
        rewrite ^/datagis/?$ /datagis/docs/ permanent;
        proxy_pass http://$APP_SERVER_IP:8000;
        proxy_set_header Host \$host;
        sub_filter '"/openapi.json"' '"/datagis/openapi.json"';
        sub_filter_once off;
        sub_filter_types text/html;
    }

    # --- 4. FLOWER MONITORING (PROTECTED) ---
    location /flower/ {
        auth_basic "Restricted Access - GIS Monitor";
        auth_basic_user_file /etc/nginx/.htpasswd;

        proxy_pass http://$APP_SERVER_IP:5555/flower/;
        proxy_set_header Host \$host;
        
        # Websocket Support
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    # --- 5. MINIO CONSOLE (PROTECTED - FIXED PATH PREFIX) ---
    location /geobackup/ {
        auth_basic "Restricted Access - Geo Storage";
        auth_basic_user_file /etc/nginx/.htpasswd;

        proxy_pass http://$APP_SERVER_IP:9005/;

        # Header Wajib agar UI tidak Blank/Grey
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        
        # Memberitahu MinIO bahwa ia berjalan di sub-path /geobackup
        proxy_set_header X-Forwarded-Prefix /geobackup;
        proxy_set_header X-NginX-Proxy true;

        # Support WebSocket
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";

        proxy_connect_timeout 300;
        proxy_redirect off;
        chunked_transfer_encoding off;
    }

    # --- 6. MINIO S3 API (UNPROTECTED) ---
    location /s3api/ {
        proxy_pass http://$APP_SERVER_IP:9000/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# ============================================================
# 4. EKSEKUSI
# ============================================================
cd $ROOT_DIR
echo "🔄 Me-restart gateway..."
docker-compose down || true
docker-compose up -d

echo "--------------------------------------------------------"
echo "✅ GATEWAY UPDATED DENGAN X-FORWARDED-PREFIX"
echo "🔗 MinIO Console: http://$GATEWAY_IP/geobackup/"
echo "--------------------------------------------------------"
