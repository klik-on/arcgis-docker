# PostgREST v12.0.3 + PostGIS + Docker Compose

## Struktur
- `Dockerfile` → build PostgREST v12.0.3 dari tarball
- `docker-compose.yml` → service `db` (PostGIS) dan `postgrest`
- `init.sql` → contoh tabel `items` dengan data geospasial
- `postgrest-v12.0.3-linux-static-x64.tar.xz` → **letakkan file ini di folder project sebelum build**

## Cara Jalankan

1. Download release binary [postgrest-v12.0.3-linux-static-x64.tar.xz](https://github.com/PostgREST/postgrest/releases/download/v12.0.3/postgrest-v12.0.3-linux-static-x64.tar.xz)
   dan taruh di folder project.

2. Build & run:
   ```bash
   docker compose up -d --build
   ```

3. Test API:
   ```bash
   curl http://localhost:3000/items
   ```

Akan muncul data JSON contoh dari tabel `items`.
