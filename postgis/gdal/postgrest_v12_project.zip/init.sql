-- Buat role anon
CREATE ROLE web_anon NOLOGIN;

-- Grant access ke schema public
GRANT USAGE ON SCHEMA public TO web_anon;

-- Buat tabel contoh dengan kolom geometri
CREATE TABLE items (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    geom geometry(Point, 4326),
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Tambahkan data contoh
INSERT INTO items (name, geom) VALUES
('Item A - Jakarta', ST_SetSRID(ST_MakePoint(106.8272, -6.1754), 4326)),
('Item B - Surabaya', ST_SetSRID(ST_MakePoint(112.7508, -7.2575), 4326)),
('Item C - Yogyakarta', ST_SetSRID(ST_MakePoint(110.3695, -7.8014), 4326));

-- Grant ke role anon
GRANT SELECT ON items TO web_anon;
